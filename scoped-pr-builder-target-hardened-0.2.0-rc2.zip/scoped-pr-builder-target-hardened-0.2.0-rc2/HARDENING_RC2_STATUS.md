# Scoped PR Builder 0.2.0rc2 Hardening Status

## Release posture

**Development/review RC:** GO with limitations.  
**Production 0.2.0:** NO-GO / BLOCKED.

RC2 is the comparative consolidation of the audited/fixed bundle and `0.2.0-rc1`. It is deliberately not promoted to final 0.2.0 because connected-forge identity/CI, strong sandbox execution, cryptographic release-readiness approval integration, semantic non-Python/JA frontends, external evaluation, and complete CI qualification still require proof.

## Hardening applied in RC2

- Clean pytest collection; donor redaction suites remain exercised through the existing vendored-wrapper integrity test rather than direct upstream imports.
- Exact positive-integer hard-cap validation for CAP-01/GRD-01 and all narrowing layers.
- Side-effect-safe Python import hygiene: no automatic removal without explicit reviewer/tool marker.
- Separate forge push and PR-create grants; exact pushed-commit acknowledgement.
- Exact-head required-check normalization across status/conclusion and fail-closed duplicate handling.
- Timezone-aware, SHA-256-backed verified identity validation.
- Full model SHA-256 pin, loopback endpoint rule, exact output schema, bounded evidence/rationale, finite confidence.
- Review-server host/body/nonce/route/cache/header hardening.
- Repository-native Python test discovery based on explicit runner evidence.
- CI updated to collect + run pytest, compile entry points, verify diff hygiene, build wheel, and smoke the console entry point.

## Local validation evidence

- Python compilation of `spb_cli.py`, all adapter modules, tools, and RC2 hardening tests: **PASS**.
- Focused changed-path regression run: **64 tests passed + 4 subtests passed**.
  - RC2 hardening tests
  - 0.2.0 upgrade tests
  - verification runner
  - approval adapter
  - release gate
- Additional impacted regression run: **34 tests passed + 86 subtests passed**.
  - patch generator
  - intent intake
  - guardrails
  - guardrail enforcement
  - security
- Default pytest discovery: **441 tests collected cleanly**.
- RC2 wheel build: **PASS** — `scoped_pr_builder_overlay-0.2.0rc2-py3-none-any.whl`, SHA-256 `e5edc04e9a682300ad8c0791603f03ff04b002ae6d871abe508da879e074717d`.
- Clean target install + actual generated `spb version` console script: **PASS**, output `0.2.0rc2`.
- Previous RC1 default pytest behavior: **FAIL at collection** on two direct vendored redaction test modules. This is fixed in RC2.

## Evidence not claimed

A complete 441-test local run is **not** recorded as PASS. The legacy suite contains Git/worktree-heavy scenarios and exceeded the available single local execution window. RC2 CI is configured to run the full suite with a bounded job timeout; final qualification must consume the real CI result, not this report.

## Remaining production blockers

See `MASTER_TODO.md`. The highest-priority blockers are:

- direct WF-01…12 orchestration and tamper-safe resume/status;
- qualification that always re-executes mandatory evidence;
- cryptographically verified release-readiness approvals and Ed25519 migration;
- live connected forge identity, draft PR, CODEOWNERS, branch protection and exact-head CI proof;
- native build/lint/typecheck mapping and strong sandbox execution;
- real pinned local-model runtime with metering;
- semantic TS/JS/Go/Rust frontends and JA compiler/authority cleanup;
- registry-growth guard;
- immutable external evaluation corpus with thresholds;
- full CI regression completion across supported Python/OS targets.
