# Scoped PR Builder Bundle Comparison and Consolidation Report

**Compared inputs**

- `scoped-pr-builder-target-audited-fixed(3).zip`
  - SHA-256: `706d48fe7c47f3e8ee684225328392af46b09a8697655573bf3e2959133d5d66`
  - ZIP bytes: 5,953,296
  - ZIP members: 1,158 total; 754 non-`.git` files
  - Embedded Git HEAD: `7a35c8b3c24deca93bc134b8d4f44cee8ba8a2ea`
  - Embedded working tree: 13 modified files + 1 untracked test relative to that HEAD
- `scoped-pr-builder-target-upgraded-0.2.0-rc1(1).zip`
  - SHA-256: `70c9452fdfc64aebac1782509a8e1dcacb62066a9457e3a8fcd20d9550e13c4d`
  - ZIP bytes: 1,889,079
  - ZIP members: 775 files; no embedded `.git` directory

## Executive conclusion

The `0.2.0-rc1` bundle is the stronger product baseline. It is a **strict content superset** of the audited/fixed bundle after `.git` metadata is excluded: all 754 audited/fixed non-Git files are present in RC1. Of those 754 common files, **742 are byte-identical and 12 are intentionally modified**. RC1 adds **21 new files** and removes no audited/fixed product file.

The audited/fixed bundle remains useful as a **development provenance source** because it contains the full Git history and exposes the exact pre-RC working-tree delta. That history should be retained separately, not shipped inside the product distribution. Shipping `.git` adds size, mutable repository state, hooks/config surface, and internal history that the runtime does not require.

Accordingly, the consolidated product uses RC1 as the functional baseline, preserves the audited/fixed comparison evidence, applies additional hardening, and is versioned **0.2.0rc2**. RC2 is an improved release candidate, **not a production 0.2.0 GO claim**.

## Structural comparison

| Dimension | Audited/fixed | 0.2.0-rc1 | Assessment |
|---|---:|---:|---|
| ZIP members | 1,158 | 775 | Audited bundle is larger primarily because it embeds `.git`. |
| Non-Git product files | 754 | 775 | RC1 adds 21 product files and removes none. |
| Common files | 754 | 754 | Complete baseline retention. |
| Common byte-identical | 742 | 742 | Most of the repository remains unchanged. |
| Common modified | 12 | 12 | Targeted productization/runtime changes. |
| RC-only files | 0 | 21 | Packaging, CI, adapters, docs, and upgrade tests. |
| Audited-only non-Git files | 0 | 0 | No product capability is lost by choosing RC1. |
| Embedded Git repository | Yes | No | Keep history as a separate development artifact, not in distributable ZIP. |
| Installable Python package | No root packaging metadata | Yes (`pyproject.toml`) | RC1 wins. |
| Root console entry point | No | Yes (`spb_cli.py` / `spb`) | RC1 wins. |
| CI workflow | No RC workflow | Yes | RC1 wins, with RC2 hardening. |
| Explicit upgrade ledger | No RC application report | Yes | RC1 wins on release transparency. |

## 21 files added by RC1

### Packaging and automation

1. `.github/workflows/tests.yml`
2. `pyproject.toml`
3. `spb_cli.py`
4. `CHANGELOG.md`

### Package/status/documentation

5. `Scoped PR Builder/__init__.py`
6. `Scoped PR Builder/tools/__init__.py`
7. `Scoped PR Builder/UPGRADE_APPLICATION_STATUS.md`
8. `Scoped PR Builder/docs/HOST_SECURITY_CONTRACT.md`

### New executable boundaries/adapters

9. `Scoped PR Builder/adapters/crypto_identity.py`
10. `Scoped PR Builder/adapters/findings.py`
11. `Scoped PR Builder/adapters/forge_adapter.py`
12. `Scoped PR Builder/adapters/hard_limits.py`
13. `Scoped PR Builder/adapters/identity.py`
14. `Scoped PR Builder/adapters/impact_graph.py`
15. `Scoped PR Builder/adapters/language_frontends.py`
16. `Scoped PR Builder/adapters/local_model_provider.py`
17. `Scoped PR Builder/adapters/review_server.py`
18. `Scoped PR Builder/adapters/sandbox_backend.py`
19. `Scoped PR Builder/adapters/smell_catalog.py`
20. `Scoped PR Builder/adapters/tool_discovery.py`

### Tests

21. `Scoped PR Builder/tests/test_upgrade_v020.py`

## 12 common files changed by RC1

| File | Main effect |
|---|---|
| `.gitignore` | Adds build/test/run cache hygiene. |
| `Scoped PR Builder/README.md` | Documents the RC1 executable candidate. |
| `adapters/approval_adapter.py` | Creates a real isolated `spb/...` branch and commit after approval. |
| `adapters/guardrails.py` | Makes suite binding context-aware and fixes declaration-diff false positives. |
| `adapters/intent_intake.py` | Sources hard caps from the guardrail registry instead of duplicated constants. |
| `adapters/patch_generator.py` | Adds deterministic hygiene recipes. |
| `adapters/release_gate.py` | Requires a human-channel readiness approval before minting a new GO record. |
| `adapters/verification_runner.py` | Adds corpus/generic profiles and repository-native test discovery. |
| `docs/LIMITATIONS_AND_NON_GOALS.md` | Reclassifies legacy empty-approval GO rows. |
| `release/LIMITATIONS.md` | Same release-classification correction at the release surface. |
| `tests/test_release_gate.py` | Tests the new GO approval requirement. |
| `tools/spb.py` | Adds `run`, `status`, `narrow`, profiles, and branch/commit reporting. |

## What RC1 materially improves

### Productization

RC1 can be built as a wheel and installed with a console entry point. It separates the source distribution from Git metadata, supplies a package version, and introduces CI discovery. This is a major step beyond an audited working tree that still depends on repository-local execution conventions.

### Generic-repository operation

The verification runner can operate in `generic` mode rather than forcing Suite 01–66 corpus cross-reference semantics onto foreign repositories. Repository-native tests become mandatory evidence in that profile, while corpus-only cross-reference becomes explicitly non-mandatory/indeterminate.

### Safer application semantics

Approved patches are applied in an isolated worktree, committed on an `spb/...` branch, and checked against the unchanged source worktree. The branch/commit are returned as evidence rather than treating an uncommitted detached tree as the final result.

### Better operator workflow

`spb run` composes the main slice through the human review boundary; `spb status` exposes current state/blocker; `spb narrow` supports shrink-only scope changes while archiving prior downstream state.

### Honest production posture

RC1 explicitly records that live forge/CI/identity, real local-model execution, strong sandboxing, JA semantic compilation, external evaluation, and several release gates remain incomplete. That is materially stronger than converting scaffolding into unsupported PASS claims.

## Problems found during the direct comparison/audit

The RC1 direction is stronger, but the audit found several concrete issues that should not be carried forward unchanged.

1. **Default pytest collection failure.** `pytest` collected copied donor redaction tests directly; those tests import upstream `redaction`, which is intentionally supplied only by the wrapper. Result: two collection errors. RC2 excludes the vendor subtree from direct pytest recursion while retaining the hash-bound wrapper test.
2. **Hard-cap parser accepted malformed policy shapes too loosely.** Recursive searching could select an unintended nested declaration, and effective caps silently ignored invalid values such as zero/negative/bool. RC2 validates the exact `parameters` fields and requires positive integers.
3. **AST “unused import” recipe could change semantics.** It could remove `from __future__ import annotations` or side-effect imports solely because no loaded `Name` was found. RC2 preserves all unmarked imports and requires an explicit `# spb: safe-remove-unused-import` marker for removal.
4. **Forge PR creation implicitly authorized a push.** A `pr.create` grant could trigger `client.push`, and a push response with no commit was accepted. RC2 requires a separate exact `forge.push` grant and exact pushed-commit acknowledgement.
5. **Required-check interpretation was too provider-specific.** GitHub-style `status=completed, conclusion=success` could be misclassified as pending. Duplicate same-name checks were silently collapsed. RC2 normalizes conclusion/status and fails closed on ambiguous duplicates.
6. **Identity expiry parsing was not fail-closed.** Malformed or timezone-naive timestamps could raise raw exceptions; evidence digests were not validated. RC2 requires timezone-aware expiry and a full SHA-256 evidence digest.
7. **Local-model boundary did not actually constrain endpoint/pin/schema enough.** Any nonempty digest was accepted, endpoint was descriptive only, and output field types were weak. RC2 requires a full SHA-256 pin, loopback HTTP(S) endpoint, exact proposal schema, bounded evidence/rationale, and finite confidence in `[0,1]`.
8. **Review server HTTP edge cases.** IPv6 Host parsing was broken; request bodies/nonces were unbounded; routes and caching/security headers were loose. RC2 adds bounded input, correct loopback Host parsing, route constraints, nonce cap, no-store and security headers.
9. **Tool discovery assumed any `pyproject.toml` implied pytest.** This could run the wrong test runner on a foreign repository and relied on executable lookup rather than the current Python environment. RC2 requires explicit pytest evidence and uses `sys.executable -m pytest`.
10. **Focused tests were green, but full-suite completion was not demonstrated locally.** RC1’s own report already stated this. RC2 fixes collection and configures CI to run the complete pytest suite, but the production gate must remain open until that CI run completes within budget.

## RC2 consolidation decision

The consolidated candidate therefore:

- starts from all 775 RC1 product files;
- carries forward every audited/fixed non-Git file;
- keeps `.git` history out of the distributable product;
- version-bumps to `0.2.0rc2`;
- applies the nine hardening corrections above;
- adds dedicated RC2 regression tests;
- adds this comparison report, a hardening status report, a machine-readable diff manifest, and a master TODO;
- keeps all environment-dependent production gates explicit and unresolved.

## Comparative verdict

- **Audited/fixed:** strongest as a provenance-bearing development snapshot, but not the best distributable product.
- **0.2.0-rc1:** strongest functional baseline and packaging direction, but still contains several correctness/security/test-discovery gaps.
- **0.2.0-rc2 hardened consolidation:** preferred product candidate for continued development and qualification.
- **Production 0.2.0:** **NO-GO** until the P0/P1 items in `MASTER_TODO.md` and the external qualification gates are satisfied.
