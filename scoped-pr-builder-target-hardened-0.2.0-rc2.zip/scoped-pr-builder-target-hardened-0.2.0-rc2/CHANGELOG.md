# Changelog

## 0.2.0-rc.2 — comparative hardening candidate

- Consolidated the audited/fixed baseline and 0.2.0-rc.1 upgrade into one release candidate.
- Fixed default pytest collection so vendored donor tests are exercised only through the hash-bound wrapper.
- Hardened hard-cap parsing/validation against malformed, boolean, zero, and negative policy values.
- Changed the Python unused-import recipe to remove only explicitly reviewer-marked imports, preserving side-effect and `__future__` imports by default.
- Split forge push authority from draft-PR creation authority and made push acknowledgement exact.
- Hardened required-check evaluation for GitHub-style `status`/`conclusion`, exact head binding, and ambiguous duplicate checks.
- Hardened verified-identity expiry/evidence validation and local-model loopback/schema/digest validation.
- Hardened the loopback review server with host parsing, request-size limits, nonce bounds, route constraints, and no-store/security headers.
- Made repository-native Python test discovery depend on explicit runner evidence rather than any `pyproject.toml`.
- Added RC2 hardening tests, comparison evidence, and a traceable master TODO.

## 0.2.0-rc.1 — upgrade candidate

- Added installable `spb` console entry point and clean CI discovery.
- Added generic verification profile and repository-native command discovery.
- Added deterministic hygiene recipes and isolated branch/commit support.
- Added one-shot `spb run` and read-only `spb status`.
- Added explicit optional boundaries for forge, identity, local model, language frontend, sandbox, Ed25519, findings and impact analysis.

This is a release candidate, not the final 0.2.0 production claim. External forge/CI/model/sandbox/JA/evaluation gates remain to be proven in their target environments.
