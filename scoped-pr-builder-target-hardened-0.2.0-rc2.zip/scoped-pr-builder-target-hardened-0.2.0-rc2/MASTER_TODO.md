# Scoped PR Builder Master TODO — Hardened Path to 0.2.0

**Baseline:** `0.2.0rc2` comparative hardening candidate  
**Target:** production `0.2.0`  
**Policy:** fail closed; no gate becomes PASS from documentation, archived evidence, model assertion, or an unexecuted test.

## Priority legend

- **P0** — release blocker for any production 0.2.0 claim.
- **P1** — required before connected/organization pilot or broad repository use.
- **P2** — scale, ergonomics, and post-core hardening.
- `[x]` — completed and locally evidenced in RC2.
- `[ ]` — open; acceptance evidence still required.

---

## Gate 00 — Comparative baseline, source integrity, and packaging hygiene

- [x] **SPB-M00-01 / P0 — Inventory both supplied bundles.** Record total/non-Git members, input SHA-256 digests, embedded Git state, and normalized tree comparison.
- [x] **SPB-M00-02 / P0 — Prove baseline retention.** Demonstrate that every audited/fixed non-Git file exists in RC1; record 742 identical, 12 modified, 21 added, 0 removed.
- [x] **SPB-M00-03 / P0 — Select canonical consolidation base.** Use RC1 as the product superset rather than attempting a lossy two-way merge.
- [x] **SPB-M00-04 / P1 — Remove `.git` from product distribution.** Preserve Git history as development provenance only; do not ship mutable repository internals in the runtime ZIP.
- [x] **SPB-M00-05 / P0 — Version-bump hardened candidate.** Set package/CLI candidate to `0.2.0rc2` and document the delta.
- [x] **SPB-M00-06 / P0 — Add comparison and hardening evidence.** Ship `BUNDLE_COMPARISON.md`, `HARDENING_RC2_STATUS.md`, `BUNDLE_DIFF_MANIFEST.json`, and this TODO.
- [ ] **SPB-M00-07 / P1 — Create a provenance-preserving development Git branch/tag for RC2.** Apply the consolidated tree atop the audited HEAD or a documented successor, commit it, and tag the exact RC2 source.
- [ ] **SPB-M00-08 / P1 — Generate release SBOM.** Produce CycloneDX or SPDX package/dependency inventory for the wheel/source ZIP and bind it to artifact hashes.
- [ ] **SPB-M00-09 / P1 — Sign release artifacts.** Use an organization-approved signing/attestation path; verify signatures in release CI.
- [ ] **SPB-M00-10 / P1 — Reproducible source package.** Two clean builds from the same commit/toolchain must produce identical normalized source contents and documented wheel reproducibility expectations.

**Gate 00 DoD:** canonical source/tag exists, distributable contains no `.git`, hashes/SBOM/signatures are bound to the release, and the supplied-bundle comparison remains reproducible.

---

## Gate 01 — Test system, CI, and installability

- [x] **SPB-M01-01 / P0 — Fix pytest collection.** Prevent direct collection of copied upstream redaction tests while retaining the hash-bound wrapper test.
- [x] **SPB-M01-02 / P0 — Prove clean collection.** `python -m pytest --collect-only -q` must collect the repository with zero errors; RC2 local evidence: 441 tests.
- [x] **SPB-M01-03 / P0 — Compile changed executable surfaces.** `py_compile` entry point, adapters, tools, and RC2 tests.
- [x] **SPB-M01-04 / P0 — Add CI full-suite + wheel smoke.** CI collects/runs pytest, checks diff hygiene, compiles, builds wheel, and executes `spb version`.
- [ ] **SPB-M01-05 / P0 — Obtain one complete clean CI PASS.** The entire collected suite must execute, not merely collect, within the job budget.
- [ ] **SPB-M01-06 / P0 — Eliminate archived-self-evidence from qualification.** Mandatory release tests must execute in the current run; skipped/archived rows cannot satisfy a gate.
- [ ] **SPB-M01-07 / P1 — Establish test runtime budget and shards.** Split Git/worktree-heavy, security/adversarial, workflow, and fast unit lanes; publish per-lane durations and timeout policy.
- [ ] **SPB-M01-08 / P1 — Python support matrix.** Run qualification on every claimed Python version (currently `>=3.11`) or narrow `requires-python` to what is actually proven.
- [ ] **SPB-M01-09 / P1 — Windows qualification.** Run install/CLI/worktree/path tests on Windows, including long-path-safe extraction and shell-free argv behavior.
- [ ] **SPB-M01-10 / P1 — Linux qualification.** Prove the default Linux profile, including sandbox-backend discovery and permissions.
- [ ] **SPB-M01-11 / P1 — Clean wheel install test.** Install the built wheel into an empty virtual environment and run version/help + generic foreign-repository smoke.
- [ ] **SPB-M01-12 / P1 — Build an sdist or explicitly declare wheel-only release policy.** Test whichever artifact classes are published.
- [ ] **SPB-M01-13 / P1 — Single-source version metadata.** Remove hard-coded version duplication between `pyproject.toml`, package `__version__`, and CLI output.
- [ ] **SPB-M01-14 / P1 — Normalize package imports.** Eliminate mixed `spb_overlay.*` and injected top-level `adapters`/`tools` namespaces so installed/source execution share one module identity.

**Gate 01 DoD:** full suite passes in CI on every claimed platform/runtime, clean wheel smoke succeeds, qualification consumes re-executed evidence, and version/import behavior is single-source.

---

## Gate 02 — Core orchestration, resume integrity, and state machine

- [ ] **SPB-M02-01 / P0 — Drive WF-01…12 directly from the product CLI.** `spb run` must use the authoritative workflow object/state machine rather than parallel file-existence composition.
- [ ] **SPB-M02-02 / P0 — Hash-validate every resumed artifact.** Before skipping a completed stage, revalidate binding/contract/candidate/report/card/receipt hashes and tenant/run identity.
- [ ] **SPB-M02-03 / P0 — Make `status` evidence-derived.** State may not be inferred from file presence alone; verify the latest artifact and report tamper/block reasons.
- [ ] **SPB-M02-04 / P0 — Fail closed on partial/corrupt run directories.** Define recovery for missing paired artifacts, truncated JSON/JSONL, stale hashes, and interrupted writes.
- [ ] **SPB-M02-05 / P1 — Atomic artifact writes.** Write temp + fsync/replace where applicable so a killed process cannot leave syntactically valid but incomplete state.
- [ ] **SPB-M02-06 / P1 — Hash-chain scope lineage.** `spb narrow` lineage must be tamper-evident and bound to parent/new scope hashes.
- [ ] **SPB-M02-07 / P1 — Prove narrow invalidation completeness.** Any scope change must invalidate every downstream plan/candidate/verification/review/approval artifact that depends on the old contract.
- [ ] **SPB-M02-08 / P1 — Define apply/archive lifecycle.** Specify whether isolated worktrees persist after apply, when they are removed, and how branch/commit evidence survives cleanup.
- [ ] **SPB-M02-09 / P1 — Idempotent/retry semantics.** Re-running each stage after success must either return the same content-addressed result or refuse with an explicit reason.
- [ ] **SPB-M02-10 / P1 — Crash/restart tests.** Inject interruption after every state write/effect boundary and prove deterministic safe recovery.

**Gate 02 DoD:** one authoritative workflow powers CLI execution, resume/status are cryptographically/evidentially validated, and crash/retry/narrow paths cannot reuse stale authority.

---

## Gate 03 — Scope policy and deterministic patch generation

- [x] **SPB-M03-01 / P0 — Centralize hard caps.** CAP-01 and GRD-01 are the executable source and must agree.
- [x] **SPB-M03-02 / P0 — Reject malformed/nonnumeric/zero/negative caps.** Narrowing layers accept positive integers only; booleans do not count as integers.
- [x] **SPB-M03-03 / P0 — Preserve side-effect imports by default.** `py_unused_imports` no longer treats AST non-use as proof of semantic removability.
- [ ] **SPB-M03-04 / P1 — Replace marked-unused-import bridge with a vetted semantic/linter recipe.** Integrate Ruff/another pinned tool in an opt-in host-tool profile and bind tool version/config/output to evidence.
- [ ] **SPB-M03-05 / P1 — Implement safe Python symbol rename.** AST/CST-based rename with import/reference coverage, scope proof, and semantic tests; no regex rename.
- [ ] **SPB-M03-06 / P1 — Add controlled host-tool recipes.** Ruff/ESLint/etc. must use registered argv templates and bounded recipe args; arbitrary model/shell strings remain forbidden.
- [ ] **SPB-M03-07 / P1 — Binary and encoding policy.** Detect binary, non-UTF-8, BOM, CRLF and generated files before recipe execution; preserve or explicitly refuse each class.
- [ ] **SPB-M03-08 / P1 — Symlink/reparse-point policy.** Prevent a scoped path from escaping repository roots through symlinks/junctions/worktree indirection.
- [ ] **SPB-M03-09 / P1 — Patch determinism test.** Same binding + scope + recipe + args must yield identical canonical patch bytes/hash across repeated runs on the same supported platform.
- [ ] **SPB-M03-10 / P1 — Recipe capability metadata.** Each recipe declares languages, file kinds, semantic risk, required tools, max file size, and whether human pre-authorization is needed.
- [ ] **SPB-M03-11 / P2 — Multi-file recipe transaction model.** Define atomic construction/verification when one scoped transformation legitimately spans several files.

**Gate 03 DoD:** every recipe has explicit semantics/capabilities, unsafe file types escape paths are refused, and deterministic recipes are proven repeatable.

---

## Gate 04 — Language frontends, impact analysis, and JA authority

- [ ] **SPB-M04-01 / P0 — Python semantic frontend becomes authoritative where claimed.** Record parser version, syntax failure, symbol/change schema, and test coverage.
- [ ] **SPB-M04-02 / P1 — Configure pinned Tree-sitter grammar for TypeScript/JavaScript.** Parse/symbol/rename/impact behavior must be tested against pinned grammar versions.
- [ ] **SPB-M04-03 / P1 — Configure pinned Go frontend.** Semantic parse/import/symbol/impact behavior with failure/indeterminate states.
- [ ] **SPB-M04-04 / P1 — Configure pinned Rust frontend.** Same requirements as Go.
- [ ] **SPB-M04-05 / P0 — Resolve JA-family semantic authority.** Integrate a real JA compiler/parser or remove/qualify every claim that implies semantic compilation.
- [ ] **SPB-M04-06 / P1 — Define unknown-language contract.** Unsupported files must remain `INDETERMINATE` and may not silently satisfy semantic gates.
- [ ] **SPB-M04-07 / P1 — Make impact graph resolve modules to repository paths.** Current import strings are not yet an authoritative dependency graph.
- [ ] **SPB-M04-08 / P1 — Represent dynamic/unknown edges.** `importlib`, plugin registries, build systems, reflection and generated code must conservatively widen tests or force indeterminate.
- [ ] **SPB-M04-09 / P1 — Cross-language impact.** Model package manifests/build graphs so Python/JS/Go/Rust changes can select relevant tests without under-testing.
- [ ] **SPB-M04-10 / P2 — Impact explainability.** Review card shows why each selected test/build/lint job is in scope and what unknowns forced fallback.

**Gate 04 DoD:** every supported language has a pinned semantic frontend or explicit indeterminate behavior; impact selection is conservative, explainable, and never reduces mandatory evidence unsafely.

---

## Gate 05 — Verification profile and strong sandbox execution

- [ ] **SPB-M05-01 / P0 — Execute repository-native build in generic profile when declared.** A Python syntax check alone cannot stand in for the project build.
- [ ] **SPB-M05-02 / P0 — Execute repository-native lint/typecheck when declared.** Map them to typed report jobs and define mandatory semantics.
- [ ] **SPB-M05-03 / P0 — Record every discovered-but-unavailable tool.** Tool missing must be visible and become FAIL/INDETERMINATE according to policy, never silently disappear.
- [ ] **SPB-M05-04 / P1 — Discovery precedence policy.** Define behavior for polyglot repos and multiple test runners; avoid duplicate/incompatible commands.
- [ ] **SPB-M05-05 / P0 — Wire a strong sandbox backend.** Bubblewrap/Docker discovery is not enough; actually execute verification under the selected backend.
- [ ] **SPB-M05-06 / P0 — Default network-off verification.** No target tests/build may reach the network unless a capability/profile explicitly permits it.
- [ ] **SPB-M05-07 / P0 — Read-only source + bounded writable workspace.** Mount/copy policy must prove tests cannot mutate source or unrelated host paths.
- [ ] **SPB-M05-08 / P0 — Resource limits.** CPU, memory, process count, file size, disk and wall-clock bounds with explicit timeout/OOM verdicts.
- [ ] **SPB-M05-09 / P1 — Environment scrub/allowlist.** Prevent ambient secrets/tokens/cloud credentials from entering untrusted target commands.
- [ ] **SPB-M05-10 / P1 — Per-command output limits.** Bound stdout/stderr capture and hash/store truncated evidence safely.
- [ ] **SPB-M05-11 / P1 — Strong-sandbox conformance tests.** Attempt filesystem escape, network access, fork bomb/process excess and env-secret access; expect refusal/containment.
- [ ] **SPB-M05-12 / P1 — Generic-profile foreign-repo matrix.** Test Python, npm, Go, Rust and mixed repos with passing/failing/missing-tool cases.

**Gate 05 DoD:** generic verification executes the repository’s real declared gates inside enforced containment and cannot mislabel a degraded process sandbox as strong isolation.

---

## Gate 06 — Human approval, identity, cryptography, and release authority

- [ ] **SPB-M06-01 / P0 — Cryptographically bind release-readiness approval.** `release_gate.record_decision` currently validates human-channel labels/rationale but does not consume a verified signed approval receipt. Replace label-only authority with verified receipt/identity evidence.
- [ ] **SPB-M06-02 / P0 — Migrate approval receipts to Ed25519 or an approved asymmetric scheme.** Keep HMAC only as an explicitly scoped local/air-gap compatibility mode if still needed.
- [ ] **SPB-M06-03 / P0 — Bind verified identity to each approval.** Issuer/subject/method/repository/evidence/expiry must be signed or otherwise provider-verified.
- [ ] **SPB-M06-04 / P0 — No self-approval in connected mode.** The author/automation principal that proposes/pushes the change cannot satisfy required human review unless policy explicitly allows it.
- [ ] **SPB-M06-05 / P1 — Key lifecycle.** Generation, storage, permissions, rotation, revocation, backup, expiry and compromised-key response.
- [ ] **SPB-M06-06 / P1 — Receipt version migration.** Old HMAC receipts remain readable but cannot accidentally satisfy a stronger connected release policy.
- [ ] **SPB-M06-07 / P1 — Clock-skew policy.** Define accepted skew for identity/grant/receipt timestamps and test malformed/naive/future/expired values.
- [ ] **SPB-M06-08 / P1 — Human review server end-to-end tests.** Approve/reject/narrow through HTTP, CSRF failure, replay, oversize form, external Host, IPv6 loopback, and missing key.
- [ ] **SPB-M06-09 / P1 — Release-scope taxonomy.** Replace temporary `pilot-sha256sums-only` hard-coding with explicit versioned release scopes and policy mapping.
- [ ] **SPB-M06-10 / P1 — Approval revocation/supersession.** Later rejection, scope change, candidate change, report change, identity expiry or policy change must invalidate old authority.

**Gate 06 DoD:** every repository/release effect is authorized by cryptographically verifiable current human identity/receipt evidence with explicit scope and revocation semantics.

---

## Gate 07 — Connected forge, CODEOWNERS, branch protection, and CI readiness

- [x] **SPB-M07-01 / P0 — Separate push and PR-create authority.** RC2 requires exact current `forge.push` and `pr.create` grants.
- [x] **SPB-M07-02 / P0 — Exact pushed-commit acknowledgement.** Missing/mismatched push commit evidence is refused.
- [x] **SPB-M07-03 / P0 — Exact-head required-check evaluation.** Normalize status/conclusion and fail closed on duplicate ambiguity.
- [ ] **SPB-M07-04 / P0 — Implement live GitHub provider.** GitHub App/OIDC or other approved credential path; no personal ambient token fallback.
- [ ] **SPB-M07-05 / P1 — Implement GitLab provider if claimed.** Same capability/grant semantics as GitHub.
- [ ] **SPB-M07-06 / P0 — Add explicit `ci_forge` environment profile.** Registry declares capabilities, network authority, identity, secrets and non-goals.
- [ ] **SPB-M07-07 / P0 — Live draft-PR proof.** Push exact approved commit, create draft only, record immutable PR/head identifiers, and prove no auto-merge.
- [ ] **SPB-M07-08 / P1 — Full CODEOWNERS semantics.** Replace conservative glob approximation with provider-compatible parsing/resolution and edge-case fixtures.
- [ ] **SPB-M07-09 / P1 — Pinned issue/PR intake.** Bind fetched content to provider repository, item id, immutable commit/ref/update identity and response hash; detect mutation between intake and apply.
- [ ] **SPB-M07-10 / P0 — Branch-protection contract.** Required reviews/checks, protected base, no force push, no bypass/self-approval, exact head SHA.
- [ ] **SPB-M07-11 / P0 — Draft-to-ready gate.** PR may become ready only after local approval, exact-head CI success, CODEOWNERS satisfaction and current identity/policy checks.
- [ ] **SPB-M07-12 / P1 — Retry/rate-limit/idempotency.** Provider retries cannot create duplicate PRs/reviewer requests or push a different head.
- [ ] **SPB-M07-13 / P1 — Connected-mode audit trail.** Record provider request/response identifiers without leaking credentials or sensitive headers.

**Gate 07 DoD:** a live provider pilot demonstrates least-privilege identity/grants, exact commit, draft-only creation, required reviewers/checks, branch protection, and auditable idempotent behavior.

---

## Gate 08 — Local model, findings, smell campaigns, and cost/accounting

- [x] **SPB-M08-01 / P0 — Full model digest pin.** RC2 requires a full SHA-256 model digest.
- [x] **SPB-M08-02 / P0 — Loopback endpoint contract.** RC2 refuses non-loopback model endpoints at this boundary.
- [x] **SPB-M08-03 / P0 — Exact proposal schema and confidence bounds.** Unknown/missing fields, invalid types and non-finite confidence are refused.
- [ ] **SPB-M08-04 / P1 — Integrate a real local runtime.** Prove Ollama/vLLM/other selected runtime with pinned model bytes/digest and no external fallback.
- [ ] **SPB-M08-05 / P1 — Transport endpoint enforcement.** The injected transport must be proven to honor the validated loopback endpoint rather than ignoring it.
- [ ] **SPB-M08-06 / P1 — Token/cost/resource meter.** Record prompt/output token estimates or provider counters, wall time, memory and per-run model budget.
- [ ] **SPB-M08-07 / P0 — Keep model non-authoritative.** Model may propose only registered recipes/args/evidence; it cannot mint scope, approval, verification, identity, forge grant or release authority.
- [ ] **SPB-M08-08 / P1 — Wire findings into intake.** Deterministic TODO/FIXME findings become evidence/proposals, not automatic scope authorization.
- [ ] **SPB-M08-09 / P1 — Bound findings scan.** Exclude build/vendor/large/binary/secret areas; cap files/bytes/findings and expose truncation as indeterminate.
- [ ] **SPB-M08-10 / P1 — Versioned smell catalog.** Each smell maps to a permitted recipe plus prerequisites/confidence/evidence; unknown smells abstain.
- [ ] **SPB-M08-11 / P1 — Serial campaign runner.** N-run smell campaigns remain one scoped PR per approved candidate, with bounded fan-out and independent review.
- [ ] **SPB-M08-12 / P2 — Campaign evaluation.** Measure precision, abstention, review acceptance, escaped regressions and rollback frequency.

**Gate 08 DoD:** a real pinned local model can assist proposal generation within strict non-authoritative boundaries, with metering and deterministic evidence paths.

---

## Gate 09 — Security architecture, observability, registry growth, and documentation

- [ ] **SPB-M09-01 / P0 — Update threat model for RC2.** Add forge push split, local model boundary, review server HTTP surface, tool discovery, package install and resume/tamper threats.
- [ ] **SPB-M09-02 / P0 — Host security contract conformance.** Explicitly test which guarantees are delegated to OS/container/credential manager and block profiles whose host prerequisites are absent.
- [ ] **SPB-M09-03 / P1 — Path traversal/archive safety.** Test malicious filenames, ZIP/tar traversal if supported, symlinks/junctions, case collisions and Windows reserved names.
- [ ] **SPB-M09-04 / P1 — Secret/PII output tests.** Redaction must cover logs, model output, forge metadata, test stdout/stderr and archived review artifacts without masking ordinary hashes.
- [ ] **SPB-M09-05 / P1 — Audit-chain completeness.** Every authority/effect transition writes a hash-chained typed row; verify no unchained lineage/decision side channel remains.
- [ ] **SPB-M09-06 / P1 — Registry-growth CI budget.** Enforce schema/version/duplicate/orphan/size budgets for component, contract, guardrail, threat, environment and documentation registries.
- [ ] **SPB-M09-07 / P1 — Structured observability.** Correlation/run/candidate/scope ids, duration, verdict, blocker and evidence hashes without sensitive payload leakage.
- [ ] **SPB-M09-08 / P1 — Documentation freshness automation.** Generated/declared docs must be regenerated or checked against current registries in CI.
- [ ] **SPB-M09-09 / P1 — Operator runbook for blocked states.** Exact remediation for tool missing, sandbox unavailable, stale identity, failed CI, reviewer missing, scope drift, tamper and rollback.
- [ ] **SPB-M09-10 / P2 — Performance budgets.** Repository scan, planning, patching, verification and review rendering budgets with large-repo fixtures.

**Gate 09 DoD:** security claims match enforced code/host prerequisites, audit coverage is complete, registries/docs cannot silently drift, and operator diagnostics are actionable.

---

## Gate 10 — External evaluation and final 0.2.0 release

- [ ] **SPB-M10-01 / P0 — Materialize immutable external corpus.** Select 5–10 public repositories across supported stacks; pin exact commits and licenses; store only permitted metadata/fixtures.
- [ ] **SPB-M10-02 / P0 — Define evaluation tasks.** Include successful bounded hygiene, intentional abstention, over-scope attempts, failing tests, missing tools, hostile repo content, large diffs and rollback.
- [ ] **SPB-M10-03 / P0 — Define quantitative release thresholds.** Scope escape rate, false PASS rate, test-detection rate, abstention correctness, patch determinism, source-tree preservation, rollback success, runtime budget.
- [ ] **SPB-M10-04 / P0 — Run evaluation from clean immutable environments.** No archived SPB evidence may satisfy external tasks.
- [ ] **SPB-M10-05 / P0 — Adversarial repository evaluation.** Prompt-injection text, malicious filenames, symlink escape, secret bait, fake evidence, test tampering, CODEOWNERS edge cases and model-output authority attacks.
- [ ] **SPB-M10-06 / P0 — Connected pilot.** At least one live draft PR reaches exact-head required-check readiness without bypassing human review/branch protection.
- [ ] **SPB-M10-07 / P0 — Strong sandbox pilot.** External project build/tests execute with network/host constraints demonstrably enforced.
- [ ] **SPB-M10-08 / P0 — Release-candidate full qualification.** All P0/P1 mandatory gates PASS on the exact final candidate commit/artifacts.
- [ ] **SPB-M10-09 / P0 — Final limitations review.** Every remaining non-goal/residual risk is published, current, and acceptable for the declared production scope.
- [ ] **SPB-M10-10 / P0 — Produce signed `0.2.0` artifacts.** Wheel/source bundle/SBOM/checksums/attestations/release notes are generated from the tagged commit.
- [ ] **SPB-M10-11 / P0 — Independent release approval.** Current verified human release authorities approve the exact artifact hashes and evaluation results.
- [ ] **SPB-M10-12 / P0 — Mint production GO only after all above evidence exists.** No manual override, model assertion, stale ledger row, or documentation-only claim can bypass the gate.

**Gate 10 DoD:** exact final artifacts pass immutable external, adversarial, connected and sandbox qualification; signed human release authority approves them; only then version `0.2.0` is GO.

---

# Master release rule

Production `0.2.0` is **BLOCKED** while any P0 item is open. Connected/organization pilot is **BLOCKED** while any P0 or required P1 item in Gates 05–07 is open. RC2 may be used for bounded local development/review with its documented degraded capabilities, but its incomplete boundaries must remain visibly `INDETERMINATE`, `PARTIAL`, or `BLOCKED` rather than being promoted by prose.
