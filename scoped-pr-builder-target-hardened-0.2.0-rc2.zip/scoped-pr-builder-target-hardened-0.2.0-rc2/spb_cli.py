"""Importable console-script shim for the historical `Scoped PR Builder/` overlay."""
from __future__ import annotations
import sys
from pathlib import Path
try:
    import spb_overlay
    OVERLAY = Path(spb_overlay.__file__).resolve().parent
except ImportError:
    OVERLAY = Path(__file__).resolve().parent / "Scoped PR Builder"
if str(OVERLAY) not in sys.path:
    sys.path.insert(0, str(OVERLAY))
from tools.spb import main  # noqa: E402
if __name__ == "__main__": raise SystemExit(main())
