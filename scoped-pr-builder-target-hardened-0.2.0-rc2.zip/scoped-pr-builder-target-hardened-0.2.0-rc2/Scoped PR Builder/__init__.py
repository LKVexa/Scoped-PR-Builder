"""Installable package marker for the historical Scoped PR Builder overlay."""
__version__ = "0.2.0rc2"
