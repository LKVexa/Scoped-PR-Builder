#!/usr/bin/env python3
"""spb — Scoped PR Builder pilot command line (reference executable path).

Each subcommand is added by the pilot slice item that introduces it; the CLI holds no
authority of its own and only composes the overlay adapters. All outputs are
deterministic JSON written to a run directory that MUST lie outside the bound
repository root (fail closed otherwise).

    spb bind <repo> <run_dir> [--revision REV]      # SLICE-02: Suite 40 records
    spb intent <repo> <run_dir> <intent.json>       # SLICE-03: scope contract (needs bind)
    spb plan <repo> <run_dir>                       # SLICE-04: Suite 51/Funnel evidence + plan (needs intent)
    spb patch <repo> <run_dir> --recipe NAME        # SLICE-05: inert bounded candidate patch (needs plan)
    spb verify <repo> <run_dir>                     # SLICE-06: isolated checks in a throwaway worktree (needs patch)
    spb review <repo> <run_dir>                     # SLICE-07: render review card + HTML (needs verify)
    spb approve <repo> <run_dir> --key K --decision D --approver ID --channel CH --rationale TEXT   # SLICE-08 (human)
    spb apply <repo> <run_dir> --key K [--receipt HASH]   # SLICE-08: revalidate + apply in an isolated worktree only
    spb archive <repo> <run_dir>                    # SLICE-09: content-addressed archive + chained state/audit ledgers
    spb rollback <repo> <run_dir> --key K           # SLICE-09: authorize rollback, execute it, record proof
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import approval_adapter as aa  # noqa: E402
from adapters import archive_adapter as ar  # noqa: E402
from adapters import evidence_retrieval as er  # noqa: E402
from adapters import intent_intake as ii  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import patch_generator as pg  # noqa: E402
from adapters import repository_context_adapter as rca  # noqa: E402
from adapters import review_renderer as rr  # noqa: E402
from adapters import review_surface as rs  # noqa: E402
from adapters import verification_runner as vr  # noqa: E402
from adapters import tool_discovery as td  # noqa: E402


def _load_binding(run_dir: Path) -> lga.RepositoryBinding:
    path = run_dir / "suite40" / "binding.json"
    if not path.is_file():
        raise lga.AdapterError("dependency.missing", "suite40/binding.json not found — run `spb bind` first (SLICE-02)")
    data = json.loads(path.read_text(encoding="utf-8"))
    binding = lga.RepositoryBinding(**data)
    lga.revalidate_binding(binding)  # freshness gate: HEAD and pinned tree must still match
    return binding


def _run_dir(repo: Path, run_dir: Path) -> Path:
    root = lga.canonical_root(repo)
    run_dir = run_dir.resolve()
    if run_dir == root or root in run_dir.parents:
        raise lga.AdapterError("run_dir.inside_repository", "run directory must be outside the bound repository")
    run_dir.mkdir(parents=True, exist_ok=True)
    return run_dir


def _write(path: Path, payload) -> str:
    data = (lga.canonical_json(payload) + "\n").encode("utf-8")
    lga.atomic_write_bytes(path, data)
    return lga.sha256_digest(data)


def cmd_bind(args: argparse.Namespace) -> int:
    run_dir = _run_dir(Path(args.repo), Path(args.run_dir))
    bundle = rca.build_context(Path(args.repo), args.revision)
    out = run_dir / "suite40"
    digests = {
        "binding.json": _write(out / "binding.json", bundle.binding),
        "context.json": _write(out / "context.json", bundle.context),
        "worktree.json": _write(out / "worktree.json", bundle.worktree),
        "freshness.json": _write(out / "freshness.json", bundle.freshness),
        "symbols.json": _write(out / "symbols.json", bundle.symbols),
        "dependencies.json": _write(out / "dependencies.json", bundle.dependencies),
    }
    receipt = {
        "step": "SLICE-02.bind",
        "adapter": f"{bundle.adapter_id}/{bundle.adapter_version}",
        "repository_id": bundle.binding["repository_id"],
        "worktree_id": bundle.binding["worktree_id"],
        "base_revision": bundle.binding["base_revision"],
        "source_snapshot_hash": bundle.binding["source_snapshot_hash"],
        "freshness_status": bundle.freshness["freshness_status"],
        "counts": {"files": bundle.context["file_count"], "symbols": len(bundle.symbols), "dependencies": len(bundle.dependencies)},
        "artifact_digests": digests,
        "bundle_hash": bundle.bundle_hash(),
    }
    _write(out / "RECEIPT.json", receipt)
    print(json.dumps(receipt, indent=2, sort_keys=True))
    return 0


def _load_contract(run_dir: Path) -> dict:
    path = run_dir / "intent" / "scope_contract.json"
    if not path.is_file():
        raise lga.AdapterError("dependency.missing", "intent/scope_contract.json not found — run `spb intent` first (SLICE-03)")
    contract = json.loads(path.read_text(encoding="utf-8"))
    ii.verify_contract_hash(contract)  # tamper gate
    return contract


def cmd_plan(args: argparse.Namespace) -> int:
    run_dir = _run_dir(Path(args.repo), Path(args.run_dir))
    binding = _load_binding(run_dir)
    contract = _load_contract(run_dir)
    bundle = er.retrieve_examples(binding, contract)
    plan = er.build_plan(contract, bundle)
    out51 = run_dir / "suite51"
    outp = run_dir / "plan"
    digests = {
        "evidence.json": _write(out51 / "evidence.json", bundle.evidence),
        "authority.json": _write(out51 / "authority.json", bundle.authority),
        "retrieval.json": _write(out51 / "retrieval.json", {k: v for k, v in json.loads(bundle.to_json()).items() if k not in ("evidence", "authority")}),
        "refactoring_plan.json": _write(outp / "refactoring_plan.json", plan),
    }
    receipt = {
        "step": "SLICE-04.plan",
        "retrieval_id": bundle.retrieval_id,
        "scope_contract_hash": contract["scope_contract_hash"],
        "corpus_size": bundle.corpus_size,
        "targets": [e["canonical_path"] for e in bundle.evidence if e["evidence_kind"] == "target_source"],
        "examples": [(e["canonical_path"], e["funnel"]["score"]) for e in bundle.evidence if e["evidence_kind"] == "analogous_example"],
        "plan_id": plan["plan_id"],
        "plan_hash": plan["plan_hash"],
        "plan_status": plan["status"],
        "abstain_reason": plan["abstain_reason"],
        "artifact_digests": digests,
    }
    _write(outp / "RECEIPT.json", receipt)
    print(json.dumps(receipt, indent=2, sort_keys=True))
    return 0


def _load_plan(run_dir: Path) -> dict:
    path = run_dir / "plan" / "refactoring_plan.json"
    if not path.is_file():
        raise lga.AdapterError("dependency.missing", "plan/refactoring_plan.json not found — run `spb plan` first (SLICE-04)")
    plan = json.loads(path.read_text(encoding="utf-8"))
    body = {k: v for k, v in plan.items() if k not in ("plan_hash", "created_at")}
    if lga.sha256_digest(lga.canonical_json(body)) != plan.get("plan_hash"):
        raise lga.AdapterError("plan.tampered", "plan_hash does not match plan content")
    return plan


def cmd_patch(args: argparse.Namespace) -> int:
    run_dir = _run_dir(Path(args.repo), Path(args.run_dir))
    binding = _load_binding(run_dir)
    contract = _load_contract(run_dir)
    plan = _load_plan(run_dir)
    cand, patch = pg.generate_candidate(binding, contract, plan, args.recipe)
    out = run_dir / "candidate"
    lga.atomic_write_bytes(out / "candidate.patch", patch)
    digests = {
        "candidate.patch": cand.patch_hash,
        "candidate.json": _write(out / "candidate.json", json.loads(cand.to_json())),
        "bounded_diff_plan.json": _write(out / "bounded_diff_plan.json", cand.bounded_diff_plan),
        "bounded_patch_plan.json": _write(out / "bounded_patch_plan.json", cand.bounded_patch_plan),
    }
    receipt = {
        "step": "SLICE-05.patch",
        "candidate_id": cand.candidate_id,
        "patch_hash": cand.patch_hash,
        "base_revision": cand.base_revision,
        "scope_contract_hash": cand.scope_contract_hash,
        "plan_hash": cand.plan_hash,
        "recipe": cand.recipe,
        "canonical_paths": list(cand.canonical_paths),
        "limit_profile": cand.limit_profile,
        "approval_state": cand.approval_state,
        "inert": cand.inert,
        "applied": False,
        "artifact_digests": digests,
    }
    _write(out / "RECEIPT.json", receipt)
    print(json.dumps(receipt, indent=2, sort_keys=True))
    return 0


def _load_candidate(run_dir: Path) -> tuple[dict, bytes]:
    cpath = run_dir / "candidate" / "candidate.json"
    ppath = run_dir / "candidate" / "candidate.patch"
    if not cpath.is_file() or not ppath.is_file():
        raise lga.AdapterError("dependency.missing", "candidate/candidate.json + candidate.patch not found — run `spb patch` first (SLICE-05)")
    candidate = json.loads(cpath.read_text(encoding="utf-8"))
    patch = ppath.read_bytes()
    pg.verify_candidate_hash(candidate, patch)  # tamper gate
    return candidate, patch


def cmd_verify(args: argparse.Namespace) -> int:
    run_dir = _run_dir(Path(args.repo), Path(args.run_dir))
    binding = _load_binding(run_dir)
    contract = _load_contract(run_dir)
    candidate, patch = _load_candidate(run_dir)
    report = vr.verify_candidate(binding, contract, candidate, patch, run_dir / "sandboxes", timeout=args.timeout, profile=getattr(args, "profile", "corpus"))
    out = run_dir / "verification"
    digests = {"report.json": _write(out / "report.json", json.loads(report.to_json()))}
    receipt = {
        "step": "SLICE-06.verify",
        "run_id": report.run_id,
        "candidate_id": report.candidate_id,
        "patch_hash": report.patch_hash,
        "verdict": report.verdict,
        "verification_profile": report.verification_profile,
        "checks": {j["check"]: j["verdict"] for j in report.jobs},
        "sandbox_destroyed": report.sandbox_destroyed,
        "source_tree_unchanged": report.source_tree_unchanged,
        "report_hash": report.report_hash,
        "artifact_digests": digests,
    }
    _write(out / "RECEIPT.json", receipt)
    print(json.dumps(receipt, indent=2, sort_keys=True))
    return 0 if report.verdict == "PASS" else 1


def _load_report(run_dir: Path) -> dict:
    path = run_dir / "verification" / "report.json"
    if not path.is_file():
        raise lga.AdapterError("dependency.missing", "verification/report.json not found — run `spb verify` first (SLICE-06)")
    report = json.loads(path.read_text(encoding="utf-8"))
    vr.verify_report_hash(report)  # tamper gate
    return report


def cmd_review(args: argparse.Namespace) -> int:
    run_dir = _run_dir(Path(args.repo), Path(args.run_dir))
    binding = _load_binding(run_dir)
    contract = _load_contract(run_dir)
    plan = _load_plan(run_dir)
    candidate, patch = _load_candidate(run_dir)
    report = _load_report(run_dir)
    evidence = json.loads((run_dir / "suite51" / "evidence.json").read_text(encoding="utf-8"))
    authority = json.loads((run_dir / "suite51" / "authority.json").read_text(encoding="utf-8"))
    card = rr.build_review_card(json.loads(binding.to_json()), contract, evidence, authority, plan, candidate, patch, report)
    page = rr.render_html(card)
    out = run_dir / "review"
    lga.atomic_write_bytes(out / "review.html", page.encode("utf-8"))
    digests = {"review_card.json": _write(out / "review_card.json", card), "review.html": lga.sha256_digest(page.encode("utf-8"))}
    receipt = {
        "step": "SLICE-07.review",
        "card_hash": card["card_hash"],
        "candidate_id": card["identity"]["candidate_id"],
        "verification_verdict": card["verification"]["verdict"],
        "blocking_risk": card["risk_summary"]["blocking_risk"],
        "preconditions": card["preconditions"],
        "authority": card["authority"],
        "artifact_digests": digests,
    }
    _write(out / "RECEIPT.json", receipt)
    print(json.dumps(receipt, indent=2, sort_keys=True))
    return 0


def _load_card(run_dir: Path) -> dict:
    path = run_dir / "review" / "review_card.json"
    if not path.is_file():
        raise lga.AdapterError("dependency.missing", "review/review_card.json not found — run `spb review` first (SLICE-07)")
    card = json.loads(path.read_text(encoding="utf-8"))
    body = {k: v for k, v in card.items() if k not in ("card_hash", "rendered_at")}
    if lga.sha256_digest(lga.canonical_json(body)) != card.get("card_hash"):
        raise lga.AdapterError("card.tampered", "card_hash does not match review card content")
    return card


def cmd_approve(args: argparse.Namespace) -> int:
    """Human-only: record a decision as a signed, chained, hash-bound receipt."""
    run_dir = _run_dir(Path(args.repo), Path(args.run_dir))
    candidate, patch = _load_candidate(run_dir)
    report = _load_report(run_dir)
    card = _load_card(run_dir)
    key = aa.load_or_create_key(Path(args.key), create=args.create_key)
    receipt = aa.issue_receipt(run_dir, key, decision=args.decision, approver_identity=args.approver, approver_channel=args.channel,
                               rationale=args.rationale, candidate=candidate, card=card, report=report, ttl_minutes=args.ttl_minutes)
    out = run_dir / "approvals"
    digest = _write(out / f"receipt-{receipt.receipt_hash[7:23]}.json", json.loads(receipt.to_json()))
    summary = {"step": "SLICE-08.approve", "decision": receipt.decision, "approver_identity": receipt.approver_identity, "approver_channel": receipt.approver_channel,
               "candidate_id": receipt.candidate_id, "patch_hash": receipt.patch_hash, "base_revision": receipt.base_revision, "scope_contract_hash": receipt.scope_contract_hash,
               "card_hash": receipt.card_hash, "verification_report_hash": receipt.verification_report_hash, "expires_at": receipt.expires_at,
               "receipt_hash": receipt.receipt_hash, "ledger_entries": len(aa.load_chain(run_dir)), "artifact_digests": {"receipt.json": digest}}
    _write(out / "RECEIPT.json", summary)
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


def _select_receipt(chain: list[dict], requested_hash: str | None) -> dict:
    """Select exactly the requested receipt; never substitute another authorization."""
    if not chain:
        raise lga.AdapterError("approval.missing", "no approval receipt exists for this candidate — a human must run `spb approve`")
    if requested_hash is None:
        return chain[-1]
    for receipt in chain:
        if receipt.get("receipt_hash") == requested_hash:
            return receipt
    raise lga.AdapterError("approval.receipt_not_found", f"requested approval receipt is not present in the signed ledger: {requested_hash}")


def cmd_apply(args: argparse.Namespace) -> int:
    run_dir = _run_dir(Path(args.repo), Path(args.run_dir))
    binding = _load_binding(run_dir)
    contract = _load_contract(run_dir)
    candidate, patch = _load_candidate(run_dir)
    report = _load_report(run_dir)
    card = _load_card(run_dir)
    key = aa.load_or_create_key(Path(args.key), create=False)
    chain = aa.verify_chain(run_dir, candidate["candidate_id"], key)
    receipt = _select_receipt(chain, args.receipt)
    rec = aa.apply_isolated(binding, contract, candidate, patch, report, card, receipt, key, run_dir, run_dir / "applied-worktrees")
    out = run_dir / "applied"
    digest = _write(out / "applied.json", json.loads(rec.to_json()))
    summary = {"step": "SLICE-08.apply", "candidate_id": rec.candidate_id, "receipt_hash": rec.receipt_hash, "applied_worktree": rec.applied_worktree,
               "changed_paths": list(rec.changed_paths), "post_apply_tree": rec.post_apply_tree, "source_tree_unchanged": rec.source_tree_unchanged,
               "branch_name": rec.branch_name, "commit_hash": rec.commit_hash, "record_hash": rec.record_hash, "artifact_digests": {"applied.json": digest}}
    _write(out / "RECEIPT.json", summary)
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


def cmd_archive(args: argparse.Namespace) -> int:
    run_dir = _run_dir(Path(args.repo), Path(args.run_dir))
    _load_binding(run_dir)
    summary = dict(ar.archive_run(run_dir), step="SLICE-09.archive")
    _write(run_dir / "archive" / "RECEIPT.json", summary)
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


def cmd_rollback(args: argparse.Namespace) -> int:
    run_dir = _run_dir(Path(args.repo), Path(args.run_dir))
    binding = _load_binding(run_dir)
    candidate, _patch = _load_candidate(run_dir)
    report = _load_report(run_dir)
    card = _load_card(run_dir)
    applied_path = run_dir / "applied" / "applied.json"
    if not applied_path.is_file():
        raise lga.AdapterError("dependency.missing", "applied/applied.json not found — run `spb apply` first")
    applied = json.loads(applied_path.read_text(encoding="utf-8"))
    key = aa.load_or_create_key(Path(args.key), create=False)
    chain = aa.verify_chain(run_dir, candidate["candidate_id"], key)
    receipt = _select_receipt(chain, applied.get("receipt_hash"))
    # Re-establish that the receipt cryptographically authorized this exact application.
    # Use the application timestamp so a later reviewer decision does not make cleanup impossible.
    from datetime import datetime
    try:
        applied_at = datetime.fromisoformat(str(applied["applied_at"]).replace("Z", "+00:00"))
    except (KeyError, ValueError) as exc:
        raise lga.AdapterError("applied.record_invalid", "applied_at is missing or malformed") from exc
    aa.verify_receipt(run_dir, key, receipt, candidate=candidate, card=card, report=report, now=applied_at)
    from adapters import security as sec
    sec.guard_write("rollback.execute", {"identity": receipt.get("approver_identity"), "channel": receipt.get("approver_channel")}, authorized_by=receipt, decision={"decision": "allow"}, run_dir=run_dir)
    record = ar.prove_rollback(run_dir, binding)
    summary = {"step": "SLICE-09.rollback", "verdict": record["verdict"], "rollback_id": record["rollback_id"], "from_version": record["from_version"], "to_version": record["to_version"],
               "after": record["after"], "artifact_digests": {"rollback.json": lga.sha256_digest((run_dir / "archive" / "rollback.json").read_bytes())}}
    _write(run_dir / "archive" / "ROLLBACK_RECEIPT.json", summary)
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0 if record["verdict"] == "PASS" else 1


def cmd_intent(args: argparse.Namespace) -> int:
    run_dir = _run_dir(Path(args.repo), Path(args.run_dir))
    binding = _load_binding(run_dir)
    intent_path = Path(args.intent)
    if not intent_path.is_file():
        raise lga.AdapterError("intent.file_missing", f"intent file not found: {intent_path}")
    try:
        payload = json.loads(intent_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise lga.AdapterError("intent.malformed", f"intent file is not valid JSON: {exc}") from exc
    contract = ii.accept_intent(payload, binding)
    out = run_dir / "intent"
    digest = _write(out / "scope_contract.json", json.loads(contract.to_json()))
    receipt = {
        "step": "SLICE-03.intent",
        "intent_id": contract.intent_id,
        "scope_contract_hash": contract.scope_contract_hash,
        "base_revision": contract.base_revision,
        "allowed_paths": list(contract.allowed_paths),
        "forbidden_paths": list(contract.forbidden_paths),
        "max_changed_files": contract.max_changed_files,
        "max_diff_lines": contract.max_diff_lines,
        "size_band_ceiling": contract.size_band_ceiling,
        "artifact_digests": {"scope_contract.json": digest},
    }
    _write(out / "RECEIPT.json", receipt)
    print(json.dumps(receipt, indent=2, sort_keys=True))
    return 0



def _state_from_run(run_dir: Path) -> dict:
    order=[("suite40/binding.json","BOUND"),("intent/scope_contract.json","INTENT_ACCEPTED"),("plan/refactoring_plan.json","PLANNED"),("candidate/candidate.json","PATCH_INERT"),("verification/report.json","VERIFIED"),("review/review_card.json","REVIEW_PENDING"),("applied/applied.json","APPLIED_ISOLATED"),("archive/RECEIPT.json","ARCHIVED")]
    state="INTAKE"; latest=None
    for rel,st in order:
        if (run_dir/rel).is_file(): state=st; latest=rel
    blocker=None; unblocker=None
    if state=="REVIEW_PENDING": blocker="human approval required"; unblocker="run `spb approve`, then `spb apply`"
    elif state=="PATCH_INERT": blocker="verification not completed"; unblocker="run `spb verify`"
    elif state=="VERIFIED": blocker="review artifact not rendered"; unblocker="run `spb review`"
    return {"state":state,"latest_artifact":latest,"blocking_reason":blocker,"unblocker":unblocker}


def cmd_status(args: argparse.Namespace) -> int:
    run_dir=Path(args.run_dir).resolve()
    if not run_dir.is_dir(): raise lga.AdapterError("status.run_missing", f"run directory not found: {run_dir}")
    result={"run_dir":str(run_dir), **_state_from_run(run_dir)}
    print(json.dumps(result, indent=2 if not args.json else None, sort_keys=True))
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    # One product entry point; it composes the exact same slice functions so each adapter remains independently debuggable.
    ns=lambda **kw: argparse.Namespace(**kw)
    repo=args.repo; rd=args.run_dir
    if not (Path(rd)/"suite40"/"binding.json").is_file(): cmd_bind(ns(repo=repo,run_dir=rd,revision=args.revision))
    if not (Path(rd)/"intent"/"scope_contract.json").is_file(): cmd_intent(ns(repo=repo,run_dir=rd,intent=args.intent))
    if not (Path(rd)/"plan"/"refactoring_plan.json").is_file(): cmd_plan(ns(repo=repo,run_dir=rd))
    if not (Path(rd)/"candidate"/"candidate.json").is_file(): cmd_patch(ns(repo=repo,run_dir=rd,recipe=args.recipe))
    if not (Path(rd)/"verification"/"report.json").is_file(): cmd_verify(ns(repo=repo,run_dir=rd,timeout=args.timeout,profile=args.profile))
    if not (Path(rd)/"review"/"review_card.json").is_file(): cmd_review(ns(repo=repo,run_dir=rd))
    result={"status":"REVIEW_PENDING", "run_dir":str(Path(rd).resolve()), **_state_from_run(Path(rd))}
    print(json.dumps(result, indent=2, sort_keys=True))
    return 3


def cmd_narrow(args: argparse.Namespace) -> int:
    run_dir=_run_dir(Path(args.repo),Path(args.run_dir)); binding=_load_binding(run_dir); contract=_load_contract(run_dir)
    if (run_dir/'applied'/'applied.json').is_file(): raise lga.AdapterError('review.scope_after_apply','cannot narrow a run after application; start a new run')
    paths=[x.strip() for x in args.allowed_paths.split(',') if x.strip()]
    rerun=rs.narrow_scope(contract,allowed_paths=paths,max_changed_files=args.max_changed_files,max_diff_lines=args.max_diff_lines,title=args.title,description=args.description)
    new=ii.accept_intent(rerun['intent'],binding); oldhash=contract['scope_contract_hash']; newhash=new.scope_contract_hash
    hist=run_dir/'history'/oldhash[7:19]; hist.mkdir(parents=True,exist_ok=True)
    import shutil
    for name in ('intent','plan','candidate','verification','review','approvals'):
        src=run_dir/name
        if src.exists():
            dst=hist/name
            if dst.exists(): shutil.rmtree(dst)
            shutil.copytree(src,dst)
            if name!='intent': shutil.rmtree(src)
    _write(run_dir/'intent'/'scope_contract.json',json.loads(new.to_json()))
    lineage={'action':'narrow_scope','parent_scope_contract_hash':oldhash,'scope_contract_hash':newhash,'allowed_paths':list(new.allowed_paths),'max_changed_files':new.max_changed_files,'max_diff_lines':new.max_diff_lines,'history':str(hist)}
    lp=run_dir/'review'/'scope_lineage.jsonl'; lp.parent.mkdir(parents=True,exist_ok=True)
    with lp.open('a',encoding='utf-8') as fh: fh.write(lga.canonical_json(lineage)+'\n')
    print(json.dumps(lineage,indent=2,sort_keys=True)); return 0


def cmd_version(args: argparse.Namespace) -> int:
    print('0.2.0rc2'); return 0

def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="spb")
    sub = p.add_subparsers(dest="cmd", required=True)
    ver = sub.add_parser("version", help="print package version")
    ver.set_defaults(func=cmd_version)
    nar = sub.add_parser("narrow", help="shrink allowed_paths/limits in the same run lineage and invalidate downstream artifacts")
    nar.add_argument("repo")
    nar.add_argument("run_dir")
    nar.add_argument("--allowed-paths", required=True, help="comma-separated subset of the current allowed paths")
    nar.add_argument("--max-changed-files", type=int)
    nar.add_argument("--max-diff-lines", type=int)
    nar.add_argument("--title")
    nar.add_argument("--description")
    nar.set_defaults(func=cmd_narrow)
    run = sub.add_parser("run", help="one-shot bind → intent → plan → patch → verify → review; stops at human approval")
    run.add_argument("repo")
    run.add_argument("run_dir")
    run.add_argument("--intent", required=True)
    run.add_argument("--recipe", required=True)
    run.add_argument("--revision", default="HEAD")
    run.add_argument("--profile", choices=vr.VERIFICATION_PROFILES, default="generic")
    run.add_argument("--timeout", type=int, default=vr.DEFAULT_TIMEOUT)
    run.set_defaults(func=cmd_run)
    st = sub.add_parser("status", help="read-only operator view of run state and unblocker")
    st.add_argument("run_dir")
    st.add_argument("--json", action="store_true")
    st.set_defaults(func=cmd_status)
    b = sub.add_parser("bind", help="bind a repository at a revision and emit Suite 40 records")
    b.add_argument("repo")
    b.add_argument("run_dir")
    b.add_argument("--revision", default="HEAD")
    b.set_defaults(func=cmd_bind)
    i = sub.add_parser("intent", help="accept one narrow refactor intent and mint its scope contract")
    i.add_argument("repo")
    i.add_argument("run_dir")
    i.add_argument("intent")
    i.set_defaults(func=cmd_intent)
    pl = sub.add_parser("plan", help="retrieve analogous local evidence (Suite 51/Funnel) and derive an advisory plan")
    pl.add_argument("repo")
    pl.add_argument("run_dir")
    pl.set_defaults(func=cmd_plan)
    pa = sub.add_parser("patch", help="generate ONE inert bounded candidate patch (never applied here)")
    pa.add_argument("repo")
    pa.add_argument("run_dir")
    pa.add_argument("--recipe", required=True)
    pa.set_defaults(func=cmd_patch)
    v = sub.add_parser("verify", help="run isolated applicability/build/test/lint/xref checks in a throwaway worktree")
    v.add_argument("repo")
    v.add_argument("run_dir")
    v.add_argument("--timeout", type=int, default=vr.DEFAULT_TIMEOUT)
    v.add_argument("--profile", choices=vr.VERIFICATION_PROFILES, default="corpus")
    v.set_defaults(func=cmd_verify)
    rv = sub.add_parser("review", help="render the human review card (JSON) and page (HTML); display-only")
    rv.add_argument("repo")
    rv.add_argument("run_dir")
    rv.set_defaults(func=cmd_review)
    ap = sub.add_parser("approve", help="HUMAN ONLY: record an approval decision as a signed hash-bound receipt")
    ap.add_argument("repo")
    ap.add_argument("run_dir")
    ap.add_argument("--key", required=True, help="path to the approval signing key (outside the run directory)")
    ap.add_argument("--create-key", action="store_true", help="create the signing key if absent (first use)")
    ap.add_argument("--decision", required=True, choices=aa.DECISIONS)
    ap.add_argument("--approver", required=True)
    ap.add_argument("--channel", required=True)
    ap.add_argument("--rationale", required=True)
    ap.add_argument("--ttl-minutes", type=int, default=aa.DEFAULT_TTL_MINUTES)
    ap.set_defaults(func=cmd_approve)
    app = sub.add_parser("apply", help="revalidate everything, then apply the approved candidate in an isolated worktree only")
    app.add_argument("repo")
    app.add_argument("run_dir")
    app.add_argument("--key", required=True)
    app.add_argument("--receipt", default=None, help="receipt_hash to use (default: latest ledger entry)")
    app.set_defaults(func=cmd_apply)
    arc = sub.add_parser("archive", help="archive state/provenance/audit receipts (content-addressed, chained)")
    arc.add_argument("repo")
    arc.add_argument("run_dir")
    arc.set_defaults(func=cmd_archive)
    rb = sub.add_parser("rollback", help="authorize and execute the declared rollback, then record the proof")
    rb.add_argument("repo")
    rb.add_argument("run_dir")
    rb.add_argument("--key", required=True, help="approval signing key used to verify the receipt that authorized the application")
    rb.set_defaults(func=cmd_rollback)
    args = p.parse_args(argv)
    try:
        return args.func(args)
    except lga.AdapterError as exc:
        print(json.dumps({"status": "BLOCKED", "code": exc.code, "message": str(exc)}, sort_keys=True), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
