#!/usr/bin/env python3
"""Behavioral regression check REG-01 (VERIFY-07-T02): every ``<sha256>  <name>`` line of a SHA256SUMS manifest must name
a sibling file whose digest matches. Exit 0 when every line holds, 1 on any mismatch or missing file, 2 when the manifest
itself is unreadable or malformed. Diagnostics go to stdout (one line per finding); nothing is modified."""
from __future__ import annotations

import hashlib
import re
import sys
from pathlib import Path

LINE = re.compile(r"^([0-9a-f]{64})  (\S.*)$")


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: check_sha256sums.py <path/to/SHA256SUMS.txt>")
        return 2
    manifest = Path(argv[1])
    if not manifest.is_file():
        print(f"{manifest}: manifest not found")
        return 2
    base = manifest.parent
    bad = 0
    checked = 0
    for n, raw in enumerate(manifest.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
        if not raw.strip():
            continue
        m = LINE.match(raw)
        if not m:
            print(f"{manifest}:{n}: malformed line")
            return 2
        digest, name = m.groups()
        target = base / name
        if not target.is_file():
            print(f"{manifest}:{n}: {name}: file missing")
            bad += 1
            continue
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        checked += 1
        if actual != digest:
            print(f"{manifest}:{n}: {name}: digest mismatch (manifest {digest[:12]}…, file {actual[:12]}…)")
            bad += 1
    print(f"{manifest}: {checked} digest(s) checked, {bad} finding(s)")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
