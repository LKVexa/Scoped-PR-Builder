# Test / evidence ledger

`TEST_LEDGER.jsonl` is the hash-chained record of Phase 01 scenario results (`tests/test_phase01_e2e.py`),
one row per scenario: scenario id, kind (boundary_e2e / control_e2e / api_contract), verdict, the repository
revision under test, and the digest of the assertion set. Rows are appended with the same chain primitive as
the run audit ledger and verified by `tests/evidence_ledger.verify`.

Regenerate (append-only) with:

    SPB_EVIDENCE_LEDGER="Scoped PR Builder/evidence/TEST_LEDGER.jsonl" python3 "Scoped PR Builder/tests/test_phase01_e2e.py"

Without `SPB_EVIDENCE_LEDGER` the suite writes a run-local ledger under the system temp directory and never
touches the repository.

Phase 04 (DATA-*-T05) appends `intake_fixture` rows — one per source per fixture case (authorized success, access
denied, stale revision, partial history, conflicting evidence; NOT_APPLICABLE rows carry their stated reason):

    SPB_EVIDENCE_LEDGER="Scoped PR Builder/evidence/TEST_LEDGER.jsonl" python3 "Scoped PR Builder/tests/test_intake_fixtures.py"

Phase 05 (COMP-*-T05) appends `component_evidence` rows — per component: unit, integration, replay (same pinned inputs →
same output hash) and every declared negative case (refusal code, no output), plus the COMP-11 rollback proof:

    SPB_EVIDENCE_LEDGER="Scoped PR Builder/evidence/TEST_LEDGER.jsonl" python3 "Scoped PR Builder/tests/test_components_replay.py"

Phase 06 (WF-*-T05) appends `workflow_integration` rows — per workflow step: the passing attempt (evidence, run state),
the unreachable-until-success check, the failing instance (injected failure kind, outcome, route, replay) and retries:

    SPB_EVIDENCE_LEDGER="Scoped PR Builder/evidence/TEST_LEDGER.jsonl" python3 "Scoped PR Builder/tests/test_workflow_integration.py"

Phase 07 (STORE-*-T05) appends `store_integrity` rows — per store: bound from a real run, create/read/replay, conflicting
write, partial write, retention/deletion, tamper attempt and recovery (heads, material hashes, refusal codes, verdicts):

    SPB_EVIDENCE_LEDGER="Scoped PR Builder/evidence/TEST_LEDGER.jsonl" python3 "Scoped PR Builder/tests/test_store_integrity.py"


Phase 08 (VERIFY-*-T05) appends `verification_gate` rows — per check: passing fixture, deterministic failure fixture
(reasons, failing jobs, exit codes, stderr digests, authorized worktree untouched), stale/mismatched evidence (gate
decisions), plus the workflow-level proofs that approval is unreachable over a failing candidate or stale results:

    SPB_EVIDENCE_LEDGER="Scoped PR Builder/evidence/TEST_LEDGER.jsonl" python3 "Scoped PR Builder/tests/test_verification_gates.py"

Phase 09 (SEC-*-T04) appends `security_adversarial` rows — per threat: the attempt at the control's suite boundary and the
attempt at the effect boundary (fail closed, no unauthorized effect, complete denial/evidence trail), recorded under
`security:<threat>:<case>@<threat-core-hash prefix>`; the Phase 09 release gate (`adapters/security.release_gate`) consumes
exactly these rows, so they must be refreshed whenever `security/THREATS.json`'s threat core changes:

    SPB_EVIDENCE_LEDGER="Scoped PR Builder/evidence/TEST_LEDGER.jsonl" python3 "Scoped PR Builder/tests/test_security_adversarial.py"

Phase 10 (MODEL-01-T04) declared a new SEC-01 deny code (`security.sec01.model_minting_attempt`), which changes the threat
core hash; the `security_adversarial` rows were refreshed with the command above so the release gate stays current. Phase 10
(MODEL-*-T05) appends `model_evaluation` rows — per condition: grounded success, hallucination, overreach, stale context,
fabricated evidence, unsupported confidence and permission escalation, each on its declared route (accept / abstain / human
review; never repair), recorded under `model:<condition>:<case>@<provider-contract-hash prefix>`:

    SPB_EVIDENCE_LEDGER="Scoped PR Builder/evidence/TEST_LEDGER.jsonl" python3 "Scoped PR Builder/tests/test_model_evaluation.py"

Phase 11 (HUMAN-*-T05) appends `review_e2e` rows — per reviewer behavior: the rendered surface passes the structural
accessibility audit, the reviewer performs the action as a typed command, and the audit trail captures exactly what was
shown and decided, recorded under `review:<behavior>:<case>@<review-registry-hash prefix>`:

    SPB_EVIDENCE_LEDGER="Scoped PR Builder/evidence/TEST_LEDGER.jsonl" python3 "Scoped PR Builder/tests/test_review_e2e.py"

Phase 12 (TEST-*-T05) appends `qualification_scenario` rows — one per matrix scenario (unit, integration, adversarial and
end-to-end), each recorded under `qualification:<scenario>@<matrix-hash prefix>` with the dimensions it asserted, its
environment hash and its replay id. The offline gate (`adapters/qualification.offline_gate`) consumes exactly these rows,
so they must be refreshed whenever `qualification/MATRIX.json` changes:

    SPB_EVIDENCE_LEDGER="Scoped PR Builder/evidence/TEST_LEDGER.jsonl" python3 "Scoped PR Builder/tests/test_qualification.py"

Phase 13 (X*-T05) appends `invariant_compliance` rows — one per platform invariant, recorded under
`invariant:<id>@<invariants-hash prefix>` with the result, the authoritative enforcement point behind it, whether it is
deferred to the host, its readiness-checklist item and the hash of the `invariant_result` record it came from. The
readiness checklist (`adapters/invariants.require_invariants`) blocks the production-readiness receipt while any
invariant is violated, indeterminate or unevaluated, so these rows must be refreshed whenever
`invariants/INVARIANTS.json` changes:

    SPB_EVIDENCE_LEDGER="Scoped PR Builder/evidence/TEST_LEDGER.jsonl" python3 -m unittest test_invariants

A `deferred` result is archived PASS because it is honestly recorded as a host requirement, never because the property
holds here: XSEC-04 (encryption in transit and at rest) is the one invariant this tool does not implement, and it
appears on the checklist as a HOST REQUIREMENT naming what the host must provide.

Phase 14 (ENV-*-T05) appends `environment_smoke` rows — one per deployment environment, recorded under
`environment:<id>@<profile-hash prefix>` with the posture, the seven smoke checks, the promotion criteria the run
demonstrated and the profile hash it was judged against. A compatibility receipt is bound to these rows, so they must
be refreshed whenever `environments/ENVIRONMENTS.json` changes:

    SPB_EVIDENCE_LEDGER="Scoped PR Builder/evidence/TEST_LEDGER.jsonl" python3 -m unittest test_environments

Phase 15 (PROD-*-T05) appends one `limitations_published` row — recorded under
`limitations:published@<readiness-hash prefix>` with the document hash and the limitation ids it publishes. The
release gate reads it for PROD-08, and it binds to the readiness registry, so declaring a new release-gate assertion
without republishing the limitations makes it stale and blocks the gate:

    python3 -c "import sys; sys.path.insert(0,'Scoped PR Builder'); from adapters import release_gate as R; R.publish_limitations()"
    SPB_EVIDENCE_LEDGER="Scoped PR Builder/evidence/TEST_LEDGER.jsonl" python3 -m unittest test_release_gate

Phase 15 also refreshed the `security_adversarial` and `environment_smoke` receipts, which the release gate had
correctly reported as stale: both were bound to registries that later phases changed. That refresh is what the
gate's own remediation list prescribed, and it is the intended workflow rather than an exception to it.

Phase 16 (DOC-*-T05) appends twelve `documentation_freshness` rows — one per generated document, recorded under
`documentation:<DOC-NN>@<docs-registry hash prefix>` with the document hash, the digest of the sources it was
generated from, and the release assertion it serves. Every PROD assertion now selects documentation evidence, so a
document that stops describing the implementation blocks the release gate rather than merely being out of date:

    python3 -c "import sys; sys.path.insert(0,'Scoped PR Builder'); from adapters import documentation as D; D.publish_all()"
    SPB_EVIDENCE_LEDGER="Scoped PR Builder/evidence/TEST_LEDGER.jsonl" python3 -m unittest test_documentation

Adding those selectors changes the readiness registry, which makes the published-limitations receipt stale. The gate
reports it, `release_gate.publish_limitations` republishes, and `test_release_gate` re-issues the receipt. That
cascade is the binding working, not an exception to it.
