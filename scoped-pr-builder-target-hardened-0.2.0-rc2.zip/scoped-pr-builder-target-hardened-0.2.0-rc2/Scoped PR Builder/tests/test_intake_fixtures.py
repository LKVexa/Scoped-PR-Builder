"""Intake fixture coverage (Phase 04 / DATA-*-T05; stdlib unittest), driven by tests/scenarios/intake.json.

For every declared source the five fixture cases run against real temporary repositories: authorized success,
access denied, stale revision, partial history (a shallow clone) and conflicting evidence. Each case lands in its
expected intake state, routes to proceed/abstain/review explicitly, and leaves one chained receipt on the
test/evidence ledger (``SPB_EVIDENCE_LEDGER``; run-local otherwise). A case a source cannot exhibit is recorded as
NOT_APPLICABLE with the stated reason — never silently skipped.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import evidence_ledger as EL  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import intake as I  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from test_intake import _git, make_repo  # noqa: E402

SCENARIOS = HERE / "scenarios" / "intake.json"
READ = ["repository.read"]
FIXTURES = {
    "default": lambda base: make_repo(base),
    "conflicting_manifests": lambda base: make_repo(base, conflicting_manifests=True),
    "duplicate_pr_ids": lambda base: make_repo(base, duplicate_exports=True),
    "duplicate_issue_ids": lambda base: make_repo(base, duplicate_exports=True),
    "duplicate_adr_numbers": lambda base: make_repo(base, conflicting_adrs=True),
    "two_owner_files": lambda base: make_repo(base, owners=2),
}


def shallow_clone(root: Path, dst: Path) -> Path:
    subprocess.run(["git", "clone", "-q", "--depth", "1", f"file://{root}", str(dst)], check=True, capture_output=True, text=True)
    return dst


class TestIntakeFixtures(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.sources = I.load_sources()
        self.scen = json.loads(SCENARIOS.read_text(encoding="utf-8")).get("scenarios", {}) if SCENARIOS.is_file() else {}
        if not self.scen:
            self.skipTest("no intake fixture scenarios yet")

    def _admit(self, sid, root, granted=READ, binding=None):
        return I.admit(sid, binding or lga.bind_repository(root), granted_effects=granted, sources=self.sources, registry=self.reg)

    def _run_case(self, sid, case, spec, tmp):
        base = Path(tmp) / case
        if case == "authorized_success":
            return self._admit(sid, FIXTURES[spec.get("fixture", "default")](base))
        if case == "access_denied":
            return self._admit(sid, FIXTURES[spec.get("fixture", "default")](base), granted=list(spec.get("granted_effects", [])))
        if case == "stale_revision":
            root = FIXTURES[spec.get("fixture", "default")](base)
            binding = lga.bind_repository(root)
            (root / "src" / "app.py").write_text("def main():\n    return 99\n"); _git(root, "add", "-A"); _git(root, "commit", "-q", "-m", "moved after bind")
            return self._admit(sid, root, binding=binding)
        if case == "partial_history":
            root = FIXTURES[spec.get("fixture", "default")](base)
            return self._admit(sid, shallow_clone(root, base / "shallow"))
        if case == "conflicting_evidence":
            return self._admit(sid, FIXTURES[spec["fixture"]](base))
        raise AssertionError(f"unknown case {case}")

    def _receipt(self, sid, case, spec, rec):
        r = I.route(rec)
        body = {"source_id": sid, "case": case, "expected": spec["expect"], "state": rec["state"], "reason": rec["reason"], "route": r["route"], "may_infer": r["may_infer"],
                "intake_hash": rec["intake_hash"], "counts": rec["counts"], "freshness": rec["freshness"]["status"], "pinned": "pin" in rec, "base_revision": rec["base_revision"],
                "items_present": bool(rec["items"]), "provenance_on_items": all("provenance_ref" in i for i in rec["items"]) if rec["items"] else None}
        return EL.record(f"intake:{sid}:{case}", "intake_fixture", "PASS", body)

    def test_fixture_cases_land_in_their_states_with_receipts(self) -> None:
        rows = 0
        for scen_id, sc in sorted(self.scen.items()):
            sid = sc["source_id"]
            for case, spec in sc["cases"].items():
                with self.subTest(scenario=scen_id, case=case), tempfile.TemporaryDirectory() as tmp:
                    if spec.get("expect") is None:
                        EL.record(f"intake:{sid}:{case}", "intake_fixture", "NOT_APPLICABLE", {"source_id": sid, "case": case, "note": spec["note"]}); rows += 1
                        continue
                    rec = self._run_case(sid, case, spec, tmp)
                    self.assertEqual(rec["state"], spec["expect"], f"{sid}/{case}: {rec['reason']}")
                    if rec["state"] == "ADMITTED":
                        self.assertTrue(rec["items"]); self.assertTrue(all(i["provenance_ref"] == rec["pin"]["pin_hash"] for i in rec["items"]))
                        self.assertEqual(I.route(rec)["route"], "proceed")
                    else:
                        self.assertIn(I.route(rec)["route"], ("abstain", "review")); self.assertTrue(rec["reason"])
                        if rec["state"] in ("DENIED", "STALE", "UNAVAILABLE", "MALFORMED", "OVERSIZED"):
                            self.assertEqual(rec["items"], [], "nothing is carried for a source that was not read, moved, or could not be normalized")
                        with self.assertRaises(lga.AdapterError):  # PARTIAL/CONFLICTING material is shown to the reviewer but never derived from
                            I.derive(rec, rec["items"][0] if rec["items"] else {}, "index_entry", {})
                    if case == "access_denied":
                        self.assertEqual(rec["freshness"]["status"], "unchecked", "a denied scope must read nothing, not even freshness")
                    self._receipt(sid, case, spec, rec); rows += 1
        self.assertGreaterEqual(EL.verify(), rows)

    def test_scenarios_declare_every_case_and_receipt_requirements(self) -> None:
        for scen_id, sc in self.scen.items():
            with self.subTest(scenario=scen_id):
                self.assertIn(sc["source_id"], self.sources["sources"])
                self.assertEqual(set(sc["cases"]), {"authorized_success", "access_denied", "stale_revision", "partial_history", "conflicting_evidence"})
                for case, spec in sc["cases"].items():
                    self.assertTrue(spec.get("expect") in I.STATES or spec.get("note"), f"{scen_id}/{case}: expectation or note required")
                self.assertTrue(sc["receipt_requirements"])


if __name__ == "__main__":
    unittest.main()
