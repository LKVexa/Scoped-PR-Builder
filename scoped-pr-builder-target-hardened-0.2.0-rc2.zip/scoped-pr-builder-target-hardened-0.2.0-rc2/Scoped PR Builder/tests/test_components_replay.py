"""Component evidence suite (Phase 05 / COMP-*-T05; stdlib unittest), driven by tests/scenarios/components.json.

For every declared component scenario: a unit check of its output, an integration check against the upstream
artifacts it consumed, a replay (the same pinned inputs invoked twice yield the same output hash) and named negative
cases that must refuse with the declared code. Every case leaves one chained receipt on the test/evidence ledger
(``SPB_EVIDENCE_LEDGER``; run-local otherwise) binding the outcome to the exact input identities and output hash.
"""
from __future__ import annotations

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import evidence_ledger as EL  # noqa: E402
from adapters import approval_adapter as aa  # noqa: E402
from adapters import archive_adapter as ar  # noqa: E402
from adapters import components as K  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from test_components import ALL, READ, Pipeline, _git  # noqa: E402

SCENARIOS = HERE / "scenarios" / "components.json"


def _w(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(lga.canonical_json(payload) + "\n", encoding="utf-8")


class TestComponentEvidence(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.comps = K.load_components(registry=self.reg)
        self.scen = json.loads(SCENARIOS.read_text(encoding="utf-8")).get("scenarios", {}) if SCENARIOS.is_file() else {}
        if not self.scen:
            self.skipTest("no component scenarios yet")
        self.tmp = tempfile.TemporaryDirectory()
        self.p = Pipeline(Path(self.tmp.name), self.comps, self.reg)
        self.rows = 0

    def tearDown(self) -> None:
        self.tmp.cleanup()

    # ---- receipts ---------------------------------------------------------------------------------------------
    def _receipt(self, cid: str, case: str, verdict: str, body: dict) -> None:
        EL.record(f"component:{cid}:{case}", "component_evidence", verdict, {"component_id": cid, "case": case, "base_revision": self.p.binding.base_revision, "source_snapshot_hash": self.p.binding.source_snapshot_hash, **body})
        self.rows += 1

    # ---- unit / integration checks per component --------------------------------------------------------------
    def _unit(self, cid: str, r: K.ComponentResult) -> dict:
        o = r.outputs
        checks = {
            "COMP-01": lambda: {"symbols": o["symbol_index"]["symbol_count"], "ok": o["symbol_index"]["symbol_count"] >= 66 and o["symbol_index"]["parse_errors"] == 0},
            "COMP-02": lambda: {"edges": o["code_graph"]["edge_count"], "ok": o["code_graph"]["edge_count"] > 0 and o["code_graph"]["call_edges"] >= 1},
            "COMP-03": lambda: {"status": o["dependency_graph"]["build_order_status"], "ok": o["dependency_graph"]["build_order_status"] in ("acyclic", "cyclic") and bool(o["dependency_graph"]["gaps"])},
            "COMP-04": lambda: {"examples": o["convention_profile"]["example_count"], "ok": o["convention_profile"]["example_count"] >= 1 and o["convention_profile"]["confidence"] in ("low", "medium", "high")},
            "COMP-05": lambda: {"risk": o["impact_report"]["risk_band"], "ok": o["impact_report"]["changed_paths"] == ["Suite04/SHA256SUMS.txt"] and o["impact_report"]["authority"] == "advisory_only"},
            "COMP-06": lambda: {"status": o["refactoring_plan"]["status"], "ok": o["refactoring_plan"]["status"] == "PLANNED" and o["refactoring_plan"]["authority"] == "advisory_only"},
            "COMP-07": lambda: {"lines": o["candidate"]["lines_added"] + o["candidate"]["lines_deleted"], "ok": o["candidate"]["inert"] and o["candidate"]["files_changed"] == 1},
            "COMP-08": lambda: {"verdict": o["verification_report"]["verdict"], "ok": o["verification_report"]["verdict"] == "PASS" and o["verification_report"]["source_tree_unchanged"]},
            "COMP-09": lambda: {"verdict": o["governor_decision"]["verdict"], "ok": o["governor_decision"]["verdict"] == "ALLOW" and o["governor_decision"]["confinement"]["within_scope"]},
            "COMP-10": lambda: {"gate": o["approval_gate"]["state"], "ok": o["approval_gate"]["state"] == "PENDING_HUMAN" and o["review_card"]["authority"] == "display_only"},
            "COMP-11": lambda: {"checkpoint": o["checkpoint"]["checkpoint_id"][:23], "ok": o["checkpoint"]["source_tree_identity"] == self.p.binding.source_snapshot_hash},
        }
        return checks[cid]()

    def _integration(self, cid: str, r: K.ComponentResult) -> dict:
        o, out = r.outputs, self.p.out
        links = {
            "COMP-01": lambda: o["dependency_records"]["index_id"] == o["symbol_index"]["index_id"],
            "COMP-02": lambda: o["code_graph"]["derived_from"]["index_hash"] == out("COMP-01", "symbol_index")["index_hash"],
            "COMP-03": lambda: o["dependency_graph"]["derived_from"]["records_hash"] == out("COMP-01", "dependency_records")["records_hash"],
            "COMP-04": lambda: o["convention_profile"]["index_id"] == out("COMP-01", "symbol_index")["index_id"] and o["convention_profile"]["scope_contract_hash"] == self.p.contract["scope_contract_hash"],
            "COMP-05": lambda: o["impact_report"]["derived_from"]["graph_id"] == out("COMP-02", "code_graph")["graph_id"] and o["impact_report"]["candidate_id"] == out("COMP-07", "candidate")["candidate_id"],
            "COMP-06": lambda: o["refactoring_plan"]["retrieval_id"] == out("COMP-04", "evidence_bundle")["retrieval_id"] and o["refactoring_plan"]["conventions_guidance"]["profile_hash"] == out("COMP-04", "convention_profile")["profile_hash"],
            "COMP-07": lambda: o["candidate"]["plan_hash"] == out("COMP-06", "refactoring_plan")["plan_hash"],
            "COMP-08": lambda: o["verification_report"]["candidate_id"] == out("COMP-07", "candidate")["candidate_id"] and o["test_selection"]["impact_hash"] == out("COMP-05", "impact_report")["impact_hash"],
            "COMP-09": lambda: o["governor_decision"]["candidate_id"] == out("COMP-07", "candidate")["candidate_id"],
            "COMP-10": lambda: o["review_card"]["impact"]["impact_hash"] == out("COMP-05", "impact_report")["impact_hash"] and o["approval_gate"]["card_hash"] == o["review_card"]["card_hash"],
            "COMP-11": lambda: o["checkpoint"]["base_revision"] == self.p.binding.base_revision,
        }
        return {"linked_to_upstream": bool(links[cid]())}

    # ---- negative cases ---------------------------------------------------------------------------------------
    def _negative(self, cid: str, case: str):
        p = self.p
        base = p.inputs_for(cid)
        if case == "undeclared_input":
            return dict(base, not_declared=1), ALL
        if case == "capability_missing":
            return base, []
        if case == "gate_bypass":
            return dict(base, auto_approve=True), ALL
        if case == "scope_widening":
            if cid == "COMP-07":
                plan = copy.deepcopy(base["refactoring_plan"]); plan["operations"][0]["path"] = "Suite05/05_demo.jad"
                return dict(base, refactoring_plan=plan), ALL
            return dict(base, candidate=dict(p.out("COMP-07", "candidate"), canonical_paths=["Suite05/05_demo.jad"]), scope_contract=p.contract), ALL
        if case == "tampered_artifact":
            tamper = {
                "COMP-02": lambda: dict(base, dependency_records=dict(base["dependency_records"], index_id="sha256:" + "0" * 64)),
                "COMP-03": lambda: dict(base, manifest_intake={"source_id": "DATA-01", "state": "ADMITTED", "items": [], "intake_hash": "x", "base_revision": p.binding.base_revision}),
                "COMP-04": lambda: dict(base, scope_contract=dict(p.contract, base_revision="b" * 40)),
                "COMP-05": lambda: dict(base, patch=base["patch"] + b"\n+tampered\n"),
                "COMP-06": lambda: dict(base, evidence_bundle=dict(base["evidence_bundle"], scope_contract_hash="sha256:" + "1" * 64)),
                "COMP-07": lambda: dict(base, recipe="improvise"),
                "COMP-08": lambda: dict(base, impact_report=dict(base["impact_report"], candidate_id="sha256:" + "2" * 64)),
                "COMP-09": lambda: dict(base, candidate=dict(base["candidate"], scope_contract_hash="sha256:" + "3" * 64)),
                "COMP-10": lambda: dict(base, verification_report=dict(base["verification_report"], candidate_id="sha256:" + "4" * 64)),
                "COMP-11": lambda: dict(base, action="rollback", run_dir=str(p.root / "inside")),
                "COMP-01": lambda: dict(base, max_files=10 ** 9),
            }
            return tamper[cid](), ALL
        raise AssertionError(f"unknown negative case {case}")

    def _rollback_run_dir(self) -> Path:
        """An applied, archived run (human receipt issued through the approval adapter with a test key) for COMP-11 rollback."""
        p = self.p; run_dir = p.base / "run"
        key = aa.load_or_create_key(p.base / "keys" / "approval.key", create=True)
        eb = p.out("COMP-04", "evidence_bundle"); cand = p.out("COMP-07", "candidate"); patch = p.patch(); report = p.out("COMP-08", "verification_report"); card = p.out("COMP-10", "review_card")
        _w(run_dir / "suite40" / "binding.json", json.loads(p.binding.to_json())); _w(run_dir / "intent" / "scope_contract.json", p.contract)
        _w(run_dir / "suite51" / "evidence.json", eb["evidence"]); _w(run_dir / "suite51" / "authority.json", eb["authority"]); _w(run_dir / "plan" / "refactoring_plan.json", p.out("COMP-06", "refactoring_plan"))
        _w(run_dir / "candidate" / "candidate.json", cand); (run_dir / "candidate" / "candidate.patch").write_bytes(patch); _w(run_dir / "verification" / "report.json", report); _w(run_dir / "review" / "review_card.json", card)
        receipt = json.loads(aa.issue_receipt(run_dir, key, decision="APPROVE", approver_identity="reviewer@example", approver_channel="test", rationale="ok", candidate=cand, card=card, report=report).to_json())
        applied = aa.apply_isolated(p.binding, p.contract, cand, patch, report, card, receipt, key, run_dir, run_dir / "applied-worktrees")
        _w(run_dir / "applied" / "applied.json", json.loads(applied.to_json()))
        ar.archive_run(run_dir)
        return run_dir

    def test_scenarios(self) -> None:
        order = ["COMP-01", "COMP-02", "COMP-03", "COMP-04", "COMP-06", "COMP-07", "COMP-09", "COMP-05", "COMP-08", "COMP-10", "COMP-11"]
        active = [cid for cid in order if f"components:{cid}" in self.scen]
        if not active:
            self.skipTest("no active component scenarios")
        self.p.run_through(active[-1])
        for cid in active:
            sc = self.scen[f"components:{cid}"]
            r = self.p.results[cid]
            with self.subTest(component=cid, case="unit"):
                u = self._unit(cid, r); self.assertTrue(u["ok"], u)
                self._receipt(cid, "unit", "PASS", {"inputs_hash": r.inputs_hash, "output_hash": r.output_hash, "result_hash": r.result_hash, **{k: v for k, v in u.items() if k != "ok"}})
            with self.subTest(component=cid, case="integration"):
                i = self._integration(cid, r); self.assertTrue(i["linked_to_upstream"], cid)
                self._receipt(cid, "integration", "PASS", {"inputs_hash": r.inputs_hash, "input_identities": r.input_identities, **i})
            if sc.get("replay", True):
                with self.subTest(component=cid, case="replay"):
                    again = K.invoke(cid, self.p.inputs_for(cid), granted_effects=ALL, components=self.comps, registry=self.reg, sandbox=self.p.base / "sb")
                    chk = K.replay_check(r, again)
                    self.assertTrue(chk["deterministic"], chk)
                    self._receipt(cid, "replay", "PASS", chk)
            for neg in sc.get("negative", []):
                with self.subTest(component=cid, case=neg["case"]):
                    if neg["case"] == "stale_binding":
                        continue  # executed last: it moves the fixture repository
                    inputs, granted = self._negative(cid, neg["case"])
                    with self.assertRaises(lga.AdapterError) as ctx:
                        K.invoke(cid, inputs, granted_effects=granted, components=self.comps, registry=self.reg, sandbox=self.p.base / "sb")
                    self.assertEqual(ctx.exception.code, neg["expect"], f"{cid}/{neg['case']}: {ctx.exception}")
                    self._receipt(cid, neg["case"], "PASS", {"expected": neg["expect"], "refused_with": ctx.exception.code, "reason": str(ctx.exception)[:200], "output": "none (refused before any result was sealed)"})
        if "COMP-11" in active and self.scen["components:COMP-11"].get("rollback"):
            with self.subTest(component="COMP-11", case="rollback"):
                run_dir = self._rollback_run_dir()
                rb = K.invoke("COMP-11", {"binding": self.p.binding, "action": "rollback", "run_dir": str(run_dir)}, granted_effects=ALL, components=self.comps, registry=self.reg)
                self.assertTrue(rb.outputs["rollback_proof"]["checkpoint_verified"]); self.assertEqual(rb.outputs["rollback_proof"]["verdict"], "PASS")
                self._receipt("COMP-11", "rollback", "PASS", {"inputs_hash": rb.inputs_hash, "output_hash": rb.output_hash, "rollback_id": rb.outputs["rollback_proof"]["rollback_id"]})
                with self.assertRaises(lga.AdapterError) as ctx:
                    K.invoke("COMP-11", {"binding": self.p.binding, "action": "rollback", "run_dir": str(run_dir)}, granted_effects=ALL, components=self.comps, registry=self.reg)
                self.assertEqual(ctx.exception.code, "rollback.nothing_to_roll_back")
                self._receipt("COMP-11", "rollback_twice", "PASS", {"refused_with": ctx.exception.code})
        stale = [cid for cid in active if any(n["case"] == "stale_binding" for n in self.scen[f"components:{cid}"].get("negative", []))]
        if stale:
            (self.p.root / "Suite01" / "01_demo.jad").write_text("moved\n"); _git(self.p.root, "add", "-A"); _git(self.p.root, "commit", "-q", "-m", "moved")
            for cid in stale:
                with self.subTest(component=cid, case="stale_binding"):
                    with self.assertRaises(lga.AdapterError) as ctx:
                        K.invoke(cid, self.p.inputs_for(cid), granted_effects=ALL, components=self.comps, registry=self.reg, sandbox=self.p.base / "sb")
                    self.assertEqual(ctx.exception.code, "component.binding_mismatch")
                    self._receipt(cid, "stale_binding", "PASS", {"refused_with": ctx.exception.code})
        self.assertGreaterEqual(EL.verify(), self.rows)

    def test_scenarios_are_well_formed(self) -> None:
        for sid, sc in self.scen.items():
            with self.subTest(scenario=sid):
                self.assertIn(sc["component_id"], self.comps["components"])
                self.assertTrue(sc["unit"] and sc["integration"] and sc["receipt_requirements"])
                for n in sc.get("negative", []):
                    self.assertTrue(n["case"] and n["expect"])


if __name__ == "__main__":
    unittest.main()
