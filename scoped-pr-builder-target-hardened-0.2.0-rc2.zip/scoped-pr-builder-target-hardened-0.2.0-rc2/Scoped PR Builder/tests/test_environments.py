"""Deployment environments: profiles, narrowing, lifecycle, smoke and promotion (T01–T05).

Every assertion here is against a real run driven under the environment's own narrowed policy and clamped intent —
the profile is the expectation, the run is the observation, and the two are compared. Nothing asserts that a profile
is correct by reading the profile back.
"""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from adapters import contracts as C  # noqa: E402
from adapters import environment as E  # noqa: E402
import test_workflow as T  # noqa: E402

_REG: dict = {}


def _reg():
    if not _REG:
        reg = C.load_registry()
        _REG.update({"reg": reg, "environments": E.load_environments(registry=reg)})
    return _REG


class ProfileTests(unittest.TestCase):
    """T01 — every environment declares all nine dimensions, over suites that exist."""

    def setUp(self):
        self.m = _reg()["environments"]

    def test_every_declared_profile_is_complete(self):
        self.assertTrue(self.m["environments"])
        for eid, e in self.m["environments"].items():
            for key in E.PROFILE_REQUIRED:
                self.assertIn(key, e, f"{eid} lacks {key}")
            self.assertIn(eid, E.ENVIRONMENT_IDS)
            self.assertEqual(e["environment_id"], eid)

    def test_ranks_are_unique_and_ordering_is_declared(self):
        ranks = [e["rank"] for e in self.m["environments"].values()]
        self.assertEqual(len(ranks), len(set(ranks)))
        self.assertEqual(E.ranked(self.m), sorted(self.m["environments"], key=lambda k: self.m["environments"][k]["rank"]))

    def test_no_environment_declares_outbound_network(self):
        for eid, e in self.m["environments"].items():
            self.assertIn(e["network"]["mode"], E.NETWORK_MODES, eid)

    def test_effects_stay_inside_the_tools_vocabulary(self):
        for eid, e in self.m["environments"].items():
            self.assertEqual(sorted(set(e["allowed_effects"]) - set(E.KNOWN_EFFECTS)), [], eid)

    def test_a_non_applying_posture_may_not_allow_a_privileged_effect(self):
        bad = json.loads(json.dumps({k: v for k, v in self.m.items() if k != "computed_hash"}))
        first = sorted(bad["environments"])[0]
        bad["environments"][first]["permissions"]["posture"] = "read_only"
        bad["environments"][first]["allowed_effects"] = sorted(set(bad["environments"][first]["allowed_effects"]) | {"patch.apply_isolated"})
        p = Path(tempfile.mkdtemp()) / "ENVIRONMENTS.json"
        p.write_text(json.dumps(bad), encoding="utf-8")
        with self.assertRaises(E.EnvironmentRefusal) as cm:
            E.load_environments(p)
        self.assertEqual(cm.exception.code, "environment.authority_broadened")

    def test_an_unbound_suite_is_refused(self):
        bad = json.loads(json.dumps({k: v for k, v in self.m.items() if k != "computed_hash"}))
        first = sorted(bad["environments"])[0]
        bad["environments"][first]["authoritative_suites"] = ["Suite99/nope.jad"]
        p = Path(tempfile.mkdtemp()) / "ENVIRONMENTS.json"
        p.write_text(json.dumps(bad), encoding="utf-8")
        with self.assertRaises(E.EnvironmentRefusal) as cm:
            E.load_environments(p)
        self.assertEqual(cm.exception.code, "environment.suite_unbound")


class NarrowingTests(unittest.TestCase):
    """T02 — an environment can only narrow authority; every attempt to broaden is refused."""

    def setUp(self):
        r = _reg()
        self.m, self.reg = r["environments"], r["reg"]
        self.rs = T.rule_set(self.reg)

    def test_narrowing_only_ever_removes(self):
        for eid in E.ranked(self.m):
            n = E.effective_rule_set(self.rs, eid, self.m)
            allowed = set(E.environment(eid, self.m)["allowed_effects"])
            for role, effects in n["grants"].items():
                self.assertLessEqual(set(effects), set(self.rs["grants"].get(role, [])), f"{eid}/{role}")
                self.assertLessEqual(set(effects), allowed, f"{eid}/{role}")

    def test_a_narrowed_rule_set_still_validates_against_the_closed_contract(self):
        for eid in E.ranked(self.m):
            n = E.effective_rule_set(self.rs, eid, self.m)
            C.validate_payload("policy_layer", n, registry=self.reg)
            self.assertNotIn("environment_id", n, "the environment identity travels beside the rule set, never inside it")

    def test_a_new_grant_a_new_role_or_a_dropped_requirement_is_refused(self):
        cases = [
            ("new role", lambda rs: dict(rs, grants={**rs["grants"], "sneaky": ["patch.apply_isolated"]})),
            ("new effect", lambda rs: dict(rs, grants={**rs["grants"], T.ROLE: sorted(set(rs["grants"][T.ROLE]) | {"store.write", "rollback.execute"})})),
            ("dropped human approval", lambda rs: dict(rs, require_human_approval=[])),
            ("dropped deny pattern", lambda rs: dict(rs, deny_by_default=[])),
        ]
        for label, mutate in cases:
            with self.subTest(label):
                with self.assertRaises(E.EnvironmentRefusal) as cm:
                    E.assert_no_broadening(self.rs, mutate(json.loads(json.dumps(self.rs))))
                self.assertEqual(cm.exception.code, "environment.authority_broadened")

    def test_a_decision_carries_the_environment_that_shaped_it(self):
        d = E.decide(self.rs, "repository.read", T.ROLE, "production_read_only",
                     context={"human_approval_receipt_verified": True}, environments=self.m)
        self.assertEqual(d["decision"], "allow")
        self.assertEqual(d["environment_id"], "production_read_only")
        self.assertEqual(d["environment_profile_hash"], E.profile_hash("production_read_only", self.m))

    def test_a_read_only_environment_denies_application(self):
        d = E.decide(self.rs, "patch.apply_isolated", T.ROLE, "production_read_only",
                     context={"human_approval_receipt_verified": True}, environments=self.m)
        self.assertEqual(d["decision"], "deny")

    def test_quotas_clamp_an_intent_and_only_downwards(self):
        greedy = dict(T.INTENT, max_changed_files=999, max_diff_lines=9999)
        capped = E.cap_intent(greedy, "production_read_only", self.m)
        self.assertEqual(capped["max_changed_files"], 0)
        self.assertEqual(capped["max_diff_lines"], 0)
        self.assertFalse(E.quota_of("production_read_only", self.m)["permits_change"])
        modest = dict(T.INTENT, max_changed_files=1, max_diff_lines=10)
        kept = E.cap_intent(modest, "staging", self.m)
        self.assertEqual(kept["max_changed_files"], 1, "clamping never raises a smaller request")


class LifecycleTests(unittest.TestCase):
    """T03 — pins, readiness, clean startup/shutdown, isolation and a deterministic evidence export."""

    def setUp(self):
        r = _reg()
        self.m, self.reg = r["environments"], r["reg"]
        self.base = Path(tempfile.mkdtemp(prefix="env-life-"))
        self.run_dir = self.base / "run"

    def test_pins_come_from_the_tool_not_from_configuration(self):
        p = E.pins(self.m, registry=self.reg)
        self.assertEqual(p["contracts_hash"], self.reg["computed_hash"])
        self.assertEqual(p["environments_hash"], self.m["computed_hash"])
        self.assertTrue(p["python"])

    def test_readiness_reports_every_declared_check(self):
        h = E.health("ci_validation", self.run_dir, environments=self.m, registry=self.reg)
        self.assertEqual(sorted(h["checks"]), sorted(E.HEALTH_CHECKS))
        self.assertTrue(h["ready"], h["failing"])

    def test_ambient_credential_names_are_reported_but_never_block(self):
        h = E.health("ci_validation", self.run_dir, environments=self.m, registry=self.reg)
        self.assertIsInstance(h["ambient_secret_names"], list)
        self.assertNotIn("secrets_policy_honoured", h["failing"],
                         "what the operator's shell exports is advisory; only key material this tool holds is a failure")

    def test_a_run_directory_inside_the_repository_is_not_ready(self):
        inside = Path(E.REPO_ROOT) / "Scoped PR Builder" / "_would_be_inside"
        h = E.health("ci_validation", inside, environments=self.m, registry=self.reg)
        self.assertIn("run_dir_outside_repository", h["failing"])
        with self.assertRaises(E.EnvironmentRefusal) as cm:
            E.require_ready("ci_validation", inside, environments=self.m, registry=self.reg)
        self.assertEqual(cm.exception.code, "environment.not_ready")

    def test_startup_and_shutdown_are_chained_and_verified(self):
        h = E.startup("ci_validation", self.run_dir, environments=self.m, registry=self.reg)
        rows = E.lifecycle(self.run_dir)
        self.assertEqual([r["phase"] for r in rows], ["startup"])
        closed = E.shutdown(h, environments=self.m)
        self.assertEqual(closed["leftovers"], [])
        self.assertEqual([r["phase"] for r in E.lifecycle(self.run_dir)], ["startup", "shutdown"])
        self.assertGreaterEqual(closed["chains_verified"].get("environment/lifecycle.jsonl", 0), 1)

    def test_a_leftover_worktree_refuses_shutdown_and_is_recorded_not_removed(self):
        h = E.startup("staging", self.run_dir, environments=self.m, registry=self.reg)
        leftover = self.run_dir / "applied-worktrees" / "stale"
        leftover.mkdir(parents=True)
        (leftover / "file.txt").write_text("left behind", encoding="utf-8")
        with self.assertRaises(E.EnvironmentRefusal) as cm:
            E.shutdown(h, environments=self.m)
        self.assertEqual(cm.exception.code, "environment.unclean_shutdown")
        self.assertTrue(leftover.is_dir(), "a leftover is recorded, never tidied away behind the operator's back")
        self.assertEqual([r["phase"] for r in E.lifecycle(self.run_dir)][-1], "shutdown")

    def test_the_evidence_export_is_deterministic(self):
        h = E.startup("ci_validation", self.run_dir, environments=self.m, registry=self.reg)
        E.shutdown(h, environments=self.m)
        a = E.export_evidence(self.run_dir, self.base / "x", environments=self.m)
        b = E.export_evidence(self.run_dir, self.base / "y", environments=self.m)
        self.assertEqual(a["manifest_hash"], b["manifest_hash"])
        self.assertEqual(a["file_count"], b["file_count"])
        self.assertTrue(all(f["sha256"].startswith("sha256:") for f in a["files"]))


class SmokeTests(unittest.TestCase):
    """T04 — a real run per environment, driven under that environment's own narrowed policy and clamped intent."""

    @classmethod
    def setUpClass(cls):
        import environment_smoke as S
        r = _reg()
        cls.m, cls.S = r["environments"], S
        cls.runs = {}
        # only the environments whose profile declares a smoke plan: during the T04 wave the plans fill in item by
        # item, and judging a run against a plan nobody declared is exactly what smoke_plan refuses to do
        cls.declared = [eid for eid in E.ranked(cls.m) if isinstance(cls.m["environments"][eid].get("smoke"), dict)]
        for eid in cls.declared:
            extra = {"overlay_suite_passed": True, "qualification_all_passed": True, "invariants_clean": True}
            if eid == "isolated_test_tenant":
                extra.update(synthetic_fixtures=True, privacy_validation_passed=True, tenant_isolated=True)
            cls.runs[eid] = S.drive(eid, environments=cls.m, evidence=extra)

    def test_every_environment_smokes_clean(self):
        for eid, r in self.runs.items():
            with self.subTest(eid):
                self.assertEqual(r["smoke"]["verdict"], "PASS", r["smoke"]["problems"])
                self.assertEqual(sorted(r["smoke"]["checks"]), sorted(E.SMOKE_CHECKS))

    def test_the_posture_a_run_reaches_is_the_posture_the_profile_declares(self):
        expected = {"read_only": 2, "draft_only": 9, "apply_isolated": 12}
        for eid, r in self.runs.items():
            with self.subTest(eid):
                posture = E.environment(eid, self.m)["permissions"]["posture"]
                self.assertEqual(len(r["completed"]), expected[posture],
                                 f"{eid} ({posture}) reached {r['completed']}")

    def test_no_run_ever_grants_itself_an_effect_outside_its_profile(self):
        for eid, r in self.runs.items():
            with self.subTest(eid):
                allowed = set(E.environment(eid, self.m)["allowed_effects"])
                self.assertLessEqual(set(r["observed"]["authorization"]["granted"]), allowed)

    def test_an_unobserved_check_is_a_failure_not_a_skip(self):
        eid = self.declared[0]
        partial = {k: v for k, v in self.runs[eid]["observed"].items() if k != "cleanup"}
        res = E.smoke_result(eid, partial, environments=self.m)
        self.assertEqual(res["verdict"], "FAIL")
        self.assertIn("cleanup", res["checks"])
        self.assertFalse(res["checks"]["cleanup"]["ok"])
        with self.assertRaises(E.EnvironmentRefusal) as cm:
            E.require_smoke(eid, res)
        self.assertEqual(cm.exception.code, "environment.smoke_failed")

    def test_a_criterion_with_no_declared_demonstration_is_never_satisfied(self):
        for eid, run in self.runs.items():
            with self.subTest(eid):
                for crit in run["smoke"]["satisfied"]:
                    self.assertIn(crit, E.CRITERION_EVIDENCE,
                                  f"{crit} was reported satisfied with no declared demonstration")
        # and a criterion the table does not know how to demonstrate is reported unmet, with that as the reason
        eid = self.declared[0]
        invented = "a criterion nobody declared a demonstration for"
        m = json.loads(json.dumps(self.m))
        target = sorted(m["environments"])[0]
        m["environments"][target].setdefault("promotion", {"entry_criteria": [], "exit_criteria": [],
                                                           "profile_assertions": [], "promotes_to": [],
                                                           "requires_receipt": True})
        m["environments"][target]["promotion"]["exit_criteria"] = [invented]
        res = E.smoke_result(eid, self.runs[eid]["observed"], environments=m)
        self.assertNotIn(invented, res["satisfied"])
        self.assertIn("no declared way to demonstrate", res["unmet"][invented])

    def test_a_posture_specific_criterion_is_not_credited_to_another_posture(self):
        """Whatever criteria happen to be declared at this point in the wave, no run is ever credited with one that
        belongs to a posture it was not running under, and each such refusal says which posture it belongs to."""
        checked = 0
        for eid, run in self.runs.items():
            posture = E.environment(eid, self.m)["permissions"]["posture"]
            for crit, why in run["smoke"]["unmet"].items():
                spec = E.CRITERION_EVIDENCE.get(crit) or {}
                if spec.get("posture") and spec["posture"] != posture:
                    self.assertIn(spec["posture"], why, f"{eid}: {crit}")
                    checked += 1
            for crit in run["smoke"]["satisfied"]:
                spec = E.CRITERION_EVIDENCE.get(crit) or {}
                if spec.get("posture"):
                    self.assertEqual(spec["posture"], posture,
                                     f"{eid} ({posture}) was credited with a {spec['posture']} criterion: {crit}")
        if not checked:
            self.skipTest("no posture-specific criterion is declared yet in this wave")


class PromotionTests(unittest.TestCase):
    """T05 — promotion criteria into and out of each environment, and the signed receipt authority widens on."""

    @classmethod
    def setUpClass(cls):
        SmokeTests.setUpClass()
        cls.m, cls.runs, cls.declared = SmokeTests.m, SmokeTests.runs, SmokeTests.declared

    def _need(self, *envs):
        missing = [e for e in envs if e not in self.runs or e not in self.promoting]
        if missing:
            self.skipTest(f"{missing} not yet smoke-tested and promoting in this wave")

    def _receipt(self, a, b, **over):
        row = [r for r in E.promotion_table(self.m) if (r["from"], r["to"]) == (a, b)][0]
        kw = dict(smoke=self.runs[a]["smoke"], entry_smoke=self.runs[b]["smoke"], readiness=self.runs[b]["readiness"],
                  approver_identity="release-manager@example", approver_channel="cli",
                  rationale="promotion approved; gains " + (", ".join(row["widens"]["privileged_gained"]) or "no privileged effect"),
                  environments=self.m)
        kw.update(over)
        return E.compatibility_receipt(a, b, **kw)

    def setUp(self):
        self.promoting = {eid: e for eid, e in self.m["environments"].items() if "promotion" in e}
        if not self.promoting:
            self.skipTest("no environment declares promotion criteria yet in this wave")

    def test_every_environment_declares_promotion_criteria_and_profile_assertions(self):
        for eid, e in self.promoting.items():
            p = E.promotion_of(e)
            self.assertTrue(p["entry_criteria"] and p["exit_criteria"], eid)
            self.assertTrue(p["requires_receipt"], eid)
            pa = E.verify_profile_assertions(eid, self.m)
            self.assertTrue(pa["ok"], f"{eid}: failing {pa['failing']}, unverifiable {pa['unverifiable']}")

    def test_every_declared_promotion_path_can_be_approved_on_real_evidence(self):
        table = [r for r in E.promotion_table(self.m)
                 if r["from"] in self.runs and r["to"] in self.runs and r["to"] in self.promoting]
        if not table:
            self.skipTest("no promotion path yet has smoke runs at both ends in this wave")
        for row in table:
            with self.subTest(f"{row['from']} -> {row['to']}"):
                r = self._receipt(row["from"], row["to"])
                v = E.require_promotion(row["from"], row["to"], r, smoke=self.runs[row["from"]]["smoke"],
                                        entry_smoke=self.runs[row["to"]]["smoke"], environments=self.m)
                self.assertEqual(v["verdict"], "VALID")

    def test_rank_is_pipeline_position_and_the_delta_states_what_actually_changes(self):
        self._need("ci_validation", "staging")
        self._need("production_read_only")
        d = E.authority_delta("staging", "production_read_only", self.m)
        self.assertEqual(d["direction"], "narrows")
        self.assertEqual(d["effects_gained"], [])
        self.assertIn("patch.apply_isolated", d["effects_lost"])
        w = E.authority_delta("ci_validation", "staging", self.m)
        self.assertEqual(w["direction"], "widens")
        self.assertEqual(sorted(w["privileged_gained"]), ["patch.apply_isolated", "rollback.execute"])

    def test_no_receipt_means_no_promotion(self):
        self._need("ci_validation", "staging")
        with self.assertRaises(E.EnvironmentRefusal) as cm:
            E.require_promotion("ci_validation", "staging", None, environments=self.m)
        self.assertEqual(cm.exception.code, "environment.promotion_denied")

    def test_a_model_channel_cannot_approve_a_promotion(self):
        self._need("ci_validation", "staging")
        with self.assertRaises(Exception) as cm:
            self._receipt("ci_validation", "staging", approver_identity="planner", approver_channel="model")
        self.assertEqual(getattr(cm.exception, "code", ""), "security.sec07.model_channel")

    def test_a_promotion_that_gains_privileged_effects_must_name_them(self):
        self._need("ci_validation", "staging")
        with self.assertRaises(E.EnvironmentRefusal) as cm:
            self._receipt("ci_validation", "staging", rationale="looks fine to me")
        self.assertEqual(cm.exception.code, "environment.promotion_denied")
        self.assertIn("must name", str(cm.exception))

    def test_the_destination_entry_criteria_need_a_run_in_the_destination(self):
        self._need("ci_validation", "staging")
        self._need("production_read_only")
        with self.assertRaises(E.EnvironmentRefusal) as cm:
            self._receipt("staging", "production_read_only", entry_smoke=self.runs["staging"]["smoke"])
        self.assertEqual(cm.exception.code, "environment.promotion_denied")
        self.assertIn("not the destination", str(cm.exception))

    def test_a_receipt_goes_stale_when_a_profile_changes(self):
        self._need("ci_validation", "staging")
        r = self._receipt("ci_validation", "staging")
        self.assertEqual(E.verify_compatibility_receipt(r, environments=self.m)["verdict"], "VALID")
        moved = json.loads(json.dumps(self.m))
        moved["environments"]["staging"]["quotas"]["max_diff_lines"] = 1
        moved["computed_hash"] = self.m["computed_hash"]
        with self.assertRaises(E.EnvironmentRefusal) as cm:
            E.verify_compatibility_receipt(r, environments=moved)
        self.assertEqual(cm.exception.code, "environment.receipt_stale")

    def test_a_tampered_receipt_is_refused(self):
        self._need("ci_validation", "staging")
        r = dict(self._receipt("ci_validation", "staging"))
        r["to_environment"] = "privileged_execution"
        with self.assertRaises(E.EnvironmentRefusal) as cm:
            E.verify_compatibility_receipt(r, environments=self.m)
        self.assertEqual(cm.exception.code, "environment.receipt_tampered")

    def test_a_receipt_authorises_only_the_hop_it_names(self):
        self._need("ci_validation", "staging")
        r = self._receipt("ci_validation", "staging")
        self._need("production_read_only", "privileged_execution")
        with self.assertRaises(E.EnvironmentRefusal) as cm:
            E.require_promotion("production_read_only", "privileged_execution", r, environments=self.m)
        self.assertEqual(cm.exception.code, "environment.promotion_denied")

    def test_smoke_results_are_archived_as_evidence(self):
        """The readiness gate reads the tool's own chained evidence ledger, so each environment's smoke verdict is
        written there — with the profile hash it was judged against and the criteria it demonstrated."""
        import evidence_ledger as EL
        rows = []
        for eid, r in self.runs.items():
            s = r["smoke"]
            rows.append(EL.record(f"environment:{eid}@{E.profile_hash(eid, self.m)[7:39]}", E.EVIDENCE_KIND,
                                  s["verdict"],
                                  {"environment_id": eid,
                                   "posture": E.environment(eid, self.m)["permissions"]["posture"],
                                   "checks": {k: v["ok"] for k, v in s["checks"].items()},
                                   "criteria_satisfied": s["satisfied"],
                                   "criteria_declared": s["criteria_declared"],
                                   "smoke_hash": s["smoke_hash"],
                                   "environment_profile_hash": s["environment_profile_hash"],
                                   "environments_hash": self.m["computed_hash"]}))
        self.assertEqual(len(rows), len(self.runs))
        self.assertTrue(all(row["verdict"] == "PASS" for row in rows))

    def test_the_receipt_records_what_was_approved_and_grants_nothing_itself(self):
        self._need("ci_validation", "staging")
        r = self._receipt("ci_validation", "staging")
        self.assertIn("evidence_only", r["authority"])
        self.assertEqual(r["authority_delta"]["direction"], "widens")
        self.assertTrue(r["smoke_hash"] and r["entry_smoke_hash"] and r["smoke_hash"] != r["entry_smoke_hash"])
        self.assertTrue(all(r["profile_assertions"].values()))


if __name__ == "__main__":
    unittest.main()
