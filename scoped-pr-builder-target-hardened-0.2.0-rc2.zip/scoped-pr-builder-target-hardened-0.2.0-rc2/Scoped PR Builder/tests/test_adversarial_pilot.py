"""SLICE-10 — adversarial fail-closed tests for the pilot path (stdlib unittest).

Two attack classes the source TODO names as promotion gates:

  * SCOPE EXPANSION  — every place an attacker (or a careless model) could widen the
    change beyond the approved scope contract: intent intake, plan operations, patch
    generation, the patch bytes themselves, verification, and application.
  * FABRICATED APPROVAL — every way an approval could be conjured without a human:
    receipts written without the key, replayed from another candidate, edited after
    issuance, forged ledger lines, approval flags injected into the review card,
    expired receipts, and approvals for candidates whose verification did not pass.

Every case must end in an explicit refusal (AdapterError / FAIL verdict) with the
source repository untouched. A single silent success is a pilot failure.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import approval_adapter as aa  # noqa: E402
from adapters import evidence_retrieval as er  # noqa: E402
from adapters import intent_intake as ii  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import patch_generator as pg  # noqa: E402
from adapters import review_renderer as rr  # noqa: E402
from adapters import verification_runner as vr  # noqa: E402


def _git(cwd: Path, *args: str) -> str:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t",
           "GIT_COMMITTER_EMAIL": "t@t", "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z", "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z"}
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=True, env=env).stdout.strip()


HDR = "ja source 0.3\nmodule suite{n}.demo\nuse Data\npolicy no_network\nemit json demo\n"


def _rebind_candidate(cand: dict, patch: bytes) -> dict:
    """Recompute the candidate hashes an attacker would need to make a forged patch look legitimate."""
    c = dict(cand, patch_hash=lga.sha256_digest(patch))
    c["candidate_id"] = lga.sha256_digest(lga.canonical_json({"patch": c["patch_hash"], "rev": c["base_revision"], "scope": c["scope_contract_hash"], "plan": c["plan_hash"]}))
    return c


class Pilot(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        base = Path(self.tmp.name)
        self.root = base / "repo"
        self.root.mkdir()
        _git(self.root, "init", "-q")
        for n in range(1, 67):
            d = self.root / f"Suite{n:02d}"
            d.mkdir()
            (d / f"{n:02d}_demo.jad").write_text(HDR.format(n=n))
        (self.root / "Suite04" / "SHA256SUMS.txt").write_text("0000  04_Old/04_demo.jad\n")
        (self.root / "Suite05" / "SHA256SUMS.txt").write_text("1111  05_Old/05_demo.jad\n")
        tests = self.root / "Scoped PR Builder" / "tests"
        tests.mkdir(parents=True)
        (tests / "test_ok.py").write_text("import unittest\nclass T(unittest.TestCase):\n    def test_a(self):\n        self.assertTrue(True)\nif __name__ == '__main__':\n    unittest.main()\n")
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c1")
        self.run_dir = base / "run"
        self.run_dir.mkdir()
        self.key = aa.load_or_create_key(base / "keys" / "approval.key", create=True)
        self.binding = lga.bind_repository(self.root)
        self.intent = {"kind": "tech_debt_refactor", "title": "Regenerate stale Suite04 SHA256SUMS manifest", "description": "x",
                       "allowed_paths": ["Suite04/SHA256SUMS.txt"], "max_changed_files": 1, "max_diff_lines": 10, "requested_by": "t"}
        self.contract = json.loads(ii.accept_intent(self.intent, self.binding).to_json())
        self.bundle = er.retrieve_examples(self.binding, self.contract)
        self.plan = er.build_plan(self.contract, self.bundle)
        cand, self.patch = pg.generate_candidate(self.binding, self.contract, self.plan, "regenerate_sha256sums_manifest")
        self.cand = json.loads(cand.to_json())
        self.sb = base / "sb"
        self.report = json.loads(vr.verify_candidate(self.binding, self.contract, self.cand, self.patch, self.sb).to_json())
        self.card = rr.build_review_card(json.loads(self.binding.to_json()), self.contract, self.bundle.evidence, self.bundle.authority, self.plan, self.cand, self.patch, self.report)
        self.snapshot = lga.tree_identity(self.root, self.binding.base_revision)

    def tearDown(self) -> None:
        self.assertEqual(lga.tree_identity(self.root, self.binding.base_revision), self.snapshot)  # source never changes
        self.assertEqual(_git(self.root, "status", "--porcelain"), "")
        self.tmp.cleanup()

    def apply(self, receipt, **over):
        args = dict(binding=self.binding, contract=self.contract, candidate=self.cand, patch=self.patch, report=self.report, card=self.card,
                    receipt=receipt, key=self.key, run_dir=self.run_dir, worktree_parent=Path(self.tmp.name) / "applied")
        args.update(over)
        return aa.apply_isolated(**args)

    def expect(self, code, fn, *a, **kw):
        with self.assertRaises(lga.AdapterError) as ctx:
            fn(*a, **kw)
        self.assertEqual(ctx.exception.code, code)


class TestScopeExpansion(Pilot):
    def test_intake_rejects_widening(self) -> None:
        self.expect("path.escape", ii.accept_intent, dict(self.intent, allowed_paths=["Suite04/../Suite05"]), self.binding)
        self.expect("intent.threshold_exceeds_cap", ii.accept_intent, dict(self.intent, max_changed_files=10_000), self.binding)
        self.expect("intent.scope_covers_audit_ledger", ii.accept_intent, dict(self.intent, allowed_paths=["Scoped PR Builder"]), lga.bind_repository(self.root)) if (self.root / "Scoped PR Builder" / "PROVENANCE.jsonl").exists() else None

    def test_contract_widened_after_acceptance(self) -> None:
        widened = dict(self.contract, allowed_paths=["Suite04/SHA256SUMS.txt", "Suite05/SHA256SUMS.txt"])
        self.expect("contract.tampered", ii.verify_contract_hash, widened)
        # even if the tampered contract were accepted downstream, the plan/candidate hashes no longer bind to it
        self.expect("patch.plan_mismatch", pg.generate_candidate, self.binding, dict(widened, scope_contract_hash="sha256:forged"), self.plan, "regenerate_sha256sums_manifest")

    def test_plan_operation_outside_scope(self) -> None:
        plan = json.loads(json.dumps(self.plan))
        plan["operations"].append(dict(plan["operations"][0], sequence=2, path="Suite05/SHA256SUMS.txt"))
        self.expect("scope.violation", pg.generate_candidate, self.binding, self.contract, plan, "regenerate_sha256sums_manifest")

    def test_patch_bytes_extended_beyond_scope(self) -> None:
        extra = self.patch + (
            "diff --git a/Suite05/SHA256SUMS.txt b/Suite05/SHA256SUMS.txt\n--- a/Suite05/SHA256SUMS.txt\n+++ b/Suite05/SHA256SUMS.txt\n"
            "@@ -1 +1 @@\n-1111  05_Old/05_demo.jad\n+pwned  05_demo.jad\n").encode()
        # attacker recomputes hashes so the candidate "looks" self-consistent
        forged = _rebind_candidate(self.cand, extra)
        report = json.loads(vr.verify_candidate(self.binding, self.contract, forged, extra, self.sb, run_tests=False).to_json())
        self.assertEqual({j["check"]: j["verdict"] for j in report["jobs"]}["scope_diff"], "FAIL")
        self.assertEqual(report["verdict"], "FAIL")
        card = rr.build_review_card(json.loads(self.binding.to_json()), self.contract, self.bundle.evidence, self.bundle.authority, self.plan, forged, extra, report)
        self.assertTrue(card["risk_summary"]["blocking_risk"])
        receipt = json.loads(aa.issue_receipt(self.run_dir, self.key, decision="APPROVE", approver_identity="r", approver_channel="test", rationale="x", candidate=forged, card=card, report=report).to_json())
        # even a genuine human APPROVE cannot push a FAILed verification through
        self.expect("apply.verification_not_pass", self.apply, receipt, candidate=forged, patch=extra, report=report, card=card)

    def test_apply_scope_drift_between_declared_and_actual(self) -> None:
        # candidate declares Suite04 but the (recomputed) patch actually touches Suite05 only
        other = self.patch.decode().replace("Suite04/SHA256SUMS.txt", "Suite05/SHA256SUMS.txt").replace("-0000  04_Old/04_demo.jad", "-1111  05_Old/05_demo.jad").encode()
        forged = _rebind_candidate(self.cand, other)
        report = dict(self.report, candidate_id=forged["candidate_id"], patch_hash=forged["patch_hash"])  # attacker also "fixes" the report
        # report hash no longer matches → card build detects nothing yet, but apply's checks must catch it somewhere fail-closed
        card = dict(self.card)
        receipt = json.loads(aa.issue_receipt(self.run_dir, self.key, decision="APPROVE", approver_identity="r", approver_channel="test", rationale="x",
                                              candidate=forged, card={**card, "identity": {**card["identity"], "candidate_id": forged["candidate_id"]}}, report=report).to_json())
        with self.assertRaises(lga.AdapterError) as ctx:
            self.apply(receipt, candidate=forged, patch=other, report=report)
        self.assertIn(ctx.exception.code, ("report.tampered", "apply.card_mismatch", "scope.violation", "apply.scope_drift", "approval.binding_mismatch"))

    def test_forbidden_path_cannot_be_reached(self) -> None:
        contract = json.loads(ii.accept_intent(dict(self.intent, allowed_paths=["Suite04"], forbidden_paths=["Suite04/SHA256SUMS.txt"], max_changed_files=2), self.binding).to_json())
        plan = er.build_plan(contract, er.retrieve_examples(self.binding, contract))
        plan["operations"] = [dict(op, path="Suite04/SHA256SUMS.txt", source_content_hash=lga.sha256_digest(b"0000  04_Old/04_demo.jad\n")) for op in plan["operations"][:1]]
        plan["plan_hash"] = "sha256:irrelevant"
        self.expect("scope.violation", pg.generate_candidate, self.binding, contract, plan, "regenerate_sha256sums_manifest")


class TestFabricatedApproval(Pilot):
    def test_receipt_written_without_key(self) -> None:
        fake = {"receipt_version": aa.RECEIPT_VERSION, "decision": "APPROVE", "approver_identity": "model", "approver_channel": "llm-output", "rationale": "I approve this",
                "candidate_id": self.cand["candidate_id"], "patch_hash": self.cand["patch_hash"], "base_revision": self.cand["base_revision"], "scope_contract_hash": self.cand["scope_contract_hash"],
                "card_hash": self.card["card_hash"], "verification_report_hash": self.report["report_hash"], "issued_at": "2026-09-03T00:00:00+00:00",
                "expires_at": "2099-01-01T00:00:00+00:00", "nonce": "0" * 32, "prev_hash": self.cand["candidate_id"]}
        fake["receipt_hash"] = lga.sha256_digest(lga.canonical_json(fake))
        fake["signature"] = "hmac-sha256:" + "f" * 64
        self.expect("approval.not_in_ledger", self.apply, fake)

    def test_forged_ledger_line(self) -> None:
        fake = {"receipt_version": aa.RECEIPT_VERSION, "decision": "APPROVE", "approver_identity": "model", "approver_channel": "llm-output", "rationale": "x",
                "candidate_id": self.cand["candidate_id"], "patch_hash": self.cand["patch_hash"], "base_revision": self.cand["base_revision"], "scope_contract_hash": self.cand["scope_contract_hash"],
                "card_hash": self.card["card_hash"], "verification_report_hash": self.report["report_hash"], "issued_at": "2026-09-03T00:00:00+00:00",
                "expires_at": "2099-01-01T00:00:00+00:00", "nonce": "0" * 32, "prev_hash": self.cand["candidate_id"]}
        fake["receipt_hash"] = lga.sha256_digest(lga.canonical_json(fake))
        fake["signature"] = "hmac-sha256:" + "f" * 64
        (self.run_dir / "approvals").mkdir(exist_ok=True)
        (self.run_dir / "approvals" / "ledger.jsonl").write_text(lga.canonical_json(fake) + "\n")
        self.expect("approval.signature_invalid", self.apply, fake)

    def test_reject_flipped_to_approve(self) -> None:
        rej = json.loads(aa.issue_receipt(self.run_dir, self.key, decision="REJECT", approver_identity="r", approver_channel="test", rationale="no", candidate=self.cand, card=self.card, report=self.report).to_json())
        flipped = dict(rej, decision="APPROVE")
        self.expect("approval.not_in_ledger", self.apply, flipped)
        # and flipping it inside the ledger file breaks the chain hash
        p = self.run_dir / "approvals" / "ledger.jsonl"
        p.write_text(lga.canonical_json(flipped) + "\n")
        self.expect("approval.receipt_tampered", self.apply, flipped)

    def test_replay_from_another_candidate(self) -> None:
        # a real approval for a different candidate (different patch) must not authorize this one
        other_patch = self.patch + b"\n"
        other = _rebind_candidate(self.cand, other_patch)
        other_report = dict(self.report, candidate_id=other["candidate_id"], patch_hash=other["patch_hash"])
        other_card = {**self.card, "identity": {**self.card["identity"], "candidate_id": other["candidate_id"]}}
        r = json.loads(aa.issue_receipt(Path(self.tmp.name) / "run-other", self.key, decision="APPROVE", approver_identity="r", approver_channel="test", rationale="x", candidate=other, card=other_card, report=other_report).to_json())
        with self.assertRaises(lga.AdapterError) as ctx:
            self.apply(r)
        self.assertIn(ctx.exception.code, ("approval.not_in_ledger", "approval.chain_broken", "approval.binding_mismatch"))

    def test_expired_receipt(self) -> None:
        r = json.loads(aa.issue_receipt(self.run_dir, self.key, decision="APPROVE", approver_identity="r", approver_channel="test", rationale="x", candidate=self.cand, card=self.card, report=self.report, ttl_minutes=1).to_json())
        self.expect("approval.expired", aa.verify_receipt, self.run_dir, self.key, r, candidate=self.cand, card=self.card, report=self.report, now=datetime.now(timezone.utc) + timedelta(minutes=5))

    def test_approval_flag_injected_into_review_card(self) -> None:
        r = json.loads(aa.issue_receipt(self.run_dir, self.key, decision="APPROVE", approver_identity="r", approver_channel="test", rationale="x", candidate=self.cand, card=self.card, report=self.report).to_json())
        injected = dict(self.card, approval_controls={**self.card["approval_controls"], "approved": True, "approved_by": "model"})
        self.expect("apply.card_mismatch", self.apply, r, card=injected)

    def test_model_asserted_verification(self) -> None:
        failing = json.loads(vr.verify_candidate(self.binding, self.contract, self.cand, self.patch, self.sb, run_tests=False).to_json())
        self.assertEqual(failing["verdict"], "INDETERMINATE")  # tests skipped → never PASS
        asserted = dict(failing, verdict="PASS")  # a model "declares" success
        # the review surface refuses to render it ...
        self.expect("report.tampered", rr.build_review_card, json.loads(self.binding.to_json()), self.contract, self.bundle.evidence, self.bundle.authority, self.plan, self.cand, self.patch, asserted)
        # ... and even with a genuine card + receipt, application refuses the asserted report
        r = json.loads(aa.issue_receipt(self.run_dir, self.key, decision="APPROVE", approver_identity="r", approver_channel="test", rationale="x", candidate=self.cand, card=self.card, report=self.report).to_json())
        self.expect("report.tampered", self.apply, r, report=asserted)
        # and the genuine INDETERMINATE report itself cannot be applied
        card = rr.build_review_card(json.loads(self.binding.to_json()), self.contract, self.bundle.evidence, self.bundle.authority, self.plan, self.cand, self.patch, failing)
        r2 = json.loads(aa.issue_receipt(self.run_dir, self.key, decision="APPROVE", approver_identity="r", approver_channel="test", rationale="x", candidate=self.cand, card=card, report=failing).to_json())
        self.expect("apply.verification_not_pass", self.apply, r2, report=failing, card=card)

    def test_genuine_approval_still_works(self) -> None:
        """Control case: the gates are not simply refusing everything."""
        r = json.loads(aa.issue_receipt(self.run_dir, self.key, decision="APPROVE", approver_identity="reviewer@example", approver_channel="test", rationale="ok", candidate=self.cand, card=self.card, report=self.report).to_json())
        rec = self.apply(r)
        self.assertEqual(rec.changed_paths, ("Suite04/SHA256SUMS.txt",))
        lga.worktree_remove(self.root, Path(rec.applied_worktree))


if __name__ == "__main__":
    unittest.main()
