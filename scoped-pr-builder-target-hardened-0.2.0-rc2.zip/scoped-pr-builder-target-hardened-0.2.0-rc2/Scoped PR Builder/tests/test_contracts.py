"""Data-driven tests for the versioned contract registry (stdlib unittest).

Every registered contract must (a) validate its own passing example, (b) refuse every
violating example with the exact code recorded in the registry, and (c) carry a
Tables/08 SchemaRegistryRecord-shaped registration row. The registry itself must be
structurally valid and hash-stable.
"""
from __future__ import annotations

import copy
import json
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import contracts as C  # noqa: E402
from adapters import controls as K  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402


class TestRegistry(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()

    def test_registry_loads_and_is_hash_stable(self) -> None:
        self.assertGreaterEqual(len(self.reg["contracts"]), 1)
        again = C.load_registry()
        self.assertEqual(self.reg["computed_hash"], again["computed_hash"])
        if self.reg.get("registry_hash"):
            self.assertEqual(self.reg["registry_hash"], self.reg["computed_hash"])

    def test_every_contract_passes_and_refuses(self) -> None:
        for cid, e in self.reg["contracts"].items():
            with self.subTest(contract=cid):
                r = C.validate_payload(cid, e["examples"]["valid"], registry=self.reg)
                self.assertEqual(r["verdict"], "VALID")
                self.assertEqual(r["contract_version"], e["version"])
                for i, bad in enumerate(e["examples"]["invalid"]):
                    with self.subTest(contract=cid, invalid=i):
                        with self.assertRaises(lga.AdapterError) as ctx:
                            C.validate_payload(cid, bad["payload"], registry=self.reg)
                        self.assertEqual(ctx.exception.code, bad["expect_code"], f"{cid} invalid[{i}] ({bad.get('why')}): {ctx.exception}")

    def test_registration_rows_shape(self) -> None:
        rows = C.registration_rows(self.reg)
        self.assertEqual(len(rows), len(self.reg["contracts"]))
        for row in rows:
            for k in ("record_schema", "schema_name", "schema_version", "sophia_meaning", "landon_binding", "professor_validation", "podium_admission"):
                self.assertIn(k, row)
            self.assertEqual(row["record_schema"], "tables.schemas/SchemaRegistryRecord")

    def test_unknown_contract_and_unknown_fields_refused(self) -> None:
        with self.assertRaises(lga.AdapterError) as ctx:
            C.validate_payload("no_such_contract", {}, registry=self.reg)
        self.assertEqual(ctx.exception.code, "contract.unknown")
        cid = next(iter(self.reg["contracts"]))
        payload = copy.deepcopy(self.reg["contracts"][cid]["examples"]["valid"])
        if isinstance(payload, dict):
            payload["__injected__"] = 1
            with self.assertRaises(lga.AdapterError) as ctx:
                C.validate_payload(cid, payload, registry=self.reg)
            self.assertEqual(ctx.exception.code, "schema.invalid")

    def test_registry_defects_fail_closed(self) -> None:
        broken = copy.deepcopy(self.reg)
        cid = next(iter(broken["contracts"]))
        broken["contracts"][cid]["schema"] = {"type": "object", "bogusKeyword": True}
        with self.assertRaises(lga.AdapterError) as ctx:
            C.validate(broken["contracts"][cid]["schema"], {}, registry=broken)
        self.assertEqual(ctx.exception.code, "registry.invalid")


class TestControls(unittest.TestCase):
    """Controls named by registry entries must exist and honour their declared semantics."""

    def test_named_controls_exist(self) -> None:
        reg = C.load_registry()
        for cid, e in reg["contracts"].items():
            for fn in e.get("controls", []):
                with self.subTest(contract=cid, control=fn):
                    mod, _, name = fn.rpartition(".")
                    import importlib
                    module = importlib.import_module(f"adapters.{mod or 'controls'}")
                    self.assertTrue(callable(getattr(module, name, None)), f"{cid}: control {fn} not found")

    def test_state_machine(self) -> None:
        if "run_state_machine" not in C.load_registry()["contracts"]:
            self.skipTest("run_state_machine not yet registered")
        h = "sha256:" + "a" * 64
        K.validate_transition("INTAKE", "BOUND", {"worktree_hash": h})
        seq = ["INTAKE", "BOUND", "INTENT_ACCEPTED", "PLANNED", "PATCH_INERT", "VERIFIED", "REVIEW_PENDING", "APPROVED", "APPLIED_ISOLATED", "ARCHIVED", "ROLLED_BACK"]
        ev = [{}, {"worktree_hash": h}, {"scope_contract_hash": h}, {"plan_hash": h}, {"patch_hash": h}, {"report_hash": h}, {"card_hash": h}, {"receipt_hash": h}, {"applied_record_hash": h}, {"manifest_hash": h}, {}]
        self.assertEqual(len(K.validate_sequence(seq, ev)), 10)
        for frm, to, evd, code in [("INTAKE", "APPROVED", {}, "state.transition_denied"), ("BLOCKED", "BOUND", {}, "state.terminal"), ("REVIEW_PENDING", "APPROVED", {}, "state.evidence_missing"), ("INTAKE", "NOPE", {}, "state.unknown"), ("VERIFIED", "APPLIED_ISOLATED", {}, "state.transition_denied")]:
            with self.assertRaises(lga.AdapterError) as ctx:
                K.validate_transition(frm, to, evd)
            self.assertEqual(ctx.exception.code, code)

    def test_idempotency(self) -> None:
        if "idempotency_key" not in C.load_registry()["contracts"]:
            self.skipTest("idempotency_key not yet registered")
        run = "sha256:" + "b" * 64
        k1 = K.idempotency_key(run, "bind", {"revision": "HEAD"})
        self.assertEqual(k1, K.idempotency_key(run, "bind", {"revision": "HEAD"}))
        self.assertNotEqual(k1, K.idempotency_key(run, "bind", {"revision": "main"}))
        ledger = [{"idempotency_key": k1, "result_hash": "sha256:" + "c" * 64}]
        self.assertEqual(K.replay_check([], k1, "sha256:" + "c" * 64), "EXECUTE")
        self.assertEqual(K.replay_check(ledger, k1, "sha256:" + "c" * 64), "REPLAY_SAME")
        with self.assertRaises(lga.AdapterError) as ctx:
            K.replay_check(ledger, k1, "sha256:" + "d" * 64)
        self.assertEqual(ctx.exception.code, "idempotency.conflict")
        with self.assertRaises(lga.AdapterError):
            K.idempotency_key("not-a-digest", "bind", {})

    def test_versioning(self) -> None:
        if "contract_versioning" not in C.load_registry()["contracts"]:
            self.skipTest("contract_versioning not yet registered")
        self.assertEqual(K.compatibility("0.1.0", "0.1.3"), "COMPATIBLE")
        self.assertEqual(K.compatibility("0.2.0", "0.1.3"), "NEEDS_UPGRADE")
        self.assertEqual(K.compatibility("1.0.0", "0.9.9"), "INCOMPATIBLE")
        with self.assertRaises(lga.AdapterError) as ctx:
            K.require_compatible("1.0.0", "0.1.0")
        self.assertEqual(ctx.exception.code, "version.incompatible")
        with self.assertRaises(lga.AdapterError):
            K.parse_semver("v1")


if __name__ == "__main__":
    unittest.main()
