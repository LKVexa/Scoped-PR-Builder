"""Guardrail regression suite (Phase 02 / PAPER-GRD-*-T05; stdlib unittest), driven by tests/scenarios/guardrails.json.

For every rule: a positive case (allowed path admitted at the orchestration boundary), a negative case (the rule's
own deny example) and a deliberate violation built from real artifacts (oversized candidate, added file, core change
without a human, rejected review). Every outcome — admitted or refused — must leave a complete provenance/audit
receipt: the guardrail decision rows, the crossing row (ADMITTED with decision hashes, or DENIED with code, class and
reason), the provenance link for admitted crossings, and a chained row on the test/evidence ledger.
"""
from __future__ import annotations

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from adapters import approval_adapter as aa  # noqa: E402
from adapters import architecture as A  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import guardrails as G  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import wiring as W  # noqa: E402
import evidence_ledger as EL  # noqa: E402
from test_guardrails_composition import ADDED_FILE_PATCH, CORE_PATCH, Fixture  # noqa: E402

REPO_ROOT = HERE.parent.parent
SCENARIOS = HERE / "scenarios" / "guardrails.json"


def _identity(reg):
    return copy.deepcopy(reg["contracts"]["api_envelope"]["examples"]["valid"]["identity"])


class TestGuardrailRegression(Fixture):
    def setUp(self) -> None:
        self.b = A.load_boundaries(registry=self.reg)
        self.w = W.load_wiring(boundaries=self.b, registry=self.reg)
        self.rtmp = tempfile.TemporaryDirectory()

    def tearDown(self) -> None:
        self.rtmp.cleanup()

    def _run(self, name):
        return W.Run(Path(self.rtmp.name) / name, _identity(self.reg), repo_root=REPO_ROOT, registry=self.reg, boundaries=self.b, wiring=self.w)

    def _facts(self, rid, source):
        r = self.rules["rules"][rid]
        if source.startswith("rule.examples."):
            return copy.deepcopy(r["examples"][source.split(".")[-1]])
        if source == "fixture:real_candidate":
            return G.facts_bounded_size(self.cand, self.contract)
        if source == "fixture:oversized_candidate":
            return G.facts_bounded_size(dict(self.cand, files_changed=30, lines_added=300, lines_deleted=300), self.contract)
        if source == "fixture:real_patch":
            return G.facts_structure_change(self.patch.decode(), self.contract)
        if source == "fixture:added_file_patch":
            return G.facts_structure_change(ADDED_FILE_PATCH, self.contract)
        if source == "fixture:real_impact":
            return G.facts_core_logic(self.patch.decode(), self.context.symbols, self.context.dependencies)
        if source == "fixture:core_patch_no_human":
            return G.facts_core_logic(CORE_PATCH, self.context.symbols, self.context.dependencies)
        if source == "fixture:approved_receipt":
            return G.facts_explicit_review(self.receipt("APPROVE"), candidate=self.cand, card=self.card, report=self.report, run_dir=self.run_dir, key=self.key)
        if source == "fixture:rejected_receipt":
            return G.facts_explicit_review(self.receipt("REJECT"), candidate=self.cand, card=self.card, report=self.report, run_dir=self.run_dir, key=self.key)
        # Phase 03 capability fixtures
        if source == "fixture:real_contract":
            return G.facts_scope_intent(self.contract)
        if source == "fixture:contract_tampered":
            return G.facts_scope_intent(dict(self.contract, max_diff_lines=self.contract["max_diff_lines"] + 1))
        if source == "fixture:real_plan_evidence":
            return G.facts_analogous_evidence(self.bundle, self.plan)
        if source == "fixture:plan_invented_refs":
            p = copy.deepcopy(self.plan); p["operations"][0]["guided_by_examples"] = ["sha256:" + "e" * 64]
            return G.facts_analogous_evidence(self.bundle, p)
        if source == "fixture:real_candidate_atomic":
            return G.facts_atomic_bounded_diff(self.cand)
        if source == "fixture:candidate_two_recipes":
            return G.facts_atomic_bounded_diff(dict(self.cand, recipe="regenerate_sha256sums_manifest+rename_module"))
        if source == "fixture:real_report":
            return G.facts_halt_on_failure(self.report, self.plan)
        if source == "fixture:failed_report":
            r = copy.deepcopy(self.report); r["verdict"] = "FAIL"; r["jobs"][0]["verdict"] = "FAIL"; r["jobs"][0]["summary"] = "patch does not apply to the pinned revision"
            return G.facts_halt_on_failure(r, self.plan)
        if source == "fixture:failed_report_silent":
            r = copy.deepcopy(self.report); r["verdict"] = "FAIL"
            return G.facts_halt_on_failure(r, self.plan)
        if source == "fixture:real_plan_gaps":
            return G.facts_knowledge_gaps(self.plan)
        if source == "fixture:plan_unsupported_claim":
            p = copy.deepcopy(self.plan); p["operations"][0]["guided_by_examples"] = []
            return G.facts_knowledge_gaps(p)
        raise AssertionError(f"unknown facts source {source}")

    def _all_pass_except(self, effect, rid, facts):
        out = {r: self.rules["rules"][r]["examples"]["pass"] for r, rr in self.rules["rules"].items() if effect in rr["evaluates_on"]}
        out[rid] = facts
        return out

    def _receipt_for(self, run, rid, outcome, decisions_or_exc, crossing=None):
        """Assemble and check the completeness of the provenance/audit receipt for one outcome."""
        audit = run.audit_entries()
        evals = [a for a in audit if a["effect"] == "guardrail.evaluate" and a["rule_id"] == rid]
        self.assertTrue(evals, f"{rid}/{outcome}: no guardrail decision row on the audit ledger")
        last = audit[-1]
        rec = {"rule_id": rid, "outcome": outcome, "decision_rows": [e["entry_hash"] for e in evals], "decision_hashes": [e["decision_hash"] for e in evals], "run_id": run.identity["run_id"], "provenance_head": run.provenance_head}
        if outcome == "admitted":
            self.assertEqual(last["verdict"], "ADMITTED")
            self.assertTrue(set(rec["decision_hashes"]) & set(last["guardrail_decisions"]))
            self.assertIsNotNone(crossing["provenance_link"])
            rec.update(crossing_row=last["entry_hash"], provenance_link=crossing["provenance_link"]["entry_hash"], trace_vector=crossing["provenance_link"]["trace_vector"])
        else:
            self.assertEqual(last["verdict"], "DENIED"); self.assertTrue(last["denial_code"].startswith("guardrail."))
            self.assertTrue(last["reason"] and last["denial_class"] in W.FAILURE_CLASSES and last["fail_closed"])
            rec.update(denial_row=last["entry_hash"], denial_code=last["denial_code"], denial_class=last["denial_class"], reason=last["reason"])
        rec["receipt_hash"] = lga.sha256_digest(lga.canonical_json(rec))
        p = Path(run.run_dir) / "guardrails" / f"regression-{rid}-{outcome}.json"
        p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(rec, indent=2, sort_keys=True), encoding="utf-8")
        row = EL.record(f"guardrail:{rid}:{outcome}", "guardrail_regression", "PASS", rec)
        self.assertRegex(row["entry_hash"], r"^sha256:[0-9a-f]{64}$")
        return rec

    def test_regression_scenarios(self) -> None:
        scen = json.loads(SCENARIOS.read_text(encoding="utf-8")).get("scenarios", {}) if SCENARIOS.is_file() else {}
        if not scen:
            self.skipTest("no guardrail regression scenarios yet")
        for sid, sc in scen.items():
            rid = sc["rule_id"]
            if sc.get("path") == "effect_boundary":
                continue  # exercised by test_effect_boundary_receipts (the effect is never admitted at a port)
            with self.subTest(scenario=sid):
                bid, effect = sc["boundary_id"], sc["effect"]
                ex = self.b["boundaries"][bid]["examples"]["valid"]
                # positive: allowed path admitted with a complete receipt
                run = self._run(f"{rid}-pos")
                out = run.cross(bid, effect, ex["payload_contract"], ex.get("payload"), direction=ex["direction"], guardrail_facts=self._all_pass_except(effect, rid, self._facts(rid, sc["positive"]["facts"])))
                self.assertEqual(out["crossing"]["verdict"], "ADMITTED")
                self._receipt_for(run, rid, "admitted", out["guardrail_decisions"], crossing=out)
                # negative + deliberate violation: refused with a complete receipt
                for label, case in (("negative", sc["negative"]), ("deliberate_violation", sc["deliberate_violation"])):
                    run = self._run(f"{rid}-{label}")
                    with self.assertRaises(G.GuardrailRefusal) as ctx:
                        run.cross(bid, effect, ex["payload_contract"], ex.get("payload"), direction=ex["direction"], guardrail_facts=self._all_pass_except(effect, rid, self._facts(rid, case["facts"])))
                    self.assertEqual(ctx.exception.code, case["expect"], f"{sid}/{label}")
                    self.assertTrue(any(d["rule_id"] == rid and d["state"] == case["state"] for d in ctx.exception.decisions))
                    self._receipt_for(run, rid, label, ctx.exception.decisions)
                    self.assertEqual(len(run._provenance_links()), 0, "a refused crossing must not extend provenance")
        self.assertGreaterEqual(EL.verify(), 3 * len([s for s in scen.values() if s.get("path") != "effect_boundary"]))

    def test_effect_boundary_receipts(self) -> None:
        """Positive and violating outcomes at the effect boundary leave persisted decision sets (GRD-04 via a rejected review)."""
        scen = json.loads(SCENARIOS.read_text(encoding="utf-8")).get("scenarios", {}) if SCENARIOS.is_file() else {}
        if "guardrail:GRD-04" not in scen:
            self.skipTest("GRD-04 regression not yet declared")
        base = Path(self.rtmp.name)
        sc = scen["guardrail:GRD-04"]
        # positive: approved review -> all four rules PASS at the effect boundary; real isolated apply; decisions persisted
        rc = self.receipt("APPROVE")
        run_pos = self._run("GRD-04-pos")
        facts = G.apply_time_facts(self.binding, self.contract, self.cand, self.patch, self.card, self.report, rc, self.run_dir, self.key)
        decisions = G.enforce("patch.apply_isolated", facts, run=run_pos, registry=self.reg)
        self.assertTrue(all(d["state"] == "PASS" for d in decisions))
        rec = aa.apply_isolated(binding=self.binding, contract=self.contract, candidate=self.cand, patch=self.patch, report=self.report, card=self.card, receipt=rc, key=self.key, run_dir=self.run_dir, worktree_parent=base / "applied")
        lga.worktree_remove(self.root, Path(rec.applied_worktree))
        saved = json.loads((self.run_dir / "guardrails" / f"patch_apply_isolated-{self.cand['candidate_id'][7:19]}.json").read_text())
        self.assertEqual(saved["decisions_hash"], rec.guardrails_hash)
        pos = {"rule_id": "GRD-04", "outcome": "admitted", "decision_rows": [a["entry_hash"] for a in run_pos.audit_entries()], "persisted_decisions": saved["decisions_hash"], "applied_record": rec.record_hash}
        pos["receipt_hash"] = lga.sha256_digest(lga.canonical_json(pos))
        self.assertGreaterEqual(len(pos["decision_rows"]), 4)  # Phase 03 adds capability rules at apply
        EL.record("guardrail:GRD-04:admitted", "guardrail_regression", "PASS", pos)
        # negative + deliberate violation: a rejected review -> GRD-04 DENY; refusal audited; no worktree; decisions persisted
        rej = self.receipt("REJECT")
        run_neg = self._run("GRD-04-neg")
        facts = G.apply_time_facts(self.binding, self.contract, self.cand, self.patch, self.card, self.report, rej, self.run_dir, self.key)
        with self.assertRaises(G.GuardrailRefusal) as ctx:
            G.enforce("patch.apply_isolated", facts, run=run_neg, registry=self.reg)
        self.assertEqual(ctx.exception.code, sc["deliberate_violation"]["expect"])
        denied = G.record_decisions(self.run_dir, "patch.apply_isolated", "sha256:" + "d" * 64, ctx.exception.decisions)
        self.assertEqual([d["state"] for d in denied["decisions"] if d["rule_id"] == "GRD-04"], ["DENY"])
        rows = run_neg.audit_entries()
        self.assertTrue(any(r["rule_id"] == "GRD-04" and r["verdict"] == "DENY" and r["reason"] for r in rows))
        neg = {"rule_id": "GRD-04", "outcome": "deliberate_violation", "decision_rows": [a["entry_hash"] for a in rows], "persisted_decisions": denied["decisions_hash"], "denial_code": ctx.exception.code, "reason": str(ctx.exception)}
        neg["receipt_hash"] = lga.sha256_digest(lga.canonical_json(neg))
        EL.record("guardrail:GRD-04:deliberate_violation", "guardrail_regression", "PASS", neg)
        with self.assertRaises(lga.AdapterError):
            aa.apply_isolated(binding=self.binding, contract=self.contract, candidate=self.cand, patch=self.patch, report=self.report, card=self.card, receipt=rej, key=self.key, run_dir=self.run_dir, worktree_parent=base / "applied-rej")
        self.assertFalse((base / "applied-rej").exists())


if __name__ == "__main__":
    unittest.main()
