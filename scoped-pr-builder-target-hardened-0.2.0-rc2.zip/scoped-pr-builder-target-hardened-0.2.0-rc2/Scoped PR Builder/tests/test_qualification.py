"""Test and adversarial qualification (Phase 12 / TEST-*; stdlib unittest), driven by qualification/MATRIX.json.

T01: the matrix is well formed — one named scenario per mandatory requirement, each with a declared deterministic fixture,
a bound harness function, a Tables/08 registration row and existing authoritative suites; fixtures are deterministic.
T02: every declared scenario runs in its own isolated world (fixture repository, run directory outside it, per-run key),
over pinned tool/model/contract versions, with a fixed seed and timeout and no undeclared network, and leaves a chained
Filing Cabinet 12 row. T03: each scenario asserts its exact declared outcome. T04: the first failure is stored with its
replay metadata, and an indeterminate or skipped mandatory scenario is never read as a pass. T05: every scenario is in the
offline regression gate, and the production-readiness receipt cannot be issued until the gate PROCEEDs.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import time
import traceback
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import evidence_ledger as EL  # noqa: E402
import qualification_harness as H  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import qualification as Q  # noqa: E402
from adapters import security as SEC  # noqa: E402

ONLY = os.environ.get("SPB_QUALIFICATION_ONLY")


class TestMatrix(unittest.TestCase):
    """T01: the matrix and its named fixtures."""

    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.matrix = Q.load_matrix(registry=self.reg)

    def test_matrix_is_well_formed_and_registers_tables_rows(self) -> None:
        self.assertEqual(self.matrix["matrix_version"], Q.MATRIX_VERSION)
        self.assertTrue(self.matrix["computed_hash"].startswith("sha256:"))
        for sid, s in self.matrix["scenarios"].items():
            with self.subTest(scenario=sid):
                self.assertIn(s["kind"], Q.KINDS); self.assertIn(s["fixture"], Q.FIXTURE_NAMES); self.assertIn(s["fixture"], H.FIXTURES)
                self.assertTrue(all((Q.REPO_ROOT / f).is_file() for f in s["authoritative_suites"]))
                self.assertEqual(s["tables_row"]["record_schema"], "tables.test_matrices/TestMatrixRow")
                self.assertTrue(s["tables_row"]["test_name"]); self.assertTrue(s["requirement"])
                self.assertEqual(Q.scenario(sid, self.matrix)["scenario_id"], sid)
        rows = Q.tables_rows(self.matrix)
        self.assertEqual(len(rows), len(self.matrix["scenarios"]))
        self.assertEqual([r["case_id"] for r in rows], sorted(r["case_id"] for r in rows))
        self.assertEqual(sorted(Q.mandatory_scenarios(self.matrix)), sorted(sid for sid, s in self.matrix["scenarios"].items() if s["mandatory"]))

    def test_matrix_defects_fail_closed(self) -> None:
        import copy
        raw = json.loads(Q.MATRIX_PATH.read_text(encoding="utf-8"))
        first = next(iter(raw["scenarios"]))
        tmp = Path(tempfile.mkdtemp())
        for mutate, code in ((lambda m: m["scenarios"][first].__setitem__("kind", "smoke"), "qualification.matrix_invalid"),
                             (lambda m: m["scenarios"][first].__setitem__("fixture", "whatever"), "qualification.matrix_invalid"),
                             (lambda m: m["scenarios"][first]["authoritative_suites"].append("Nope/00.ja"), "qualification.suite_unbound"),
                             (lambda m: m["scenarios"][first].pop("mandatory"), "qualification.matrix_invalid"),
                             (lambda m: m.__setitem__("matrix_version", "x/9.9.9"), "qualification.matrix_invalid")):
            m = copy.deepcopy(raw); mutate(m); p = tmp / "MATRIX.json"; p.write_text(json.dumps(m), encoding="utf-8")
            with self.subTest(code=code):
                with self.assertRaises(Q.QualificationRefusal) as ctx:
                    Q.load_matrix(p, registry=self.reg)
                self.assertEqual(ctx.exception.code, code)
        with self.assertRaises(Q.QualificationRefusal) as ctx:
            Q.load_matrix(tmp / "missing.json", registry=self.reg)
        self.assertEqual(ctx.exception.code, "qualification.matrix_missing")
        with self.assertRaises(Q.QualificationRefusal) as ctx:
            Q.scenario("TEST-NOPE-99", self.matrix)
        self.assertEqual(ctx.exception.code, "qualification.scenario_unknown")

    def test_named_fixtures_are_deterministic_and_isolated(self) -> None:
        used = sorted({s["fixture"] for s in self.matrix["scenarios"].values()})
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            for name in used:
                with self.subTest(fixture=name):
                    a = H.FIXTURES[name](base / f"{name}-a"); b = H.FIXTURES[name](base / f"{name}-b")
                    ta = lga.tree_identity(a, lga.git(a, "rev-parse", "HEAD")); tb = lga.tree_identity(b, lga.git(b, "rev-parse", "HEAD"))
                    self.assertEqual(ta, tb, f"{name} is not deterministic")
                    run_dir = base / f"{name}-run"
                    self.assertTrue(Q.assert_isolated(a, run_dir)["isolated"])
                    with self.assertRaises(Q.QualificationRefusal) as ctx:
                        Q.assert_isolated(a, a / "inside")
                    self.assertEqual(ctx.exception.code, "qualification.not_isolated")
            with self.assertRaises(Q.QualificationRefusal) as ctx:
                Q.assert_isolated(Q.REPO_ROOT, base / "elsewhere")
            self.assertIn(ctx.exception.code, ("qualification.not_isolated", "qualification.fixture_invalid"))


class TestScenarios(unittest.TestCase):
    """T02–T04: every declared scenario runs isolated, pinned and network-free; asserts its exact outcome; stores its
    first failure with replay metadata; and never reads an indeterminate mandatory scenario as a pass."""

    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.matrix = Q.load_matrix(registry=self.reg)
        self.pins = H.pinned_versions(self.reg)
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.store = self.base / "qualification-run"; self.store.mkdir()
        self.rows = 0

    def tearDown(self) -> None:
        SEC.use_trail(None)
        self.tmp.cleanup()

    def scenarios(self) -> list[str]:
        ids = sorted(self.matrix["scenarios"])
        return [s for s in ids if s == ONLY] if ONLY else ids

    def run_one(self, sid: str) -> dict:
        entry = Q.scenario(sid, self.matrix)
        runtime = Q.runtime_of(entry)
        started = time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime())
        iso = H.Isolation(self.base / sid.lower(), self.reg, entry["fixture"])
        isolation = Q.assert_isolated(iso.root, iso.run_dir)
        before = iso.identity()
        fn = H.SCENARIOS.get(entry["harness"])
        self.assertIsNotNone(fn, f"{sid}: harness {entry['harness']!r} is not bound")
        observed: dict = {}
        try:
            with H.NetworkGuard() as guard:
                extra = fn(iso)
            observed = H.observe(iso, before, network=guard, extra=extra)
            asserter = getattr(Q, "assert_outcome", None)  # bound at T03; the expectation itself is declared per scenario
            assertion = asserter(entry, observed) if asserter and entry.get("expect") else {"asserted": [], "checks": {}, "assertion_hash": lga.sha256_digest(lga.canonical_json(observed))}
            verdict = "PASS"
        except Exception as exc:  # noqa: BLE001 — the harness converts any failure into a stored first failure
            if not observed:
                try:
                    observed = H.observe(iso, before)
                except Exception:  # noqa: BLE001
                    observed = {"state": iso.run.state, "provenance": {"ledgers": {}, "chains_verified": True}}
            store_first = getattr(Q, "record_failure", None)  # bound at T04
            stored = store_first(self.store, entry, verdict="FAIL", reason=str(exc)[:400], observed=observed, pins=self.pins, runtime=runtime, isolation=isolation,
                                 output=traceback.format_exc()[-4000:], logs={"steps": json.dumps(observed.get("steps", []))[:2000]}) if store_first else None
            Q.record_run(self.store, entry, observed, verdict="FAIL", pins=self.pins, runtime=runtime, isolation=isolation, started_at=started, finished_at=time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime()))
            hint = f"; first failure stored: replay {stored['replay']['replay_id'][:23]} via {stored['replay']['command']}" if stored else ""
            raise self.failureException(f"{sid}: {exc}{hint}") from exc
        row = Q.record_run(self.store, entry, observed, verdict=verdict, pins=self.pins, runtime=runtime, isolation=isolation, started_at=started, finished_at=time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime()))
        gate_id = getattr(Q, "gate_scenario_id", None)  # bound at T05
        EL.record(gate_id(sid, self.matrix) if gate_id else f"qualification:{sid}@{self.matrix['computed_hash'][7:39]}", getattr(Q, "EVIDENCE_KIND", "qualification_scenario"), verdict, {"scenario_id": sid, "kind": entry["kind"], "mandatory": entry["mandatory"], "asserted": assertion["asserted"],
                                                                                   "assertion_hash": assertion["assertion_hash"], "environment_hash": row["environment"]["environment_hash"],
                                                                                   "replay_id": row["r12_replay_id"], "state": observed["state"], "network_attempts": observed["network_attempts"]})
        self.rows += 1
        return {"entry": entry, "observed": observed, "assertion": assertion, "row": row}

    def test_every_declared_scenario_runs_isolated_pinned_and_asserted(self) -> None:
        ids = self.scenarios()
        self.assertTrue(ids, "the matrix declares no scenarios")
        for sid in ids:
            with self.subTest(scenario=sid):
                out = self.run_one(sid)
                self.assertEqual(out["observed"]["network_attempts"], 0)
                self.assertTrue(out["observed"]["provenance"]["chains_verified"])
                self.assertEqual(out["row"]["podium_certification"], "PASS")
                self.assertEqual(out["row"]["environment"]["pins"]["matrix_hash"], self.matrix["computed_hash"])
                if getattr(Q, "assert_outcome", None) and Q.scenario(sid, self.matrix).get("expect"):
                    self.assertTrue(out["assertion"]["asserted"], f"{sid} asserted nothing")
        rows = Q.cabinet_rows(self.store)
        self.assertEqual(len(rows), len(ids))
        self.assertEqual(sorted(r["sophia_event"] for r in rows), sorted(ids))
        self.assertGreaterEqual(EL.verify(), self.rows)

    def test_expectations_are_exact_and_cover_the_declared_dimensions(self) -> None:
        covered = set()
        declared = {sid: s for sid, s in self.matrix["scenarios"].items() if s.get("expect")}
        if not declared:
            self.skipTest("no expectations declared yet")
        for sid, s in declared.items():
            exp = Q.expectation_of(s)
            covered |= set(exp)
            with self.subTest(scenario=sid):
                self.assertIn("state", exp)
                self.assertFalse(set(exp) - set(Q.EXPECT_KEYS))
        if len(declared) == len(self.matrix["scenarios"]):
            self.assertTrue({"state", "changed_paths", "approval_decisions", "diagnostics", "source_tree_unchanged", "evidence_closure", "rollback"} <= covered,
                            f"the matrix as a whole must assert every dimension; covered {sorted(covered)}")
        entry = Q.scenario(sorted(declared)[0], self.matrix)
        good = {"state": entry["expect"]["state"], "effects": {"granted": [], "denied": []}, "changed_paths": [], "evidence": {}, "approval": {"decisions": [], "applied": False},
                "diagnostics": [], "provenance": {"chains_verified": True}, "source_tree_unchanged": True, "rollback": {"worktrees_cleaned": True}}
        with self.assertRaises(Q.QualificationRefusal) as ctx:
            Q.assert_outcome(entry, dict(good, state="SOMETHING_ELSE"))
        self.assertEqual(ctx.exception.code, "qualification.expectation_unmet")
        with self.assertRaises(Q.QualificationRefusal) as ctx:
            Q.assert_outcome(entry, dict(good, provenance={"chains_verified": False}))
        self.assertEqual(ctx.exception.code, "qualification.expectation_unmet")
        with self.assertRaises(Q.QualificationRefusal) as ctx:
            Q.expectation_of(dict(entry, expect={}))
        self.assertEqual(ctx.exception.code, "qualification.matrix_invalid")

    def test_first_failure_is_stored_and_non_pass_is_never_promoted(self) -> None:
        entry = Q.scenario(sorted(self.matrix["scenarios"])[0], self.matrix)
        runtime = Q.runtime_of(entry)
        isolation = {"repository": str(self.base / "r"), "run_dir": str(self.store), "isolated": True}
        observed = {"state": "BLOCKED", "provenance": {"ledgers": {"workflow_steps": "sha256:" + "1" * 64}, "chains_verified": True}, "workspace": {"tree_identity": "sha256:" + "2" * 64, "head": "a" * 40, "status_hash": "sha256:" + "3" * 64}, "steps": []}
        first = Q.record_failure(self.store, entry, verdict="FAIL", reason=f"token {H.GH} in the message", observed=observed, pins=self.pins, runtime=runtime, isolation=isolation, output="traceback here", logs={"stderr": "boom"})
        self.assertEqual(first["scenario_id"], entry["scenario_id"]); self.assertTrue(first["replay"]["replay_id"].startswith("sha256:"))
        self.assertEqual(first["environment"]["environment_hash"], Q.environment_identity(self.pins)["environment_hash"])
        self.assertEqual(first["replay"]["fixture"], entry["fixture"]); self.assertEqual(first["replay"]["seed"], runtime["seed"]); self.assertIn(entry["scenario_id"], first["replay"]["command"])
        self.assertEqual(first["hashes"]["ledgers"], observed["provenance"]["ledgers"]); self.assertEqual(first["observed_hash"], lga.sha256_digest(lga.canonical_json(observed)))
        self.assertNotIn(H.GH, json.dumps(first), "a stored failure never carries secret material")
        second = Q.record_failure(self.store, entry, verdict="FAIL", reason="a later, different failure", observed=observed, pins=self.pins, runtime=runtime, isolation=isolation)
        self.assertEqual(second["reason"], first["reason"], "the FIRST failure is kept")
        self.assertEqual(second["repeat_count"], 2); self.assertEqual(len(Q.failures(self.store)), 1)
        for verdict in ("INDETERMINATE", "SKIPPED", "BLOCKED", "FAIL"):
            with self.subTest(verdict=verdict):
                v = Q.verdict_of(entry, verdict, reason="not executed")
                self.assertFalse(v["passed"]); self.assertTrue(v["release_blocking"], f"a mandatory {verdict} must block")
                with self.assertRaises(Q.QualificationRefusal) as ctx:
                    Q.require_pass(entry, verdict, reason="not executed")
                self.assertEqual(ctx.exception.code, "qualification.mandatory_not_passed")
        self.assertTrue(Q.verdict_of(entry, "PASS")["passed"])
        self.assertFalse(Q.verdict_of(dict(entry, mandatory=False), "SKIPPED")["release_blocking"])
        with self.assertRaises(Q.QualificationRefusal):
            Q.verdict_of(entry, "GREEN")


class TestOfflineGate(unittest.TestCase):
    """T05: the offline regression gate over the tool's own evidence ledger, and the production-readiness receipt."""

    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.matrix = Q.load_matrix(registry=self.reg)
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self._n = 0

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def ledger_with(self, *, verdict="PASS", matrix=None, only=None) -> Path:
        self._n += 1
        p = self.base / f"ledger-{self._n}.jsonl"
        m = matrix or self.matrix
        for sid in (only if only is not None else sorted(m["scenarios"])):
            EL.record(Q.gate_scenario_id(sid, m), Q.EVIDENCE_KIND, verdict, {"scenario_id": sid}, path=p)
        return p

    def test_every_scenario_is_mandatory_in_the_offline_gate(self) -> None:
        self.assertEqual(sorted(Q.mandatory_scenarios(self.matrix)), sorted(self.matrix["scenarios"]), "every qualification scenario is mandatory for release")
        from adapters import verification_runner as vr
        defs = json.loads(vr.REGRESSION_PATH.read_text(encoding="utf-8"))
        reg04 = [c for c in defs["checks"] if c["id"] == "REG-04"]
        self.assertTrue(reg04, "REG-04 must re-run the qualification suite when the overlay changes")
        self.assertIn("test_qualification.py", " ".join(reg04[0]["argv"]))
        self.assertTrue(any(p.startswith("Scoped PR Builder/") for p in reg04[0]["applies_to"]))

    def test_gate_blocks_missing_stale_failed_and_waivers(self) -> None:
        d = Q.offline_gate(ledger=self.base / "none.jsonl", matrix=self.matrix)
        self.assertEqual(d["decision"], "BLOCK"); self.assertTrue(all(v["status"] == "missing" for v in d["per_scenario"].values()))
        stale = dict(self.matrix, computed_hash="sha256:" + "7" * 64)
        d = Q.offline_gate(ledger=self.ledger_with(matrix=stale), matrix=self.matrix)
        self.assertTrue(all(v["status"] == "stale" for v in d["per_scenario"].values()))
        d = Q.offline_gate(ledger=self.ledger_with(verdict="FAIL"), matrix=self.matrix)
        self.assertTrue(all(v["status"] == "failed" for v in d["per_scenario"].values()))
        partial = sorted(self.matrix["scenarios"])[:-1]
        d = Q.offline_gate(ledger=self.ledger_with(only=partial), matrix=self.matrix)
        self.assertEqual(d["decision"], "BLOCK"); self.assertEqual(d["blocking"], [sorted(self.matrix["scenarios"])[-1]])
        good = self.ledger_with()
        d = Q.offline_gate(ledger=good, matrix=self.matrix)
        self.assertEqual(d["decision"], "PROCEED", d["per_scenario"]); self.assertEqual(d["blocking"], [])
        for waiver in ({"skip_qualification": True}, {"waive": "TEST-ADV-01"}, {"bypass_gate": 1}, {"qualification": "ignore"}):
            d = Q.offline_gate(ledger=good, matrix=self.matrix, inputs=waiver)
            self.assertEqual(d["decision"], "BLOCK", waiver); self.assertIn("WAIVER", d["blocking"])
        with self.assertRaises(Q.QualificationRefusal) as ctx:
            Q.require_offline_gate(stage="release", ledger=self.base / "none.jsonl", matrix=self.matrix)
        self.assertEqual(ctx.exception.code, "qualification.offline_gate_blocked")

    def test_readiness_receipt_only_over_a_passing_gate(self) -> None:
        with self.assertRaises(Q.QualificationRefusal) as ctx:
            Q.production_readiness_receipt(ledger=self.base / "none.jsonl", matrix=self.matrix)
        self.assertEqual(ctx.exception.code, "qualification.readiness_blocked")
        r = Q.production_readiness_receipt(ledger=self.ledger_with(), matrix=self.matrix, pins=H.pinned_versions(self.reg))
        self.assertEqual(r["readiness_version"], Q.READINESS_VERSION); self.assertTrue(r["receipt_hash"].startswith("sha256:"))
        self.assertEqual(sorted(r["mandatory_scenarios"]), sorted(self.matrix["scenarios"]))
        self.assertTrue(all(v == "satisfied" for v in r["per_scenario"].values())); self.assertIn("approves nothing", r["authority"])
        with self.assertRaises(Q.QualificationRefusal):
            Q.production_readiness_receipt(ledger=self.ledger_with(), matrix=self.matrix, inputs={"skip_gate": True})

    def test_the_tools_own_ledger_satisfies_the_gate(self) -> None:
        """The tool's own archived receipts must be current for every mandatory scenario. On a fresh overlay the receipts
        do not exist yet — they are written by running this suite with SPB_EVIDENCE_LEDGER pointed at the overlay ledger,
        which is exactly what the phase close does; until then there is nothing to certify, never a silent pass."""
        d = Q.offline_gate(matrix=self.matrix)
        if all(v["status"] == "missing" for v in d["per_scenario"].values()):
            self.skipTest("qualification receipts not archived yet (run with SPB_EVIDENCE_LEDGER to record them)")
        self.assertEqual(d["decision"], "PROCEED", {k: v for k, v in d["per_scenario"].items() if v["status"] != "satisfied"})


if __name__ == "__main__":
    unittest.main()
