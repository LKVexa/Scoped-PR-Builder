"""Documentation deliverables: generated from the registries, and refused when they no longer match (T01–T05).

The tests run against the real registries, because a document generated from fixtures would prove nothing about
whether this tool's documentation describes this tool.
"""

from __future__ import annotations

import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from adapters import contracts as C  # noqa: E402
from adapters import documentation as DOC  # noqa: E402

_S: dict = {}


def _state():
    if not _S:
        reg = C.load_registry()
        _S.update({"reg": reg, "docs": DOC.load_docs(registry=reg)})
    return _S


def _sandbox(overlay_only: bool = True) -> Path:
    """A throwaway overlay root to publish into, so tests never write over the real documents."""
    root = Path(tempfile.mkdtemp(prefix="docs-")) / "overlay"
    (root / DOC.DOCS_DIR).mkdir(parents=True)
    return root


class RegistryTests(unittest.TestCase):
    """T01 — twelve documents, each declaring a generator this adapter implements and sources it draws from."""

    def setUp(self):
        s = _state()
        self.m, self.reg = s["docs"], s["reg"]

    def test_every_declared_document_is_complete(self):
        self.assertTrue(self.m["documents"])
        for did, d in self.m["documents"].items():
            self.assertIn(did, DOC.DOC_IDS)
            for key in DOC.DOC_REQUIRED:
                self.assertIn(key, d, f"{did} lacks {key}")
            self.assertTrue(str(d["filename"]).endswith(".md"))

    def test_a_document_with_no_sources_is_refused(self):
        bad = json.loads(json.dumps({k: v for k, v in self.m.items() if k != "computed_hash"}))
        first = sorted(bad["documents"])[0]
        bad["documents"][first]["sources"] = []
        p = Path(tempfile.mkdtemp()) / "DOCS.json"
        p.write_text(json.dumps(bad), encoding="utf-8")
        with self.assertRaises(DOC.DocumentationRefusal) as cm:
            DOC.load_docs(p)
        self.assertEqual(cm.exception.code, "documentation.sources_undeclared")

    def test_a_document_may_be_declared_before_its_generator_exists_but_never_generated(self):
        """Declaring the deliverable and populating it are different tiers. A declared document whose generator does
        not exist loads — and is refused the moment anything tries to generate it."""
        bad = json.loads(json.dumps({k: v for k, v in self.m.items() if k != "computed_hash"}))
        first = sorted(bad["documents"])[0]
        bad["documents"][first]["generator"] = "wishful_thinking"
        p = Path(tempfile.mkdtemp()) / "DOCS.json"
        p.write_text(json.dumps(bad), encoding="utf-8")
        loaded = DOC.load_docs(p)
        self.assertFalse(loaded["documents"][first]["generator_implemented"])
        if not hasattr(DOC, "render"):
            self.skipTest("generation arrives in a later wave")
        with self.assertRaises(DOC.DocumentationRefusal) as cm:
            DOC.render(first, docs=loaded, registry=self.reg if hasattr(self, "reg") else None)
        self.assertEqual(cm.exception.code, "documentation.generator_unknown")

    def test_every_declared_generator_is_implemented_once_the_set_is_complete(self):
        if len(self.m["documents"]) < len(DOC.DOC_IDS):
            self.skipTest("the documentation set is still being declared in this wave")
        unimplemented = [d for d, e in self.m["documents"].items() if not e["generator_implemented"]]
        if unimplemented and not hasattr(DOC, "render"):
            self.skipTest("generators arrive in a later wave")
        self.assertEqual(unimplemented, [])

    def test_an_unbound_suite_is_refused(self):
        bad = json.loads(json.dumps({k: v for k, v in self.m.items() if k != "computed_hash"}))
        first = sorted(bad["documents"])[0]
        bad["documents"][first]["authoritative_suites"] = ["Suite99/nope.jad"]
        p = Path(tempfile.mkdtemp()) / "DOCS.json"
        p.write_text(json.dumps(bad), encoding="utf-8")
        with self.assertRaises(DOC.DocumentationRefusal) as cm:
            DOC.load_docs(p)
        self.assertEqual(cm.exception.code, "documentation.suite_unbound")

    def test_every_document_registers_in_the_knowledge_repository(self):
        rows = DOC.knowledge_repository_rows(self.m)
        self.assertEqual(len(rows), len(self.m["documents"]))
        for r in rows:
            self.assertTrue(r["knowledge_repository"].startswith("41.1/"))
            self.assertTrue(r["path"].startswith("Scoped PR Builder/docs/"))


class GenerationTests(unittest.TestCase):
    """T02 — each document is generated from its declared registries, so what it says is what is implemented."""

    def setUp(self):
        s = _state()
        self.m, self.reg = s["docs"], s["reg"]

    def test_every_document_generates_from_the_real_registries(self):
        for did in sorted(self.m["documents"]):
            with self.subTest(did):
                text = DOC.render(did, docs=self.m, registry=self.reg)
                self.assertIn(did, text)
                self.assertGreater(len(text), 1200, f"{did} generated almost nothing")

    def test_a_document_records_the_version_of_every_source_it_used(self):
        sources = DOC.source_state(registry=self.reg)
        for did, d in sorted(self.m["documents"].items()):
            with self.subTest(did):
                text = DOC.render(did, docs=self.m, registry=self.reg)
                for s in d["sources"]:
                    frag = DOC._short(sources[s]["hash"], 16)
                    self.assertIn(frag, text, f"{did} does not record the version of {s}")

    def test_generation_is_deterministic_apart_from_the_timestamp(self):
        did = sorted(self.m["documents"])[0]
        a = DOC._strip_volatile(DOC.render(did, docs=self.m, registry=self.reg))
        b = DOC._strip_volatile(DOC.render(did, docs=self.m, registry=self.reg))
        self.assertEqual(a, b)

    def test_a_document_cannot_be_generated_from_an_unreadable_source(self):
        """If a registry cannot be read, the document is refused rather than generated with that section missing."""
        did = sorted(self.m["documents"])[0]
        real = DOC.source_state
        try:
            DOC.source_state = lambda **kw: dict(real(**kw), **{
                s: {"hash": None, "entries": None, "error": "simulated"} for s in self.m["documents"][did]["sources"]})
            with self.assertRaises(DOC.DocumentationRefusal) as cm:
                DOC.render(did, docs=self.m, registry=self.reg)
            self.assertEqual(cm.exception.code, "documentation.source_unreadable")
        finally:
            DOC.source_state = real

    def test_the_permission_matrix_matches_the_environment_profiles(self):
        """A spot check that generation is real: every environment and effect in the matrix comes from the profiles."""
        from adapters import environment as E
        text = DOC.render("DOC-04", docs=self.m, registry=self.reg)
        em = E.load_environments()
        for eid in em["environments"]:
            self.assertIn(eid.replace("_", " "), text, eid)
        for eff in E.KNOWN_EFFECTS:
            self.assertIn(f"`{eff}`", text, eff)
        for eid, e in em["environments"].items():
            for eff in e["permissions"].get("require_human_approval") or []:
                if eff in e["allowed_effects"]:
                    self.assertIn("human gate", text)

    def test_the_threat_model_names_every_declared_threat(self):
        from adapters import security as SEC
        text = DOC.render("DOC-05", docs=self.m, registry=self.reg)
        for tid in SEC.load_threats()["threats"]:
            self.assertIn(f"`{tid}`", text, tid)


class FrontMatterTests(unittest.TestCase):
    """T03 — ownership, versions, sources, assumptions, gaps and triggers; and nothing unimplemented as fact."""

    def setUp(self):
        s = _state()
        self.m, self.reg = s["docs"], s["reg"]
        # front matter is added per document during the T03 wave; assert over what is declared so far
        self.declared = {d: e for d, e in self.m["documents"].items() if "front_matter" in e}
        if not self.declared:
            self.skipTest("no document declares front matter yet in this wave")

    def test_every_document_declares_complete_front_matter(self):
        for did, d in self.declared.items():
            with self.subTest(did):
                fm = d.get("front_matter") or {}
                for key in DOC.FRONT_MATTER:
                    self.assertIn(key, fm, f"{did} front matter lacks {key}")
                self.assertTrue(fm["ownership"].strip(), did)
                self.assertTrue(fm["known_gaps"], f"{did} declares no known gaps — every document has some")
                self.assertTrue(fm["change_triggers"], did)

    def test_incomplete_front_matter_is_refused(self):
        bad = json.loads(json.dumps({k: v for k, v in self.m.items() if k != "computed_hash"}))
        did = sorted(self.declared)[0]
        bad["documents"][did]["front_matter"].pop("change_triggers")
        p = Path(tempfile.mkdtemp()) / "DOCS.json"
        p.write_text(json.dumps(bad), encoding="utf-8")
        with self.assertRaises(DOC.DocumentationRefusal) as cm:
            DOC.load_docs(p)
        self.assertEqual(cm.exception.code, "documentation.front_matter_incomplete")

    def test_the_rendered_document_carries_owner_gaps_and_triggers(self):
        for did, d in sorted(self.declared.items()):
            with self.subTest(did):
                text = DOC.render(did, docs=self.m, registry=self.reg)
                self.assertIn(d["front_matter"]["ownership"], text)
                self.assertIn("Known gaps", text)
                self.assertIn("Change triggers", text)
                for gap in d["front_matter"]["known_gaps"]:
                    self.assertIn(gap[:48], text)

    def test_a_known_gap_written_as_an_operational_claim_is_refused(self):
        """A gap saying 'X is fully enforced' is not a gap — it is unimplemented behaviour written as fact."""
        did = sorted(self.declared)[0]
        entry = json.loads(json.dumps(self.declared[did]))
        entry["front_matter"]["known_gaps"] = ["cross-run provenance is fully implemented"]
        problems = DOC.check_honesty(entry)
        self.assertTrue(problems)
        self.assertIn("contradicts it being a gap", problems[0])
        bad = json.loads(json.dumps({k: v for k, v in self.m.items() if k != "computed_hash"}))
        bad["documents"][did] = entry
        with self.assertRaises(DOC.DocumentationRefusal) as cm:
            DOC.render(did, docs=bad, registry=self.reg)
        self.assertEqual(cm.exception.code, "documentation.unimplemented_as_fact")

    def test_an_assumption_stating_an_implemented_fact_is_not_refused(self):
        """Assumptions are exempt by design: they routinely state implemented facts, and linting them would force
        true statements to be weakened to satisfy a regex."""
        did = sorted(self.declared)[0]
        entry = json.loads(json.dumps(self.declared[did]))
        entry["front_matter"]["assumptions"] = ["every threat is enforced at an effect boundary"]
        self.assertEqual(DOC.check_honesty(entry), [])

    def test_the_deferred_invariant_is_documented_as_a_host_requirement_not_a_control(self):
        if "DOC-05" not in self.m["documents"]:
            self.skipTest("DOC-05 is not declared yet in this wave")
        text = DOC.render("DOC-05", docs=self.m, registry=self.reg)
        self.assertIn("XSEC-04", text)
        self.assertIn("Not implemented by this tool", text)
        self.assertIn("host requirement", text.lower())


class FreshnessTests(unittest.TestCase):
    """T04 — the check that detects a document no longer describing the implementation."""

    def setUp(self):
        s = _state()
        self.m, self.reg = s["docs"], s["reg"]
        self.root = _sandbox()
        with_fresh = [d for d, e in self.m["documents"].items()
                      if "freshness_check" in e and e["generator"] in DOC.GENERATORS]
        if not with_fresh:
            self.skipTest("no document declares a freshness check yet in this wave")
        self.did = "DOC-04" if "DOC-04" in with_fresh else sorted(with_fresh)[0]

    def test_a_freshly_published_document_is_fresh(self):
        DOC.publish(self.did, root=self.root, docs=self.m, registry=self.reg)
        r = DOC.check_freshness(self.did, root=self.root, docs=self.m, registry=self.reg)
        self.assertEqual(r["status"], "fresh")
        self.assertIsNone(r["remediation"])

    def test_an_ungenerated_document_is_absent(self):
        r = DOC.check_freshness(self.did, root=self.root, docs=self.m, registry=self.reg)
        self.assertEqual(r["status"], "absent")
        self.assertIn("publish", r["remediation"])

    def test_a_hand_edited_document_is_drifted(self):
        DOC.publish(self.did, root=self.root, docs=self.m, registry=self.reg)
        p = DOC.doc_path(self.did, root=self.root, docs=self.m)
        p.write_text(p.read_text(encoding="utf-8") + "\n\n_A line somebody added by hand._\n", encoding="utf-8")
        r = DOC.check_freshness(self.did, root=self.root, docs=self.m, registry=self.reg)
        self.assertEqual(r["status"], "drifted")
        self.assertIn("edited by hand", r["why"])

    def test_a_moved_source_registry_makes_the_document_stale(self):
        DOC.publish(self.did, root=self.root, docs=self.m, registry=self.reg)
        p = DOC.doc_path(self.did, root=self.root, docs=self.m)
        # rewrite the recorded fragment for one source: the same thing a registry change does
        text = p.read_text(encoding="utf-8")
        sources = DOC.source_state(registry=self.reg)
        source = self.m["documents"][self.did]["sources"][0]
        frag = DOC._short(sources[source]["hash"], 16)
        p.write_text(text.replace(frag, "0" * 16), encoding="utf-8")
        r = DOC.check_freshness(self.did, root=self.root, docs=self.m, registry=self.reg)
        self.assertEqual(r["status"], "stale")
        self.assertEqual([x["source"] for x in r["stale_sources"]], [source])
        self.assertEqual(r["stale_sources"][0]["meaning"], DOC.STALENESS_REASONS[source])

    def test_every_source_has_a_stated_meaning_when_it_changes(self):
        declared = {s for d in self.m["documents"].values() for s in d["sources"]}
        for s in declared:
            self.assertIn(s, DOC.STALENESS_REASONS, f"{s} can go stale with nothing said about what that means")

    def test_check_all_blocks_and_names_what_to_do(self):
        DOC.publish_all(root=self.root, docs=self.m, registry=self.reg)
        r = DOC.check_all(root=self.root, docs=self.m, registry=self.reg)
        if r["blocking"]:
            self.skipTest(f"not every document can be generated yet in this wave: {r['blocking']}")
        victim = sorted(self.m["documents"])[0]
        DOC.doc_path(victim, root=self.root, docs=self.m).unlink()
        r2 = DOC.check_all(root=self.root, docs=self.m, registry=self.reg)
        self.assertEqual(r2["blocking"], [victim])
        self.assertTrue(r2["remediation"][0]["do"])
        with self.assertRaises(DOC.DocumentationRefusal) as cm:
            DOC.require_fresh(root=self.root, docs=self.m, registry=self.reg)
        self.assertEqual(cm.exception.code, "documentation.stale")

    def test_all_twelve_real_documents_are_published_and_fresh(self):
        """The documents in the overlay itself — not a sandbox — must describe the overlay as it is."""
        r = DOC.check_all(docs=self.m, registry=self.reg)
        if set(r["per_document"].values()) == {"absent"}:
            self.skipTest("the documents have not been published in this wave yet")
        self.assertEqual(r["blocking"], [],
                         f"{[(d, r['per_document'][d]) for d in r['blocking']]} — regenerate with publish_all()")


class ReleaseEvidenceTests(unittest.TestCase):
    """T05 — completion and freshness of each document are part of the production-readiness evidence package."""

    def setUp(self):
        s = _state()
        self.m, self.reg = s["docs"], s["reg"]
        # release evidence is bound per document during the T05 wave; assert over what is bound so far
        self.bound = {d: e for d, e in self.m["documents"].items() if "release_evidence" in e}
        if not self.bound:
            self.skipTest("no document is bound to a release assertion yet in this wave")

    def test_every_document_declares_which_assertion_it_serves(self):
        from adapters import release_gate as RG
        for did, d in sorted(self.bound.items()):
            with self.subTest(did):
                ev = d["release_evidence"]
                self.assertEqual(ev["evidence_kind"], DOC.EVIDENCE_KIND)
                self.assertIn(ev["serves_assertion"], RG.ASSERTION_IDS)
        if len(self.bound) == len(DOC.DOC_IDS):
            self.assertEqual(sorted(self.bound), sorted(self.m["documents"]))

    def test_the_readiness_registry_names_documentation_evidence(self):
        """The other half of the binding: the assertions each document serves must actually select for it."""
        from adapters import release_gate as RG
        readiness = RG.load_readiness(registry=self.reg)
        # an assertion gains its selector at the LAST document that serves it, so only assert the ones already wired
        wired = {aid for aid, a in readiness["assertions"].items()
                 if any(sel["kind"] == DOC.EVIDENCE_KIND for sel in a["evidence"])}
        served = {d["release_evidence"]["serves_assertion"] for d in self.bound.values()}
        if not wired:
            self.skipTest("no assertion selects documentation evidence yet in this wave")
        for aid in sorted(wired):
            sels = [s for s in readiness["assertions"][aid]["evidence"] if s["kind"] == DOC.EVIDENCE_KIND]
            self.assertEqual(len(sels), 1, f"{aid} selects documentation evidence more than once")
            self.assertEqual(sels[0]["binds_to"], "docs")
            self.assertTrue(sels[0]["requires_all"], aid)
        if len(self.bound) == len(DOC.DOC_IDS):
            self.assertEqual(wired, served)

    def test_the_receipt_id_binds_to_the_documentation_registry(self):
        for did in sorted(self.bound):
            rid = DOC.gate_document_id(did, self.m)
            self.assertTrue(rid.startswith(f"documentation:{did}@"))
            self.assertIn(self.m["computed_hash"][7:39], rid)

    def test_stale_documentation_blocks_the_release_gate(self):
        """The end-to-end property: a document that stops describing the implementation stops the release."""
        from adapters import release_gate as RG
        readiness = RG.load_readiness(registry=self.reg)
        readiness = RG.load_readiness(registry=self.reg)
        served = sorted(aid for aid, a in readiness["assertions"].items()
                        if any(sel["kind"] == DOC.EVIDENCE_KIND for sel in a["evidence"]))
        if not served:
            self.skipTest("no assertion selects documentation evidence yet in this wave")
        rows = RG.ledger_rows()
        kept = [r for r in rows if r.get("kind") != DOC.EVIDENCE_KIND]
        p = Path(tempfile.mkdtemp()) / "TEST_LEDGER.jsonl"
        from adapters.archive_adapter import _chain_append
        for r in kept:
            _chain_append(p, {k: v for k, v in r.items() if k not in ("prev_hash", "entry_hash")})
        d = RG.gate(ledger=p, registry=self.reg)
        self.assertEqual(d["decision"], "NO_GO")
        self.assertTrue(set(served) <= set(d["blocking"]),
                        f"{set(served) - set(d['blocking'])} are served by documentation but did not block")

    def test_documentation_freshness_is_archived_as_evidence(self):
        """The receipts the gate reads: one per document, recorded only when that document is actually fresh."""
        import evidence_ledger as EL
        r = DOC.check_all(docs=self.m, registry=self.reg)
        if r["blocking"]:
            self.skipTest(f"not every document is fresh yet in this wave: {r['blocking']}")
        rows = []
        for did in sorted(self.bound):
            detail = r["detail"][did]
            rows.append(EL.record(DOC.gate_document_id(did, self.m), DOC.EVIDENCE_KIND, "PASS",
                                  {"doc_id": did, "status": detail["status"],
                                   "document_hash": detail.get("document_hash"),
                                   "source_digest": detail.get("source_digest"),
                                   "sources": self.m["documents"][did]["sources"],
                                   "serves_assertion": self.bound[did]["release_evidence"]["serves_assertion"],
                                   "docs_hash": self.m["computed_hash"]}))
        self.assertEqual(len(rows), len(self.bound))
        self.assertTrue(all(x["verdict"] == "PASS" for x in rows))

    def test_a_document_that_is_not_fresh_never_gets_a_receipt(self):
        """The rule that makes the receipt mean something: it is issued from the freshness result, not alongside it."""
        root = _sandbox()
        r = DOC.check_all(root=root, docs=self.m, registry=self.reg)
        self.assertEqual(sorted(r["blocking"]), sorted(self.m["documents"]))
        self.assertEqual(r["fresh"], [])


if __name__ == "__main__":
    unittest.main()
