"""Model orchestration and abstention (Phase 10 / MODEL-01..07; stdlib unittest).

T01: the provider/orchestration contract (pinned approved providers, versioned prompt policy, source-labeled retrieval
context, schema-validated structured output, evidence-referenced conclusions, no self-granting, evaluation cases) loads,
binds and refuses on defects. T02: every model call is recorded on a chained ledger with provider/model/version, prompt
policy version, authorized retrieval set, deterministic analyzer inputs, output schema version and run identity; COMP-06 /
WF-06 go through the boundary. T03: structured output is validated before use and missing evidence, policy conflicts,
stale context, malformed output or low confidence route to abstention / human review — never to automatic repair. T04:
the model path cannot mint capabilities, approvals, evidence, source labels or verification receipts at any depth.
"""
from __future__ import annotations

import copy
import inspect
import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from adapters import contracts as C  # noqa: E402
from adapters import evidence_retrieval as er  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import model_orchestration as MO  # noqa: E402
from adapters import security as SEC  # noqa: E402
from test_components import _git, make_repo  # noqa: E402
from test_verification_checks import contract_for  # noqa: E402

CONDITION_IDS = [f"MODEL-{n:02d}" for n in range(1, 8)]


class Fixture:
    """One bound fixture repository with a scope contract and its authorized evidence bundle."""

    def __init__(self, base: Path, allowed=("Suite04/SHA256SUMS.txt",), files=1, lines=10) -> None:
        self.base = base
        self.root = make_repo(base)
        self.binding = lga.bind_repository(self.root)
        self.reg = C.load_registry()
        self.contract = contract_for(self.binding, list(allowed), files=files, lines=lines)
        self.bundle = er.retrieve_examples(self.binding, self.contract)
        self.run_dir = base / "run"; self.run_dir.mkdir(exist_ok=True)
        self.ctr = MO.load_model_contract(registry=self.reg)
        self.sources = MO.label_sources(self.bundle.evidence, retrieval_id=self.bundle.retrieval_id, binding=self.binding)

    def output(self, **over) -> dict:
        """A grounded, contract-valid advisory output over the authorized set (the shape a provider must return)."""
        target = next(i for i in self.sources["items"] if i["kind"] == "target_source")
        examples = [i["evidence_id"] for i in self.sources["items"] if i["kind"] == "analogous_example"][:2]
        out = {"record_schema": f"{MO.NS}/ModelOutput", "provider_id": "deterministic-advisor", "provider_version": "0.1.0", "output_schema_version": MO.OUTPUT_SCHEMA_VERSION, "status": "PLANNED", "authority": "advisory_only", "cannot": list(MO.CANNOT),
               "scope_contract_hash": self.contract["scope_contract_hash"], "retrieval_id": self.bundle.retrieval_id, "base_revision": self.binding.base_revision,
               "conclusions": [{"claim": "the manifest is stale and must be regenerated", "impact": "high", "evidence_refs": [target["evidence_id"]] + examples}],
               "operations": [{"path": "Suite04/SHA256SUMS.txt", "operation": "bounded_rewrite_within_scope", "source_content_hash": target["content_hash"]}],
               "confidence": {"band": "high", "basis": "target and analogous manifests in the authorized set"}, "abstention": None, "plan": {"authority": "advisory_only", "status": "PLANNED", "operations": []}}
        out.update(over)
        return out


class TestModelOrchestration(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.f = Fixture(Path(self.tmp.name))
        SEC.use_trail(self.f.run_dir)

    def tearDown(self) -> None:
        SEC.use_trail(None)
        self.tmp.cleanup()

    def provider(self):
        return MO.provider_entry("deterministic-advisor", self.f.ctr)

    def test_registry_loads_pinned_approved_providers_and_bound_conditions(self) -> None:
        ctr = self.f.ctr
        self.assertEqual(ctr["providers_version"], MO.PROVIDERS_VERSION); self.assertTrue(ctr["computed_hash"].startswith("sha256:"))
        self.assertIn("deterministic-advisor", ctr["providers"])
        for pid, p in ctr["providers"].items():
            with self.subTest(provider=pid):
                self.assertTrue(p["pinned"]); self.assertTrue(C.SEMVER_RE.match(p["version"])); self.assertEqual(p["network"], "none"); self.assertIn(p["output_contract"], self.f.reg["contracts"])
                self.assertTrue((MO.REPO_ROOT / p["approved_by"]).is_file()); self.assertTrue(p["approved_by"].endswith("54.1_Approved_Local_Providers.jasp"))
        for cid, c in ctr["conditions"].items():
            with self.subTest(condition=cid):
                self.assertIn(cid, CONDITION_IDS); self.assertTrue(c["rule"]); self.assertTrue(all((MO.REPO_ROOT / f).is_file() for f in c["bound_to"]))
                self.assertTrue(callable(getattr(MO, MO.CONDITIONS[cid], None)), f"{cid}: condition {MO.CONDITIONS[cid]} is not executable")
        try:
            self.assertEqual(self.provider()["provider_id"], "deterministic-advisor")
        except MO.ModelRefusal as exc:  # approval alone never makes a provider callable: the implementation is bound at T02
            self.assertEqual(exc.code, "model.provider_unbound")

    def test_registry_defects_and_unapproved_providers_fail_closed(self) -> None:
        with self.assertRaises(MO.ModelRefusal) as ctx:
            MO.provider_entry("gpt-anything", self.f.ctr)
        self.assertEqual(ctx.exception.code, "model.provider_unapproved")
        MO.register_provider("test-only-provider")(lambda **kw: {})  # an implementation can be bound in code; approval cannot
        with self.assertRaises(MO.ModelRefusal) as ctx:
            MO.provider_entry("test-only-provider", self.f.ctr)
        self.assertEqual(ctx.exception.code, "model.provider_unapproved")
        broken = copy.deepcopy(json.loads(MO.PROVIDERS_PATH.read_text(encoding="utf-8")))
        p = broken["providers"]["deterministic-advisor"]
        for mutate, code in ((lambda q: q.__setitem__("network", "https"), "model.registry_invalid"), (lambda q: q.__setitem__("pinned", False), "model.registry_invalid"), (lambda q: q.__setitem__("version", "latest"), "model.registry_invalid"),
                             (lambda q: q.__setitem__("output_contract", "no_such_contract"), "model.registry_invalid"), (lambda q: q.__setitem__("approved_by", "Nope/54.1.jasp"), "model.suite_unbound")):
            q = copy.deepcopy(p); mutate(q); b = copy.deepcopy(broken); b["providers"]["deterministic-advisor"] = q
            path = self.f.base / "PROVIDERS.json"; path.write_text(json.dumps(b), encoding="utf-8")
            with self.subTest(code=code):
                with self.assertRaises(MO.ModelRefusal) as ctx:
                    MO.load_model_contract(path, registry=self.f.reg)
                self.assertEqual(ctx.exception.code, code)
        with self.assertRaises(MO.ModelRefusal) as ctx:
            MO.load_model_contract(self.f.base / "missing.json", registry=self.f.reg)
        self.assertEqual(ctx.exception.code, "model.registry_missing")

    def test_sources_are_labeled_from_suite51_records_only(self) -> None:
        s = self.f.sources
        self.assertEqual(s["count"], len(self.f.bundle.evidence)); self.assertEqual(s["retrieval_id"], self.f.bundle.retrieval_id)
        for i in s["items"]:
            self.assertTrue(i["source_label"].startswith("repository:") and i["source_label"].endswith("@" + self.f.binding.base_revision[:12]))
            self.assertEqual(i["authority"], "repository_evidence"); self.assertEqual(i["trust"], "untrusted"); self.assertIn("evidence_retrieval", i["minted_by"]); self.assertIn(i["kind"], ("target_source", "analogous_example"))
        foreign = copy.deepcopy(self.f.bundle.evidence); foreign[0]["source_snapshot_hash"] = "sha256:" + "1" * 64
        with self.assertRaises(MO.ModelRefusal) as ctx:
            MO.label_sources(foreign, retrieval_id=self.f.bundle.retrieval_id, binding=self.f.binding)
        self.assertEqual(ctx.exception.code, "model.context_unauthorized")

    def test_prompt_policy_is_versioned_with_the_four_rule_sections(self) -> None:
        if self.f.ctr.get("prompt_policy") is None:
            self.skipTest("prompt policy not declared yet")
        p = MO.assemble_prompt(self.f.ctr, self.f.contract, self.f.sources)
        self.assertEqual(p["policy_version"], self.f.ctr["prompt_policy"]["version"]); self.assertEqual(sorted(p["sections"]), sorted(MO.PROMPT_SECTIONS))
        self.assertIn("Suite04/SHA256SUMS.txt", p["sections"]["scope"]); self.assertIn(str(self.f.sources["count"]), p["sections"]["evidence"]); self.assertIn("abstain", p["sections"]["abstention"].lower())
        self.assertTrue(all(c in p["sections"]["uncertainty"] + p["sections"]["abstention"] + p["sections"]["scope"] for c in ("mint_permissions",)) or "mint_permissions" in json.dumps(p["sections"]))
        self.assertEqual(p["prompt_hash"], MO.assemble_prompt(self.f.ctr, self.f.contract, self.f.sources)["prompt_hash"])
        with self.assertRaises(MO.ModelRefusal) as ctx:
            MO.assemble_prompt({k: v for k, v in self.f.ctr.items() if k != "prompt_policy"}, self.f.contract, self.f.sources)
        self.assertEqual(ctx.exception.code, "model.prompt_policy_missing")

    def test_structured_output_is_schema_validated_before_use(self) -> None:
        out = MO.validate_output(self.f.output(), registry=self.f.reg)
        self.assertEqual(out["authority"], "advisory_only")
        for bad, why in ((dict(self.f.output(), authority="binding"), "authority"), (dict(self.f.output(), status="APPROVED"), "status"), ({k: v for k, v in self.f.output().items() if k != "conclusions"}, "missing conclusions"),
                         (dict(self.f.output(), cannot=["expand_scope"]), "incomplete incapacities"), (dict(self.f.output(), extra_field=1), "unknown field"), (dict(self.f.output(), confidence={"band": "certain", "basis": "x"}), "confidence vocabulary")):
            with self.subTest(why=why):
                with self.assertRaises(MO.ModelRefusal) as ctx:
                    MO.validate_output(bad, registry=self.f.reg)
                self.assertEqual(ctx.exception.code, "model.output_malformed")

    def test_conditions_over_evidence_scope_freshness_confidence_and_self_grant(self) -> None:
        s, out = self.f.sources, self.f.output()
        self.assertEqual(MO.check_evidence_refs(out, s), {"missing": [], "fabricated": []})
        halluc = dict(out, conclusions=[{"claim": "rename every module", "impact": "high", "evidence_refs": []}])
        self.assertEqual(MO.check_evidence_refs(halluc, s)["missing"], ["rename every module"])
        fab = dict(out, conclusions=[{"claim": "x", "impact": "high", "evidence_refs": ["sha256:" + "9" * 64]}])
        self.assertEqual(MO.check_evidence_refs(fab, s)["fabricated"], ["sha256:" + "9" * 64])
        over = dict(out, operations=[{"path": "Suite05/05_demo.jad", "operation": "bounded_rewrite_within_scope", "source_content_hash": "sha256:" + "0" * 64}])
        self.assertEqual(MO.check_scope(over, self.f.contract), ["Suite05/05_demo.jad"])
        self.assertTrue(MO.check_scope(dict(out, operations=out["operations"] * 2), self.f.contract))
        self.assertEqual(MO.check_context_fresh(out, s, self.f.binding), [])
        self.assertTrue(MO.check_context_fresh(dict(out, base_revision="b" * 40), s, self.f.binding))
        self.assertTrue(MO.check_context_fresh(dict(out, retrieval_id="sha256:" + "2" * 64), s, self.f.binding))
        self.assertEqual(MO.check_confidence(out, s), [])
        self.assertTrue(MO.check_confidence(dict(out, conclusions=[], confidence={"band": "high", "basis": "trust me"}), s))
        self.assertEqual(MO.check_confidence(dict(out, confidence={"band": "low", "basis": "thin"}), s), ["low confidence"])
        self.assertEqual(MO.check_no_self_grant(dict(out, granted_effects=["repository.write"], approval={"decision": "APPROVE"})), ["approval", "granted_effects"])
        self.assertEqual(MO.check_no_self_grant(out), [])

    def test_every_call_is_recorded_with_its_determinants(self) -> None:
        res = MO.invoke("deterministic-advisor", binding=self.f.binding, scope_contract=self.f.contract, bundle=self.f.bundle, analyzer_inputs={"convention_profile": {"profile_hash": "sha256:" + "a" * 64}, "symbol_index": {"index_hash": "sha256:" + "b" * 64}}, run_dir=self.f.run_dir, run_id="run-1", registry=self.f.reg)
        self.assertEqual(res["provider"], {"provider_id": "deterministic-advisor", "version": "0.1.0"})
        rows = MO.calls(self.f.run_dir)
        self.assertEqual([r["phase"] for r in rows], ["before", "after"])
        before, after = rows
        self.assertEqual(before["provider"]["provider_id"], "deterministic-advisor"); self.assertEqual(before["provider"]["version"], "0.1.0"); self.assertTrue(before["provider"]["pinned"])
        self.assertEqual(before["prompt"]["policy_version"], self.f.ctr["prompt_policy"]["version"]); self.assertEqual(before["prompt"]["prompt_hash"], res["prompt"]["prompt_hash"])
        self.assertEqual(before["authorized_retrieval_set"], {"retrieval_id": self.f.bundle.retrieval_id, "authorized_set_hash": res["sources"]["authorized_set_hash"], "count": len(self.f.bundle.evidence)})
        self.assertEqual(before["deterministic_inputs"], {"convention_profile": "sha256:" + "a" * 64, "symbol_index": "sha256:" + "b" * 64})
        self.assertEqual(before["output_schema"], {"contract": "model_output", "version": MO.OUTPUT_SCHEMA_VERSION})
        self.assertEqual(before["run_identity"], {"run_id": "run-1", "repository_id": self.f.binding.repository_id, "base_revision": self.f.binding.base_revision, "source_snapshot_hash": self.f.binding.source_snapshot_hash, "scope_contract_hash": self.f.contract["scope_contract_hash"]})
        self.assertEqual(after["call_id"], before["call_id"]); self.assertEqual(after["prompt_hash"], before["prompt"]["prompt_hash"]); self.assertEqual(after["output_schema_version"], MO.OUTPUT_SCHEMA_VERSION); self.assertTrue(after["output_hash"].startswith("sha256:"))
        self.assertEqual(after["route"]["route"], "accept", after["route"]); self.assertEqual(after["refusals"], [])
        out = res["output"]; self.assertEqual(out["status"], "PLANNED"); self.assertEqual(out["plan"]["model_version"], "deterministic-advisor/0.1.0"); self.assertTrue(out["conclusions"] and all(c["evidence_refs"] for c in out["conclusions"]))
        # the chain is tamper-evident
        p = self.f.run_dir / "model" / "calls.jsonl"; lines = p.read_text(encoding="utf-8").splitlines(); e = json.loads(lines[0]); e["provider"]["version"] = "9.9.9"; lines[0] = lga.canonical_json(e); p.write_text("\n".join(lines) + "\n", encoding="utf-8")
        with self.assertRaises(lga.AdapterError):
            MO.calls(self.f.run_dir)

    def test_invoke_refuses_unapproved_providers_foreign_bundles_and_skip_shaped_inputs(self) -> None:
        for kw in ({"skip_validation": True}, {"repair": "auto"}, {"force": 1}, {"override_scope": True}, {"anything_else": 1}):
            with self.subTest(kw=kw):
                with self.assertRaises(MO.ModelRefusal) as ctx:
                    MO.invoke("deterministic-advisor", binding=self.f.binding, scope_contract=self.f.contract, bundle=self.f.bundle, registry=self.f.reg, **kw)
                self.assertEqual(ctx.exception.code, "model.input_refused")
        with self.assertRaises(MO.ModelRefusal) as ctx:
            MO.invoke("test-only-provider", binding=self.f.binding, scope_contract=self.f.contract, bundle=self.f.bundle, registry=self.f.reg)
        self.assertEqual(ctx.exception.code, "model.provider_unapproved")
        other = contract_for(self.f.binding, ["Suite04"], files=2, lines=20)
        with self.assertRaises(MO.ModelRefusal) as ctx:
            MO.invoke("deterministic-advisor", binding=self.f.binding, scope_contract=other, bundle=self.f.bundle, registry=self.f.reg)
        self.assertEqual(ctx.exception.code, "model.context_unauthorized")
        self.assertFalse((self.f.run_dir / "model").exists(), "a refused call leaves no record — nothing was called")
        unpersisted = MO.invoke("deterministic-advisor", binding=self.f.binding, scope_contract=self.f.contract, bundle=self.f.bundle, registry=self.f.reg)
        self.assertFalse(unpersisted["record"]["persisted"]); self.assertTrue(unpersisted["record"]["entry_hash"].startswith("sha256:"))

    def test_comp06_goes_through_the_boundary(self) -> None:
        from adapters import components as K
        comps = K.load_components(registry=self.f.reg)
        spec = comps["components"]["COMP-06"]["interface"]
        if "model_call" not in spec["outputs"]:
            self.skipTest("COMP-06 not yet wired through the model boundary")
        eb = json.loads(self.f.bundle.to_json())
        r = K.invoke("COMP-06", {"binding": self.f.binding, "scope_contract": self.f.contract, "evidence_bundle": eb, "run_dir": self.f.run_dir}, granted_effects=["repository.read"], components=comps, registry=self.f.reg)
        plan, call = r.outputs["refactoring_plan"], r.outputs["model_call"]
        self.assertEqual(plan["status"], "PLANNED"); self.assertEqual(plan["authority"], "advisory_only"); self.assertEqual(plan["model_version"], "deterministic-advisor/0.1.0"); self.assertEqual(plan["model_call_id"], call["call_id"])
        self.assertEqual(call["provider"], {"provider_id": "deterministic-advisor", "version": "0.1.0"}); self.assertEqual(call["route"]["route"], "accept"); self.assertIn("model_call", spec["volatile_fields"])
        self.assertEqual([x["phase"] for x in MO.calls(self.f.run_dir)], ["before", "after"])
        self.assertEqual(plan["plan_hash"], lga.sha256_digest(lga.canonical_json({k: v for k, v in plan.items() if k not in ("plan_hash", "created_at")})))
        again = K.invoke("COMP-06", {"binding": self.f.binding, "scope_contract": self.f.contract, "evidence_bundle": eb, "run_dir": self.f.run_dir}, granted_effects=["repository.read"], components=comps, registry=self.f.reg)
        self.assertTrue(K.replay_check(r, again)["deterministic"], K.replay_check(r, again)); self.assertEqual(len(MO.calls(self.f.run_dir)), 4)
        with self.assertRaises(K.ComponentRefusal):
            K.invoke("COMP-06", {"binding": self.f.binding, "scope_contract": self.f.contract, "evidence_bundle": eb, "granted_effects": ["repository.write"]}, granted_effects=["repository.read"], components=comps, registry=self.f.reg)

    def _evaluate(self, raw, **kw):
        p = self.provider(); prompt = MO.assemble_prompt(self.f.ctr, self.f.contract, self.f.sources)
        return MO.evaluate(raw, provider=p, prompt=prompt, sources=self.f.sources, binding=self.f.binding, scope_contract=self.f.contract, run_dir=self.f.run_dir, call_id="sha256:" + "c" * 64, registry=self.f.reg, **kw)

    def test_outputs_are_routed_to_abstention_or_human_review_never_repaired(self) -> None:
        out = self.f.output()
        ok = self._evaluate(out); self.assertEqual(ok["route"]["route"], "accept"); self.assertIsNotNone(ok["output"])
        cases = {"malformed": ("not an object", "human_review", "malformed_output"), "invalid_schema": (dict(out, status="DONE"), "human_review", "malformed_output"),
                 "missing_evidence": (dict(out, conclusions=[{"claim": "rewrite everything", "impact": "high", "evidence_refs": []}]), "abstain", "insufficient_evidence"),
                 "fabricated": (dict(out, conclusions=[{"claim": "x", "impact": "high", "evidence_refs": ["sha256:" + "9" * 64]}]), "human_review", "fabricated_evidence"),
                 "policy_conflict": (dict(out, operations=[{"path": "Suite05/05_demo.jad", "operation": "bounded_rewrite_within_scope", "source_content_hash": "sha256:" + "0" * 64}]), "abstain", "out_of_scope"),
                 "stale": (dict(out, base_revision="b" * 40), "abstain", "stale_context"), "low_confidence": (dict(out, confidence={"band": "low", "basis": "thin"}), "abstain", "low_confidence"),
                 "declared_abstention": (dict(out, status="ABSTAIN", abstention={"reason_code": "insufficient_evidence", "detail": "no analogous manifests"}), "abstain", "insufficient_evidence"),
                 "pin_mismatch": (dict(out, provider_version="0.2.0"), "human_review", "provider_unapproved"), "other_scope": (dict(out, scope_contract_hash="sha256:" + "3" * 64), "human_review", "malformed_output")}
        for name, (raw, route, code) in cases.items():
            with self.subTest(case=name):
                r = self._evaluate(raw)
                self.assertEqual((r["route"]["route"], r["route"]["reason_code"]), (route, code), r["route"])
                self.assertIsNone(r["output"], "a routed output is never handed on"); self.assertTrue(r["route"]["repair"].startswith("never"))
                if route == "abstain":
                    a = r["route"]["abstention"]; C.validate_payload("abstention", a, registry=self.f.reg); self.assertEqual(a["run_state"], "ABSTAINED"); self.assertEqual(a["scope_contract_hash"], self.f.contract["scope_contract_hash"])
                self.assertEqual(r["record"]["route"]["route"], route)
        self.assertEqual(MO.ROUTE_REASONS["low_confidence"], "abstain"); self.assertEqual(MO.ROUTE_REASONS["fabricated_evidence"], "human_review")
        with self.assertRaises(lga.AdapterError):
            MO.abstention_record("because", "x", scope_contract=self.f.contract, registry=self.f.reg)

    def test_wf06_surfaces_the_abstention_and_keeps_the_plan_advisory(self) -> None:
        from adapters import components as K
        comps = K.load_components(registry=self.f.reg)
        if "model_call" not in comps["components"]["COMP-06"]["interface"]["outputs"]:
            self.skipTest("COMP-06 not yet wired through the model boundary")
        (self.f.root / "zzqx.md").write_text("zzqx qqwe\n"); _git(self.f.root, "add", "-A"); _git(self.f.root, "commit", "-q", "-m", "lonely")  # no token of this file occurs anywhere else
        binding = lga.bind_repository(self.f.root); contract = contract_for(binding, ["zzqx.md"], title="zzqx"); bundle = er.retrieve_examples(binding, contract)
        run_dir = self.f.base / "two"; run_dir.mkdir()
        r = K.invoke("COMP-06", {"binding": binding, "scope_contract": contract, "evidence_bundle": json.loads(bundle.to_json()), "run_dir": run_dir}, granted_effects=["repository.read"], components=comps, registry=self.f.reg)
        plan, call = r.outputs["refactoring_plan"], r.outputs["model_call"]
        self.assertEqual(plan["status"], "ABSTAIN"); self.assertEqual(call["route"]["route"], "abstain"); self.assertEqual(call["route"]["reason_code"], "insufficient_evidence"); self.assertEqual(plan["authority"], "advisory_only")
        self.assertTrue(plan.get("abstain_reason")); self.assertEqual(MO.calls(run_dir)[-1]["route"]["route"], "abstain")
        C.validate_payload("abstention", call["abstention"], registry=self.f.reg)

    def test_minting_is_detected_at_any_depth_and_trailed(self) -> None:
        out = self.f.output()
        self.assertEqual(MO.minting_attempts(out), [])
        nested = dict(out, plan={"authority": "advisory_only", "status": "PLANNED", "operations": [], "approval_receipt": {"decision": "APPROVE", "signature": "x"}, "extra": {"granted_effects": ["repository.write"]}})
        found = MO.minting_attempts(nested)
        self.assertEqual(sorted({a["mints"] for a in found}), ["approvals", "capabilities"]); self.assertTrue(all(a["path"].startswith("$.plan") for a in found))
        shaped = dict(out, plan={"authority": "advisory_only", "status": "PLANNED", "operations": [{"record_schema": "overlay.scoped_pr_builder.verification/CheckResult", "result": "pass"}]})
        self.assertEqual([a["mints"] for a in MO.minting_attempts(shaped)], ["verification_receipts"])
        self.assertEqual([a["mints"] for a in MO.minting_attempts(dict(out, plan={"authority": "binding"}))], ["capabilities"])
        n = len(SEC.denials(self.f.run_dir))
        refusals = MO.detect_minting(nested, run_dir=self.f.run_dir, subject={"call_id": "x"})
        self.assertEqual(sorted(r["code"] for r in refusals), ["model.self_grant"]); rows = SEC.denials(self.f.run_dir)
        self.assertEqual(len(rows), n + 1); self.assertEqual(rows[-1]["code"], "security.sec01.model_minting_attempt"); self.assertEqual(rows[-1]["threat_id"], "SEC-01"); SEC.verify_trail(self.f.run_dir)
        self.assertNotIn("approval_receipt", json.dumps(rows[-1]["subject"]), "the trail carries counts, never the minted payload")
        self.assertEqual(MO.detect_minting(out, run_dir=self.f.run_dir), []); self.assertEqual(len(SEC.denials(self.f.run_dir)), n + 1)
        for kind, layer in MO.control_layers().items():
            self.assertNotIn("model_orchestration.invoke", layer); self.assertIn(kind, MO.MINTED_ONLY_BY)

    def test_evaluate_refuses_minted_capabilities_approvals_evidence_labels_and_receipts(self) -> None:
        out = self.f.output()
        cases = {"capabilities": dict(out, plan=dict(out["plan"], granted_effects=["repository.write"])), "approvals": dict(out, plan=dict(out["plan"], approval={"decision": "APPROVE", "approver_channel": "model"})),
                 "evidence": dict(out, plan=dict(out["plan"], evidence_records=[{"evidence_id": "sha256:" + "9" * 64}])), "source_labels": dict(out, plan=dict(out["plan"], source_labels=["repository:x@y"])),
                 "verification_receipts": dict(out, plan=dict(out["plan"], check_results=[{"result": "pass"}])), "plan_evidence": dict(out, plan=dict(out["plan"], evidence_refs=[{"evidence_id": "sha256:" + "8" * 64}]))}
        expect = {"capabilities": "model.self_grant", "approvals": "model.self_grant", "evidence": "model.evidence_minted", "source_labels": "model.evidence_minted", "verification_receipts": "model.verification_minted", "plan_evidence": "model.evidence_minted"}
        for name, raw in cases.items():
            with self.subTest(case=name):
                r = self._evaluate(raw)
                self.assertEqual(r["route"]["route"], "human_review", r["route"]); self.assertEqual(r["route"]["reason_code"], "self_grant"); self.assertIsNone(r["output"])
                self.assertIn(expect[name], [x["code"] for x in r["refusals"]], r["refusals"])
        seal = MO.seal_sources(self.f.sources)
        tampered = copy.deepcopy(self.f.sources); tampered["items"][0]["source_label"] = "repository:minted@0000"
        r = self._evaluate(out, sources_seal=seal)
        self.assertEqual(r["route"]["route"], "accept")
        p = self.provider(); prompt = MO.assemble_prompt(self.f.ctr, self.f.contract, self.f.sources)
        r = MO.evaluate(out, provider=p, prompt=prompt, sources=tampered, binding=self.f.binding, scope_contract=self.f.contract, registry=self.f.reg, sources_seal=seal)
        self.assertEqual(r["route"]["route"], "human_review"); self.assertIn("model.label_minted", [x["code"] for x in r["refusals"]])
        with self.assertRaises(MO.ModelRefusal) as ctx:
            MO.verify_source_labels(tampered, self.f.bundle, self.f.binding)
        self.assertEqual(ctx.exception.code, "model.label_minted")
        MO.verify_source_labels(self.f.sources, self.f.bundle, self.f.binding)

    def test_a_provider_that_touches_the_labeled_set_is_refused(self) -> None:
        @MO.register_provider("deterministic-advisor")
        def rogue(*, prompt, sources, scope_contract, bundle, binding, analyzer_inputs):
            sources["items"].append({"evidence_id": "sha256:" + "7" * 64, "source_label": "repository:minted@0000", "locator": "x", "content_hash": "sha256:" + "7" * 64, "kind": "analogous_example", "authority": "repository_evidence", "trust": "untrusted", "minted_by": "model"})
            return self.f.output()
        try:
            r = MO.invoke("deterministic-advisor", binding=self.f.binding, scope_contract=self.f.contract, bundle=self.f.bundle, run_dir=self.f.run_dir, registry=self.f.reg)
        finally:
            MO.register_provider("deterministic-advisor")(MO._provider_deterministic_advisor)
        self.assertEqual(r["route"]["route"], "human_review"); self.assertIn("model.label_minted", [x["code"] for x in r["refusals"]]); self.assertIsNone(r["output"])

    def test_control_layers_never_take_model_output(self) -> None:
        layers = MO.verify_control_layers()
        self.assertEqual(sorted(layers), sorted(MO.MINTED_ONLY_BY))
        from adapters import controls
        self.assertEqual(list(inspect.signature(controls.policy_decide).parameters), ["rule_set", "effect", "principal_role", "context"])
        src = Path(MO.__file__).read_text(encoding="utf-8")
        for forbidden in ("evidence_ledger", "import approval_adapter", "import guardrails", "policy_decide(", "issue_receipt(", "typed_result(", "EL.record"):
            self.assertNotIn(forbidden, src, f"the model path must not reach {forbidden}")
        with self.assertRaises(MO.ModelRefusal) as ctx:
            MO.invoke("deterministic-advisor", binding=self.f.binding, scope_contract=self.f.contract, bundle=self.f.bundle, registry=self.f.reg, granted_effects=["repository.write"])
        self.assertEqual(ctx.exception.code, "model.input_refused")


if __name__ == "__main__":
    unittest.main()
