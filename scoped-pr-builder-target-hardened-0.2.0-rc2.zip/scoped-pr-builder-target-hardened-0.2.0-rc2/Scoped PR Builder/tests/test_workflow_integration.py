"""Workflow integration evidence (Phase 06 / WF-*-T05; stdlib unittest), driven by tests/scenarios/workflow.json.

For every declared step: (1) the next state is unreachable until the step succeeds — the following step refuses to
start and the run state does not move; (2) a failing instance (an injected failure of the declared kind) lands in its
declared outcome, preserves the attempt's inputs, error and state on the chained step records, and the run replays
from those records alone; (3) the passing instance advances the run state with the declared evidence. Every case
leaves a chained receipt on the test/evidence ledger (``SPB_EVIDENCE_LEDGER``; run-local otherwise).
"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import evidence_ledger as EL  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import controls as CT  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import workflow as W  # noqa: E402
from test_workflow import ORDER, Driver  # noqa: E402

SCENARIOS = HERE / "scenarios" / "workflow.json"


def _raise(code: str):
    def stub(run, inputs):
        raise W.WorkflowRefusal(code, f"injected {code}")
    return stub


class TestWorkflowIntegration(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.wf = W.load_workflow(registry=self.reg)
        self.scen = json.loads(SCENARIOS.read_text(encoding="utf-8")).get("scenarios", {}) if SCENARIOS.is_file() else {}
        if not self.scen:
            self.skipTest("no workflow scenarios yet")
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.rows = 0

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def _receipt(self, sid: str, case: str, body: dict, verdict: str = "PASS") -> None:
        EL.record(f"workflow:{sid}:{case}", "workflow_integration", verdict, {"step_id": sid, "case": case, **body})
        self.rows += 1

    def test_scenarios(self) -> None:
        active = [s for s in ORDER if f"workflow:{s}" in self.scen]
        # ---- passing path once: every active step advances with its declared evidence ---------------------------
        pos = Driver(self.base / "pos", self.reg, self.wf)
        last = active[-1]
        row = pos.drive("WF-11" if last == "WF-12" else last)
        self.assertEqual(row["outcome"], "SUCCEEDED", row["reason"])
        if last == "WF-12":
            row = pos.run.run_step("WF-12", pos.inputs_for("WF-12"))
            self.assertEqual(row["outcome"], "SUCCEEDED", row["reason"])
        for sid in active:
            rec = pos.run.completed[sid]; s = self.wf["steps"][sid]
            with self.subTest(step=sid, case="passing"):
                self.assertEqual(rec["run_state_after"], s["run_state_to"])
                self.assertTrue(all(k in rec["evidence"] for k in s["transition_evidence"]))
                self._receipt(sid, "passing", {"attempt_id": rec["attempt_id"], "inputs_hash": rec["inputs_hash"], "evidence": rec["evidence"], "run_state_after": rec["run_state_after"], "record_hash": rec["record_hash"]})
        replay = W.WorkflowRun.load(pos.run_dir, workflow=self.wf, registry=self.reg)
        self.assertEqual(replay.state, pos.run.state); self.assertEqual(sorted(replay.completed), sorted(pos.run.completed))
        # ---- per step: unreachable-until-success and a failing instance that preserves state -------------------
        for sid in active:
            sc = self.scen[f"workflow:{sid}"]; idx = ORDER.index(sid)
            d = Driver(self.base / sid.lower(), self.reg, self.wf)
            if idx > 0:
                r = d.drive(ORDER[idx - 1])
                self.assertEqual(r["outcome"], "SUCCEEDED", r["reason"])
            nxt = sc.get("unreachable_next")
            with self.subTest(step=sid, case="unreachable_until_success"):
                self.assertTrue(d.run.next_state_reachable(sid))
                state_before = d.run.state
                if nxt:
                    self.assertFalse(d.run.next_state_reachable(nxt))
                    with self.assertRaises(lga.AdapterError) as ctx:
                        d.run.start_step(nxt, {})
                    self.assertIn(ctx.exception.code, ("workflow.precondition_unmet", "workflow.state_mismatch"))
                    self.assertEqual(d.run.state, state_before)
                self._receipt(sid, "unreachable_until_success", {"next_step": nxt, "run_state": state_before, "refused_with": ctx.exception.code if nxt else "n/a (last step)"})
            fi = sc["failing_instance"]
            with self.subTest(step=sid, case="failing_instance"):
                real = W._EXEC[sid]
                W._EXEC[sid] = _raise(fi["inject"])
                try:
                    row = d.run.run_step(sid, d.inputs_for(sid))
                finally:
                    W._EXEC[sid] = real
                self.assertEqual(row["outcome"], fi["expect_outcome"], row["reason"]); self.assertEqual(row["error_code"], fi["inject"])
                self.assertEqual(d.run.state, fi["expect_state"] if fi.get("expect_state") else state_before)
                self.assertNotIn(sid, d.run.completed)
                recs = [r for r in d.run.records() if r["step_id"] == sid]
                self.assertEqual([r["phase"] for r in recs[-2:]], ["before", "after"]); self.assertEqual(recs[-1]["inputs_hash"], recs[-2]["inputs_hash"]); self.assertTrue(recs[-2]["inputs"] is not None)
                again = W.WorkflowRun.load(d.run_dir, workflow=self.wf, registry=self.reg)
                self.assertEqual(again.state, d.run.state); self.assertEqual(again.last_attempt[sid]["error_code"], fi["inject"]); self.assertEqual(again.attempts[sid], d.run.attempts[sid])
                if nxt:
                    self.assertFalse(again.next_state_reachable(nxt))
                self._receipt(sid, "failing_instance", {"injected": fi["inject"], "kind": W.classify_failure(fi["inject"]), "outcome": row["outcome"], "route": row["route"], "run_state_after": d.run.state, "records_for_step": len(recs), "replayed": True, "record_hash": row["record_hash"]})
                if fi.get("retry_expect"):
                    W._EXEC[sid] = real
                    r2 = d.run.run_step(sid, d.inputs_for(sid), retry=True)
                    self.assertEqual(r2["outcome"], fi["retry_expect"], r2["reason"]); self.assertEqual(r2["attempt_no"], 2)
                    self._receipt(sid, "retry", {"attempt_id": r2["attempt_id"], "replay_of": r2["replay_of"], "outcome": r2["outcome"], "run_state_after": d.run.state})
        self.assertGreaterEqual(EL.verify(), self.rows)

    def test_scenarios_are_well_formed(self) -> None:
        for sid, sc in self.scen.items():
            with self.subTest(scenario=sid):
                self.assertIn(sc["step_id"], self.wf["steps"]); self.assertTrue(sc["receipt_requirements"])
                fi = sc["failing_instance"]; self.assertTrue(fi["inject"] and fi["expect_outcome"] in W.OUTCOMES)
                if sc.get("unreachable_next"):
                    self.assertIn(sc["unreachable_next"], self.wf["steps"])


if __name__ == "__main__":
    unittest.main()
