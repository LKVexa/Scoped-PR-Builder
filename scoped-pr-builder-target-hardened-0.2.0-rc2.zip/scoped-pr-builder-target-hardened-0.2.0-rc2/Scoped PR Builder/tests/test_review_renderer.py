"""Deterministic tests for the review surface (stdlib unittest)."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import evidence_retrieval as er  # noqa: E402
from adapters import intent_intake as ii  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import patch_generator as pg  # noqa: E402
from adapters import review_renderer as rr  # noqa: E402
from adapters import verification_runner as vr  # noqa: E402


def _git(cwd: Path, *args: str) -> str:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t",
           "GIT_COMMITTER_EMAIL": "t@t", "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z", "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z"}
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=True, env=env).stdout.strip()


HDR = "ja source 0.3\nmodule suite{n}.demo\nuse Data\npolicy no_network\nemit json demo\n"
INJECT = "<script>alert('x')</script><img src=x onerror=alert(1)>"


class Fixture(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "repo"
        self.root.mkdir()
        _git(self.root, "init", "-q")
        for n in range(1, 67):
            d = self.root / f"Suite{n:02d}"
            d.mkdir()
            (d / f"{n:02d}_demo.jad").write_text(HDR.format(n=n))
        (self.root / "Suite04" / "SHA256SUMS.txt").write_text(f"0000  04_Old/{INJECT}.jad\n")
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c1")
        self.binding = lga.bind_repository(self.root)
        self.contract = json.loads(ii.accept_intent({"kind": "tech_debt_refactor", "title": "Regenerate stale Suite04 SHA256SUMS manifest " + INJECT,
                                                     "description": "x", "allowed_paths": ["Suite04/SHA256SUMS.txt"], "max_changed_files": 1, "max_diff_lines": 10, "requested_by": "t"}, self.binding).to_json())
        self.bundle = er.retrieve_examples(self.binding, self.contract)
        self.plan = er.build_plan(self.contract, self.bundle)
        cand, self.patch = pg.generate_candidate(self.binding, self.contract, self.plan, "regenerate_sha256sums_manifest")
        self.cand = json.loads(cand.to_json())
        self.report = json.loads(vr.verify_candidate(self.binding, self.contract, self.cand, self.patch, Path(self.tmp.name) / "sb", run_tests=False).to_json())
        self.bdict = json.loads(self.binding.to_json())

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def card(self, **over):
        args = dict(binding=self.bdict, contract=self.contract, evidence=self.bundle.evidence, authority=self.bundle.authority, plan=self.plan, candidate=self.cand, patch=self.patch, report=self.report)
        args.update(over)
        return rr.build_review_card(**args)


class TestReview(Fixture):
    def test_card_sections_and_hash(self) -> None:
        card = self.card()
        for k in ("risk_summary", "evidence_summary", "parameter_summary", "impact_summary", "rollback_summary", "hash_summary", "capability_contract", "preconditions", "expected_effects", "unified_diff", "review_history", "approval_controls", "verification"):
            self.assertIn(k, card)
        self.assertEqual(card["authority"], "display_only")
        self.assertTrue(card["unified_diff"]["read_only"])
        self.assertIn("tests", card["preconditions"]["unresolved"])  # INDETERMINATE in fixture -> blocking
        self.assertTrue(card["risk_summary"]["blocking_risk"])
        body = {k: v for k, v in card.items() if k not in ("card_hash", "rendered_at")}
        self.assertEqual(lga.sha256_digest(lga.canonical_json(body)), card["card_hash"])

    def test_html_escapes_untrusted_content(self) -> None:
        page = rr.render_html(self.card())
        self.assertNotIn("<script", page)
        self.assertNotIn("<img", page)
        self.assertIn("&lt;script&gt;alert(&#x27;x&#x27;)&lt;/script&gt;&lt;img src=x onerror=alert(1)&gt;", page)
        self.assertIn("default-src 'none'", page)
        self.assertIn("BLOCKED", page)
        self.assertIn("Unified diff", page)
        self.assertIn("class=\"del\"", page)

    def test_mismatch_fails_closed(self) -> None:
        with self.assertRaises(lga.AdapterError) as ctx:
            self.card(report=dict(self.report, candidate_id="sha256:other"))
        self.assertEqual(ctx.exception.code, "review.candidate_mismatch")
        with self.assertRaises(lga.AdapterError) as ctx:
            self.card(patch=self.patch + b"x")
        self.assertEqual(ctx.exception.code, "review.patch_mismatch")
        with self.assertRaises(lga.AdapterError) as ctx:
            self.card(plan=dict(self.plan, base_revision="0" * 40))
        self.assertEqual(ctx.exception.code, "review.revision_mismatch")


if __name__ == "__main__":
    unittest.main()


class TestIntakeExposure(Fixture):
    """DATA-*-T04: intake states are exposed on the card (display-only) and a non-admitted source tree refuses retrieval."""

    def test_intake_section_and_retrieval_gate(self) -> None:
        from adapters import intake as I
        records = I.admit_all(self.binding, granted_effects=["repository.read"])
        card = self.card(intake=records)
        self.assertEqual(card["intake"]["authority"], "display_only"); self.assertEqual(card["intake"]["sources"][0]["source_id"], "DATA-01")
        self.assertIn("Evidence intake", rr.render_html(card))
        self.assertNotEqual(card["card_hash"], self.card()["card_hash"])
        denied = dict(records, **{"DATA-01": I.admit("DATA-01", self.binding, granted_effects=[])})
        with self.assertRaises(lga.AdapterError) as ctx:
            er.retrieve_examples(self.binding, self.contract, intake=denied)
        self.assertEqual(ctx.exception.code, "intake.denied")
        with self.assertRaises(lga.AdapterError) as ctx:
            er.retrieve_examples(self.binding, self.contract, intake={})
        self.assertEqual(ctx.exception.code, "intake.missing")
        self.assertTrue(er.retrieve_examples(self.binding, self.contract, intake=records).evidence)
