"""Security regression gate (Phase 09 / SEC-*-T05; stdlib unittest): every threat-control test is mandatory for release and
cannot be waived by the component being evaluated. The gate reads only the tool's own chained evidence ledger, requires a PASS
``security_adversarial`` receipt per threat bound to the current threat core (including the fail_closed case), refuses
waiver-shaped inputs by name, and REG-03 re-runs the adversarial suite inside the sandbox whenever the overlay changes."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path, PurePosixPath

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import evidence_ledger as EL  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import security as SEC  # noqa: E402
from adapters import verification_runner as vr  # noqa: E402

THREAT_IDS = [f"SEC-{n:02d}" for n in range(1, 9)]


class TestReleaseGate(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.th = SEC.load_threats(registry=self.reg)
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        SEC.use_trail(self.base / "run")

    def tearDown(self) -> None:
        SEC.use_trail(None)
        self.tmp.cleanup()

    def gated(self) -> list[str]:
        return [tid for tid in THREAT_IDS if "release_gate" in self.th["threats"].get(tid, {})]

    _n = 0

    def _ledger_with(self, cases=("control", "fail_closed"), core=None, verdict="PASS", threats=None) -> Path:
        self._n += 1
        p = self.base / f"ledger-{self._n}.jsonl"
        for tid in (threats or list(self.th["threats"])):  # every declared threat is gated, whether or not its block is declared yet
            for case in cases:
                EL.record(f"security:{tid}:{case}@{core or self.th['core_hash'][7:39]}", "security_adversarial", verdict, {"threat_id": tid, "case": case}, path=p)
        return p

    def test_declarations_are_mandatory_and_non_waivable(self) -> None:
        for tid in self.gated():
            g = self.th["threats"][tid]["release_gate"]
            with self.subTest(threat=tid):
                self.assertTrue(g["mandatory"]); self.assertFalse(g["waivable"]); self.assertEqual(g["evidence_kind"], "security_adversarial"); self.assertIn("REG-03", g["regression"])
        defs = json.loads(vr.REGRESSION_PATH.read_text(encoding="utf-8"))
        reg = [c for c in defs["checks"] if c["id"] == "REG-03"]
        self.assertTrue(reg); self.assertIn("test_security_adversarial.py", " ".join(reg[0]["argv"])); self.assertTrue(any(p.startswith("Scoped PR Builder/") for p in reg[0]["applies_to"]))
        self.assertTrue(str(vr.REGRESSION_PATH).startswith(str(SEC.OVERLAY_ROOT)), "definitions must be the tool's own, never the sandbox copy")

    def test_gate_blocks_missing_stale_failed_incomplete_and_waivers(self) -> None:
        if not self.gated():
            self.skipTest("no release gates yet")
        every = list(self.th["threats"])
        d = SEC.release_gate(ledger=self.base / "none.jsonl", threats=self.th)
        self.assertEqual(d["decision"], "BLOCK"); self.assertTrue(all(d["per_threat"][t]["status"] == "missing" for t in every))
        d = SEC.release_gate(ledger=self._ledger_with(core="0" * 32), threats=self.th)
        self.assertTrue(all(d["per_threat"][t]["status"] == "stale" for t in every))
        d = SEC.release_gate(ledger=self._ledger_with(verdict="FAIL"), threats=self.th)
        self.assertTrue(all(d["per_threat"][t]["status"] == "failed" for t in every))
        d = SEC.release_gate(ledger=self._ledger_with(cases=("control",)), threats=self.th)
        self.assertTrue(all(d["per_threat"][t]["status"] == "incomplete" for t in every))
        good = self._ledger_with()
        d = SEC.release_gate(ledger=good, threats=self.th)
        self.assertEqual(d["decision"], "PROCEED", d["per_threat"]); self.assertEqual(d["blocking"], [])
        for waiver in ({"skip_security_gate": True}, {"waive": "SEC-03"}, {"bypass_checks": 1}, {"security_gate": "off"}):
            d = SEC.release_gate(ledger=good, threats=self.th, inputs=waiver)
            self.assertEqual(d["decision"], "BLOCK", waiver); self.assertIn("WAIVER", d["blocking"])
        with self.assertRaises(SEC.SecurityDenial) as ctx:
            SEC.require_release_gate(stage="test", ledger=self._ledger_with(cases=("control",)), threats=self.th)
        self.assertEqual(ctx.exception.code, "security.release_gate_blocked")
        self.assertTrue(any(e["event"] == "release_gate" for e in SEC.events(self.base / "run")))
        lines = good.read_text().splitlines(); e = json.loads(lines[0]); e["verdict"] = "PASS"; e["scenario_id"] = e["scenario_id"]; e["kind"] = "edited"; lines[0] = lga.canonical_json(e); good.write_text("\n".join(lines) + "\n")
        with self.assertRaises(lga.AdapterError):  # an edited ledger is refused, not re-read
            SEC.release_gate(ledger=good, threats=self.th)

    def test_tool_ledger_satisfies_the_gate(self) -> None:
        """The tool's own archived receipts (evidence/TEST_LEDGER.jsonl) must be current for every gated threat."""
        if not self.gated():
            self.skipTest("no release gates yet")
        d = SEC.release_gate(threats=self.th)
        self.assertEqual(d["decision"], "PROCEED", {t: v for t, v in d["per_threat"].items() if v["status"] != "satisfied"})

    def test_component_under_evaluation_cannot_waive(self) -> None:
        if not self.gated():
            self.skipTest("no release gates yet")
        sandbox = self.base / "sandbox"; (sandbox / "Scoped PR Builder" / "adapters").mkdir(parents=True)
        (sandbox / "Scoped PR Builder" / "verification").mkdir(parents=True)
        (sandbox / "Scoped PR Builder" / "verification" / "REGRESSION.json").write_text('{"checks": [], "regression_version": "scoped_pr_builder.regression/0.1.0"}', encoding="utf-8")  # the candidate's copy tries to drop every definition
        verdict, msg, out, err, code = vr._regression(sandbox, [PurePosixPath("Scoped PR Builder/adapters/security.py")], 60)
        head = json.loads(out.decode("utf-8").split("\n", 1)[0])
        self.assertIn("REG-03", [a["id"] for a in head["applied"]], "REG-03 must still apply from the tool's own definitions")
        self.assertEqual(verdict, "FAIL")  # the suite is absent in this fixture sandbox: applied and failed, never silently passed
        self.assertEqual(head["definitions_hash"], lga.sha256_digest(vr.REGRESSION_PATH.read_bytes()))


if __name__ == "__main__":
    unittest.main()
