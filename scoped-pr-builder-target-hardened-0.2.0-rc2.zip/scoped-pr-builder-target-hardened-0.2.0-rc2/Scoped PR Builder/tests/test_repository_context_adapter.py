"""Deterministic tests for the Suite 40 repository-context adapter (stdlib unittest)."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import local_git_adapter as lga  # noqa: E402
from adapters import repository_context_adapter as rca  # noqa: E402

JAD = """ja source 0.3
module suite40.demo.freshness
use Data
policy no_network

schema DemoRecord {
    id: Count primary
}
dataset demo_records
    from dmk("demo_records.dmk")
    validate DemoRecord
query admitted_demo { from demo_records select id }
emit json admitted_demo
"""
DMK = """ja source 0.3
module suite40.demo.freshness.source
use DeepMLKernel
policy no_network
kernel DemoSource(seed: Tensor<f32>[1,5]) -> Dataset<DemoRecord>
{ emit_row output[0] }
emit dataset "demo_records.dmk"
"""
JASP = """ja source 0.3
module suite66.demo.terminal
use Service
policy no_network
service DemoService {
    message Ping { id: Text }
    endpoint ping(request: Ping) -> Stream<Ping>
        auth capability demo.ping
    protocol P { state Open }
}
integrate { Suite_40_Repository_Context_Engine; Suite_99_Missing }
emit json DemoService.compatibility_report
"""
PY = """import os
from pathlib import Path

class Thing:
    def run(self):
        return 1

def helper():
    return 2
"""


def _git(cwd: Path, *args: str) -> str:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t",
           "GIT_COMMITTER_EMAIL": "t@t", "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z", "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z"}
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=True, env=env).stdout.strip()


class Fixture(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "repo"
        (self.root / "Repository Context Engine").mkdir(parents=True)
        (self.root / "Terminal").mkdir()
        (self.root / "tools").mkdir()
        _git(self.root, "init", "-q")
        (self.root / "Repository Context Engine" / "40.4_Demo_Freshness.jad").write_text(JAD)
        (self.root / "Repository Context Engine" / "demo_records.dmk").write_text(DMK)
        (self.root / "Terminal" / "66.01_Demo.jasp").write_text(JASP)
        (self.root / "tools" / "thing.py").write_text(PY)
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c1")
        self.c1 = _git(self.root, "rev-parse", "HEAD")

    def tearDown(self) -> None:
        self.tmp.cleanup()


class TestContext(Fixture):
    def test_records_are_shaped_and_deterministic(self) -> None:
        b1 = rca.build_context(self.root)
        b2 = rca.build_context(self.root)
        self.assertEqual(b1.context["file_count"], 4)
        self.assertEqual(b1.context["record_schema"], "suite40.repository_context_engine.context/RepositoryContextRecord")
        self.assertEqual(b1.freshness["freshness_status"], "fresh")
        self.assertEqual(b1.worktree["base_revision"], self.c1)
        # deterministic apart from timestamps: same ids/hashes across two runs
        self.assertEqual(b1.context["context_hash"], b2.context["context_hash"])
        self.assertEqual([s["symbol_id"] for s in b1.symbols], [s["symbol_id"] for s in b2.symbols])
        self.assertEqual([d["dependency_id"] for d in b1.dependencies], [d["dependency_id"] for d in b2.dependencies])
        for rec in (b1.context, b1.worktree, b1.freshness, *b1.symbols, *b1.dependencies):
            for k in ("sophia_judgment", "charlotte_validation", "landon_status", "podium_receipt", "repository_id", "worktree_id"):
                self.assertIn(k, rec)
        json.loads(b1.to_json())  # serializable

    def test_symbols_and_dependencies(self) -> None:
        b = rca.build_context(self.root)
        kinds = {(s["file_path"], s["symbol_kind"], s["qualified_name"]) for s in b.symbols}
        self.assertIn(("Repository Context Engine/40.4_Demo_Freshness.jad", "schema", "suite40.demo.freshness.DemoRecord"), kinds)
        self.assertIn(("Repository Context Engine/40.4_Demo_Freshness.jad", "dataset", "suite40.demo.freshness.demo_records"), kinds)
        self.assertIn(("Repository Context Engine/demo_records.dmk", "kernel", "suite40.demo.freshness.source.DemoSource"), kinds)
        self.assertIn(("Terminal/66.01_Demo.jasp", "endpoint", "suite66.demo.terminal.ping"), kinds)
        self.assertIn(("tools/thing.py", "class", "tools.thing.Thing"), kinds)
        self.assertIn(("tools/thing.py", "function", "tools.thing.helper"), kinds)
        deps = {(d["source_node"], d["dependency_kind"], d["target_node"], d["resolution_status"]) for d in b.dependencies}
        self.assertIn(("Repository Context Engine/40.4_Demo_Freshness.jad", "data_source", "Repository Context Engine/demo_records.dmk", "resolved"), deps)
        self.assertIn(("Terminal/66.01_Demo.jasp", "suite_reference", "Suite_40_Repository_Context_Engine", "resolved"), deps)
        self.assertIn(("Terminal/66.01_Demo.jasp", "suite_reference", "Suite_99_Missing", "unresolved"), deps)
        self.assertIn(("tools/thing.py", "python_import", "os", "external"), deps)
        ds = [d for d in b.dependencies if d["dependency_kind"] == "data_source"]
        self.assertTrue(all(d["cycle_status"] == "acyclic" for d in ds))

    def test_index_is_from_pinned_revision_not_working_copy(self) -> None:
        # modify working copy without committing: records must still reflect c1 and freshness must go stale
        (self.root / "tools" / "thing.py").write_text(PY + "\ndef extra():\n    return 3\n")
        b = rca.build_context(self.root)
        names = {s["qualified_name"] for s in b.symbols}
        self.assertNotIn("tools.thing.extra", names)
        self.assertEqual(b.freshness["freshness_status"], "stale")
        self.assertEqual(b.freshness["stale_reason"], "uncommitted_changes_present")
        self.assertEqual(b.worktree["dirty_file_count"], 1)

    def test_fail_closed_inputs(self) -> None:
        with self.assertRaises(lga.AdapterError):
            rca.build_context(self.root, "no-such-rev")
        with self.assertRaises(lga.AdapterError) as ctx:
            rca.build_context(self.root, max_files=1)
        self.assertEqual(ctx.exception.code, "context.too_large")

    def test_cycle_detection(self) -> None:
        self.assertEqual(rca._nodes_on_cycles({"a": {"b"}, "b": {"c"}, "c": {"a"}, "d": {"a"}}), {"a", "b", "c"})
        self.assertEqual(rca._nodes_on_cycles({"a": {"b"}, "b": set()}), set())
        self.assertEqual(rca._nodes_on_cycles({"a": {"a"}}), {"a"})


if __name__ == "__main__":
    unittest.main()
