"""Regression tests for CLI authorization selection boundaries."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE.parent / "tools"))

from adapters import local_git_adapter as lga  # noqa: E402
import spb  # noqa: E402


class TestReceiptSelection(unittest.TestCase):
    def test_explicit_unknown_receipt_never_falls_back_to_latest(self) -> None:
        chain = [{"receipt_hash": "sha256:first"}, {"receipt_hash": "sha256:latest"}]
        with self.assertRaises(lga.AdapterError) as ctx:
            spb._select_receipt(chain, "sha256:missing")
        self.assertEqual(ctx.exception.code, "approval.receipt_not_found")

    def test_implicit_selection_still_uses_latest(self) -> None:
        chain = [{"receipt_hash": "sha256:first"}, {"receipt_hash": "sha256:latest"}]
        self.assertEqual(spb._select_receipt(chain, None)["receipt_hash"], "sha256:latest")


if __name__ == "__main__":
    unittest.main()
