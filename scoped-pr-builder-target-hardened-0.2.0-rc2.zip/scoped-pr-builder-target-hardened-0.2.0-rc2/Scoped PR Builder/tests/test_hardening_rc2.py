from __future__ import annotations

import json
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path, PurePosixPath

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import forge_adapter as F
from adapters import hard_limits as H
from adapters import identity as I
from adapters import local_model_provider as M
from adapters import patch_generator as P
from adapters import review_server as RS
from adapters import tool_discovery as TD


class HardeningRC2(unittest.TestCase):
    def test_effective_caps_only_narrow_and_validate(self):
        self.assertEqual(H.effective_caps(requested={"max_changed_files": 3}), {"max_changed_files": 3, "max_diff_lines": 400})
        with self.assertRaises(Exception):
            H.effective_caps(requested={"max_changed_files": 0})
        with self.assertRaises(Exception):
            H.effective_caps(environment={"max_diff_lines": True})

    def test_hard_caps_reject_conflict(self):
        data = json.loads(H.RULES_PATH.read_text(encoding="utf-8"))
        data["rules"]["GRD-01"]["parameters"]["hard_max_diff_lines"] = 401
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "rules.json"
            p.write_text(json.dumps(data), encoding="utf-8")
            with self.assertRaises(Exception):
                H.hard_caps(p)

    def test_identity_requires_timezone_and_digest_evidence(self):
        future = (datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat()
        good = I.VerifiedIdentity("github", "user:1", "oidc", "o/r", future, "sha256:" + "a" * 64)
        self.assertIs(I.require_current(good, repository="o/r"), good)
        bad_time = I.VerifiedIdentity("github", "user:1", "oidc", "o/r", "2030-01-01T00:00:00", "sha256:" + "a" * 64)
        with self.assertRaises(Exception):
            I.require_current(bad_time, repository="o/r")
        bad_hash = I.VerifiedIdentity("github", "user:1", "oidc", "o/r", future, "sha256:abc")
        with self.assertRaises(Exception):
            I.require_current(bad_hash, repository="o/r")

    def test_model_boundary_requires_full_pin_and_loopback(self):
        digest = "sha256:" + "b" * 64
        spec = M.LocalModelSpec("ollama", "coder", digest, "http://127.0.0.1:11434")
        result = M.propose_recipe(
            spec,
            lambda payload: {"recipe_name": "trim_trailing_whitespace", "recipe_args": {}, "evidence_refs": [], "rationale": "deterministic hygiene", "confidence": 0.9},
            {},
            {"trim_trailing_whitespace"},
        )
        self.assertEqual(result["recipe_name"], "trim_trailing_whitespace")
        with self.assertRaises(Exception):
            M.propose_recipe(M.LocalModelSpec("ollama", "coder", digest, "https://models.example.com"), lambda p: result, {}, {"trim_trailing_whitespace"})
        with self.assertRaises(Exception):
            M.propose_recipe(M.LocalModelSpec("ollama", "coder", "sha256:abc"), lambda p: result, {}, {"trim_trailing_whitespace"})

    def test_model_schema_is_exact(self):
        spec = M.LocalModelSpec("ollama", "coder", "sha256:" + "c" * 64)
        with self.assertRaises(Exception):
            M.propose_recipe(
                spec,
                lambda payload: {"recipe_name": "trim_trailing_whitespace", "recipe_args": {}, "evidence_refs": [], "rationale": "x", "confidence": 0.9, "extra": True},
                {},
                {"trim_trailing_whitespace"},
            )

    def test_unused_import_recipe_preserves_semantic_and_side_effect_imports(self):
        src = b"from __future__ import annotations\nimport plugin\n\nVALUE = 1\n"
        out = P.RECIPES["py_unused_imports"](None, PurePosixPath("x.py"), src, [])
        self.assertEqual(out, src)

    def test_unused_import_recipe_only_removes_explicitly_marked_line(self):
        src = b"import os  # spb: safe-remove-unused-import\nVALUE = 1\n"
        out = P.RECIPES["py_unused_imports"](None, PurePosixPath("x.py"), src, [])
        self.assertEqual(out, b"VALUE = 1\n")

    def test_review_host_parser_accepts_ipv4_ipv6_and_rejects_external(self):
        self.assertTrue(RS._host_header_loopback("127.0.0.1:8080"))
        self.assertTrue(RS._host_header_loopback("[::1]:8080"))
        self.assertTrue(RS._host_header_loopback("localhost"))
        self.assertFalse(RS._host_header_loopback("example.com"))
        self.assertFalse(RS._host_header_loopback("localhost.example.com"))

    def test_tool_discovery_does_not_assume_pytest_from_plain_pyproject(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "pyproject.toml").write_text("[project]\nname='x'\nversion='0.0.1'\n", encoding="utf-8")
            (root / "test_x.py").write_text("import unittest\n", encoding="utf-8")
            tests = [x for x in TD.discover(root) if x["kind"] == "tests"]
            self.assertEqual(tests[0]["name"], "unittest")

    def test_tool_discovery_honors_explicit_pytest_config(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "pyproject.toml").write_text("[project]\nname='x'\nversion='0.0.1'\n[tool.pytest.ini_options]\ntestpaths=['tests']\n", encoding="utf-8")
            tests = [x for x in TD.discover(root) if x["kind"] == "tests"]
            self.assertEqual(tests[0]["name"], "pytest")
            self.assertEqual(tests[0]["argv"][:3], [sys.executable, "-m", "pytest"])

    def test_required_checks_support_conclusion_and_fail_closed_on_duplicates(self):
        checks = [
            {"name": "test", "head_sha": "a", "status": "completed", "conclusion": "success"},
            {"name": "lint", "head_sha": "a", "status": "completed", "conclusion": "success"},
        ]
        self.assertTrue(F.required_checks_state(checks, ["test", "lint"], head_sha="a")["ready"])
        dup = checks + [{"name": "test", "head_sha": "a", "status": "completed", "conclusion": "success"}]
        state = F.required_checks_state(dup, ["test", "lint"], head_sha="a")
        self.assertFalse(state["ready"])
        self.assertEqual(state["duplicates"], ["test"])

    def test_draft_pr_requires_independent_push_grant_and_exact_ack(self):
        class Client:
            def __init__(self, commit): self.commit = commit
            def push(self, repository, branch, commit): return {"commit": self.commit}
            def create_draft_pr(self, repository, base, head, title, body): return {"draft": True, "number": 1}

        exp = (datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat()
        pr = F.ForgeGrant("github", "o/r", "pr.create", "human", exp)
        push = F.ForgeGrant("github", "o/r", "forge.push", "human", exp)
        with self.assertRaises(Exception):
            F.create_draft_pr(Client("abc"), pr, push_grant=None, provider="github", repository="o/r", base="main", branch="spb/x", commit="abc", title="x", body="x")
        ok = F.create_draft_pr(Client("abc"), pr, push_grant=push, provider="github", repository="o/r", base="main", branch="spb/x", commit="abc", title="x", body="x")
        self.assertEqual(ok["head_commit"], "abc")
        with self.assertRaises(Exception):
            F.create_draft_pr(Client("wrong"), pr, push_grant=push, provider="github", repository="o/r", base="main", branch="spb/x", commit="abc", title="x", body="x")


if __name__ == "__main__":
    unittest.main()
