"""Data-driven tests for the boundary port wiring (Phase 01 / *-T02; stdlib unittest).

Every port must load (stable ids, existing boundary, importable entry points, no side channels),
admit its boundary's valid example through ``Run.cross`` with a validated envelope and a chained
audit entry, and refuse a violating message with the exact code — with the denial recorded.
Validation profiles registered by API-*-T02 bound payload size, identity shape and versions.
"""
from __future__ import annotations

import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import architecture as A  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import controls as K  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import wiring as W  # noqa: E402

REPO_ROOT = HERE.parent.parent


def _guarded(run):
    """Phase 02: guarded effects need guardrail facts at every crossing; these port tests exercise the wiring with
    satisfied guardrails (the rules' own PASS examples). Blocking paths live in tests/test_guardrails_enforcement.py."""
    try:
        from adapters import guardrails as GR
        rules = GR.load_rules(registry=run.registry)
    except Exception:
        return run
    orig = run.cross

    def cross(bid, effect, cid, payload, **kw):
        if "guardrail_facts" not in kw:
            kw["guardrail_facts"] = {rid: r["examples"]["pass"] for rid, r in rules["rules"].items() if effect in r["evaluates_on"]}
        return orig(bid, effect, cid, payload, **kw)
    run.cross = cross
    return run


def _identity(reg):
    ex = reg["contracts"]["api_envelope"]["examples"]["valid"]
    return copy.deepcopy(ex["identity"])


class TestWiring(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.b = A.load_boundaries(registry=self.reg)
        self.w = W.load_wiring(boundaries=self.b, registry=self.reg)
        self.tmp = tempfile.TemporaryDirectory()
        self.run = _guarded(W.Run(Path(self.tmp.name) / "run", _identity(self.reg), repo_root=REPO_ROOT, registry=self.reg, boundaries=self.b, wiring=self.w))

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_wiring_loads_and_is_hash_stable(self) -> None:
        self.assertEqual(self.w["computed_hash"], W.load_wiring(boundaries=self.b, registry=self.reg)["computed_hash"])
        for pid, p in self.w["ports"].items():
            with self.subTest(port=pid):
                self.assertEqual(p["side_channels"], [])
                self.assertEqual(pid, f"port:{p['boundary_id']}")

    def test_every_port_admits_and_refuses(self) -> None:
        for pid, p in self.w["ports"].items():
            entry = self.b["boundaries"][p["boundary_id"]]
            ex = entry["examples"]["valid"]
            with self.subTest(port=pid):
                key = K.idempotency_key(self.run.identity["run_id"], p["boundary_id"], {"payload": ex.get("payload")}) if ex["effect"] in p["idempotency_required_effects"] else None
                out = self.run.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], ex.get("payload"), direction=ex["direction"], idempotency_key=key)
                self.assertEqual(out["crossing"]["verdict"], "ADMITTED")
                self.assertEqual(out["audit_entry"]["verdict"], "ADMITTED")
                self.assertEqual(out["envelope"]["contract_version"], self.reg["contracts"][ex["payload_contract"]]["version"])
                # a contract the port does not carry is refused and the denial is on the ledger
                with self.assertRaises(lga.AdapterError) as ctx:
                    self.run.cross(ex["boundary_id"], ex["effect"], "api_envelope", {}, direction=ex["direction"])
                self.assertEqual(ctx.exception.code, "wiring.contract_not_wired")
                last = self.run.audit_entries()[-1]
                self.assertEqual(last["verdict"], "DENIED")
                self.assertEqual(last["denial_code"], "wiring.contract_not_wired")
                # a denied effect is refused by the boundary itself
                if entry["denied_effects"]:
                    with self.assertRaises(lga.AdapterError) as ctx:
                        self.run.cross(ex["boundary_id"], entry["denied_effects"][0], ex["payload_contract"], ex.get("payload"), direction=ex["direction"])
                    self.assertEqual(ctx.exception.code, "boundary.effect_denied")

    def test_audit_chain_is_verified(self) -> None:
        ex = self.b["boundaries"]["connector_adaptor"]["examples"]["valid"]
        self.run.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], ex.get("payload"), direction=ex["direction"])
        entries = self.run.audit_entries()
        self.assertGreaterEqual(len(entries), 1)
        text = self.run.audit_path.read_text(encoding="utf-8")
        self.run.audit_path.write_text(text.replace('"ADMITTED"', '"TAMPERED"', 1), encoding="utf-8")
        with self.assertRaises(lga.AdapterError):
            self.run.audit_entries()

    def test_run_directory_must_be_outside_repository(self) -> None:
        with self.assertRaises(lga.AdapterError) as ctx:
            W.Run(REPO_ROOT / "Scoped PR Builder" / "run", _identity(self.reg), repo_root=REPO_ROOT, registry=self.reg, boundaries=self.b, wiring=self.w)
        self.assertEqual(ctx.exception.code, "run.inside_repository")

    def test_identity_pinning(self) -> None:
        ex = self.b["boundaries"]["connector_adaptor"]["examples"]["valid"]
        other = _identity(self.reg); other["run_id"] = "sha256:" + "9" * 64
        with self.assertRaises(lga.AdapterError) as ctx:
            self.run.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], ex.get("payload"), identity=other)
        self.assertEqual(ctx.exception.code, "identity.mismatch")
        bad = _identity(self.reg); bad["base_revision"] = "HEAD"
        with self.assertRaises(lga.AdapterError) as ctx:
            W.Run(Path(self.tmp.name) / "run2", bad, repo_root=REPO_ROOT, registry=self.reg, boundaries=self.b, wiring=self.w)
        self.assertEqual(ctx.exception.code, "run.identity_invalid")

    def test_validation_profiles(self) -> None:
        """API-*-T02: unbounded payloads, unknown fields, malformed identities, unsupported versions are refused."""
        profiled = {cid: e for cid, e in self.reg["contracts"].items() if "validation_profile" in e}
        if not profiled:
            self.skipTest("no validation profiles registered yet")
        ex = self.b["boundaries"]["connector_adaptor"]["examples"]["valid"]
        for cid, e in profiled.items():
            with self.subTest(contract=cid):
                prof = e["validation_profile"]
                self.assertTrue(prof["reject_unknown_fields"])
                self.assertGreater(prof["max_payload_bytes"], 0)
                self.assertEqual(W.payload_limit(cid, self.reg), prof["max_payload_bytes"])
                big = dict(copy.deepcopy(e["examples"]["valid"]), _pad="x" * (prof["max_payload_bytes"] + 1)) if isinstance(e["examples"]["valid"], dict) else None
                if big is not None:
                    with self.assertRaises(lga.AdapterError) as ctx:
                        C.validate_payload(cid, big, registry=self.reg)
                    self.assertEqual(ctx.exception.code, "schema.invalid")
                for v in prof.get("unsupported_versions", []):
                    with self.assertRaises(lga.AdapterError) as ctx:
                        self.run.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], ex.get("payload"), declared_version=v)
                    self.assertIn(ctx.exception.code, ("version.incompatible", "version.invalid"))
        # size bound at the port
        with self.assertRaises(lga.AdapterError) as ctx:
            self.run.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], dict(ex["payload"], repository_root="/" + "x" * W.payload_limit("bind_request", self.reg)))
        self.assertEqual(ctx.exception.code, "payload.unbounded")

    def test_idempotent_replay(self) -> None:
        p = self.w["ports"]["port:connector_adaptor"]
        if not p["idempotency_required_effects"]:
            self.skipTest("no idempotent effects wired")
        eff = p["idempotency_required_effects"][0]
        ex = self.b["boundaries"]["connector_adaptor"]["examples"]["valid"]
        with self.assertRaises(lga.AdapterError) as ctx:
            self.run.cross("connector_adaptor", eff, ex["payload_contract"], ex["payload"])
        self.assertEqual(ctx.exception.code, "idempotency.required")
        key = "sha256:" + "7" * 64
        first = self.run.cross("connector_adaptor", eff, ex["payload_contract"], ex["payload"], idempotency_key=key)
        again = self.run.cross("connector_adaptor", eff, ex["payload_contract"], ex["payload"], idempotency_key=key)
        self.assertEqual(first["replay"], "EXECUTE"); self.assertEqual(again["replay"], "REPLAY_SAME")
        self.assertEqual(sum(1 for e in self.run.audit_entries() if e["effect"] == eff and e["verdict"] == "ADMITTED"), 1)
        with self.assertRaises(lga.AdapterError) as ctx:
            self.run.cross("connector_adaptor", eff, ex["payload_contract"], dict(ex["payload"], revision="main"), idempotency_key=key)
        self.assertEqual(ctx.exception.code, "idempotency.conflict")

    def test_dispatch_binds_a_real_repository(self) -> None:
        repo = Path(self.tmp.name) / "repo"
        repo.mkdir()
        subprocess.run(["git", "init", "-q", str(repo)], check=True)
        (repo / "a.txt").write_text("a\n")
        subprocess.run(["git", "-C", str(repo), "add", "."], check=True)
        subprocess.run(["git", "-C", str(repo), "-c", "user.email=t@t", "-c", "user.name=t", "commit", "-q", "-m", "init"], check=True)
        payload = {"request_id": "sha256:" + "1" * 64, "repository_root": str(repo), "revision": "HEAD", "require_clean": True}
        out = self.run.dispatch("connector_adaptor", "repository.bind", "bind_request", payload)
        self.assertTrue(out["executed"])
        self.assertEqual(out["result"].dirty_file_count, 0)
        C.validate_payload("repository_binding", json.loads(out["result"].to_json()), registry=self.reg)

    def test_identity_carried_across_boundaries(self) -> None:
        """ARCH-*-T03: identity is pinned, provenance_ref advances with the chain, model_version is settable only where declared."""
        policed = {bid: e for bid, e in self.b["boundaries"].items() if "identity_policy" in e and f"port:{bid}" in self.w["ports"]}
        if not policed:
            self.skipTest("no identity policies registered yet")
        for bid, e in policed.items():
            ex = e["examples"]["valid"]
            p = self.w["ports"][f"port:{bid}"]
            with self.subTest(boundary=bid):
                head_before, hop_before = self.run.provenance_head, self.run.hop
                key = K.idempotency_key(self.run.identity["run_id"], bid + ".t03", {"payload": ex.get("payload")}) if ex["effect"] in p["idempotency_required_effects"] else None
                out = self.run.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], ex.get("payload"), direction=ex["direction"], idempotency_key=key)
                self.assertEqual(out["envelope"]["identity"]["provenance_ref"], self.run.provenance_head)
                self.assertNotEqual(self.run.provenance_head, head_before)
                self.assertEqual(self.run.hop, hop_before + 1)
                self.assertEqual(out["provenance_link"]["parent_ref"], head_before)
                self.assertEqual(out["audit_entry"]["trace_vector"], f"{self.run.trace_base}.{self.run.hop}")
                for f in e["identity_policy"]["immutable_across"]:
                    self.assertEqual(out["envelope"]["identity"][f], self.run.identity[f])
                # an immutable field changed -> refused; a stale provenance_ref -> refused
                foreign = self.run.current_identity(); foreign["policy_hash"] = "sha256:" + "e" * 64
                with self.assertRaises(lga.AdapterError) as ctx:
                    self.run.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], ex.get("payload"), direction=ex["direction"], identity=foreign)
                self.assertEqual(ctx.exception.code, "identity.mismatch")
                stale = self.run.current_identity(); stale["provenance_ref"] = head_before
                with self.assertRaises(lga.AdapterError) as ctx:
                    self.run.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], ex.get("payload"), direction=ex["direction"], identity=stale)
                self.assertEqual(ctx.exception.code, "provenance.stale_ref")
                # model_version may be set only where the policy says so
                mv = self.run.current_identity(); mv["model_version"] = "local-model/1"
                if "model_version" in e["identity_policy"].get("may_set", []):
                    key2 = K.idempotency_key(self.run.identity["run_id"], bid + ".mv", {"payload": ex.get("payload")}) if key else None
                    out2 = self.run.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], ex.get("payload"), direction=ex["direction"], identity=mv, idempotency_key=key2)
                    self.assertEqual(out2["envelope"]["identity"]["model_version"], "local-model/1")
                else:
                    with self.assertRaises(lga.AdapterError) as ctx:
                        self.run.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], ex.get("payload"), direction=ex["direction"], identity=mv)
                    self.assertEqual(ctx.exception.code, "identity.field_not_settable")
        # the provenance chain is verified on every read
        links = self.run._provenance_links()
        self.assertGreaterEqual(len(links), len(policed))
        text = self.run.provenance_path.read_text(encoding="utf-8")
        self.run.provenance_path.write_text(text.replace('"inbound"', '"outbound"', 1) if '"inbound"' in text else text.replace('"outbound"', '"inbound"', 1), encoding="utf-8")
        with self.assertRaises(lga.AdapterError):
            self.run._provenance_links()

    def test_decision_references(self) -> None:
        """API-*-T03: state-changing messages must carry immutable identities and policy/provenance references."""
        influenced = {cid: e for cid, e in self.reg["contracts"].items() if "decision_influence" in e}
        if not influenced:
            self.skipTest("no decision influence declared yet")
        for cid, e in influenced.items():
            infl = e["decision_influence"]
            payload = copy.deepcopy(e["examples"]["valid"])
            with self.subTest(contract=cid):
                good = self.run.current_identity()
                self.run._check_decision_refs(cid, good, payload)  # passing path
                if not infl["state_changing"]:
                    continue
                for f in infl.get("required_identity", []) + infl.get("required_refs", []):
                    bad = dict(good); bad[f] = None
                    with self.assertRaises(lga.AdapterError) as ctx:
                        self.run._check_decision_refs(cid, bad, payload)
                    self.assertEqual(ctx.exception.code, "identity.refs_missing", f)
                for path in infl.get("required_payload_ids", []):
                    broken = copy.deepcopy(payload); cur = broken
                    segs = path.split(".")
                    for seg in segs[:-1]:
                        cur = cur[seg]
                    cur[segs[-1]] = "not-an-id"
                    with self.assertRaises(lga.AdapterError) as ctx:
                        self.run._check_decision_refs(cid, good, broken)
                    self.assertEqual(ctx.exception.code, "identity.payload_id_missing", path)
        # through a real port: a state-changing boundary contract without provenance_ref is refused before the crossing
        wired = [(bid, e) for bid, e in self.b["boundaries"].items() if f"port:{bid}" in self.w["ports"] and e["examples"]["valid"]["payload_contract"] in influenced and influenced[e["examples"]["valid"]["payload_contract"]]["decision_influence"]["state_changing"]]
        for bid, e in wired[:3]:
            ex = e["examples"]["valid"]
            noref = self.run.current_identity(); noref["provenance_ref"] = None
            with self.assertRaises(lga.AdapterError) as ctx:
                self.run.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], ex.get("payload"), direction=ex["direction"], identity=noref)
            self.assertIn(ctx.exception.code, ("identity.refs_missing",))
            self.assertEqual(self.run.audit_entries()[-1]["denial_code"], ctx.exception.code)

    def test_fail_closed_classes(self) -> None:
        """ARCH-*-T04: unavailable, stale, unauthorized, malformed and version-incompatible inputs are refused and the denial is classified and recorded."""
        declared = {bid: e for bid, e in self.b["boundaries"].items() if (e["failure_behavior"].get("classes")) and f"port:{bid}" in self.w["ports"]}
        if not declared:
            self.skipTest("no failure classes declared yet")
        for bid, e in declared.items():
            ex = e["examples"]["valid"]
            p = self.w["ports"][f"port:{bid}"]
            classes = e["failure_behavior"]["classes"]
            with self.subTest(boundary=bid):
                self.assertEqual(set(classes), set(W.FAILURE_CLASSES))
                for cls, spec in classes.items():
                    self.assertTrue(spec["codes"], f"{bid}/{cls} declares no codes")
                    for code in spec["codes"]:
                        self.assertEqual(self.run.classify(bid, code), cls)
                key = K.idempotency_key(self.run.identity["run_id"], bid + ".t04", {"payload": ex.get("payload")}) if ex["effect"] in p["idempotency_required_effects"] else None
                trials = {
                    "malformed": dict(payload={"__not__": "a payload"}),
                    "unauthorized": dict(effect=e["denied_effects"][0]),
                    "version_incompatible": dict(declared_version="9.0.0"),
                }
                for cls, override in trials.items():
                    kwargs = dict(direction=ex["direction"], idempotency_key=key)
                    eff = override.get("effect", ex["effect"]); payload = override.get("payload", ex.get("payload"))
                    if "declared_version" in override:
                        kwargs["declared_version"] = override["declared_version"]
                    with self.assertRaises(lga.AdapterError) as ctx:
                        self.run.cross(ex["boundary_id"], eff, ex["payload_contract"], payload, **kwargs)
                    last = self.run.audit_entries()[-1]
                    self.assertEqual(last["verdict"], "DENIED"); self.assertEqual(last["denial_code"], ctx.exception.code)
                    self.assertEqual(last["denial_class"], cls, f"{bid}: {ctx.exception.code} classified {last['denial_class']}, expected {cls}")
                    self.assertTrue(last["fail_closed"]); self.assertTrue(last["reason"])
                # stale: a provenance_ref that is not the current head
                out = self.run.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], ex.get("payload"), direction=ex["direction"], idempotency_key=key)
                stale = self.run.current_identity(); stale["provenance_ref"] = out["provenance_link"]["parent_ref"]
                with self.assertRaises(lga.AdapterError) as ctx:
                    self.run.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], ex.get("payload"), direction=ex["direction"], identity=stale)
                self.assertEqual(self.run.audit_entries()[-1]["denial_class"], "stale")
                # unavailable: an authoritative suite file that is gone at crossing time
                broken = copy.deepcopy(self.b); broken["boundaries"][bid]["authoritative_suites"][0]["file"] = "Nope/99_missing.jad"
                r2 = _guarded(W.Run(Path(self.tmp.name) / f"run-{bid}", _identity(self.reg), repo_root=REPO_ROOT, registry=self.reg, boundaries=broken, wiring=self.w))
                with self.assertRaises(lga.AdapterError) as ctx:
                    r2.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], ex.get("payload"), direction=ex["direction"])
                self.assertEqual(ctx.exception.code, "boundary.unavailable")
                self.assertEqual(r2.audit_entries()[-1]["denial_class"], "unavailable")

    def test_lifecycle_and_retries(self) -> None:
        """API-*-T04: compatibility/migration/deprecation declared per contract; retries never duplicate privileged effects."""
        lc = {cid: e for cid, e in self.reg["contracts"].items() if "lifecycle" in e}
        if not lc:
            self.skipTest("no lifecycle declared yet")
        for cid, e in lc.items():
            with self.subTest(contract=cid):
                self.run._check_lifecycle(cid, e)  # active contracts pass
                self.assertIn(e["lifecycle"]["deprecation"]["status"], ("active", "deprecated", "sunset"))
                dep = copy.deepcopy(e); dep["lifecycle"]["deprecation"] = {"status": "deprecated", "replaced_by": f"{cid}/0.2.0", "accept_until_sunset": False}
                with self.assertRaises(lga.AdapterError) as ctx:
                    self.run._check_lifecycle(cid, dep)
                self.assertEqual(ctx.exception.code, "contract.deprecated")
                sun = copy.deepcopy(e); sun["lifecycle"]["deprecation"] = {"status": "sunset", "replaced_by": f"{cid}/1.0.0"}
                with self.assertRaises(lga.AdapterError) as ctx:
                    self.run._check_lifecycle(cid, sun)
                self.assertEqual(ctx.exception.code, "contract.sunset")
                bad = copy.deepcopy(e); bad["lifecycle"]["migration"] = [{"from": "0.2.0", "to": "0.1.0", "action": "downgrade"}]
                with self.assertRaises(lga.AdapterError) as ctx:
                    self.run._check_lifecycle(cid, bad)
                self.assertEqual(ctx.exception.code, "lifecycle.migration_invalid")
                self.assertEqual(K.compatibility(e["version"], e["version"]), "COMPATIBLE")
        # a deprecated contract is refused at the port, and the denial is classified version_incompatible
        reg2 = copy.deepcopy(self.reg); reg2["contracts"]["bind_request"]["lifecycle"] = {"compatibility_policy": "same_major_and_minor_lte_supported", "migration": [], "idempotency": {}, "deprecation": {"status": "deprecated", "replaced_by": "bind_request/0.2.0", "accept_until_sunset": False}}
        r2 = _guarded(W.Run(Path(self.tmp.name) / "run-dep", _identity(self.reg), repo_root=REPO_ROOT, registry=reg2, boundaries=self.b, wiring=self.w))
        ex = self.b["boundaries"]["connector_adaptor"]["examples"]["valid"]
        with self.assertRaises(lga.AdapterError) as ctx:
            r2.cross(ex["boundary_id"], ex["effect"], ex["payload_contract"], ex["payload"])
        self.assertEqual(ctx.exception.code, "contract.deprecated")
        self.assertEqual(r2.audit_entries()[-1]["denial_class"], "version_incompatible")
        # every guarded port: a privileged effect retried with the same key executes once
        for pid, p in self.w["ports"].items():
            if not p.get("privileged_effects_guarded") or not p["idempotency_required_effects"]:
                continue
            e = self.b["boundaries"][p["boundary_id"]]; ex = e["examples"]["valid"]
            eff = p["idempotency_required_effects"][0]
            if ex["direction"] != "inbound" and ex["payload_contract"] not in p["outbound_contracts"]:
                continue
            key = K.idempotency_key(self.run.identity["run_id"], p["boundary_id"] + ".retry", {"payload": ex.get("payload")})
            first = self.run.cross(p["boundary_id"], eff, ex["payload_contract"], ex.get("payload"), direction=ex["direction"], idempotency_key=key)
            again = self.run.cross(p["boundary_id"], eff, ex["payload_contract"], ex.get("payload"), direction=ex["direction"], idempotency_key=key)
            self.assertEqual((first["replay"], again["replay"]), ("EXECUTE", "REPLAY_SAME"))
            self.assertEqual(sum(1 for a in self.run.audit_entries() if a.get("idempotency_key") == key and a["verdict"] == "ADMITTED"), 1)

    def test_side_channel_scan_fails_closed(self) -> None:
        broken = copy.deepcopy(self.w)
        pid = next(iter(broken["ports"]))
        broken["ports"][pid]["side_channels"] = ["shared_tmp_file"]
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump({k: v for k, v in broken.items() if k != "computed_hash"}, f)
        with self.assertRaises(lga.AdapterError) as ctx:
            W.load_wiring(Path(f.name), boundaries=self.b, registry=self.reg)
        self.assertEqual(ctx.exception.code, "wiring.side_channel")


if __name__ == "__main__":
    unittest.main()
