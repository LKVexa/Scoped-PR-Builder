"""Deterministic tests for hash-bound approval and isolated application (stdlib unittest)."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch as mock_patch
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import approval_adapter as aa  # noqa: E402
from adapters import evidence_retrieval as er  # noqa: E402
from adapters import intent_intake as ii  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import patch_generator as pg  # noqa: E402
from adapters import review_renderer as rr  # noqa: E402
from adapters import verification_runner as vr  # noqa: E402


def _git(cwd: Path, *args: str) -> str:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t",
           "GIT_COMMITTER_EMAIL": "t@t", "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z", "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z"}
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=True, env=env).stdout.strip()


HDR = "ja source 0.3\nmodule suite{n}.demo\nuse Data\npolicy no_network\nemit json demo\n"


class Fixture(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        base = Path(self.tmp.name)
        self.root = base / "repo"
        self.root.mkdir()
        _git(self.root, "init", "-q")
        for n in range(1, 67):
            d = self.root / f"Suite{n:02d}"
            d.mkdir()
            (d / f"{n:02d}_demo.jad").write_text(HDR.format(n=n))
        (self.root / "Suite04" / "SHA256SUMS.txt").write_text("0000  04_Old/04_demo.jad\n")
        tests = self.root / "Scoped PR Builder" / "tests"
        tests.mkdir(parents=True)
        (tests / "test_ok.py").write_text("import unittest\nclass T(unittest.TestCase):\n    def test_a(self):\n        self.assertTrue(True)\nif __name__ == '__main__':\n    unittest.main()\n")
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c1")
        self.run_dir = base / "run"
        self.run_dir.mkdir()
        self.key_path = base / "keys" / "approval.key"
        self.key = aa.load_or_create_key(self.key_path, create=True)
        self.binding = lga.bind_repository(self.root)
        self.contract = json.loads(ii.accept_intent({"kind": "tech_debt_refactor", "title": "Regenerate stale Suite04 SHA256SUMS manifest", "description": "x",
                                                     "allowed_paths": ["Suite04/SHA256SUMS.txt"], "max_changed_files": 1, "max_diff_lines": 10, "requested_by": "t"}, self.binding).to_json())
        self.bundle = er.retrieve_examples(self.binding, self.contract)
        self.plan = er.build_plan(self.contract, self.bundle)
        cand, self.patch = pg.generate_candidate(self.binding, self.contract, self.plan, "regenerate_sha256sums_manifest")
        self.cand = json.loads(cand.to_json())
        self.report = json.loads(vr.verify_candidate(self.binding, self.contract, self.cand, self.patch, base / "sb").to_json())
        self.assertEqual(self.report["verdict"], "PASS")
        self.card = rr.build_review_card(json.loads(self.binding.to_json()), self.contract, self.bundle.evidence, self.bundle.authority, self.plan, self.cand, self.patch, self.report)
        self.wt_parent = base / "applied"

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def approve(self, decision="APPROVE", **kw):
        return json.loads(aa.issue_receipt(self.run_dir, self.key, decision=decision, approver_identity="reviewer@example", approver_channel="test",
                                           rationale="looks right", candidate=self.cand, card=self.card, report=self.report, **kw).to_json())

    def approve_for(self, report, card):
        return json.loads(aa.issue_receipt(self.run_dir, self.key, decision="APPROVE", approver_identity="reviewer@example", approver_channel="test",
                                           rationale="ok", candidate=self.cand, card=card, report=report).to_json())

    def apply(self, receipt, **over):
        args = dict(binding=self.binding, contract=self.contract, candidate=self.cand, patch=self.patch, report=self.report, card=self.card, receipt=receipt, key=self.key, run_dir=self.run_dir, worktree_parent=self.wt_parent)
        args.update(over)
        return aa.apply_isolated(**args)


class TestApproval(Fixture):
    def test_receipt_chain_and_isolated_apply(self) -> None:
        r = self.approve()
        for f in aa.BOUND_FIELDS:
            self.assertIn(f, r)
        self.assertTrue(r["signature"].startswith("hmac-sha256:"))
        chain = aa.verify_chain(self.run_dir, self.cand["candidate_id"], self.key)
        self.assertEqual(len(chain), 1)
        self.assertEqual(chain[0]["prev_hash"], self.cand["candidate_id"])
        rec = self.apply(r)
        self.assertEqual(rec.changed_paths, ("Suite04/SHA256SUMS.txt",))
        self.assertTrue(rec.post_apply_tree.startswith("git-tree:"))
        self.assertTrue(rec.source_tree_unchanged)
        wt = Path(rec.applied_worktree)
        self.assertTrue(wt.is_dir() and self.root not in wt.parents)
        self.assertNotIn("04_Old", (wt / "Suite04" / "SHA256SUMS.txt").read_text())
        self.assertIn("04_Old", (self.root / "Suite04" / "SHA256SUMS.txt").read_text())  # source untouched
        self.assertEqual(_git(self.root, "status", "--porcelain"), "")
        body = json.loads(rec.to_json()); body.pop("record_hash")
        self.assertEqual(lga.sha256_digest(lga.canonical_json(body)), rec.record_hash)

    def test_fabricated_and_tampered_receipts_rejected(self) -> None:
        r = self.approve()
        # (a) receipt edited after issuance
        with self.assertRaises(lga.AdapterError) as ctx:
            self.apply(dict(r, rationale="edited"))
        self.assertEqual(ctx.exception.code, "approval.not_in_ledger")
        # (b) a fabricated receipt with a fake signature, never in the ledger
        fake = dict(r, nonce="00" * 16)
        fake["receipt_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in fake.items() if k not in ("receipt_hash", "signature")}))
        fake["signature"] = "hmac-sha256:" + "0" * 64
        with self.assertRaises(lga.AdapterError) as ctx:
            self.apply(fake)
        self.assertEqual(ctx.exception.code, "approval.not_in_ledger")
        # (c) ledger line forged with the wrong key → chain verification fails for everyone
        other = aa.load_or_create_key(Path(self.tmp.name) / "keys" / "other.key", create=True)
        forged = json.loads(aa.issue_receipt(Path(self.tmp.name) / "run2", other, decision="APPROVE", approver_identity="x", approver_channel="x", rationale="x",
                                             candidate=self.cand, card=self.card, report=self.report).to_json())
        with (self.run_dir / "approvals" / "ledger.jsonl").open("a") as f:
            f.write(json.dumps(forged, sort_keys=True) + "\n")
        with self.assertRaises(lga.AdapterError) as ctx:
            self.apply(r)
        self.assertIn(ctx.exception.code, ("approval.signature_invalid", "approval.chain_broken"))

    def test_reject_and_supersession(self) -> None:
        rej = self.approve("REJECT")
        with self.assertRaises(lga.AdapterError) as ctx:
            self.apply(rej)
        self.assertEqual(ctx.exception.code, "approval.not_approved")
        ok = self.approve("APPROVE")
        later = json.loads(aa.issue_receipt(self.run_dir, self.key, decision="REQUEST_CHANGES", approver_identity="r", approver_channel="test", rationale="wait",
                                            candidate=self.cand, card=self.card, report=self.report).to_json())
        self.assertEqual(later["prev_hash"], ok["receipt_hash"])  # ledger order is the supersession order
        with self.assertRaises(lga.AdapterError) as ctx:
            self.apply(ok)
        self.assertEqual(ctx.exception.code, "approval.superseded")

    def test_historical_verification_ignores_decisions_issued_after_that_time(self) -> None:
        base = datetime.now(timezone.utc).replace(microsecond=0) - timedelta(minutes=3)
        later_time = base + timedelta(minutes=1)
        with mock_patch.object(aa, "_now", return_value=base):
            approved = self.approve("APPROVE")
        with mock_patch.object(aa, "_now", return_value=later_time):
            changed = self.approve("REQUEST_CHANGES")
        self.assertEqual(changed["prev_hash"], approved["receipt_hash"])
        # At application time the approval was still current.
        aa.verify_receipt(self.run_dir, self.key, approved, candidate=self.cand, card=self.card, report=self.report, now=base + timedelta(seconds=30))
        # Once the later decision exists in time, the old approval is superseded.
        with self.assertRaises(lga.AdapterError) as ctx:
            aa.verify_receipt(self.run_dir, self.key, approved, candidate=self.cand, card=self.card, report=self.report, now=later_time)
        self.assertEqual(ctx.exception.code, "approval.superseded")

    def test_expiry_and_binding(self) -> None:
        r = self.approve(ttl_minutes=1)
        with self.assertRaises(lga.AdapterError) as ctx:
            aa.verify_receipt(self.run_dir, self.key, r, candidate=self.cand, card=self.card, report=self.report, now=datetime.now(timezone.utc) + timedelta(minutes=2))
        self.assertEqual(ctx.exception.code, "approval.expired")
        other_cand = dict(self.cand, candidate_id="sha256:other")
        with self.assertRaises(lga.AdapterError) as ctx:
            aa.verify_receipt(self.run_dir, self.key, r, candidate=other_cand, card=self.card, report=self.report)
        self.assertIn(ctx.exception.code, ("approval.binding_mismatch", "approval.chain_broken"))

    def test_apply_refuses_stale_head_and_failed_verification(self) -> None:
        r = self.approve()
        # an edited verdict is tampering, refused before any verdict logic runs
        with self.assertRaises(lga.AdapterError) as ctx:
            self.apply(r, report=dict(self.report, verdict="FAIL"))
        self.assertEqual(ctx.exception.code, "report.tampered")
        # a genuine non-PASS report (tests skipped -> INDETERMINATE) with a valid hash is refused on its verdict
        genuine = json.loads(vr.verify_candidate(self.binding, self.contract, self.cand, self.patch, Path(self.tmp.name) / "sb2", run_tests=False).to_json())
        self.assertEqual(genuine["verdict"], "INDETERMINATE")
        card2 = rr.build_review_card(json.loads(self.binding.to_json()), self.contract, self.bundle.evidence, self.bundle.authority, self.plan, self.cand, self.patch, genuine)
        r2 = self.approve_for(genuine, card2)
        with self.assertRaises(lga.AdapterError) as ctx:
            self.apply(r2, report=genuine, card=card2)
        self.assertEqual(ctx.exception.code, "apply.verification_not_pass")
        (self.root / "Suite05" / "x.txt").write_text("x\n")
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c2")
        with self.assertRaises(lga.AdapterError) as ctx:
            self.apply(r)
        self.assertEqual(ctx.exception.code, "freshness.stale")
        self.assertFalse(self.wt_parent.exists())


if __name__ == "__main__":
    unittest.main()
