"""Deterministic tests for refactor-intent intake / scope contract (stdlib unittest)."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import intent_intake as ii  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402


def _git(cwd: Path, *args: str) -> str:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t",
           "GIT_COMMITTER_EMAIL": "t@t", "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z", "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z"}
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=True, env=env).stdout.strip()


def good_intent(**over):
    base = {
        "kind": "tech_debt_refactor",
        "title": "Remove duplicated helper in src",
        "description": "Replace the two copies of helper() with one shared function; no behavior change.",
        "allowed_paths": ["src"],
        "forbidden_paths": ["src/secret.txt"],
        "max_changed_files": 3,
        "max_diff_lines": 40,
        "requested_by": "reviewer@example",
    }
    base.update(over)
    return base


class Fixture(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "repo"
        (self.root / "src").mkdir(parents=True)
        (self.root / "docs").mkdir()
        _git(self.root, "init", "-q")
        (self.root / "src" / "a.py").write_text("def helper():\n    return 1\n")
        (self.root / "src" / "secret.txt").write_text("x\n")
        (self.root / "docs" / "d.md").write_text("doc\n")
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c1")
        self.binding = lga.bind_repository(self.root)

    def tearDown(self) -> None:
        self.tmp.cleanup()


class TestIntake(Fixture):
    def test_accepts_narrow_intent_and_hash_binds(self) -> None:
        c = ii.accept_intent(good_intent(), self.binding)
        self.assertEqual(c.allowed_paths, ("src",))
        self.assertEqual(c.forbidden_paths, ("src/secret.txt",))
        self.assertEqual(c.base_revision, self.binding.base_revision)
        self.assertEqual(c.size_band_ceiling, "small")
        self.assertTrue(c.scope_contract_hash.startswith("sha256:"))
        stored = json.loads(c.to_json())
        ii.verify_contract_hash(stored)  # round-trips
        # same intent -> same intent_id and scope hash (deterministic)
        c2 = ii.accept_intent(good_intent(), self.binding)
        self.assertEqual(c.intent_id, c2.intent_id)
        self.assertEqual(c.scope_contract_hash, c2.scope_contract_hash)

    def test_tamper_detected(self) -> None:
        stored = json.loads(ii.accept_intent(good_intent(), self.binding).to_json())
        stored["allowed_paths"] = ["src", "docs"]
        with self.assertRaises(lga.AdapterError) as ctx:
            ii.verify_contract_hash(stored)
        self.assertEqual(ctx.exception.code, "contract.tampered")

    def test_rejections_fail_closed(self) -> None:
        cases = [
            (good_intent(extra="x"), "intent.unknown_fields"),
            ({k: v for k, v in good_intent().items() if k != "allowed_paths"}, "intent.missing_fields"),
            (good_intent(kind="feature"), "intent.kind_unsupported"),
            (good_intent(allowed_paths=[]), "scope.empty"),
            (good_intent(allowed_paths=["/src"]), "path.absolute"),
            (good_intent(allowed_paths=["src/../docs"]), "path.escape"),
            (good_intent(allowed_paths=["nope"]), "intent.path_not_in_tree"),
            (good_intent(allowed_paths=["src", "src"]), "intent.paths_duplicate"),
            (good_intent(max_changed_files=0), "intent.threshold_invalid"),
            (good_intent(max_changed_files=True), "intent.threshold_invalid"),
            (good_intent(max_diff_lines=ii.HARD_MAX_DIFF_LINES + 1), "intent.threshold_exceeds_cap"),
            (good_intent(max_changed_files=ii.HARD_MAX_CHANGED_FILES + 1), "intent.threshold_exceeds_cap"),
            (good_intent(forbidden_paths=["src"]), "intent.scope_empty_after_forbidden"),
            (good_intent(base_revision="0" * 40), "intent.binding_mismatch"),
            (good_intent(repository_id="sha256:bogus"), "intent.binding_mismatch"),
            (good_intent(title=""), "intent.field_invalid"),
            (good_intent(description="x" * 2001), "intent.field_too_long"),
            ("not-an-object", "intent.malformed"),
        ]
        for payload, code in cases:
            with self.subTest(code=code):
                with self.assertRaises(lga.AdapterError) as ctx:
                    ii.accept_intent(payload, self.binding)
                self.assertEqual(ctx.exception.code, code)

    def test_audit_ledger_cannot_be_in_scope(self) -> None:
        (self.root / "Scoped PR Builder").mkdir()
        (self.root / "Scoped PR Builder" / "PROVENANCE.jsonl").write_text("{}\n")
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c2")
        b = lga.bind_repository(self.root)
        with self.assertRaises(lga.AdapterError) as ctx:
            ii.accept_intent(good_intent(allowed_paths=["Scoped PR Builder"]), b)
        self.assertEqual(ctx.exception.code, "intent.scope_covers_audit_ledger")

    def test_size_bands(self) -> None:
        self.assertEqual(ii.size_band(10), "extra_small")
        self.assertEqual(ii.size_band(11), "small")
        self.assertEqual(ii.size_band(100), "medium")
        self.assertEqual(ii.size_band(400), "large")
        self.assertEqual(ii.size_band(401), "extra_large")


if __name__ == "__main__":
    unittest.main()
