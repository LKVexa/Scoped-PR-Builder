"""Human review and approval surface (Phase 11 / HUMAN-01..07; stdlib unittest).

T01: the review registry loads (one declared behavior per requirement, typed action, explicit side effects, existing
suites) and the surface exposes original evidence (byte-exact, hash-verified), exactly what was and was not analyzed,
scope narrowing for a rerun, rejection and evidence-request controls, the approval record and human accountability.
T02: everything displayed is bound to immutable run/candidate hashes; stale or tampered views are refused. T03: every
reviewer action is a typed command (identity, authority, scope, timestamp, nonce/idempotency key, explicit side effects),
executed once and replayed never. T04: non-applying commands cannot apply anything and any changed bound input (or a later
non-approving command) invalidates a prior approval.
"""
from __future__ import annotations

import copy
import inspect
import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from adapters import approval_adapter as aa  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import evidence_retrieval as er  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import patch_generator as pg  # noqa: E402
from adapters import review_renderer as rr  # noqa: E402
from adapters import review_surface as RS  # noqa: E402
from adapters import security as SEC  # noqa: E402
from adapters import verification_checks as VC  # noqa: E402
from test_components import _git, make_repo  # noqa: E402
from test_verification_checks import contract_for  # noqa: E402

BEHAVIOR_IDS = [f"HUMAN-{n:02d}" for n in range(1, 8)]


class Fixture:
    """One verified candidate over a fixture repository, with the artifacts a reviewer surface is built from."""

    def __init__(self, base: Path, allowed=("Suite04/SHA256SUMS.txt",), files=2, lines=20) -> None:
        self.base = base
        self.root = make_repo(base)
        self.binding = lga.bind_repository(self.root)
        self.reg = C.load_registry()
        self.contract = contract_for(self.binding, list(allowed), files=files, lines=lines)
        self.bundle = er.retrieve_examples(self.binding, self.contract)
        self.plan = er.build_plan(self.contract, self.bundle)
        cand, self.patch = pg.generate_candidate(self.binding, self.contract, self.plan, "regenerate_sha256sums_manifest")
        self.cand = json.loads(cand.to_json())
        self.report, self.results = VC.run_checks(self.binding, self.contract, self.cand, self.patch, base / "sb", registry=self.reg)
        self.card = rr.build_review_card(json.loads(self.binding.to_json()), self.contract, self.bundle.evidence, self.bundle.authority, self.plan, self.cand, self.patch, self.report)
        self.run_dir = base / "run"; self.run_dir.mkdir(exist_ok=True)
        self.key = aa.load_or_create_key(base / "keys" / "approval.key", create=True)
        self.review = RS.load_review(registry=self.reg)

    def artifacts(self, **over) -> dict:
        a = {"binding": self.binding, "scope_contract": self.contract, "evidence_bundle": json.loads(self.bundle.to_json()), "refactoring_plan": self.plan, "candidate": self.cand, "patch": self.patch, "verification_report": self.report, "review_card": self.card, "check_results": self.results}
        a.update(over)
        return a

    def surface(self, **over) -> dict:
        return RS.build_surface(self.artifacts(**over), run_id="sha256:" + "5" * 64, run_dir=self.run_dir, review=self.review, registry=self.reg)


class TestReviewSurface(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.f = Fixture(Path(self.tmp.name))
        SEC.use_trail(self.f.run_dir)

    def tearDown(self) -> None:
        SEC.use_trail(None)
        self.tmp.cleanup()

    def declared(self, bid: str) -> bool:
        return bid in self.f.review["behaviors"]

    def test_registry_loads_and_binds_every_declared_behavior(self) -> None:
        rv = self.f.review
        self.assertEqual(rv["review_version"], RS.REVIEW_VERSION); self.assertTrue(rv["computed_hash"].startswith("sha256:"))
        for bid, b in rv["behaviors"].items():
            with self.subTest(behavior=bid):
                self.assertIn(bid, BEHAVIOR_IDS); self.assertIn(b["reviewer_action"], RS.ACTIONS); self.assertFalse(b["side_effects"]["applies_patch"]); self.assertTrue(b["side_effects"]["effects"])
                self.assertTrue(any(s.endswith("50.5_Diff_Patch_and_Review_Human_Approval.ja") or s.endswith("50.3_Diff_Patch_and_Review_Diff_Review.ja") for s in b["authoritative_suites"]), "50.5 (or 50.3 for HUMAN-07) stays authoritative for evidence/approval semantics")
                self.assertTrue(all((RS.REPO_ROOT / s).is_file() for s in b["authoritative_suites"]))
        broken = copy.deepcopy(json.loads(RS.REVIEW_PATH.read_text(encoding="utf-8")))
        first = next(iter(broken["behaviors"]))
        for mutate, code in ((lambda q: q["behaviors"][first].__setitem__("reviewer_action", "apply_patch"), "review.registry_invalid"), (lambda q: q["behaviors"][first]["side_effects"].__setitem__("applies_patch", True), "review.registry_invalid"),
                             (lambda q: q["behaviors"][first]["authoritative_suites"].append("Nope/50.5.ja"), "review.suite_unbound"), (lambda q: q.__setitem__("review_version", "x/9.9.9"), "review.registry_invalid")):
            b = copy.deepcopy(broken); mutate(b); path = self.f.base / "REVIEW.json"; path.write_text(json.dumps(b), encoding="utf-8")
            with self.subTest(code=code):
                with self.assertRaises(RS.ReviewRefusal) as ctx:
                    RS.load_review(path, registry=self.f.reg)
                self.assertEqual(ctx.exception.code, code)
        with self.assertRaises(RS.ReviewRefusal) as ctx:
            RS.behavior_for("approve", {"behaviors": {}})
        self.assertEqual(ctx.exception.code, "review.action_undeclared")

    def test_reviewer_inspects_original_evidence_byte_exact(self) -> None:
        s = self.f.surface(); sec = s["sections"]["HUMAN-01"]
        self.assertEqual(sec["revision"], self.f.binding.base_revision); self.assertTrue(sec["items"]); self.assertEqual(s["authority"], "display_only")
        for item in sec["items"]:
            with self.subTest(path=item["path"]):
                ev = RS.inspect_evidence(self.f.root, self.f.binding.base_revision, item)
                self.assertTrue(ev["verified"]); self.assertEqual(ev["content_hash"], item["content_hash"]); self.assertEqual(lga.sha256_digest(lga.read_blob(self.f.root, self.f.binding.base_revision, lga.relative_path(item["path"]))), ev["content_hash"])
                self.assertEqual(ev["authority"], "display_only"); self.assertTrue(ev["text"] or ev["size"] == 0)
        tampered = dict(sec["items"][0], content_hash="sha256:" + "1" * 64)
        with self.assertRaises(RS.ReviewRefusal) as ctx:
            RS.inspect_evidence(self.f.root, self.f.binding.base_revision, tampered)
        self.assertEqual(ctx.exception.code, "review.evidence_mismatch")
        (self.f.root / "Suite04" / "SHA256SUMS.txt").write_text("edited\n"); _git(self.f.root, "add", "-A"); _git(self.f.root, "commit", "-q", "-m", "moved")
        ev = RS.inspect_evidence(self.f.root, self.f.binding.base_revision, sec["items"][0])  # the pinned revision, never the working tree
        self.assertEqual(ev["content_hash"], sec["items"][0]["content_hash"])
        with self.assertRaises(RS.ReviewRefusal) as ctx:
            RS.inspect_evidence(self.f.root, self.f.binding.base_revision, dict(sec["items"][0], path="Suite04/nope.txt"))
        self.assertEqual(ctx.exception.code, "review.evidence_missing")

    def test_reviewer_sees_exactly_what_was_and_was_not_analyzed(self) -> None:
        intake = {"DATA-01": {"state": "ADMITTED", "counts": {"items": 3, "excluded": 1}, "excluded": [{"path": "Suite04/secret.env", "reason": "secret-bearing"}]}, "DATA-02": {"state": "MISSING", "counts": {"items": 0, "excluded": 0}, "excluded": []}}
        s = self.f.surface(intake_records=intake, model_call={"provider": {"provider_id": "deterministic-advisor", "version": "0.1.0"}, "route": {"route": "accept"}, "call_id": "sha256:" + "c" * 64})
        cov = s["sections"]["HUMAN-02"]
        self.assertEqual([x["source_id"] for x in cov["analyzed"]["intake_sources_admitted"]], ["DATA-01"]); self.assertEqual([x["source_id"] for x in cov["not_analyzed"]["intake_sources_not_admitted"]], ["DATA-02"])
        self.assertEqual(cov["not_analyzed"]["intake_items_excluded"], [{"source_id": "DATA-01", "path": "Suite04/secret.env", "reason": "secret-bearing"}])
        self.assertTrue(cov["analyzed"]["checks_executed"]); self.assertIn("Suite04/SHA256SUMS.txt", cov["analyzed"]["evidence_targets"]); self.assertEqual(cov["analyzed"]["model_calls"][0]["route"], "accept")
        self.assertEqual(cov["not_analyzed"]["corpus_files_not_retrieved"], int(self.f.bundle.corpus_size) - len(self.f.bundle.evidence)); self.assertIn("NOT analyzed", cov["statement"]); self.assertIn("advisory", cov["not_analyzed"]["model_reasoning"])
        report = dict(self.f.report, jobs=[dict(j, verdict="INDETERMINATE", summary="not run") if j["check"] == "tests" else j for j in self.f.report["jobs"]])
        cov2 = RS.analysis_coverage(self.f.card, json.loads(self.f.bundle.to_json()), report, None, self.f.contract, None, None)
        self.assertIn("tests", cov2["not_analyzed"]["checks_not_executed"]); self.assertEqual(cov2["not_analyzed"]["model_reasoning"], "no model call recorded")

    def test_scope_narrowing_never_widens_and_rerun_is_a_new_intent(self) -> None:
        s = self.f.surface(); sec = s["sections"]["HUMAN-03"]
        self.assertEqual(sec["current"]["allowed_paths"], ["Suite04/SHA256SUMS.txt"]); self.assertEqual(sec["current"]["max_changed_files"], 2); self.assertIn("new scope contract", sec["rerun_semantics"])
        rerun = RS.narrow_scope(self.f.contract, allowed_paths=["Suite04/SHA256SUMS.txt"], max_changed_files=1, max_diff_lines=10)
        self.assertEqual(rerun["intent"]["allowed_paths"], ["Suite04/SHA256SUMS.txt"]); self.assertEqual(rerun["narrowed_from"], self.f.contract["scope_contract_hash"])
        from adapters import intent_intake as ii
        new = json.loads(ii.accept_intent(rerun["intent"], self.f.binding).to_json())
        self.assertNotEqual(new["scope_contract_hash"], self.f.contract["scope_contract_hash"]); self.assertEqual(new["max_changed_files"], 1)
        for kw, code in (({"allowed_paths": ["Suite04"]}, "review.scope_widening"), ({"allowed_paths": ["Suite05/05_demo.jad"]}, "review.scope_widening"), ({"allowed_paths": ["Suite04/SHA256SUMS.txt"], "max_changed_files": 9}, "review.scope_widening"), ({"allowed_paths": ["Suite04/SHA256SUMS.txt"], "max_diff_lines": 400}, "review.scope_widening"), ({"allowed_paths": []}, "review.scope_empty"), ({"allowed_paths": ["../etc"]}, None)):
            with self.subTest(kw=kw):
                with self.assertRaises(lga.AdapterError) as ctx:
                    RS.narrow_scope(self.f.contract, **kw)
                if code:
                    self.assertEqual(ctx.exception.code, code)

    def test_rejection_and_evidence_request_controls_declare_no_application(self) -> None:
        s = self.f.surface()
        for bid in ("HUMAN-04", "HUMAN-05"):
            sec = s["sections"][bid]
            self.assertFalse(sec["side_effects"]["applies_patch"]); self.assertTrue(sec["guarantees"]); self.assertIn(sec["action"], ("reject", "request_evidence"))
            if self.declared(bid):
                self.assertTrue(any("receipt" in e for e in sec["side_effects"]["effects"]))

    def test_approval_record_and_accountability(self) -> None:
        s = self.f.surface()
        self.assertTrue(s["sections"]["HUMAN-06"]["pending"]); self.assertEqual(s["sections"]["HUMAN-06"]["decisions"], [])
        acc = s["sections"]["HUMAN-07"]; self.assertEqual(acc["accountable_party"], "human reviewer"); self.assertIn("pending a human", acc["decided_by"]); self.assertIn("decide", acc["ai_cannot"]); self.assertEqual(acc["statement"], RS.ACCOUNTABILITY_STATEMENT)
        r = json.loads(aa.issue_receipt(self.f.run_dir, self.f.key, decision="APPROVE", approver_identity="reviewer@example", approver_channel="console", rationale="ok", candidate=self.f.cand, card=self.f.card, report=self.f.report).to_json())
        s2 = self.f.surface(); rec = s2["sections"]["HUMAN-06"]["decisions"][0]
        self.assertFalse(s2["sections"]["HUMAN-06"]["pending"]); self.assertEqual((rec["identity"], rec["channel"], rec["issued_at"], rec["receipt_hash"]), ("reviewer@example", "console", r["issued_at"], r["receipt_hash"]))
        self.assertEqual(rec["approved_scope"]["scope_contract_hash"], self.f.contract["scope_contract_hash"]); self.assertEqual(rec["approved_scope"]["candidate_paths"], list(self.f.cand["canonical_paths"])); self.assertEqual(rec["approved_scope"]["patch_hash"], self.f.cand["patch_hash"])
        self.assertEqual(s2["sections"]["HUMAN-07"]["decided_by"], "reviewer@example via console (APPROVE)")
        html = RS.render_surface_html(s2)
        self.assertIn("never rests with the AI", html); self.assertIn("reviewer@example", html); self.assertNotIn("<script", html)
        for word in ("decided by the model", "approved by the model", "AI approved"):
            self.assertNotIn(word, html.lower())
        with self.assertRaises(RS.ReviewRefusal) as ctx:
            self.f.surface(candidate=dict(self.f.cand, patch_hash="sha256:" + "2" * 64))
        self.assertEqual(ctx.exception.code, "review.artifact_mismatch")

    def test_everything_displayed_is_bound_to_immutable_hashes(self) -> None:
        s = RS.bind_view(self.f.surface(), self.f.artifacts(), run_id="sha256:" + "5" * 64)
        self.assertTrue(s["view_hash"].startswith("sha256:"))
        for k in RS.BOUND_FIELDS_VIEW:
            self.assertIn(k, s["bound_to"])
        self.assertEqual(s["bound_to"]["candidate_id"], self.f.cand["candidate_id"]); self.assertEqual(s["bound_to"]["card_hash"], self.f.card["card_hash"]); self.assertEqual(s["bound_to"]["report_hash"], self.f.report["report_hash"])
        self.assertEqual(sorted(s["displayed"]), ["diff", "evidence_links", "findings", "requested_actions", "rollback_plan", "uncertainty_state", "verification_results"])
        for k, v in s["displayed"].items():
            self.assertEqual(v["bound_to"], s["bound_to"], k); self.assertTrue(v["item_hash"].startswith("sha256:"))
        self.assertEqual(s["displayed"]["diff"]["content"]["patch_hash"], self.f.cand["patch_hash"]); self.assertEqual(s["displayed"]["verification_results"]["content"]["report_hash"], self.f.report["report_hash"])
        for bid, sec in s["sections"].items():
            self.assertEqual(sec["bound_to"], s["bound_to"], bid); self.assertEqual(s["section_hashes"][bid], sec["section_hash"])
        self.assertEqual(RS.verify_view(s, self.f.artifacts())["view_hash"], s["view_hash"])
        again = RS.bind_view(self.f.surface(), self.f.artifacts(), run_id="sha256:" + "5" * 64)
        self.assertEqual(again["view_hash"], s["view_hash"], "binding is deterministic over the same artifacts")

    def test_stale_or_tampered_views_are_refused(self) -> None:
        s = RS.bind_view(self.f.surface(), self.f.artifacts(), run_id="sha256:" + "5" * 64)
        with self.assertRaises(RS.ReviewRefusal) as ctx:
            RS.verify_view(self.f.surface(), self.f.artifacts())
        self.assertEqual(ctx.exception.code, "review.view_unbound")
        other = self.f.artifacts(candidate=dict(self.f.cand, patch_hash="sha256:" + "2" * 64))
        with self.assertRaises(RS.ReviewRefusal) as ctx:
            RS.verify_view(s, other)
        self.assertEqual(ctx.exception.code, "review.view_stale")
        t = copy.deepcopy(s); t["sections"]["HUMAN-02"]["statement"] = "everything was analyzed"
        with self.assertRaises(RS.ReviewRefusal) as ctx:
            RS.verify_view(t, self.f.artifacts())
        self.assertEqual(ctx.exception.code, "review.view_tampered")
        t = copy.deepcopy(s); t["displayed"]["verification_results"]["content"]["verdict"] = "PASS!"
        with self.assertRaises(RS.ReviewRefusal) as ctx:
            RS.verify_view(t, self.f.artifacts())
        self.assertEqual(ctx.exception.code, "review.view_tampered")
        t = copy.deepcopy(s); t["view_hash"] = "sha256:" + "0" * 64
        with self.assertRaises(RS.ReviewRefusal):
            RS.verify_view(t, self.f.artifacts())
        html = RS.render_surface_html(s); self.assertIn(s["view_hash"], html)

    def bound(self, **over) -> dict:
        return RS.bind_view(self.f.surface(**over), self.f.artifacts(**over), run_id="sha256:" + "5" * 64)

    def test_reviewer_actions_are_typed_commands(self) -> None:
        s = self.bound()
        cmd = RS.issue_command("inspect_evidence", identity="reviewer@example", channel="console", surface=s, fields={"path": "Suite04/SHA256SUMS.txt"}, review=self.f.review, registry=self.f.reg)
        C.validate_payload("reviewer_command", cmd, registry=self.f.reg)
        self.assertEqual(cmd["authority"], {"role": "human_reviewer", "declared_by": "human", "basis": cmd["authority"]["basis"]}); self.assertIn("HUMAN-01", cmd["authority"]["basis"])
        self.assertEqual(cmd["scope"]["view_hash"], s["view_hash"]); self.assertEqual(cmd["scope"]["candidate_id"], self.f.cand["candidate_id"]); self.assertTrue(cmd["issued_at"]); self.assertRegex(cmd["nonce"], r"^[0-9a-f]{32}$"); self.assertTrue(cmd["idempotency_key"].startswith("sha256:"))
        self.assertFalse(cmd["side_effects"]["applies_patch"]); self.assertEqual(cmd["side_effects"]["effects"], RS.behavior_for("inspect_evidence", self.f.review)["side_effects"]["effects"])
        for kw, code in (({"action": "apply_patch"}, "review.action_invalid"), ({"channel": "model"}, None), ({"identity": ""}, "review.identity_missing"), ({"fields": {}}, "review.command_fields_missing"), ({"nonce": "zz"}, "review.nonce_invalid")):
            with self.subTest(kw=kw):
                args = dict(action="inspect_evidence", identity="reviewer@example", channel="console", surface=s, fields={"path": "Suite04/SHA256SUMS.txt"}, review=self.f.review, registry=self.f.reg); args.update(kw)
                with self.assertRaises(lga.AdapterError) as ctx:
                    RS.issue_command(args.pop("action"), **args)
                if code:
                    self.assertEqual(ctx.exception.code, code)
        with self.assertRaises(RS.ReviewRefusal) as ctx:
            RS.issue_command("reject", identity="reviewer@example", channel="console", surface=s, rationale="", review=self.f.review, registry=self.f.reg)
        self.assertEqual(ctx.exception.code, "review.rationale_required")
        with self.assertRaises(RS.ReviewRefusal) as ctx:
            RS.issue_command("reject", identity="reviewer@example", channel="console", surface=self.f.surface(), rationale="x", review=self.f.review, registry=self.f.reg)
        self.assertEqual(ctx.exception.code, "review.view_unbound")
        bad = dict(cmd, side_effects={"applies_patch": True, "effects": ["apply"], "records": []})
        with self.assertRaises(lga.AdapterError):
            C.validate_payload("reviewer_command", bad, registry=self.f.reg)

    def test_commands_execute_once_and_replay_without_a_second_effect(self) -> None:
        s = self.bound(); a = self.f.artifacts()
        cmd = RS.issue_command("inspect_evidence", identity="reviewer@example", channel="console", surface=s, fields={"path": "Suite04/SHA256SUMS.txt"}, review=self.f.review, registry=self.f.reg)
        r1 = RS.execute_command(self.f.run_dir, cmd, artifacts=a, surface=s, registry=self.f.reg)
        self.assertEqual(r1["outcome"], "executed"); self.assertTrue(r1["evidence"]["verified"]); self.assertEqual(len(RS.commands(self.f.run_dir)), 1); self.assertEqual(len(RS.audit_trail(self.f.run_dir)), 1)
        r2 = RS.execute_command(self.f.run_dir, cmd, artifacts=a, surface=s, registry=self.f.reg)
        self.assertEqual(r2["outcome"], "replayed"); self.assertTrue(r2["replayed"]); self.assertEqual(r2["audit_hash"], r1["audit_hash"]); self.assertEqual(len(RS.commands(self.f.run_dir)), 1)
        conflict = dict(cmd, rationale="changed"); conflict["command_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in conflict.items() if k != "command_hash"}))
        with self.assertRaises(RS.ReviewRefusal) as ctx:
            RS.execute_command(self.f.run_dir, conflict, artifacts=a, surface=s, registry=self.f.reg)
        self.assertEqual(ctx.exception.code, "review.idempotency_conflict")
        foreign = RS.issue_command("inspect_evidence", identity="reviewer@example", channel="console", surface=s, fields={"path": "Suite04/SHA256SUMS.txt"}, review=self.f.review, registry=self.f.reg)
        with self.assertRaises(RS.ReviewRefusal) as ctx:
            RS.execute_command(self.f.run_dir, foreign, artifacts=self.f.artifacts(candidate=dict(self.f.cand, patch_hash="sha256:" + "2" * 64)), surface=s, registry=self.f.reg)
        self.assertEqual(ctx.exception.code, "review.view_stale")
        audit = RS.audit_trail(self.f.run_dir)[0]
        self.assertEqual(audit["shown"]["view_hash"], s["view_hash"]); self.assertEqual(audit["decided"]["command_hash"], cmd["command_hash"]); self.assertEqual(audit["decided"]["identity"]["identity_digest"], lga.sha256_digest("reviewer@example")); self.assertNotIn("reviewer@example", json.dumps(audit))
        for action, fields, rationale in (("request_evidence", {"question": "show the upstream manifest format"}, "need more"), ("reject", {}, "not now")):
            c = RS.issue_command(action, identity="reviewer@example", channel="console", surface=s, fields=fields, rationale=rationale, review=self.f.review, registry=self.f.reg)
            with self.assertRaises(RS.ReviewRefusal) as ctx:
                RS.execute_command(self.f.run_dir, c, artifacts=a, surface=s, registry=self.f.reg)
            self.assertEqual(ctx.exception.code, "review.key_required")
            r = RS.execute_command(self.f.run_dir, c, artifacts=a, surface=s, key=self.f.key, registry=self.f.reg)
            self.assertEqual(r["decision"], RS.RECEIPT_DECISION[action]); self.assertTrue(r["receipt_hash"])
        chain = aa.load_chain(self.f.run_dir); self.assertEqual([r["decision"] for r in chain], ["REQUEST_CHANGES", "REJECT"]); self.assertTrue(all(r["approver_identity"] == "reviewer@example" for r in chain))

    def test_non_applying_commands_cannot_apply_and_leave_no_effect(self) -> None:
        src = inspect.getsource(RS)
        self.assertNotIn("apply_isolated(", src.replace("patch.apply_isolated", "")); self.assertNotIn("archive_run(", src); self.assertNotIn("WorkflowRun", src)
        s = self.bound(); a = self.f.artifacts()
        before = RS.effect_proof(a, self.f.run_dir)
        for action, fields, rationale in (("inspect_evidence", {"path": "Suite04/SHA256SUMS.txt"}, ""), ("request_evidence", {"question": "why"}, "more evidence"), ("narrow_scope", {"allowed_paths": ["Suite04/SHA256SUMS.txt"], "max_changed_files": 1}, "smaller"), ("cancel", {}, "stop"), ("reject", {}, "no")):
            with self.subTest(action=action):
                self.assertIn(action, RS.NON_APPLYING)
                c = RS.issue_command(action, identity="reviewer@example", channel="console", surface=s, fields=fields, rationale=rationale, review=self.f.review, registry=self.f.reg)
                r = RS.execute_command(self.f.run_dir, c, artifacts=a, surface=s, key=self.f.key, registry=self.f.reg)
                self.assertTrue(r["effect_proof"]["no_side_effect"]); self.assertFalse(r["effect_proof"]["applied_patch"]); self.assertEqual(r["effect_proof"]["receipt_rows"], 1 if action in RS.RECEIPT_DECISION else 0)
        after = RS.effect_proof(a, self.f.run_dir)
        self.assertEqual({k: before[k] for k in ("tree_identity", "head", "status_hash", "applied_dir", "applied_worktrees", "archive_dir")}, {k: after[k] for k in ("tree_identity", "head", "status_hash", "applied_dir", "applied_worktrees", "archive_dir")})
        self.assertFalse((self.f.run_dir / "applied").exists()); self.assertFalse((self.f.run_dir / "applied-worktrees").exists())
        with self.assertRaises(RS.ReviewRefusal) as ctx:
            RS.assert_no_effect(before, dict(after, applied_dir=True), allow_receipt=True)
        self.assertEqual(ctx.exception.code, "review.side_effect")

    def test_changed_bound_inputs_and_later_commands_invalidate_prior_approval(self) -> None:
        s = self.bound(); a = self.f.artifacts()
        approve = RS.issue_command("approve", identity="reviewer@example", channel="console", surface=s, rationale="looks right", review=self.f.review, registry=self.f.reg)
        r = RS.execute_command(self.f.run_dir, approve, artifacts=a, surface=s, key=self.f.key, registry=self.f.reg)
        receipt = r["receipt"]; self.assertEqual(receipt["decision"], "APPROVE"); self.assertFalse(r["effect_proof"]["applied_patch"])
        self.assertEqual(RS.assert_approval_current(self.f.run_dir, receipt, a)["current"], True)
        aa.verify_receipt(self.f.run_dir, self.f.key, receipt, candidate=self.f.cand, card=self.f.card, report=self.f.report)
        # any changed bound input → stale
        for over, field in (({"candidate": dict(self.f.cand, patch_hash="sha256:" + "2" * 64)}, "patch_hash"), ({"review_card": dict(self.f.card, card_hash="sha256:" + "3" * 64)}, "card_hash"), ({"verification_report": dict(self.f.report, report_hash="sha256:" + "4" * 64)}, "report_hash")):
            with self.subTest(field=field):
                with self.assertRaises(lga.AdapterError) as ctx:
                    RS.assert_approval_current(self.f.run_dir, receipt, self.f.artifacts(**over))
                self.assertEqual(ctx.exception.code, "approval.stale_inputs"); self.assertIn(field, str(ctx.exception))
        # a later request-more-evidence by a human invalidates the approval; the ledger is not edited
        req = RS.issue_command("request_evidence", identity="reviewer@example", channel="console", surface=s, fields={"question": "show the other manifests"}, rationale="not enough", review=self.f.review, registry=self.f.reg)
        r2 = RS.execute_command(self.f.run_dir, req, artifacts=a, surface=s, key=self.f.key, registry=self.f.reg)
        self.assertEqual(r2["effect_proof"]["invalidated_approvals"], [receipt["receipt_hash"]]); self.assertIn(receipt["receipt_hash"], RS.invalidated_receipts(self.f.run_dir))
        with self.assertRaises(lga.AdapterError) as ctx:
            RS.assert_approval_current(self.f.run_dir, receipt, a)
        self.assertEqual(ctx.exception.code, "approval.invalidated")
        with self.assertRaises(lga.AdapterError) as ctx:
            aa.verify_receipt(self.f.run_dir, self.f.key, receipt, candidate=self.f.cand, card=self.f.card, report=self.f.report)
        self.assertEqual(ctx.exception.code, "approval.superseded")
        self.assertEqual([x["decision"] for x in aa.load_chain(self.f.run_dir)], ["APPROVE", "REQUEST_CHANGES"])
        # narrowing the scope yields a different scope contract: the old approval cannot bind to the rerun's candidate
        rerun = RS.narrow_scope(self.f.contract, allowed_paths=["Suite04/SHA256SUMS.txt"], max_changed_files=1, max_diff_lines=10)
        from adapters import intent_intake as ii
        new_contract = json.loads(ii.accept_intent(rerun["intent"], self.f.binding).to_json())
        self.assertNotEqual(new_contract["scope_contract_hash"], receipt["scope_contract_hash"])
        with self.assertRaises(lga.AdapterError) as ctx:
            RS.assert_approval_current(self.f.base / "run2", receipt, self.f.artifacts(scope_contract=new_contract, candidate=dict(self.f.cand, scope_contract_hash=new_contract["scope_contract_hash"])))
        self.assertEqual(ctx.exception.code, "approval.stale_inputs")


if __name__ == "__main__":
    unittest.main()
