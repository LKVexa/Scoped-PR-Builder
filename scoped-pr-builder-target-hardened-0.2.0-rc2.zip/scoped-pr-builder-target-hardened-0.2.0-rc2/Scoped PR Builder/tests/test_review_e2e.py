"""Human review — UI/accessibility and end-to-end proofs (Phase 11 / HUMAN-*-T05; stdlib unittest), driven by
tests/scenarios/review.json.

For every declared behavior a real run is driven through the workflow to the review card (WF-09), the reviewer surface is
built, bound and rendered, the rendered page passes the structural accessibility audit, the reviewer performs the
behavior's action as a typed command, and the audit trail is proven to capture exactly what was shown (view, section and
item hashes) and what was decided (command, identity reference, receipt). Non-applying actions leave the repository and
the run untouched; the approval carries identity, timestamp and approved scope; accountability is the human's. Every case
leaves a chained ``review_e2e`` receipt under ``review:<behavior>:<case>@<review-hash prefix>``.
"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import evidence_ledger as EL  # noqa: E402
from adapters import approval_adapter as aa  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import review_surface as RS  # noqa: E402
from adapters import security as SEC  # noqa: E402
from adapters import workflow as W  # noqa: E402
from test_components import _git  # noqa: E402
from test_workflow import Driver  # noqa: E402

SCENARIOS = HERE / "scenarios" / "review.json"


class TestReviewEndToEnd(unittest.TestCase):
    def setUp(self) -> None:
        self.scen = json.loads(SCENARIOS.read_text(encoding="utf-8")).get("scenarios", {}) if SCENARIOS.is_file() else {}
        if not self.scen:
            self.skipTest("no review scenarios yet")
        self.reg = C.load_registry()
        self.review = RS.load_review(registry=self.reg)
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.core = self.review["computed_hash"][7:39]
        self.rows = 0

    def tearDown(self) -> None:
        SEC.use_trail(None)
        self.tmp.cleanup()

    # ---- helpers ------------------------------------------------------------------------------------------------
    def run_to_review(self, name: str = "one") -> Driver:
        d = Driver(self.base / name, self.reg)
        row = d.drive("WF-09"); self.assertEqual(row["outcome"], "SUCCEEDED", row["reason"])
        return d

    def surface_for(self, d: Driver) -> dict:
        s = RS.build_surface(d.run.artifacts, run_id=d.run.run_id, run_dir=d.run_dir, review=self.review, registry=self.reg)
        return RS.bind_view(s, d.run.artifacts, run_id=d.run.run_id)

    def identity(self, d: Driver) -> tuple:
        root = Path(d.run.artifacts["binding"].root_path)
        return (lga.tree_identity(root, d.run.artifacts["binding"].base_revision), _git(root, "status", "--porcelain", "--untracked-files=all"), (d.run_dir / "applied").exists(), (d.run_dir / "applied-worktrees").exists(), d.run.state)

    def receipt(self, bid: str, case: str, body: dict) -> None:
        EL.record(f"review:{bid}:{case}@{self.core}", "review_e2e", "PASS", {"behavior_id": bid, "case": case, "review_hash": self.review["computed_hash"], **body})
        self.rows += 1

    def act(self, d: Driver, s: dict, action: str, *, fields=None, rationale="reviewed", key=None) -> tuple[dict, dict]:
        cmd = RS.issue_command(action, identity="reviewer@example", channel="console", surface=s, fields=fields or {}, rationale=rationale, review=self.review, registry=self.reg)
        res = RS.execute_command(d.run_dir, cmd, artifacts=d.run.artifacts, surface=s, key=key, registry=self.reg)
        return cmd, res

    def audited(self, d: Driver, s: dict, cmd: dict, res: dict) -> dict:
        proof = RS.verify_audit_against_view(d.run_dir, s, cmd, result=res)
        self.assertEqual(proof["shown"], s["view_hash"]); self.assertEqual(proof["decided"], cmd["command_hash"])
        return proof

    # ---- the harness ---------------------------------------------------------------------------------------------
    def test_ui_accessibility_and_end_to_end_per_declared_behavior(self) -> None:
        d = self.run_to_review()
        SEC.use_trail(d.run_dir)
        s = self.surface_for(d)
        html = RS.render_surface_html(s)
        a11y = RS.check_accessibility(html)
        self.assertTrue(a11y["accessible"], a11y["violations"]); self.assertEqual(a11y["passed"], a11y["rules"])
        self.assertNotIn("<script", html); self.assertIn(s["view_hash"], html)
        before = self.identity(d)
        for sid, sc in self.scen.items():
            bid = sc["behavior_id"]; case = sc["case"]
            with self.subTest(behavior=bid, case=case):
                body = {"view_hash": s["view_hash"], "a11y_rules_passed": a11y["passed"], "page_hash": a11y["page_hash"], "action": sc["action"]}
                getattr(self, f"_{bid.lower().replace('-', '_')}")(d, s, body)
                self.receipt(bid, case, body)
        self.assertEqual(self.identity(d)[:4], before[:4], "no reviewer action touched the repository or applied anything")
        self.assertGreaterEqual(EL.verify(), self.rows)

    def _human_01(self, d, s, body):  # inspect original evidence
        item = s["sections"]["HUMAN-01"]["items"][0]
        cmd, res = self.act(d, s, "inspect_evidence", fields={"path": item["path"]})
        self.assertTrue(res["evidence"]["verified"]); self.assertEqual(res["evidence"]["content_hash"], item["content_hash"]); self.assertIsNone(res["receipt_hash"]); self.assertTrue(res["effect_proof"]["no_side_effect"])
        body.update(self.audited(d, s, cmd, res)); body["evidence_verified"] = True; body["content_hash"] = item["content_hash"]

    def _human_02(self, d, s, body):  # see exactly what was and was not analyzed
        cov = s["sections"]["HUMAN-02"]
        self.assertTrue(cov["analyzed"]["intake_sources_admitted"]); self.assertTrue(cov["analyzed"]["checks_executed"]); self.assertIn("NOT analyzed", cov["statement"])
        html = RS.render_surface_html(s); self.assertIn("Not analyzed", html); self.assertIn(cov["statement"][:40], html.replace("&#x27;", "'"))
        self.assertEqual(s["displayed"]["uncertainty_state"]["content"]["coverage_statement"], cov["statement"])
        body["statement_hash"] = lga.sha256_digest(cov["statement"]); body["not_analyzed_keys"] = sorted(cov["not_analyzed"])

    def _human_03(self, d, s, body):  # narrow scope and rerun
        cmd, res = self.act(d, s, "narrow_scope", fields={"allowed_paths": ["Suite04/SHA256SUMS.txt"], "max_diff_lines": 8}, rationale="tighter", key=d.key)
        self.assertEqual(res["decision"], "REQUEST_CHANGES"); self.assertTrue(res["effect_proof"]["no_side_effect"])
        rerun = res["rerun"]["intent"]; self.assertEqual(rerun["max_diff_lines"], 8)
        d2 = Driver(self.base / "rerun", self.reg, repo=Path(d.run.artifacts["binding"].root_path))
        for sid in ("WF-01", "WF-02", "WF-03", "WF-04", "WF-05", "WF-06", "WF-07", "WF-08", "WF-09"):
            r = d2.run.run_step(sid, d2.inputs_for(sid) if sid != "WF-03" else {"intent": rerun})
            self.assertEqual(r["outcome"], "SUCCEEDED", r["reason"])
        self.assertNotEqual(d2.run.artifacts["scope_contract"]["scope_contract_hash"], d.run.artifacts["scope_contract"]["scope_contract_hash"]); self.assertEqual(d2.run.artifacts["scope_contract"]["max_diff_lines"], 8)
        body.update(self.audited(d, s, cmd, res)); body["rerun_scope_contract_hash"] = d2.run.artifacts["scope_contract_hash"]; body["rerun_state"] = d2.run.state

    def _human_04(self, d, s, body):  # reject without side effects
        d3 = self.run_to_review("reject"); s3 = self.surface_for(d3); before = self.identity(d3)
        cmd, res = self.act(d3, s3, "reject", rationale="not this one", key=d3.key)
        self.assertEqual(res["decision"], "REJECT"); self.assertTrue(res["effect_proof"]["no_side_effect"])
        receipt = [r for r in aa.load_chain(d3.run_dir) if r["receipt_hash"] == res["receipt_hash"]][0]
        row = d3.run.run_step("WF-10", {"receipt": receipt, "key": d3.key})
        self.assertEqual(row["outcome"], "BLOCKED", row["reason"]); self.assertEqual(d3.run.state, "BLOCKED"); self.assertEqual(W.classify_failure(row["error_code"]), "authorization_failure")
        after = self.identity(d3); self.assertEqual(before[:4], after[:4]); self.assertFalse((d3.run_dir / "applied").exists())
        proof = RS.verify_audit_against_view(d3.run_dir, s3, cmd, result=res)
        body.update(proof); body["run_state"] = d3.run.state; body["error_code"] = row["error_code"]

    def _human_05(self, d, s, body):  # require additional evidence
        d5 = self.run_to_review("evidence"); s5 = self.surface_for(d5)
        cmd, res = self.act(d5, s5, "request_evidence", fields={"question": "show every manifest this recipe touches", "paths": ["Suite04/SHA256SUMS.txt"]}, rationale="incomplete", key=d5.key)
        self.assertEqual(res["decision"], "REQUEST_CHANGES"); self.assertTrue(res["request_hash"].startswith("sha256:"))
        receipt = [r for r in aa.load_chain(d5.run_dir) if r["receipt_hash"] == res["receipt_hash"]][0]
        row = d5.run.run_step("WF-10", {"receipt": receipt, "key": d5.key})
        self.assertEqual(row["outcome"], "BLOCKED", row["reason"]); self.assertNotEqual(d5.run.state, "APPROVED")
        reqs = [json.loads(l) for l in (d5.run_dir / "review" / "evidence_requests.jsonl").read_text().splitlines() if l.strip()]
        self.assertEqual(reqs[0]["question"], "show every manifest this recipe touches"); self.assertEqual(reqs[0]["receipt_hash"], res["receipt_hash"])
        body.update(RS.verify_audit_against_view(d5.run_dir, s5, cmd, result=res)); body["request_hash"] = res["request_hash"]; body["run_state"] = d5.run.state

    def _human_06(self, d, s, body):  # approval identity, timestamp, approved scope recorded
        d6 = self.run_to_review("approve"); s6 = self.surface_for(d6)
        cmd, res = self.act(d6, s6, "approve", rationale="matches the evidence", key=d6.key)
        rec = res["approval_record"]; self.assertEqual(rec["identity"], "reviewer@example"); self.assertEqual(rec["issued_at"], res["receipt"]["issued_at"]); self.assertEqual(rec["approved_scope"]["scope_contract_hash"], d6.run.artifacts["scope_contract_hash"]); self.assertEqual(rec["approved_scope"]["candidate_paths"], list(d6.run.artifacts["candidate"]["canonical_paths"]))
        self.assertTrue((d6.run_dir / "review" / "approval_record.json").is_file())
        row = d6.run.run_step("WF-10", {"receipt": res["receipt"], "key": d6.key})
        self.assertEqual(row["outcome"], "SUCCEEDED", row["reason"]); self.assertEqual(d6.run.state, "APPROVED")
        decision = json.loads((d6.run_dir / "review" / "human_decision.json").read_text()); self.assertEqual((decision["approver_identity"], decision["receipt_hash"]), ("reviewer@example", res["receipt_hash"]))
        s6b = self.surface_for(d6); shown = s6b["sections"]["HUMAN-06"]["decisions"][-1]
        self.assertEqual((shown["identity"], shown["issued_at"], shown["approved_scope"]["patch_hash"]), ("reviewer@example", res["receipt"]["issued_at"], d6.run.artifacts["candidate"]["patch_hash"]))
        body.update(RS.verify_audit_against_view(d6.run_dir, s6, cmd, result=res)); body["approved_scope_hash"] = lga.sha256_digest(lga.canonical_json(rec["approved_scope"])); body["run_state"] = d6.run.state

    def _human_07(self, d, s, body):  # accountability is never the AI's
        html = RS.render_surface_html(s); acc = s["sections"]["HUMAN-07"]
        self.assertEqual(acc["accountable_party"], "human reviewer"); self.assertIn("never rests with the AI", html)
        low = html.lower()
        for phrase in ("approved by the model", "decided by the model", "the ai approved", "model approved", "ai decided"):
            self.assertNotIn(phrase, low)
        d7 = self.run_to_review("accountable"); s7 = self.surface_for(d7)
        cmd, res = self.act(d7, s7, "approve", rationale="I take responsibility", key=d7.key)
        s7b = self.surface_for(d7); acc7 = s7b["sections"]["HUMAN-07"]
        self.assertEqual(acc7["decided_by"], "reviewer@example via console (APPROVE)"); self.assertEqual(acc7["ai_role"], "advisory only")
        trail = RS.audit_trail(d7.run_dir)[-1]; self.assertEqual(trail["decided"]["identity"]["identity_digest"], lga.sha256_digest("reviewer@example")); self.assertNotIn("model", json.dumps(trail["decided"]))
        body.update(RS.verify_audit_against_view(d7.run_dir, s7, cmd, result=res)); body["decided_by"] = acc7["decided_by"]; body["statement_hash"] = lga.sha256_digest(RS.ACCOUNTABILITY_STATEMENT)

    def test_scenarios_are_well_formed(self) -> None:
        for sid, sc in self.scen.items():
            with self.subTest(scenario=sid):
                self.assertEqual(sid, f"review:{sc['behavior_id']}"); self.assertIn(sc["behavior_id"], self.review["behaviors"]); self.assertEqual(sc["action"], self.review["behaviors"][sc["behavior_id"]]["reviewer_action"])
                self.assertTrue(sc["case"] and sc["asserts"] and sc["receipt_requirements"] and sc["introduced_by"].endswith("-T05"))


if __name__ == "__main__":
    unittest.main()
