"""Component boundary tests (Phase 05 / COMP-01..11; stdlib unittest).

Interfaces load and bind to existing suites; every declared contract exists; invoking an unknown component, an
undeclared input, a missing input, an ungranted capability or a stale binding fails closed; each bound component
processes a pinned fixture repository into schema-valid, provenance-carrying outputs (T03); limits refuse widening,
gate bypass, oversized and overdue results (T04). Tests for layers not yet applied skip by name.
"""
from __future__ import annotations

import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from adapters import approval_adapter as aa  # noqa: E402
from adapters import components as K  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import intent_intake as ii  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402

REPO_ROOT = HERE.parent.parent
READ = ["repository.read"]
ALL = ["repository.read", "diff.generate_inert", "worktree.isolate", "verification.run_isolated", "review.render", "rollback.execute"]
HDR = "ja source 0.3\nmodule suite{n}.demo\nuse Data\npolicy no_network\nemit json demo\n"
PY = "import os\n\n\ndef helper(x):\n    return os.path.join('a', x)\n\n\ndef main():\n    return helper('b')\n"


def _git(cwd: Path, *args: str) -> str:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t", "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z", "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z"}
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=True, env=env).stdout.strip()


def make_repo(base: Path) -> Path:
    root = base / "repo"; root.mkdir(parents=True)
    _git(root, "init", "-q")
    for n in range(1, 67):
        d = root / f"Suite{n:02d}"; d.mkdir()
        (d / f"{n:02d}_demo.jad").write_text(HDR.format(n=n))
    (root / "Suite04" / "SHA256SUMS.txt").write_text("0000  04_Old/04_demo.jad\n")
    (root / "Suite04" / "tool.py").write_text(PY)
    tests = root / "Scoped PR Builder" / "tests"; tests.mkdir(parents=True)
    (tests / "test_ok.py").write_text("import unittest\nclass T(unittest.TestCase):\n    def test_a(self):\n        self.assertTrue(True)\nif __name__ == '__main__':\n    unittest.main()\n")
    _git(root, "add", "-A"); _git(root, "commit", "-q", "-m", "c1")
    return root


class Pipeline:
    """Drives the bound components in order over one fixture repository; stops where the executable boundary ends."""

    def __init__(self, base: Path, comps, reg) -> None:
        self.base, self.comps, self.reg = base, comps, reg
        self.root = make_repo(base)
        self.binding = lga.bind_repository(self.root)
        self.contract = json.loads(ii.accept_intent({"kind": "tech_debt_refactor", "title": "Regenerate stale Suite04 SHA256SUMS manifest", "description": "x", "allowed_paths": ["Suite04/SHA256SUMS.txt"], "max_changed_files": 1, "max_diff_lines": 10, "requested_by": "t"}, self.binding).to_json())
        self.results: dict[str, K.ComponentResult] = {}

    def invoke(self, cid: str, inputs: dict, *, granted=None, **kw) -> K.ComponentResult:
        r = K.invoke(cid, inputs, granted_effects=granted or ALL, components=self.comps, registry=self.reg, sandbox=self.base / "sb", **kw)
        self.results[cid] = r
        return r

    def out(self, cid: str, name: str):
        return self.results[cid].outputs[name]

    def bound(self, cid: str) -> bool:
        return cid in K._IMPL and cid in self.comps["components"]

    def run_through(self, last: str) -> None:
        order = ["COMP-01", "COMP-02", "COMP-03", "COMP-04", "COMP-06", "COMP-07", "COMP-09", "COMP-05", "COMP-08", "COMP-10", "COMP-11"]
        for cid in order[: order.index(last) + 1]:
            if not self.bound(cid):
                raise unittest.SkipTest(f"{cid} not bound yet")
            self.invoke(cid, self.inputs_for(cid))

    def inputs_for(self, cid: str) -> dict:
        b = self.binding
        if cid == "COMP-01":
            return {"binding": b}
        if cid == "COMP-02":
            return {"binding": b, "symbol_index": self.out("COMP-01", "symbol_index"), "dependency_records": self.out("COMP-01", "dependency_records")}
        if cid == "COMP-03":
            return {"binding": b, "dependency_records": self.out("COMP-01", "dependency_records")}
        if cid == "COMP-04":
            return {"binding": b, "scope_contract": self.contract, "symbol_index": self.out("COMP-01", "symbol_index")}
        if cid == "COMP-06":
            return {"binding": b, "scope_contract": self.contract, "evidence_bundle": self.out("COMP-04", "evidence_bundle"), "convention_profile": self.out("COMP-04", "convention_profile")}
        if cid == "COMP-07":
            return {"binding": b, "scope_contract": self.contract, "refactoring_plan": self.out("COMP-06", "refactoring_plan"), "recipe": "regenerate_sha256sums_manifest"}
        if cid == "COMP-09":
            return {"scope_contract": self.contract, "candidate": self.out("COMP-07", "candidate")}
        if cid == "COMP-05":
            return {"binding": b, "candidate": self.out("COMP-07", "candidate"), "patch": self.patch(), "symbol_index": self.out("COMP-01", "symbol_index"), "code_graph": self.out("COMP-02", "code_graph"), "dependency_graph": self.out("COMP-03", "dependency_graph")}
        if cid == "COMP-08":
            return {"binding": b, "scope_contract": self.contract, "candidate": self.out("COMP-07", "candidate"), "patch": self.patch(), "impact_report": self.out("COMP-05", "impact_report")}
        if cid == "COMP-10":
            eb = self.out("COMP-04", "evidence_bundle")
            return {"binding": b, "scope_contract": self.contract, "evidence": eb["evidence"], "authority": eb["authority"], "refactoring_plan": self.out("COMP-06", "refactoring_plan"), "candidate": self.out("COMP-07", "candidate"), "patch": self.patch(),
                    "verification_report": self.out("COMP-08", "verification_report"), "impact_report": self.out("COMP-05", "impact_report")}
        if cid == "COMP-11":
            return {"binding": b, "action": "checkpoint"}
        raise KeyError(cid)

    def patch(self) -> bytes:
        return self.out("COMP-07", "patch_text").encode("utf-8")


class Fixture(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.comps = K.load_components(registry=self.reg)
        self.tmp = tempfile.TemporaryDirectory()
        self.p = Pipeline(Path(self.tmp.name), self.comps, self.reg)

    def tearDown(self) -> None:
        self.tmp.cleanup()


class TestInterfaces(Fixture):
    def test_registry_loads_binds_and_declares_everything(self) -> None:
        self.assertEqual(self.comps["computed_hash"], K.load_components(registry=self.reg)["computed_hash"])
        for cid, c in self.comps["components"].items():
            with self.subTest(component=cid):
                iface = c["interface"]
                for f in c["authoritative_suites"]:
                    self.assertTrue((REPO_ROOT / f).is_file(), f)
                self.assertTrue(iface["inputs"] and iface["outputs"] and iface["errors"] and iface["provenance_fields"])
                self.assertEqual(iface["bounds"]["max_failures"], 0)
                for name, spec in iface["inputs"].items():
                    if spec["kind"] == "contract":
                        self.assertIn(spec["ref"], self.reg["contracts"], f"{cid}.{name}")
                for name, spec in iface["outputs"].items():
                    if spec.get("validation", "").startswith("contract:"):
                        self.assertIn(spec["validation"].split(":", 1)[1], self.reg["contracts"], f"{cid}.{name}")

    def test_unknown_component_and_broken_registry_fail_closed(self) -> None:
        with self.assertRaises(lga.AdapterError) as ctx:
            K.invoke("COMP-99", {}, granted_effects=READ, components=self.comps, registry=self.reg)
        self.assertEqual(ctx.exception.code, "component.unknown")
        broken = copy.deepcopy(self.comps); cid = next(iter(broken["components"]))
        broken["components"][cid]["interface"]["bounds"]["max_failures"] = 3
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump({k: v for k, v in broken.items() if k != "computed_hash"}, f)
        with self.assertRaises(lga.AdapterError) as ctx:
            K.load_components(Path(f.name), registry=self.reg)
        self.assertEqual(ctx.exception.code, "component.registry_invalid")

    def test_inputs_capabilities_and_binding_fail_closed(self) -> None:
        for cid, c in self.comps["components"].items():
            with self.subTest(component=cid):
                with self.assertRaises(lga.AdapterError) as ctx:
                    K.invoke(cid, {"not_declared": 1}, granted_effects=ALL, components=self.comps, registry=self.reg)
                self.assertEqual(ctx.exception.code, "component.input_invalid")
                required = [n for n, s in c["interface"]["inputs"].items() if s.get("required", True)]
                if required:
                    with self.assertRaises(lga.AdapterError) as ctx:
                        K.invoke(cid, {}, granted_effects=ALL, components=self.comps, registry=self.reg)
                    self.assertEqual(ctx.exception.code, "component.input_missing")
        # ungranted capability: the first component that needs one
        cid = next(c for c, e in self.comps["components"].items() if e["interface"]["capabilities"])
        with self.assertRaises(lga.AdapterError) as ctx:
            K.invoke(cid, self.p.inputs_for(cid) if cid == "COMP-01" else {"binding": self.p.binding}, granted_effects=[], components=self.comps, registry=self.reg)
        self.assertIn(ctx.exception.code, ("component.capability_missing", "component.input_missing", "component.input_invalid"))
        if self.p.bound("COMP-01"):
            (self.p.root / "Suite01" / "01_demo.jad").write_text("changed\n"); _git(self.p.root, "add", "-A"); _git(self.p.root, "commit", "-q", "-m", "moved")
            with self.assertRaises(lga.AdapterError) as ctx:
                K.invoke("COMP-01", {"binding": self.p.binding}, granted_effects=READ, components=self.comps, registry=self.reg)
            self.assertEqual(ctx.exception.code, "component.binding_mismatch")

    def test_not_executable_until_bound(self) -> None:
        unbound = [cid for cid in self.comps["components"] if cid not in K._IMPL]
        if not unbound:
            self.skipTest("every component is bound")
        for cid in unbound:
            with self.subTest(component=cid):
                with self.assertRaises(lga.AdapterError) as ctx:
                    K.invoke(cid, self.p.inputs_for(cid) if cid == "COMP-01" else {}, granted_effects=ALL, components=self.comps, registry=self.reg)
                self.assertIn(ctx.exception.code, ("component.not_executable", "component.input_missing"))

    def test_composition_documents_the_authoritative_suite(self) -> None:
        composed = {cid: c for cid, c in self.comps["components"].items() if "composition" in c}
        if not composed:
            self.skipTest("no composition declared yet")
        for cid, c in composed.items():
            with self.subTest(component=cid):
                comp = c["composition"]
                self.assertIn(comp["centered_on"], c["authoritative_suites"]); self.assertTrue((REPO_ROOT / comp["centered_on"]).is_file())
                self.assertEqual(comp["duplicates"], "none"); self.assertTrue(comp["composes"]); self.assertIn("authoritative", comp["authoritative"])
                for fn in comp["composes"]:
                    mod, _, name = fn.partition(".")
                    import importlib
                    self.assertTrue(callable(getattr(importlib.import_module(f"adapters.{mod}"), name, None)), fn)


class TestExecution(Fixture):
    """T03: each bound component processes the pinned fixture and returns validated, provenance-carrying outputs."""

    def _check_result(self, r: K.ComponentResult) -> None:
        self.assertRegex(r.result_hash, r"^sha256:"); self.assertRegex(r.inputs_hash, r"^sha256:"); self.assertRegex(r.output_hash, r"^sha256:")
        c = self.comps["components"][r.component_id]
        for name, spec in c["interface"]["outputs"].items():
            if spec.get("required", True):
                self.assertIn(name, r.outputs)
        if any(s["kind"] == "binding" for s in c["interface"]["inputs"].values()):
            self.assertEqual(r.provenance["base_revision"], self.p.binding.base_revision); self.assertEqual(r.provenance["source_snapshot_hash"], self.p.binding.source_snapshot_hash)

    def test_comp01_symbol_index(self) -> None:
        self.p.run_through("COMP-01"); r = self.p.results["COMP-01"]; self._check_result(r)
        idx = r.outputs["symbol_index"]
        self.assertGreaterEqual(idx["symbol_count"], 66); self.assertIn("Suite04/tool.py", idx["by_file"]); self.assertEqual(idx["parse_errors"], 0)
        self.assertEqual(r.outputs["dependency_records"]["index_id"], idx["index_id"])

    def test_comp02_code_graph(self) -> None:
        self.p.run_through("COMP-02"); r = self.p.results["COMP-02"]; self._check_result(r)
        g = r.outputs["code_graph"]
        self.assertGreater(g["node_count"], 66); self.assertIn("contains", g["edge_kinds"]); self.assertGreaterEqual(g["call_edges"], 1)
        with self.assertRaises(lga.AdapterError) as ctx:
            self.p.invoke("COMP-02", dict(self.p.inputs_for("COMP-02"), dependency_records=dict(self.p.out("COMP-01", "dependency_records"), index_id="sha256:" + "0" * 64)))
        self.assertEqual(ctx.exception.code, "component.input_invalid")

    def test_comp03_dependency_graph(self) -> None:
        self.p.run_through("COMP-03"); r = self.p.results["COMP-03"]; self._check_result(r)
        g = r.outputs["dependency_graph"]
        self.assertIn(g["build_order_status"], ("acyclic", "cyclic")); self.assertTrue(g["gaps"]); self.assertIsNone(g["declared_packages"])
        with self.assertRaises(lga.AdapterError) as ctx:
            self.p.invoke("COMP-03", dict(self.p.inputs_for("COMP-03"), manifest_intake={"source_id": "DATA-01", "state": "ADMITTED", "items": [], "intake_hash": "x", "base_revision": self.p.binding.base_revision}))
        self.assertEqual(ctx.exception.code, "component.input_invalid")

    def test_comp04_conventions(self) -> None:
        self.p.run_through("COMP-04"); r = self.p.results["COMP-04"]; self._check_result(r)
        prof = r.outputs["convention_profile"]
        self.assertEqual(prof["scope_contract_hash"], self.p.contract["scope_contract_hash"]); self.assertGreaterEqual(prof["example_count"], 1); self.assertTrue(prof["evidence_refs"])
        self.assertIn(prof["conventions"]["naming"]["symbol_style"], ("snake_case", "CamelCase", None))
        with self.assertRaises(lga.AdapterError) as ctx:
            self.p.invoke("COMP-04", dict(self.p.inputs_for("COMP-04"), scope_contract=dict(self.p.contract, base_revision="b" * 40)))
        self.assertEqual(ctx.exception.code, "component.binding_mismatch")

    def test_comp06_planner(self) -> None:
        self.p.run_through("COMP-06"); r = self.p.results["COMP-06"]; self._check_result(r)
        plan = r.outputs["refactoring_plan"]
        self.assertEqual(plan["status"], "PLANNED"); self.assertEqual(plan["authority"], "advisory_only"); self.assertIn("conventions_guidance", plan)
        with self.assertRaises(lga.AdapterError) as ctx:
            self.p.invoke("COMP-06", dict(self.p.inputs_for("COMP-06"), evidence_bundle=dict(self.p.out("COMP-04", "evidence_bundle"), scope_contract_hash="sha256:" + "1" * 64)))
        self.assertEqual(ctx.exception.code, "component.input_invalid")

    def test_comp07_patch(self) -> None:
        self.p.run_through("COMP-07"); r = self.p.results["COMP-07"]; self._check_result(r)
        cand = r.outputs["candidate"]
        self.assertTrue(cand["inert"]); self.assertEqual(cand["files_changed"], 1); self.assertEqual(r.outputs["patch"]["bytes_sha256"], cand["patch_hash"])
        with self.assertRaises(lga.AdapterError) as ctx:
            self.p.invoke("COMP-07", dict(self.p.inputs_for("COMP-07"), recipe="improvise"))
        self.assertEqual(ctx.exception.code, "recipe.unregistered")

    def test_comp09_governor(self) -> None:
        self.p.run_through("COMP-09"); r = self.p.results["COMP-09"]; self._check_result(r)
        d = r.outputs["governor_decision"]
        self.assertEqual(d["verdict"], "ALLOW"); self.assertEqual(len(d["decisions"]), 3); self.assertTrue(d["confinement"]["within_scope"])
        wide = dict(self.p.out("COMP-07", "candidate"), canonical_paths=["Suite05/05_demo.jad"])
        d2 = self.p.invoke("COMP-09", {"scope_contract": self.p.contract, "candidate": wide}).outputs["governor_decision"]
        self.assertEqual(d2["verdict"], "REFUSE"); self.assertEqual(d2["confinement"]["violations"], ["Suite05/05_demo.jad"])

    def test_comp05_impact(self) -> None:
        self.p.run_through("COMP-05"); r = self.p.results["COMP-05"]; self._check_result(r)
        imp = r.outputs["impact_report"]
        self.assertEqual(imp["changed_paths"], ["Suite04/SHA256SUMS.txt"]); self.assertIn(imp["risk_band"], ("low", "medium", "high")); self.assertEqual(imp["authority"], "advisory_only")
        with self.assertRaises(lga.AdapterError) as ctx:
            self.p.invoke("COMP-05", dict(self.p.inputs_for("COMP-05"), patch=self.p.patch() + b"\n+tampered\n"))
        self.assertEqual(ctx.exception.code, "candidate.patch_hash_mismatch")

    def test_comp08_runner(self) -> None:
        self.p.run_through("COMP-08"); r = self.p.results["COMP-08"]; self._check_result(r)
        rep = r.outputs["verification_report"]
        self.assertEqual(rep["verdict"], "PASS"); self.assertTrue(rep["source_tree_unchanged"])
        sel = r.outputs["test_selection"]; self.assertEqual(sel["mode"], "incremental" if sel["selected_tests"] else "full"); self.assertEqual(sel["impact_hash"], self.p.out("COMP-05", "impact_report")["impact_hash"])
        with self.assertRaises(lga.AdapterError) as ctx:
            K.invoke("COMP-08", self.p.inputs_for("COMP-08"), granted_effects=ALL, components=self.comps, registry=self.reg, sandbox=self.p.root / "inside")
        self.assertEqual(ctx.exception.code, "component.input_invalid")

    def test_comp10_review_ui(self) -> None:
        self.p.run_through("COMP-10"); r = self.p.results["COMP-10"]; self._check_result(r)
        self.assertEqual(r.outputs["approval_gate"]["state"], "PENDING_HUMAN"); self.assertIn("<html", r.outputs["html"])
        self.assertEqual(r.outputs["review_card"]["authority"], "display_only"); self.assertIn("impact", r.outputs["review_card"])
        with self.assertRaises(lga.AdapterError) as ctx:
            self.p.invoke("COMP-10", dict(self.p.inputs_for("COMP-10"), verification_report=None))
        self.assertEqual(ctx.exception.code, "component.input_missing")

    def test_comp11_checkpoint_and_rollback(self) -> None:
        self.p.run_through("COMP-11"); r = self.p.results["COMP-11"]; self._check_result(r)
        cp = r.outputs["checkpoint"]
        self.assertEqual(cp["source_tree_identity"], self.p.binding.source_snapshot_hash); self.assertTrue(cp["git_tree"].startswith("git-tree:"))
        with self.assertRaises(lga.AdapterError) as ctx:
            self.p.invoke("COMP-11", {"binding": self.p.binding, "action": "rollback", "run_dir": str(self.p.base / "run")}, granted=READ)
        self.assertEqual(ctx.exception.code, "component.capability_missing")


class TestLimits(Fixture):
    """T04: scope, resource, timeout and failure limits; widening and human-gate bypass refused."""

    def setUp(self) -> None:
        super().setUp()
        if not hasattr(K, "_enforce_bounds"):
            self.skipTest("limits layer not yet present")

    def test_override_inputs_refused_by_name(self) -> None:
        for cid in self.comps["components"]:
            with self.subTest(component=cid):
                with self.assertRaises(lga.AdapterError) as ctx:
                    K.invoke(cid, {"auto_approve": True}, granted_effects=ALL, components=self.comps, registry=self.reg)
                self.assertEqual(ctx.exception.code, "component.human_gate_bypass")
                with self.assertRaises(lga.AdapterError) as ctx:
                    K.invoke(cid, {"widen_scope": ["/"]}, granted_effects=ALL, components=self.comps, registry=self.reg)
                self.assertEqual(ctx.exception.code, "component.scope_widening")

    def test_scope_widening_refused(self) -> None:
        self.p.run_through("COMP-07")
        for cid in ("COMP-05", "COMP-08", "COMP-10"):
            if not self.p.bound(cid) or (self.comps["components"][cid]["interface"].get("limits") or {}).get("scope") != "candidate_within_contract":
                continue
            self.p.run_through(cid)
            wide = dict(self.p.out("COMP-07", "candidate"), canonical_paths=["Suite05/05_demo.jad"])
            with self.subTest(component=cid):
                with self.assertRaises(lga.AdapterError) as ctx:
                    self.p.invoke(cid, dict(self.p.inputs_for(cid), candidate=wide, scope_contract=self.p.contract))
                self.assertEqual(ctx.exception.code, "component.scope_widening")
        if (self.comps["components"]["COMP-07"]["interface"].get("limits") or {}).get("scope") == "plan_within_contract":
            plan = copy.deepcopy(self.p.out("COMP-06", "refactoring_plan")); plan["operations"][0]["path"] = "Suite05/05_demo.jad"
            with self.assertRaises(lga.AdapterError) as ctx:
                self.p.invoke("COMP-07", dict(self.p.inputs_for("COMP-07"), refactoring_plan=plan))
            self.assertEqual(ctx.exception.code, "component.scope_widening")

    def test_resource_and_timeout_limits_discard_results(self) -> None:
        if not self.p.bound("COMP-01"):
            self.skipTest("COMP-01 not bound")
        tight = copy.deepcopy(self.comps); tight["components"]["COMP-01"]["interface"]["bounds"]["max_output_items"] = 3
        with self.assertRaises(lga.AdapterError) as ctx:
            K.invoke("COMP-01", {"binding": self.p.binding}, granted_effects=READ, components=tight, registry=self.reg)
        self.assertEqual(ctx.exception.code, "component.bounds_exceeded")
        slow = copy.deepcopy(self.comps); slow["components"]["COMP-01"]["interface"]["bounds"]["timeout_s"] = 0
        with self.assertRaises(lga.AdapterError) as ctx:
            K.invoke("COMP-01", {"binding": self.p.binding}, granted_effects=READ, components=slow, registry=self.reg)
        self.assertEqual(ctx.exception.code, "component.timeout")
        with self.assertRaises(lga.AdapterError) as ctx:
            K.invoke("COMP-01", {"binding": self.p.binding, "max_files": 10 ** 9}, granted_effects=READ, components=self.comps, registry=self.reg)
        self.assertEqual(ctx.exception.code, "component.bounds_exceeded")

    def test_every_component_declares_limits(self) -> None:
        declared = {cid for cid, c in self.comps["components"].items() if c["interface"].get("limits")}
        if not declared:
            self.skipTest("no limits declared yet")
        for cid in declared:
            lim = self.comps["components"][cid]["interface"]["limits"]
            self.assertTrue({"scope", "resource", "timeout", "failure", "human_gate", "rejects"} <= set(lim), cid)


if __name__ == "__main__":
    unittest.main()
