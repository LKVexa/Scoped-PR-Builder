"""Fail-closed proof for every platform invariant (T04).

For each invariant and each of the four negative classes — bypass, stale-or-replayed, malformed, cross-boundary —
the declared probe is executed against the real adapters and the observed refusal is checked against the code the
registry declares, with the run's effect ledgers proving nothing changed. A class declared not-applicable must say
why; it is never silently skipped.

The probes run against one governed run; each mutating probe works on its own copy, so no probe's outcome can be
decided by another probe having run first.
"""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from adapters import approval_adapter as AA  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import invariants as I  # noqa: E402
from adapters import review_surface as RS  # noqa: E402
import invariant_probes as P  # noqa: E402
import test_workflow as T  # noqa: E402

_CTX: dict = {}


def _context():
    """One governed run plus everything the probes need to reach a boundary honestly."""
    if not _CTX:
        base = Path(tempfile.mkdtemp(prefix="inv-neg-"))
        reg = C.load_registry()
        d = T.Driver(base, reg)
        d.drive("WF-12")
        run, rd, art = d.run, d.run.run_dir, d.run.artifacts
        chain = AA.load_chain(rd)
        surface = json.loads((rd / "review" / "surface.json").read_text(encoding="utf-8"))
        plan = json.loads((rd / "plan" / "refactoring_plan.json").read_text(encoding="utf-8"))
        sc = art["scope_contract"]
        first = RS.issue_command("request_evidence", surface=surface, identity="operator@example", channel="cli",
                                 rationale="negative-suite fixture: a first executed command",
                                 fields={"question": "probe", "paths": [], "kinds": []}, registry=reg)
        second = RS.issue_command("reject", surface=surface, identity="operator@example", channel="cli",
                                  rationale="negative-suite fixture: a second, different command", registry=reg)
        _CTX.update({
            "run_dir": rd, "registry": reg, "binding": art["binding"], "key": d.key,
            "candidate": art["candidate"], "card": art["review_card"], "report": art["verification_report"],
            "receipt": chain[-1] if chain else {}, "surface": surface, "artifacts": art,
            "scope_contract": {"allowed_paths": [str(x) for x in sc["allowed_paths"]],
                               "forbidden_paths": [str(x) for x in sc.get("forbidden_paths", [])]},
            "sources": {"retrieval_id": plan["retrieval_id"],
                        "source_snapshot_hash": art["binding"].source_snapshot_hash},
            "evidence_record": plan["evidence_refs"][0],
            "executed_command": first, "second_command": second, "reject_command": second,
            "invariants": I.load_invariants(registry=reg),
        })
    return _CTX


def _with_cases(m):
    """The invariants that declare negative cases. During the T04 wave the registry fills in item by item, so every
    assertion here is over what is declared *so far* — the wave's last item is where the set is complete."""
    return {i: e for i, e in m["invariants"].items() if "negative_cases" in e}


def _complete(m):
    return len(_with_cases(m)) == len(m["invariants"])


class ProbeSurfaceTests(unittest.TestCase):
    """Every declared probe exists and is executable; every executable probe is declared by some invariant."""

    def setUp(self):
        self.ctx = _context()
        self.m = self.ctx["invariants"]
        self.declared = _with_cases(self.m)
        if not self.declared:
            self.skipTest("no invariant declares negative cases yet in this wave")

    def test_every_declared_probe_is_implemented(self):
        required = I.probes_required(self.m)
        missing = sorted(set(required) - set(P.PROBES))
        self.assertEqual(missing, [], f"declared probes with no implementation: {missing}")

    def test_every_implemented_probe_is_declared_by_an_invariant(self):
        if not _complete(self.m):
            self.skipTest("the registry is still filling in; orphan probes are only meaningful once every invariant declares")
        required = I.probes_required(self.m)
        orphans = sorted(set(P.PROBES) - set(required))
        self.assertEqual(orphans, [], f"probes no invariant declares — dead test code: {orphans}")

    def test_every_negative_class_is_declared_for_every_invariant(self):
        for iid, e in self.declared.items():
            cases = I.negative_cases_of(e)
            self.assertEqual(set(cases), set(I.NEGATIVE_CLASSES), iid)
            for cls, case in cases.items():
                if case.get("applicable") is False:
                    self.assertGreater(len(case["reason"]), 40,
                                       f"{iid}/{cls}: a not-applicable class must say why, at length")
                else:
                    self.assertIn(case["probe"], P.PROBES, f"{iid}/{cls}")

    def test_the_only_not_applicable_classes_belong_to_the_deferred_invariant(self):
        na = {iid: [c for c, v in I.negative_cases_of(e).items() if v.get("applicable") is False]
              for iid, e in self.declared.items()}
        na = {k: v for k, v in na.items() if v}
        self.assertLessEqual(set(na), {"XSEC-04"},
                             "only the host-deferred invariant may declare a class not applicable")
        if _complete(self.m):
            self.assertEqual(sorted(na), ["XSEC-04"])


class FailClosedTests(unittest.TestCase):
    """T04 — every applicable negative case refuses with its declared code and leaves no effect."""

    def setUp(self):
        self.ctx = _context()
        self.m = self.ctx["invariants"]
        self.declared = _with_cases(self.m)
        if not self.declared:
            self.skipTest("no invariant declares negative cases yet in this wave")
        self.victim = sorted(self.declared)[0]

    def test_every_applicable_negative_case_fails_closed(self):
        checked, failures = 0, []
        for iid, e in sorted(self.declared.items()):
            for cls in I.NEGATIVE_CLASSES:
                case = I.negative_cases_of(e)[cls]
                if case.get("applicable") is False:
                    continue
                code, effect = P.run_probe(case["probe"], self.ctx)
                try:
                    I.assert_fail_closed(e, cls, code, effect_observed=effect)
                    checked += 1
                except I.InvariantRefusal as exc:
                    failures.append(f"{iid}/{cls} via {case['probe']}: {exc}")
        self.assertEqual(failures, [], "\n".join(failures))
        expected = 4 * len(self.declared) - sum(
            1 for e in self.declared.values() for v in I.negative_cases_of(e).values() if v.get("applicable") is False)
        self.assertEqual(checked, expected, "every applicable negative case must have been executed")

    def test_a_probe_that_is_not_refused_is_a_failure_not_a_pass(self):
        e = I.invariant(self.victim, self.m)
        with self.assertRaises(I.InvariantRefusal) as cm:
            I.assert_fail_closed(e, "bypass", None)
        self.assertEqual(cm.exception.code, "invariant.not_fail_closed")
        self.assertIn("not refused", str(cm.exception))

    def test_a_refusal_that_still_produced_an_effect_is_a_failure(self):
        e = I.invariant(self.victim, self.m)
        good = I.negative_cases_of(e)["bypass"]["expect_code"]
        with self.assertRaises(I.InvariantRefusal) as cm:
            I.assert_fail_closed(e, "bypass", good[0] if isinstance(good, list) else good, effect_observed=True)
        self.assertIn("still produced an effect", str(cm.exception))

    def test_a_refusal_with_the_wrong_code_is_a_failure(self):
        e = I.invariant(self.victim, self.m)
        with self.assertRaises(I.InvariantRefusal):
            I.assert_fail_closed(e, "bypass", "some.other.code")

    def test_probe_outcomes_do_not_depend_on_probe_order(self):
        forward = {n: P.run_probe(n, self.ctx)[0] for n in sorted(P.PROBES)}
        reverse = {n: P.run_probe(n, self.ctx)[0] for n in sorted(P.PROBES, reverse=True)}
        self.assertEqual(forward, reverse, "a probe's outcome must not depend on which probes ran before it")
        self.assertTrue(all(v for v in forward.values()), "every probe must reach a refusal")

    def test_the_sec06_export_boundary_guarantees_masking_rather_than_refusal(self):
        """SEC-06's refusal branch cannot fire (masking is idempotent); what it does enforce is asserted directly.

        This is why the XSEC bypass probes target SEC-03. The guarantee here — restricted output never leaves
        unmasked — is real and is tested; the unreachable branch is recorded as a finding, not claimed as a control.
        """
        ev = P.assert_export_masked("AKIAIOSFODNN7EXAMPLE and api_key = \"sk-live-" + "a" * 40 + "\"")
        self.assertGreaterEqual(ev["spans_in"], 1)
        self.assertEqual(ev["spans_out"], 0)
        self.assertTrue(ev["masked"])


class CoverageTests(unittest.TestCase):
    """The negative suite's own shape: which boundaries it actually exercises."""

    def setUp(self):
        self.m = _context()["invariants"]
        if not _complete(self.m):
            self.skipTest("platform-wide coverage is only meaningful once every invariant declares its negative cases")

    def test_all_four_classes_are_exercised_across_the_platform(self):
        counts = Counter()
        for e in self.m["invariants"].values():
            for cls, case in I.negative_cases_of(e).items():
                if case.get("applicable") is not False:
                    counts[cls] += 1
        for cls in I.NEGATIVE_CLASSES:
            self.assertGreaterEqual(counts[cls], 10, f"{cls} is barely exercised across the platform")

    def test_the_probe_set_spans_the_refusing_adapters(self):
        codes = set()
        for e in self.m["invariants"].values():
            for case in I.negative_cases_of(e).values():
                if case.get("applicable") is not False:
                    exp = case["expect_code"]
                    codes.update(exp if isinstance(exp, list) else [exp])
        prefixes = {c.split(".")[0] for c in codes}
        for expected in ("security", "approval", "review", "model", "scope", "store", "archive", "intent", "boundary"):
            self.assertIn(expected, prefixes, f"no negative case reaches a {expected}.* refusal")


if __name__ == "__main__":
    unittest.main()
