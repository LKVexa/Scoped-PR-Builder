"""Deterministic tests for isolated verification (stdlib unittest)."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import evidence_retrieval as er  # noqa: E402
from adapters import intent_intake as ii  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import patch_generator as pg  # noqa: E402
from adapters import verification_runner as vr  # noqa: E402


def _git(cwd: Path, *args: str) -> str:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t",
           "GIT_COMMITTER_EMAIL": "t@t", "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z", "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z"}
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=True, env=env).stdout.strip()


HDR = "ja source 0.3\nmodule suite{n}.demo\nuse Data\npolicy no_network\nemit json demo\n"


class Fixture(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "repo"
        self.root.mkdir()
        _git(self.root, "init", "-q")
        # 66 numbered suites so the cross-reference check has a valid corpus
        for n in range(1, 67):
            d = self.root / f"Suite{n:02d}"
            d.mkdir()
            (d / f"{n:02d}_demo.jad").write_text(HDR.format(n=n))
        alpha = self.root / "Suite04"
        (alpha / "SHA256SUMS.txt").write_text("0000  04_Old/04_demo.jad\n")
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c1")
        self.binding = lga.bind_repository(self.root)
        self.contract = json.loads(ii.accept_intent({
            "kind": "tech_debt_refactor", "title": "Regenerate stale Suite04 SHA256SUMS manifest",
            "description": "Suite04/SHA256SUMS.txt lists an obsolete jad path; regenerate digests.",
            "allowed_paths": ["Suite04/SHA256SUMS.txt"], "max_changed_files": 1, "max_diff_lines": 10, "requested_by": "t",
        }, self.binding).to_json())
        self.plan = er.build_plan(self.contract, er.retrieve_examples(self.binding, self.contract))
        self.cand, self.patch = pg.generate_candidate(self.binding, self.contract, self.plan, "regenerate_sha256sums_manifest")
        self.cand_json = json.loads(self.cand.to_json())
        self.sandbox_parent = Path(self.tmp.name) / "sandboxes"

    def tearDown(self) -> None:
        self.tmp.cleanup()


class TestVerification(Fixture):
    def test_pass_path_isolated_and_destroyed(self) -> None:
        r = vr.verify_candidate(self.binding, self.contract, self.cand_json, self.patch, self.sandbox_parent, run_tests=False)
        verdicts = {j["check"]: j["verdict"] for j in r.jobs}
        for c in ("applicability", "scope_diff", "size_limits", "build", "lint", "cross_reference"):
            self.assertEqual(verdicts[c], "PASS", c)
        self.assertEqual(verdicts["tests"], "INDETERMINATE")  # fixture repo has no tests -> never PASS
        self.assertEqual(r.verdict, "INDETERMINATE")
        self.assertTrue(r.sandbox_destroyed)
        self.assertTrue(r.source_tree_unchanged)
        self.assertEqual(_git(self.root, "status", "--porcelain"), "")
        self.assertEqual((self.root / "Suite04" / "SHA256SUMS.txt").read_text(), "0000  04_Old/04_demo.jad\n")
        body = json.loads(r.to_json()); body.pop("report_hash")
        self.assertEqual(lga.sha256_digest(lga.canonical_json(body)), r.report_hash)

    def test_full_pass_when_tests_exist(self) -> None:
        tests = self.root / "Scoped PR Builder" / "tests"
        tests.mkdir(parents=True)
        (tests / "test_ok.py").write_text("import unittest\nclass T(unittest.TestCase):\n    def test_a(self):\n        self.assertTrue(True)\nif __name__ == '__main__':\n    unittest.main()\n")
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c2")
        b = lga.bind_repository(self.root)
        c = json.loads(ii.accept_intent({"kind": "tech_debt_refactor", "title": "Regenerate stale Suite04 SHA256SUMS manifest", "description": "x",
                                          "allowed_paths": ["Suite04/SHA256SUMS.txt"], "max_changed_files": 1, "max_diff_lines": 10, "requested_by": "t"}, b).to_json())
        p = er.build_plan(c, er.retrieve_examples(b, c))
        cand, patch = pg.generate_candidate(b, c, p, "regenerate_sha256sums_manifest")
        r = vr.verify_candidate(b, c, json.loads(cand.to_json()), patch, self.sandbox_parent)
        self.assertEqual(r.verdict, "PASS", {j["check"]: (j["verdict"], j["summary"]) for j in r.jobs})

    def test_scope_expansion_fails_closed(self) -> None:
        # A patch that also touches a file outside the declared/allowed scope must FAIL at scope_diff
        extra = self.patch + (
            "diff --git a/Suite05/05_demo.jad b/Suite05/05_demo.jad\n--- a/Suite05/05_demo.jad\n+++ b/Suite05/05_demo.jad\n"
            "@@ -1,5 +1,5 @@\n ja source 0.3\n-module suite5.demo\n+module suite5.demo_x\n use Data\n policy no_network\n emit json demo\n"
        ).encode()
        forged = dict(self.cand_json, patch_hash=lga.sha256_digest(extra))
        forged["candidate_id"] = lga.sha256_digest(lga.canonical_json({"patch": forged["patch_hash"], "rev": forged["base_revision"], "scope": forged["scope_contract_hash"], "plan": forged["plan_hash"]}))
        r = vr.verify_candidate(self.binding, self.contract, forged, extra, self.sandbox_parent, run_tests=False)
        verdicts = {j["check"]: j["verdict"] for j in r.jobs}
        self.assertEqual(verdicts["scope_diff"], "FAIL")
        self.assertEqual(r.verdict, "FAIL")
        self.assertTrue(r.source_tree_unchanged)
        self.assertTrue(r.sandbox_destroyed)

    def test_tampered_patch_rejected_before_sandbox(self) -> None:
        with self.assertRaises(lga.AdapterError) as ctx:
            vr.verify_candidate(self.binding, self.contract, self.cand_json, self.patch + b"\n", self.sandbox_parent)
        self.assertEqual(ctx.exception.code, "candidate.patch_hash_mismatch")
        self.assertFalse(self.sandbox_parent.exists())

    def test_non_applicable_patch_fails(self) -> None:
        (self.root / "Suite04" / "SHA256SUMS.txt").write_text("ffff  changed\n")
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c2")
        b2 = lga.bind_repository(self.root)
        cand = dict(self.cand_json, base_revision=b2.base_revision)
        cand["candidate_id"] = lga.sha256_digest(lga.canonical_json({"patch": cand["patch_hash"], "rev": cand["base_revision"], "scope": cand["scope_contract_hash"], "plan": cand["plan_hash"]}))
        c2 = dict(self.contract, base_revision=b2.base_revision)
        r = vr.verify_candidate(b2, c2, cand, self.patch, self.sandbox_parent, run_tests=False)
        self.assertEqual(r.jobs[0]["check"], "applicability")
        self.assertEqual(r.jobs[0]["verdict"], "FAIL")
        self.assertEqual(r.verdict, "FAIL")


if __name__ == "__main__":
    unittest.main()
