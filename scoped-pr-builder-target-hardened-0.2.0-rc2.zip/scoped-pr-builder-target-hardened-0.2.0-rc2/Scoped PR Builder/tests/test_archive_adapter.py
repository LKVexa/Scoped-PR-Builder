"""Deterministic tests for archival and rollback proof (stdlib unittest)."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tarfile
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import approval_adapter as aa  # noqa: E402
from adapters import archive_adapter as ar  # noqa: E402
from adapters import evidence_retrieval as er  # noqa: E402
from adapters import intent_intake as ii  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import patch_generator as pg  # noqa: E402
from adapters import review_renderer as rr  # noqa: E402
from adapters import verification_runner as vr  # noqa: E402


def _git(cwd: Path, *args: str) -> str:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t",
           "GIT_COMMITTER_EMAIL": "t@t", "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z", "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z"}
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=True, env=env).stdout.strip()


HDR = "ja source 0.3\nmodule suite{n}.demo\nuse Data\npolicy no_network\nemit json demo\n"


def _w(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(lga.canonical_json(payload) + "\n", encoding="utf-8")


class Fixture(unittest.TestCase):
    """Runs the whole pilot chain on a fixture repository and lays out a run directory like spb does."""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        base = Path(self.tmp.name)
        self.root = base / "repo"
        self.root.mkdir()
        _git(self.root, "init", "-q")
        for n in range(1, 67):
            d = self.root / f"Suite{n:02d}"
            d.mkdir()
            (d / f"{n:02d}_demo.jad").write_text(HDR.format(n=n))
        (self.root / "Suite04" / "SHA256SUMS.txt").write_text("0000  04_Old/04_demo.jad\n")
        tests = self.root / "Scoped PR Builder" / "tests"
        tests.mkdir(parents=True)
        (tests / "test_ok.py").write_text("import unittest\nclass T(unittest.TestCase):\n    def test_a(self):\n        self.assertTrue(True)\nif __name__ == '__main__':\n    unittest.main()\n")
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c1")
        self.run_dir = base / "run"
        self.key = aa.load_or_create_key(base / "keys" / "approval.key", create=True)
        self.binding = lga.bind_repository(self.root)
        _w(self.run_dir / "suite40" / "binding.json", json.loads(self.binding.to_json()))
        contract = json.loads(ii.accept_intent({"kind": "tech_debt_refactor", "title": "Regenerate stale Suite04 SHA256SUMS manifest", "description": "x",
                                                "allowed_paths": ["Suite04/SHA256SUMS.txt"], "max_changed_files": 1, "max_diff_lines": 10, "requested_by": "t"}, self.binding).to_json())
        _w(self.run_dir / "intent" / "scope_contract.json", contract)
        bundle = er.retrieve_examples(self.binding, contract)
        plan = er.build_plan(contract, bundle)
        _w(self.run_dir / "suite51" / "evidence.json", bundle.evidence)
        _w(self.run_dir / "suite51" / "authority.json", bundle.authority)
        _w(self.run_dir / "plan" / "refactoring_plan.json", plan)
        cand, patch = pg.generate_candidate(self.binding, contract, plan, "regenerate_sha256sums_manifest")
        cand = json.loads(cand.to_json())
        _w(self.run_dir / "candidate" / "candidate.json", cand)
        (self.run_dir / "candidate" / "candidate.patch").write_bytes(patch)
        report = json.loads(vr.verify_candidate(self.binding, contract, cand, patch, base / "sb").to_json())
        _w(self.run_dir / "verification" / "report.json", report)
        card = rr.build_review_card(json.loads(self.binding.to_json()), contract, bundle.evidence, bundle.authority, plan, cand, patch, report)
        _w(self.run_dir / "review" / "review_card.json", card)
        receipt = json.loads(aa.issue_receipt(self.run_dir, self.key, decision="APPROVE", approver_identity="reviewer@example", approver_channel="test", rationale="ok",
                                              candidate=cand, card=card, report=report).to_json())
        applied = aa.apply_isolated(self.binding, contract, cand, patch, report, card, receipt, self.key, self.run_dir, self.run_dir / "applied-worktrees")
        _w(self.run_dir / "applied" / "applied.json", json.loads(applied.to_json()))
        self.applied = applied

    def tearDown(self) -> None:
        self.tmp.cleanup()


class TestArchive(Fixture):
    def test_archive_then_rollback_proof(self) -> None:
        summary = ar.archive_run(self.run_dir)
        out = self.run_dir / "archive"
        manifest = json.loads((out / "MANIFEST.json").read_text())
        self.assertEqual(manifest["artifact_count"], summary["artifact_count"])
        self.assertGreaterEqual(manifest["artifact_count"], 8)
        for e in manifest["artifacts"]:
            self.assertEqual(ar._sha(self.run_dir / e["path"]), e["sha256"])
        states = [json.loads(l)["run_state"] for l in (out / "run-state.jsonl").read_text().splitlines()]
        self.assertEqual(states, ["INTAKE", "BOUND", "INTENT_ACCEPTED", "PLANNED", "PATCH_INERT", "VERIFIED", "REVIEW_PENDING", "APPROVED", "APPLIED_ISOLATED", "ARCHIVED"])
        self.assertEqual(ar.verify_chain_file(out / "run-state.jsonl"), 10)
        self.assertEqual(ar.verify_chain_file(out / "audit.jsonl"), 2)  # approval.issue + patch.apply_isolated
        prov = json.loads((out / "provenance.json").read_text())
        outputs = {l["output"] for l in prov["links"]}
        self.assertEqual(outputs, {"binding", "scope_contract", "plan", "candidate", "verification_report", "review_card", "approval_receipt", "applied"})
        with tarfile.open(out / summary["archive_tarball"]) as tar:
            names = tar.getnames()
        self.assertIn("candidate/candidate.patch", names)
        self.assertIn("archive/MANIFEST.json", names)
        # rollback proof
        wt = Path(self.applied.applied_worktree)
        self.assertTrue(wt.exists())
        rec = ar.prove_rollback(self.run_dir, self.binding)
        self.assertEqual(rec["verdict"], "PASS", rec)
        self.assertFalse(wt.exists())
        self.assertEqual(rec["to_version"], self.binding.source_snapshot_hash)
        self.assertEqual(rec["after"]["linked_worktrees"], [])
        states = [json.loads(l)["run_state"] for l in (out / "run-state.jsonl").read_text().splitlines()]
        self.assertEqual(states[-1], "ROLLED_BACK")
        self.assertEqual(ar.verify_chain_file(out / "audit.jsonl"), 3)
        self.assertIn("04_Old", (self.root / "Suite04" / "SHA256SUMS.txt").read_text())  # checkpoint intact

    def test_chain_tamper_detected_and_missing_artifacts_block(self) -> None:
        ar.archive_run(self.run_dir)
        p = self.run_dir / "archive" / "run-state.jsonl"
        lines = p.read_text().splitlines()
        e = json.loads(lines[3]); e["run_state"] = "APPROVED"
        lines[3] = json.dumps(e, sort_keys=True, separators=(",", ":"))
        p.write_text("\n".join(lines) + "\n")
        with self.assertRaises(lga.AdapterError) as ctx:
            ar.verify_chain_file(p)
        self.assertEqual(ctx.exception.code, "archive.chain_tampered")
        (self.run_dir / "applied" / "applied.json").unlink()
        with self.assertRaises(lga.AdapterError) as ctx:
            ar.archive_run(self.run_dir)
        self.assertEqual(ctx.exception.code, "archive.artifact_missing")

    def test_rollback_twice_is_refused(self) -> None:
        ar.archive_run(self.run_dir)
        ar.prove_rollback(self.run_dir, self.binding)
        with self.assertRaises(lga.AdapterError) as ctx:
            ar.prove_rollback(self.run_dir, self.binding)
        self.assertEqual(ctx.exception.code, "rollback.nothing_to_roll_back")

    def test_rollback_refuses_rehashed_worktree_path_outside_run(self) -> None:
        victim = Path(self.tmp.name) / "victim-data"
        victim.mkdir()
        marker = victim / "keep.txt"
        marker.write_text("do not delete\n")
        p = self.run_dir / "applied" / "applied.json"
        applied = json.loads(p.read_text())
        applied["applied_worktree"] = str(victim)
        body = {k: v for k, v in applied.items() if k != "record_hash"}
        applied["record_hash"] = lga.sha256_digest(lga.canonical_json(body))
        _w(p, applied)
        with self.assertRaises(lga.AdapterError) as ctx:
            ar.prove_rollback(self.run_dir, self.binding)
        self.assertEqual(ctx.exception.code, "rollback.worktree_outside_run")
        self.assertTrue(marker.is_file())

    def test_rollback_preserves_preexisting_linked_worktree(self) -> None:
        other = Path(self.tmp.name) / "preexisting-worktree"
        lga.worktree_add(self.root, other, self.binding.base_revision)
        try:
            ar.archive_run(self.run_dir)
            rec = ar.prove_rollback(self.run_dir, self.binding)
            self.assertEqual(rec["verdict"], "PASS", rec)
            self.assertTrue(other.is_dir())
            self.assertIn(str(other.resolve()), rec["after"]["linked_worktrees"])
        finally:
            if other.exists():
                lga.worktree_remove(self.root, other)

    def test_archive_provenance_uses_receipt_that_actually_authorized_apply(self) -> None:
        applied = json.loads((self.run_dir / "applied" / "applied.json").read_text())
        candidate = json.loads((self.run_dir / "candidate" / "candidate.json").read_text())
        report = json.loads((self.run_dir / "verification" / "report.json").read_text())
        card = json.loads((self.run_dir / "review" / "review_card.json").read_text())
        later = aa.issue_receipt(self.run_dir, self.key, decision="REJECT", approver_identity="reviewer@example", approver_channel="test", rationale="later review",
                                 candidate=candidate, card=card, report=report)
        self.assertNotEqual(later.receipt_hash, applied["receipt_hash"])
        ar.archive_run(self.run_dir)
        provenance = json.loads((self.run_dir / "archive" / "provenance.json").read_text())
        approval_link = next(link for link in provenance["links"] if link["output"] == "approval_receipt")
        self.assertEqual(approval_link["hash"], applied["receipt_hash"])
        states = [json.loads(line) for line in (self.run_dir / "archive" / "run-state.jsonl").read_text().splitlines()]
        approved_state = next(row for row in states if row["run_state"] == "APPROVED")
        self.assertEqual(approved_state["evidence_ref"], applied["receipt_hash"])
        self.assertEqual(ar.verify_chain_file(self.run_dir / "archive" / "audit.jsonl"), 3)

    def test_archive_refuses_tampered_applied_record(self) -> None:
        p = self.run_dir / "applied" / "applied.json"
        applied = json.loads(p.read_text())
        applied["post_apply_tree"] = "git-tree:tampered"
        _w(p, applied)
        with self.assertRaises(lga.AdapterError) as ctx:
            ar.archive_run(self.run_dir)
        self.assertEqual(ctx.exception.code, "applied.record_tampered")


if __name__ == "__main__":
    unittest.main()
