"""Composition tests for the guardrail fact providers (Phase 02 / PAPER-GRD-*-T02; stdlib unittest).

The facts each rule decides on are derived from real overlay artifacts produced by the authoritative-suite
adapters — a bound repository, an accepted scope contract, a generated inert candidate, a verified report, a
review card and signed approval receipts — never from policy duplicated inside the guardrail module.
"""
from __future__ import annotations

import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import approval_adapter as aa  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import evidence_retrieval as er  # noqa: E402
from adapters import guardrails as G  # noqa: E402
from adapters import intent_intake as ii  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import patch_generator as pg  # noqa: E402
from adapters import repository_context_adapter as rca  # noqa: E402
from adapters import review_renderer as rr  # noqa: E402
from adapters import verification_runner as vr  # noqa: E402


def _git(cwd: Path, *args: str) -> str:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t",
           "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z", "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z"}
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=True, env=env).stdout.strip()


HDR = "ja source 0.3\nmodule suite{n}.demo\nuse Data\npolicy no_network\nemit json demo\n"
ADDED_FILE_PATCH = """diff --git a/Suite04/New.jad b/Suite04/New.jad
new file mode 100644
index 0000000..1111111
--- /dev/null
+++ b/Suite04/New.jad
@@ -0,0 +1,3 @@
+ja source 0.3
+module suite04.new_thing
+emit json demo
"""
CORE_PATCH = """diff --git a/Chair/chair_authorization.jasec b/Chair/chair_authorization.jasec
index 1111111..2222222 100644
--- a/Chair/chair_authorization.jasec
+++ b/Chair/chair_authorization.jasec
@@ -1,6 +1,12 @@
-deny x
-deny y
-deny z
-deny w
-deny v
-deny u
+allow x
+allow y
+allow z
+allow w
+allow v
+allow u
+allow t
+allow s
+allow r
+allow q
+allow p
+allow o
"""


class Fixture(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.tmp = tempfile.TemporaryDirectory()
        base = Path(cls.tmp.name)
        cls.root = base / "repo"
        cls.root.mkdir()
        _git(cls.root, "init", "-q")
        for n in range(1, 67):
            d = cls.root / f"Suite{n:02d}"
            d.mkdir()
            (d / f"{n:02d}_demo.jad").write_text(HDR.format(n=n))
        (cls.root / "Suite04" / "SHA256SUMS.txt").write_text("0000  04_Old/04_demo.jad\n")
        chair = cls.root / "Chair"; chair.mkdir()
        (chair / "chair_authorization.jasec").write_text("ja source 0.3\nmodule suite13.chair.authorization\nuse Security\npolicy no_network\nemit mcrt \"x\"\n")
        for n in (5, 6, 7):
            (cls.root / f"Suite{n:02d}" / f"{n:02d}_demo.jad").write_text(HDR.format(n=n) + 'dataset d from dmk("../Chair/chair_authorization.jasec")\n')
        tests = cls.root / "Scoped PR Builder" / "tests"
        tests.mkdir(parents=True)
        (tests / "test_ok.py").write_text("import unittest\nclass T(unittest.TestCase):\n    def test_a(self):\n        self.assertTrue(True)\nif __name__ == '__main__':\n    unittest.main()\n")
        _git(cls.root, "add", "-A")
        _git(cls.root, "commit", "-q", "-m", "c1")
        cls.run_dir = base / "run"; cls.run_dir.mkdir()
        cls.key = aa.load_or_create_key(base / "keys" / "approval.key", create=True)
        cls.binding = lga.bind_repository(cls.root)
        cls.contract = json.loads(ii.accept_intent({"kind": "tech_debt_refactor", "title": "Regenerate stale Suite04 SHA256SUMS manifest", "description": "x",
                                                    "allowed_paths": ["Suite04/SHA256SUMS.txt"], "max_changed_files": 1, "max_diff_lines": 10, "requested_by": "t"}, cls.binding).to_json())
        cls.bundle = er.retrieve_examples(cls.binding, cls.contract)
        cls.plan = er.build_plan(cls.contract, cls.bundle)
        cand, cls.patch = pg.generate_candidate(cls.binding, cls.contract, cls.plan, "regenerate_sha256sums_manifest")
        cls.cand = json.loads(cand.to_json())
        cls.report = json.loads(vr.verify_candidate(cls.binding, cls.contract, cls.cand, cls.patch, base / "sb").to_json())
        cls.card = rr.build_review_card(json.loads(cls.binding.to_json()), cls.contract, cls.bundle.evidence, cls.bundle.authority, cls.plan, cls.cand, cls.patch, cls.report)
        cls.context = rca.build_context(cls.root, cls.binding.base_revision)
        cls.reg = C.load_registry()
        cls.rules = G.load_rules(registry=cls.reg)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.tmp.cleanup()

    def receipt(self, decision="APPROVE", **kw):
        return json.loads(aa.issue_receipt(self.run_dir, self.key, decision=decision, approver_identity="reviewer@example", approver_channel="test", rationale="ok",
                                           candidate=self.cand, card=self.card, report=self.report, **kw).to_json())

    def ev(self, rid, facts, effect):
        return G.evaluate(rid, facts, effect=effect, rules=self.rules, registry=self.reg)


class TestComposition(Fixture):
    def test_grd01_from_bounded_diff_plan(self) -> None:
        if "composition" not in self.rules["rules"]["GRD-01"]:
            self.skipTest("GRD-01 not yet composed")
        facts = G.facts_bounded_size(self.cand, self.contract)
        self.assertEqual(facts["changed_files"], 1); self.assertEqual(facts["lines_changed"], 2)
        self.assertEqual(self.ev("GRD-01", facts, "diff.generate_inert")["state"], "PASS")
        big = dict(self.cand, files_changed=30, lines_added=300, lines_deleted=300)
        d = self.ev("GRD-01", G.facts_bounded_size(big, self.contract), "diff.generate_inert")
        self.assertEqual(d["state"], "DENY"); self.assertIn("exceed", d["reason"])
        mid = dict(self.cand, files_changed=1, lines_added=5, lines_deleted=4)
        self.assertEqual(self.ev("GRD-01", G.facts_bounded_size(mid, self.contract), "patch.apply_isolated")["state"], "PASS")

    def test_grd02_from_diff_and_approval(self) -> None:
        if "composition" not in self.rules["rules"]["GRD-02"]:
            self.skipTest("GRD-02 not yet composed")
        facts = G.facts_structure_change(self.patch.decode(), self.contract)
        self.assertEqual(facts["file_statuses"], [{"path": "Suite04/SHA256SUMS.txt", "status": "modified"}]); self.assertEqual(facts["added_declarations"], 0)
        self.assertEqual(self.ev("GRD-02", facts, "diff.generate_inert")["state"], "PASS")
        violating = G.facts_structure_change(ADDED_FILE_PATCH, self.contract)
        self.assertEqual(violating["file_statuses"][0]["status"], "added"); self.assertEqual(violating["added_declarations"], 1)
        self.assertEqual(self.ev("GRD-02", violating, "diff.generate_inert")["state"], "DENY")
        approved = G.facts_structure_change(ADDED_FILE_PATCH, dict(self.contract, allowed_paths=["Suite04"]), approval=self.receipt("APPROVE"), approved_scopes=["structure.change"])
        self.assertEqual(self.ev("GRD-02", approved, "patch.apply_isolated")["state"], "PASS")
        unscoped = G.facts_structure_change(ADDED_FILE_PATCH, dict(self.contract, allowed_paths=["Suite04"]), approval=self.receipt("APPROVE"), approved_scopes=[])
        self.assertEqual(self.ev("GRD-02", unscoped, "patch.apply_isolated")["state"], "DENY")

    def test_grd03_from_symbols_and_dependencies(self) -> None:
        if "composition" not in self.rules["rules"]["GRD-03"]:
            self.skipTest("GRD-03 not yet composed")
        facts = G.facts_core_logic(self.patch.decode(), self.context.symbols, self.context.dependencies)
        self.assertEqual(len(facts["touched_symbols"]), 1)
        self.assertEqual(self.ev("GRD-03", facts, "plan.propose")["state"], "PASS")
        core = G.facts_core_logic(CORE_PATCH, self.context.symbols, self.context.dependencies)
        t = core["touched_symbols"][0]
        self.assertEqual(t["symbol"], "suite13.chair.authorization"); self.assertGreaterEqual(t["in_degree"], 3); self.assertEqual(t["lines_changed"], 18)
        d = self.ev("GRD-03", core, "patch.apply_isolated")
        self.assertEqual(d["state"], "DENY"); self.assertIn("human", d["reason"])
        human = G.facts_core_logic(CORE_PATCH, self.context.symbols, self.context.dependencies, human={"involved": True, "approver_identity": "reviewer@example", "channel": "test"})
        self.assertEqual(self.ev("GRD-03", human, "patch.apply_isolated")["state"], "PASS")

    def test_grd04_from_receipt_verification(self) -> None:
        if "composition" not in self.rules["rules"]["GRD-04"]:
            self.skipTest("GRD-04 not yet composed")
        none = G.facts_explicit_review(None, candidate=self.cand, card=self.card, report=self.report)
        self.assertEqual(self.ev("GRD-04", none, "patch.apply_isolated")["state"], "DENY")
        rc = self.receipt("APPROVE")
        unverified = G.facts_explicit_review(rc, candidate=self.cand, card=self.card, report=self.report)
        self.assertEqual(self.ev("GRD-04", unverified, "patch.apply_isolated")["state"], "DIAGNOSTIC")
        ok = G.facts_explicit_review(rc, candidate=self.cand, card=self.card, report=self.report, run_dir=self.run_dir, key=self.key)
        self.assertEqual(self.ev("GRD-04", ok, "patch.apply_isolated")["state"], "PASS")
        rej = self.receipt("REJECT")
        bad = G.facts_explicit_review(rej, candidate=self.cand, card=self.card, report=self.report, run_dir=self.run_dir, key=self.key)
        self.assertEqual(self.ev("GRD-04", bad, "patch.apply_isolated")["state"], "DENY")
        later = self.receipt("APPROVE")
        expired = G.facts_explicit_review(later, candidate=self.cand, card=self.card, report=self.report, run_dir=self.run_dir, key=self.key, now=datetime.now(timezone.utc) + timedelta(days=3))
        d = self.ev("GRD-04", expired, "patch.apply_isolated")
        self.assertEqual(d["state"], "DENY"); self.assertIn("expired", d["reason"])
        other = dict(later, candidate_id="sha256:" + "9" * 64)
        d = self.ev("GRD-04", G.facts_explicit_review(other, candidate=self.cand, card=self.card, report=self.report, run_dir=self.run_dir, key=self.key), "patch.apply_isolated")
        self.assertEqual(d["state"], "DENY")


if __name__ == "__main__":
    unittest.main()
