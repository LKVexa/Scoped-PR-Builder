"""Executable negative probes for the platform invariants (XAUTH..XEVAL, T04).

Each probe drives the real adapter through the failure it is named for and returns `(code, effect_observed)`:
the stable refusal code the boundary raised, and whether the refused attempt nevertheless changed anything. A probe
that is not refused returns `(None, effect)`, which `invariants.assert_fail_closed` treats as a failure — "it did not
crash" is never a pass here.

Probes never assert; they observe. The assertion lives in `invariants.assert_fail_closed`, against the expected code
the invariant registry declares, so a probe cannot quietly agree with whatever the code happens to do today.

Nothing here fabricates approval: the test key is created by the approval adapter inside the run directory and is
only ever used to construct receipts the probes then prove are *rejected*.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Mapping

import sys as _sys

_HERE = Path(__file__).resolve().parent
if str(_HERE.parent) not in _sys.path:
    _sys.path.insert(0, str(_HERE.parent))

from adapters import approval_adapter as AA  # noqa: E402
from adapters import architecture as ARCH  # noqa: E402
from adapters import archive_adapter as AR  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import controls as CT  # noqa: E402
from adapters import intent_intake as II  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import model_orchestration as MO  # noqa: E402
from adapters import qualification as Q  # noqa: E402
from adapters import review_surface as RS  # noqa: E402
from adapters import security as SEC  # noqa: E402
from adapters import store as ST  # noqa: E402

PROBES: dict[str, Callable[..., tuple[str | None, bool]]] = {}


def probe(name: str):
    def deco(fn):
        PROBES[name] = fn
        return fn
    return deco


def _code(exc: BaseException) -> str | None:
    return getattr(exc, "code", None)


def run_probe(name: str, ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """Run one probe over a live run context. An unknown probe is an error, never a silent skip."""
    fn = PROBES.get(name)
    if fn is None:
        raise KeyError(f"no such probe {name!r}; declared probes: {sorted(PROBES)}")
    return fn(ctx)


# --------------------------------------------------------------------------- #
# bypass — going around the boundary rather than through it
# --------------------------------------------------------------------------- #
@probe("bypass_untrusted_channel")
def _p_untrusted_channel(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A model channel tries to record a human decision."""
    try:
        SEC.require_human_channel("model", identity="assistant", run_dir=ctx["run_dir"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("bypass_undeclared_writer")
def _p_undeclared_writer(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A model principal tries to append to an audit ledger."""
    before = _ledger_len(ctx)
    try:
        SEC.guard_audit_writer("model", run_dir=ctx["run_dir"])
        return None, _ledger_len(ctx) != before
    except lga.AdapterError as exc:
        return _code(exc), _ledger_len(ctx) != before


@probe("bypass_unapproved_apply")
def _p_unapproved_apply(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A privileged write with no verified human APPROVE receipt behind it."""
    try:
        SEC.guard_write("patch.apply_isolated", {"identity": "operator@example", "channel": "cli"},
                        authorized_by=None, decision={"decision": "allow"}, run_dir=ctx["run_dir"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("bypass_policy_denied_write")
def _p_policy_denied(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """The policy decision is an explicit deny and the effect is attempted anyway."""
    try:
        SEC.guard_write("store.write", {"identity": "operator@example", "channel": "cli"},
                        authorized_by=None, decision={"decision": "deny", "reason": "probe"}, run_dir=ctx["run_dir"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("bypass_model_actor_write")
def _p_model_actor(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    try:
        SEC.guard_write("store.write", {"identity": "planner", "channel": "model"},
                        authorized_by=None, decision={"decision": "allow"}, run_dir=ctx["run_dir"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("bypass_scope_widening")
def _p_scope_widening(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A path outside the approved scope is offered to the confinement check."""
    from pathlib import PurePosixPath as P
    sc = ctx["scope_contract"]
    allowed = [P(x) for x in sc["allowed_paths"]]
    try:
        lga.require_within_scope([P("Suite66/never_in_scope.txt")], allowed, [P(x) for x in sc.get("forbidden_paths", [])])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("bypass_model_minting")
def _p_model_minting(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """Model output that grants itself permission."""
    raw = {"summary": "x", "granted_effects": ["patch.apply_isolated"], "approval": {"decision": "APPROVE"}}
    try:
        MO.validate_output(raw, registry=ctx["registry"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("bypass_forged_receipt")
def _p_forged_receipt(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A receipt whose signature was not produced by the run's approval key."""
    chain = AA.load_chain(ctx["run_dir"])
    if not chain:
        return None, False
    forged = dict(chain[-1], signature="0" * 64)
    try:
        AA.verify_receipt(ctx["run_dir"], ctx["key"], forged, candidate=ctx["candidate"], card=ctx["card"], report=ctx["report"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("bypass_export_restricted")
def _p_export_restricted(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A candidate that would carry secret material forward into the repository, and from there into every later
    review, export and model context, is offered to the effect boundary.

    This probes SEC-03 rather than SEC-06 deliberately. `enforce_sec06_export` classifies and masks, and its refusal
    branch requires a secret-shaped span to survive its own masking — which cannot happen, because masking is
    idempotent. Its real, enforced guarantee is that restricted output only ever leaves masked; that guarantee is
    asserted separately by `assert_export_masked` below. The refusing boundary for "secrets never travel" is SEC-03.
    """
    patch = b"diff --git a/x b/x\n--- a/x\n+++ b/x\n@@ -0,0 +1 @@\n+AKIAIOSFODNN7EXAMPLE\n"
    try:
        SEC.enforce_sec03_effect(patch, run_dir=ctx["run_dir"], subject={"probe": "bypass_export_restricted"})
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


def assert_export_masked(text: str) -> dict[str, Any]:
    """The property SEC-06 actually enforces: whatever leaves is the masked rendering, and no secret-shaped span
    recognised in the input survives into it. Returns the evidence; raises AssertionError if the guarantee fails."""
    before = SEC.scan_secrets(text)
    out = SEC.enforce_sec06_export("probe_artifact", text)
    after = SEC.scan_secrets(out)
    if before and out == text:
        raise AssertionError("SEC-06: restricted content left the boundary unmasked")
    if after:
        raise AssertionError(f"SEC-06: {after} secret-shaped span(s) survived masking")
    return {"spans_in": before, "spans_out": after, "masked": out != text or before == 0}


@probe("bypass_human_gate")
def _p_human_gate(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """Approval is attempted over a surface that carries blocking risk."""
    surface = dict(ctx["surface"], blocking_risk="probe: an unresolved blocking risk")
    try:
        RS.issue_command("approve", surface=surface, identity="operator@example", channel="cli",
                         rationale="probe: approving over a blocking surface", registry=ctx["registry"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


def _copy_run(ctx: Mapping[str, Any]) -> Path:
    """A throwaway copy of the run directory: probes that tamper, invalidate or execute never touch the run they
    observe, so probe order can never decide a probe's outcome."""
    import shutil
    import tempfile
    dest = Path(tempfile.mkdtemp(prefix="probe-copy-")) / "run"
    shutil.copytree(Path(ctx["run_dir"]), dest)
    return dest


#: The effect witness. Deliberately excludes the security trail: a refusal that writes its own denial row has
#: produced an audit record, not an effect, and counting it would make every fail-closed probe look like a failure.
EFFECT_LEDGERS = ("workflow/steps.jsonl", "archive/run-state.jsonl", "archive/audit.jsonl",
                  "approvals/ledger.jsonl", "review/commands.jsonl")


def _ledger_len(ctx: Mapping[str, Any]) -> int:
    """Total rows across the run's effect ledgers — the witness for probes that must change nothing."""
    n = 0
    for rel in EFFECT_LEDGERS:
        p = Path(ctx["run_dir"]) / rel
        if p.is_file():
            n += len([l for l in p.read_text(encoding="utf-8").splitlines() if l.strip()])
    return n


# --------------------------------------------------------------------------- #
# stale_or_replayed — acting on state that has moved, or replaying what was already used
# --------------------------------------------------------------------------- #
@probe("stale_binding")
def _p_stale_binding(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """The pinned revision no longer matches the repository HEAD."""
    b = ctx["binding"]
    moved = b.__class__(**{**{f: getattr(b, f) for f in b.__dataclass_fields__}, "base_revision": "0" * 40,
                           "current_revision": "0" * 40})
    try:
        lga.revalidate_binding(moved)
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("stale_snapshot")
def _p_stale_snapshot(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    b = ctx["binding"]
    moved = b.__class__(**{**{f: getattr(b, f) for f in b.__dataclass_fields__}, "source_snapshot_hash": "sha256:" + "0" * 64})
    try:
        lga.revalidate_binding(moved)
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("stale_approval_inputs")
def _p_stale_approval(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """An approval is checked against a candidate whose bound inputs have since changed."""
    # on a copy: an invalidation row written by another probe must not decide this probe's outcome
    copy = _copy_run(ctx)
    receipt = dict(ctx["receipt"], patch_hash="sha256:" + "0" * 64)
    try:
        RS.assert_approval_current(copy, receipt, ctx["artifacts"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("stale_view")
def _p_stale_view(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A view bound to other artifacts is offered for verification."""
    other = {k: dict(v) if isinstance(v, dict) else v for k, v in ctx["artifacts"].items()}
    cand = dict(other.get("candidate") or {})
    cand["candidate_id"] = "sha256:" + "1" * 64
    other["candidate"] = cand
    try:
        RS.verify_view(ctx["surface"], other)
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("stale_model_pin")
def _p_stale_model_pin(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A model output that claims a revision other than the one the run pinned."""
    out = {"retrieval_id": ctx["sources"]["retrieval_id"], "base_revision": "0" * 40}
    stale = MO.check_context_fresh(out, ctx["sources"], ctx["binding"])
    # check_context_fresh reports rather than raises; the boundary that consumes it is `evaluate`, which routes it
    return ("model.pin_mismatch" if stale else None), False


@probe("stale_source_input")
def _p_stale_source(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A derived record whose recorded source material no longer hashes as recorded."""
    report = {"stale_inputs": [{"record_id": "probe", "why": "the persisted input no longer matches the repository"}],
              "workflow": {"resumable": True, "run_state": "PLANNED"}}
    try:
        ST.assert_fresh(report)
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("replayed_command")
def _p_replayed_command(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A different command is issued under an idempotency key that was already used."""
    # on a copy: executing a command is an effect, and no probe may leave one on the run it observes
    copy = _copy_run(ctx)
    cctx = dict(ctx, run_dir=copy)
    first = ctx["executed_command"]
    RS.execute_command(copy, first, artifacts=ctx["artifacts"], surface=ctx["surface"],
                       key=ctx["key"], registry=ctx["registry"])
    before = _ledger_len(cctx)
    # a genuinely different command, forced onto the key the first one already used
    second = dict(ctx["second_command"], idempotency_key=first["idempotency_key"])
    try:
        RS.execute_command(copy, second, artifacts=ctx["artifacts"], surface=ctx["surface"],
                           key=ctx["key"], registry=ctx["registry"])
        return None, _ledger_len(cctx) != before
    except lga.AdapterError as exc:
        return _code(exc), _ledger_len(cctx) != before


@probe("replayed_approval_token")
def _p_replayed_token(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A receipt reused after a later human command invalidated it."""
    chain = AA.load_chain(ctx["run_dir"])
    if not chain:
        return None, False
    # on a copy: the invalidation this probe needs must not become another probe's starting condition
    copy = _copy_run(ctx)
    RS.invalidate_prior_approvals(copy, ctx["reject_command"])
    try:
        RS.assert_approval_current(copy, chain[-1], ctx["artifacts"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("expired_receipt")
def _p_expired_receipt(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A receipt verified after its declared TTL has passed."""
    from datetime import datetime, timedelta, timezone
    chain = AA.load_chain(ctx["run_dir"])
    if not chain:
        return None, False
    later = datetime.now(timezone.utc) + timedelta(days=3650)
    try:
        AA.verify_receipt(ctx["run_dir"], ctx["key"], chain[-1], candidate=ctx["candidate"], card=ctx["card"],
                          report=ctx["report"], now=later)
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("stale_gate_receipt")
def _p_stale_gate(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """The offline gate is asked to pass while a mandatory scenario has not passed."""
    try:
        Q.require_offline_gate(stage="probe", ledger=Path(ctx["run_dir"]) / "qualification" / "empty_gate.jsonl")
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


# --------------------------------------------------------------------------- #
# malformed — input that does not have the shape the boundary declares
# --------------------------------------------------------------------------- #
@probe("malformed_payload")
def _p_malformed_payload(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A payload that violates its registered contract."""
    try:
        C.validate_payload("reviewer_command", {"action": 17}, registry=ctx["registry"])
        return None, False
    except C.SchemaError as exc:
        return _code(exc), False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("malformed_argv")
def _p_malformed_argv(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A shell string where an argv vector is required."""
    try:
        SEC.validate_argv("python -c 'import os; os.system(\"id\")'", run_dir=ctx["run_dir"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("malformed_path_arg")
def _p_malformed_path(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A tool argument naming an absolute path outside the sandbox and the overlay."""
    try:
        SEC.validate_argv(["python", "/etc/shadow"], sandbox=Path(ctx["run_dir"]) / "sandbox", run_dir=ctx["run_dir"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("malformed_model_output")
def _p_malformed_output(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """Model output that is not the declared shape at all."""
    try:
        MO.validate_output("not an object", registry=ctx["registry"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("malformed_intent")
def _p_malformed_intent(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """An intent that is not a JSON object."""
    try:
        II.accept_intent(["not", "an", "object"], ctx["binding"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("malformed_crossing")
def _p_malformed_crossing(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A boundary crossing message that is not an object."""
    try:
        ARCH.check_crossing("not a message")
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


# --------------------------------------------------------------------------- #
# cross_boundary — material from another repository, revision, view or chain
# --------------------------------------------------------------------------- #
@probe("cross_tenant_artifact")
def _p_cross_tenant(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """An artifact bound to another repository is offered as evidence."""
    foreign = {"repository_id": "sha256:" + "9" * 64, "base_revision": ctx["binding"].base_revision}
    try:
        SEC.assert_tenant(ctx["binding"], ("probe_artifact", foreign), run_dir=ctx["run_dir"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("cross_revision_artifact")
def _p_cross_revision(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    foreign = {"repository_id": ctx["binding"].repository_id, "base_revision": "f" * 40}
    try:
        SEC.assert_tenant(ctx["binding"], ("probe_artifact", foreign), run_dir=ctx["run_dir"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("cross_boundary_audit_tampered")
def _p_audit_tampered(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """An audit ledger is edited under the run directory and then read at an effect boundary.

    The probe works on a COPY of the run directory: it must never damage the run it is observing.
    """
    copy = _copy_run(ctx)
    p = copy / "workflow" / "steps.jsonl"
    lines = p.read_text(encoding="utf-8").splitlines()
    row = json.loads(lines[0]); row["outcome"] = "SUCCEEDED"; lines[0] = json.dumps(row)
    p.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        SEC.assert_audit_intact(copy, stores=False, include_archive=False)
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("cross_boundary_chain_tampered")
def _p_chain_tampered(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    copy = _copy_run(ctx)
    p = copy / "workflow" / "events.jsonl"
    lines = p.read_text(encoding="utf-8").splitlines()
    row = json.loads(lines[-1]); row["kind"] = "runtime.tampered"; lines[-1] = json.dumps(row)
    p.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        AR.verify_chain_file(p)
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("cross_boundary_view_tampered")
def _p_view_tampered(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A surface whose displayed content was edited after it was bound."""
    surface = json.loads(json.dumps(ctx["surface"]))
    section = sorted(surface["section_hashes"])[0]
    surface["sections"][section] = {"tampered": "content the reviewer never saw"}
    try:
        RS.verify_view(surface, ctx["artifacts"])
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("cross_boundary_evidence_mismatch")
def _p_evidence_mismatch(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """An evidence record whose blob no longer hashes to what was recorded."""
    rec = dict(ctx["evidence_record"], content_hash="sha256:" + "4" * 64)
    b = ctx["binding"]
    try:
        RS.inspect_evidence(Path(b.root_path), b.base_revision, rec)
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


@probe("cross_boundary_unknown")
def _p_unknown_boundary(ctx: Mapping[str, Any]) -> tuple[str | None, bool]:
    """A crossing addressed to a boundary that is not declared."""
    msg = {"boundary_id": "boundary.that.does.not.exist", "identity": {"run_id": "probe"}, "payload": {}}
    try:
        ARCH.check_crossing(msg)
        return None, False
    except lga.AdapterError as exc:
        return _code(exc), False


__all__ = ["EFFECT_LEDGERS", "PROBES", "assert_export_masked", "probe", "run_probe"]
