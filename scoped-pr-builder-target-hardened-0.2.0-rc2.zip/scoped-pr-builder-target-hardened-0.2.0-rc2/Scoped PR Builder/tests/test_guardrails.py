"""Data-driven tests for the guardrail rules (Phase 02 / PAPER-GRD-*; stdlib unittest).

Every rule in guardrails/RULES.json must: bind to existing authoritative suite files; evaluate its own examples
to exactly PASS / DENY / ABSTAIN / DIAGNOSTIC; refuse when facts are absent (ABSTAIN, blocking); refuse malformed
facts (DIAGNOSTIC, blocking); and produce a hash-bound, schema-valid guardrail_decision for every outcome.
Later waves add fact providers, enforcement, review exposure and regression scenarios (see the T0x sections).
"""
from __future__ import annotations

import copy
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import contracts as C  # noqa: E402
from adapters import guardrails as G  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402

REPO_ROOT = HERE.parent.parent


class TestRules(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.rules = G.load_rules(registry=self.reg)

    def test_registry_loads_and_binds(self) -> None:
        self.assertEqual(self.rules["computed_hash"], G.load_rules(registry=self.reg)["computed_hash"])
        for rid, r in self.rules["rules"].items():
            with self.subTest(rule=rid):
                for f in r["authoritative_suites"]:
                    self.assertTrue((REPO_ROOT / f).is_file(), f)
                self.assertIn(r["kind"], G.KINDS)
                self.assertTrue(r["capability"].startswith("action.scope") or "." in r["capability"])

    def test_every_rule_reaches_every_state(self) -> None:
        for rid, r in self.rules["rules"].items():
            effect = r["evaluates_on"][0]
            for state in G.STATES:
                with self.subTest(rule=rid, state=state):
                    d = G.evaluate(rid, copy.deepcopy(r["examples"][state.lower()]), effect=effect, rules=self.rules, registry=self.reg)
                    self.assertEqual(d["state"], state, f"{rid}/{state}: {d['reason']}")
                    self.assertEqual(d["blocking"], state != "PASS")
                    self.assertRegex(d["decision_hash"], r"^sha256:[0-9a-f]{64}$")
                    self.assertTrue(d["reason"])

    def test_absent_and_malformed_facts_block(self) -> None:
        for rid, r in self.rules["rules"].items():
            effect = r["evaluates_on"][0]
            with self.subTest(rule=rid):
                self.assertEqual(G.evaluate(rid, None, effect=effect, rules=self.rules, registry=self.reg)["state"], "ABSTAIN")
                self.assertEqual(G.evaluate(rid, {}, effect=effect, rules=self.rules, registry=self.reg)["state"], "ABSTAIN")
                bad = copy.deepcopy(r["examples"]["pass"]); bad["__injected__"] = True
                self.assertEqual(G.evaluate(rid, bad, effect=effect, rules=self.rules, registry=self.reg)["state"], "DIAGNOSTIC")
                with self.assertRaises(lga.AdapterError) as ctx:
                    G.evaluate(rid, r["examples"]["pass"], effect="no.such_effect", rules=self.rules, registry=self.reg)
                self.assertEqual(ctx.exception.code, "guardrail.not_applicable")

    def test_evaluate_all_never_defaults_to_pass(self) -> None:
        effects = sorted({e for r in self.rules["rules"].values() for e in r["evaluates_on"]})
        for effect in effects:
            with self.subTest(effect=effect):
                decisions = G.evaluate_all({}, effect=effect, rules=self.rules, registry=self.reg)
                self.assertTrue(decisions)
                self.assertTrue(all(d["state"] == "ABSTAIN" and d["blocking"] for d in decisions))
                facts = {rid: r["examples"]["pass"] for rid, r in self.rules["rules"].items() if effect in r["evaluates_on"]}
                decisions = G.evaluate_all(facts, effect=effect, rules=self.rules, registry=self.reg)
                self.assertTrue(all(d["state"] == "PASS" for d in decisions))

    def test_unknown_rule_and_unbound_suite_fail_closed(self) -> None:
        with self.assertRaises(lga.AdapterError) as ctx:
            G.evaluate("GRD-99", {}, effect="diff.generate_inert", rules=self.rules, registry=self.reg)
        self.assertEqual(ctx.exception.code, "guardrail.unknown")
        import json, tempfile
        broken = copy.deepcopy(self.rules); rid = next(iter(broken["rules"]))
        broken["rules"][rid]["authoritative_suites"][0] = "Nope/99_missing.ja"
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump({k: v for k, v in broken.items() if k != "computed_hash"}, f)
        with self.assertRaises(lga.AdapterError) as ctx:
            G.load_rules(Path(f.name), registry=self.reg)
        self.assertEqual(ctx.exception.code, "guardrail.suite_unbound")


if __name__ == "__main__":
    unittest.main()
