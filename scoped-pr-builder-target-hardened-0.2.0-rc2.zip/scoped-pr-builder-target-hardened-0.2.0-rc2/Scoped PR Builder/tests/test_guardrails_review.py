"""Review-surface exposure tests for the guardrails (Phase 02 / PAPER-GRD-*-T04; stdlib unittest).

Before any state-changing action the review card shows, per rule: the statement, the current state, the current
values (evidence), the blocking reason and what would satisfy it. The section is display-only, hash-bound into
the card (tampering is refused at apply), rendered escaped, and re-evaluated on live facts at the effect boundary.
"""
from __future__ import annotations

import copy
import json
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from adapters import approval_adapter as aa  # noqa: E402
from adapters import guardrails as G  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import review_renderer as rr  # noqa: E402
from test_guardrails_composition import Fixture  # noqa: E402


class TestReviewExposure(Fixture):
    def test_card_exposes_every_rule_before_apply(self) -> None:
        exposed = [rid for rid, r in self.rules["rules"].items() if r.get("review_exposure")]
        if not exposed:
            self.skipTest("no review exposure declared yet")
        sec = self.card.get("guardrails")
        self.assertIsNotNone(sec, "review card lacks the guardrails section")
        self.assertEqual(sec["authority"], "display_only"); self.assertEqual(sec["effect"], "patch.apply_isolated")
        by_rule = {r["rule_id"]: r for r in sec["rules"]}
        for rid in exposed:
            with self.subTest(rule=rid):
                row = by_rule[rid]
                self.assertEqual(row["title"], self.rules["rules"][rid]["title"])
                self.assertTrue(row["statement"] and row["reason"] and row["satisfied_by"])
                self.assertIn(row["state"], G.STATES)
        # honest pre-review state: size/structure pass, review is DENY (no decision yet), impact abstains without context
        self.assertEqual(by_rule["GRD-01"]["state"], "PASS"); self.assertEqual(by_rule["GRD-02"]["state"], "PASS")
        self.assertEqual(by_rule["GRD-04"]["state"], "DENY"); self.assertFalse(sec["all_pass"])
        self.assertTrue(any(b.startswith("GRD-04 DENY") for b in sec["blocking_reasons"]))
        if "GRD-03" in by_rule:
            self.assertEqual(by_rule["GRD-03"]["state"], "ABSTAIN")

    def test_card_with_context_evaluates_impact(self) -> None:
        if not self.rules["rules"]["GRD-03"].get("review_exposure"):
            self.skipTest("GRD-03 not yet exposed")
        card = rr.build_review_card(json.loads(self.binding.to_json()), self.contract, self.bundle.evidence, self.bundle.authority, self.plan, self.cand, self.patch, self.report, context=self.context)
        row = {r["rule_id"]: r for r in card["guardrails"]["rules"]}["GRD-03"]
        self.assertEqual(row["state"], "PASS")
        self.assertTrue(any("touched=1" in v for v in row["current_values"]))

    def test_html_renders_rules_escaped_and_display_only(self) -> None:
        if not self.card.get("guardrails"):
            self.skipTest("no guardrails section yet")
        html = rr.render_html(self.card)
        self.assertIn("Guardrails (paper rules", html)
        for r in self.card["guardrails"]["rules"]:
            self.assertIn(r["title"], html)
        self.assertNotIn("<script", html)
        evil = copy.deepcopy(self.card)
        evil["guardrails"]["rules"][0]["reason"] = "<img src=x onerror=alert(1)>"
        html2 = rr.render_html(evil)
        self.assertNotIn("<img", html2); self.assertIn("&lt;img", html2)

    def test_tampered_section_is_refused_at_apply(self) -> None:
        if not self.card.get("guardrails"):
            self.skipTest("no guardrails section yet")
        rc = self.receipt("APPROVE")
        forged = copy.deepcopy(self.card)
        for r in forged["guardrails"]["rules"]:
            r["state"], r["blocking"] = "PASS", False
        forged["guardrails"]["all_pass"] = True; forged["guardrails"]["blocking_reasons"] = []
        with self.assertRaises(lga.AdapterError) as ctx:
            aa.apply_isolated(binding=self.binding, contract=self.contract, candidate=self.cand, patch=self.patch, report=self.report, card=forged, receipt=rc, key=self.key, run_dir=self.run_dir, worktree_parent=Path(self.tmp.name) / "applied-forged")
        self.assertEqual(ctx.exception.code, "apply.card_mismatch")

    def test_live_reevaluation_after_decision(self) -> None:
        if not all(r.get("review_exposure") for r in self.rules["rules"].values()):
            self.skipTest("not every rule exposed yet")
        rc = self.receipt("APPROVE")
        facts = G.apply_time_facts(self.binding, self.contract, self.cand, self.patch, self.card, self.report, rc, self.run_dir, self.key)
        decisions = G.evaluate_all(facts, effect="patch.apply_isolated", rules=self.rules, registry=self.reg)
        frag = G.review_fragment(decisions, effect="patch.apply_isolated", rules=self.rules)
        self.assertTrue(frag["all_pass"]); self.assertGreaterEqual(len(frag["rules"]), 4)  # Phase 03 adds CAP-03/CAP-04 at apply
        self.assertNotEqual(frag["fragment_hash"], self.card["guardrails"]["fragment_hash"])


if __name__ == "__main__":
    unittest.main()
