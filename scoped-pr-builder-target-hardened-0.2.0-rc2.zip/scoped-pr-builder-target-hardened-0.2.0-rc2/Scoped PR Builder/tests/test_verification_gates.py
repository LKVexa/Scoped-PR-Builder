"""Verification-gate evidence (Phase 08 / VERIFY-*-T05; stdlib unittest), driven by tests/scenarios/verify.json.

For every declared check: a passing fixture (the real recipe candidate, executed in a detached worktree), a deterministic
failure fixture (a hash-bound forged candidate that breaks exactly that condition — its failure must yield reviewable
diagnostics and leave the authorized worktree untouched), and a stale/mismatched-evidence fixture (a fresh pass re-gated
against another patch/revision, and a result whose evidence was edited). Once per run the workflow itself is driven to
show that approval cannot be reached over a failing candidate or over stale results. Every case leaves a chained receipt
on the test/evidence ledger (``SPB_EVIDENCE_LEDGER``; run-local otherwise).
"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path, PurePosixPath

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import evidence_ledger as EL  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import patch_generator as pg  # noqa: E402
from adapters import verification_checks as VC  # noqa: E402
from test_verification_checks import Base, CHECK_IDS, contract_for, forge  # noqa: E402
from test_workflow import Driver  # noqa: E402

SCENARIOS = HERE / "scenarios" / "verify.json"
ZERO = "0" * 64


@pg.recipe("test_break_manifest")
def _break_manifest(binding, target, current, tree):
    """Test-only recipe: a well-formed manifest whose digest is wrong (REG-01 must catch it)."""
    return f"{ZERO}  tool.py\n".encode("utf-8")


class TestVerificationGates(Base):
    def setUp(self) -> None:
        super().setUp()
        self.scen = json.loads(SCENARIOS.read_text(encoding="utf-8")).get("scenarios", {}) if SCENARIOS.is_file() else {}
        if not self.scen:
            self.skipTest("no verification scenarios yet")
        self.rows = 0

    def _receipt(self, cid: str, case: str, body: dict, verdict: str = "PASS") -> None:
        EL.record(f"verify:{cid}:{case}", "verification_gate", verdict, {"check_id": cid, "case": case, **body})
        self.rows += 1

    # ---- deterministic failure fixtures, one per check -------------------------------------------------------------
    def _failure_fixture(self, cid: str):
        rev = self.binding.base_revision
        if cid == "VERIFY-01":
            cand, patch = forge(self.cand, self.contract, self.root, rev, {"Suite04/SHA256SUMS.txt": "x\n"})
            patch = patch.replace(b"-0000  04_Old/04_demo.jad", b"-9999  nope")
            cand = dict(cand, patch_hash=lga.sha256_digest(patch)); cand["candidate_id"] = lga.sha256_digest(lga.canonical_json({"patch": cand["patch_hash"], "rev": cand["base_revision"], "scope": cand["scope_contract_hash"], "plan": cand["plan_hash"]}))
            return self.contract, cand, patch, "patch context does not match the authorized revision"
        if cid == "VERIFY-02":
            c = contract_for(self.binding, ["Suite04/tool.py"], lines=20)
            return (c, *forge(self.cand, c, self.root, rev, {"Suite04/tool.py": "def broken(:\n    return 1\n"}), "syntax error in a changed python file")
        if cid == "VERIFY-03":
            c = contract_for(self.binding, ["Scoped PR Builder/tests/test_ok.py"], lines=20)
            return (c, *forge(self.cand, c, self.root, rev, {"Scoped PR Builder/tests/test_ok.py": "import unittest\nclass T(unittest.TestCase):\n    def test_a(self):\n        self.assertTrue(False)\nif __name__ == '__main__':\n    unittest.main()\n"}), "a required test fails")
        if cid == "VERIFY-04":
            c = contract_for(self.binding, ["Suite04/tool.py"], lines=20)
            return (c, *forge(self.cand, c, self.root, rev, {"Suite04/tool.py": "def f():   \n    return 1\n"}), "a lint finding (trailing whitespace) above the zero threshold")
        if cid == "VERIFY-05":
            c = contract_for(self.binding, ["Suite04"], files=2, lines=40)
            cand, patch = forge(self.cand, c, self.root, rev, {"Suite04/SHA256SUMS.txt": "abcd  x\n", "Suite04/tool.py": "def g():\n    return 2\n"})
            cand["canonical_paths"] = ["Suite04/SHA256SUMS.txt"]; cand["files_changed"] = 1  # the second file is changed but never declared
            return c, cand, patch, "a changed file the candidate never declared"
        if cid == "VERIFY-06":
            c = contract_for(self.binding, ["Suite04/SHA256SUMS.txt"], lines=2)
            return (c, *forge(self.cand, c, self.root, rev, {"Suite04/SHA256SUMS.txt": "a\nb\nc\nd\n"}), "diff exceeds the review threshold (max_diff_lines)")
        if cid == "VERIFY-07":
            return (self.contract, *forge(self.cand, self.contract, self.root, rev, {"Suite04/SHA256SUMS.txt": f"{ZERO}  tool.py\n"}), "a behavioral regression check (REG-01 manifest digests) fails")
        raise AssertionError(cid)

    def test_scenarios(self) -> None:
        active = [cid for cid in CHECK_IDS if f"verify:{cid}" in self.scen and self.bound(cid, "execution")]
        report, results = VC.run_checks(self.binding, self.contract, self.cand, self.patch, self.sandboxes, registry=self.reg)
        by = VC.results_by_check(results); s = self.subject()
        self.assert_source_untouched()
        for cid in active:
            sc = self.scen[f"verify:{cid}"]
            # passing --------------------------------------------------------------------------------------------
            with self.subTest(check=cid, case="passing"):
                r = by[cid]
                self.assertEqual(r["result"], "pass", r["reasons"]); self.assertTrue(r["executed"]); self.assertTrue(r["executor"]["job_ids"])
                self.assertEqual(VC.gate([r], s, registry=self.reg)["per_check"][cid]["status"], "satisfied")
                self._receipt(cid, "passing", {"result": r["result"], "result_hash": r["result_hash"], "jobs": [d["check"] for d in r["diagnostics"]], "evidence_refs": len(r["evidence_refs"]), "report_hash": report["report_hash"], "fingerprint": (r.get("reproducibility") or {}).get("fingerprint"), "source_tree_unchanged": report["source_tree_unchanged"]})
            # deterministic failure --------------------------------------------------------------------------------
            with self.subTest(check=cid, case="failure"):
                c, cand, patch, why = self._failure_fixture(cid)
                rep2, res2 = VC.run_checks(self.binding, c, cand, patch, self.sandboxes, registry=self.reg)
                r2 = VC.results_by_check(res2)[cid]
                self.assertEqual(r2["result"], "fail", (why, r2["summary"], r2["reasons"]))
                self.assertTrue(r2["reasons"]); self.assertTrue(r2["diagnostics"])
                bad = [d for d in r2["diagnostics"] if d["verdict"] == "FAIL"]
                self.assertTrue(bad); self.assertTrue(all(d["command"] and (d["stderr_tail"] or d["stdout_tail"] or d["summary"]) for d in bad))
                self.assertTrue(rep2["sandbox_destroyed"]); self.assertTrue(rep2["source_tree_unchanged"]); self.assert_source_untouched()
                self.assertEqual(VC.gate(res2, VC.subject_of(self.binding, c, cand), registry=self.reg)["per_check"][cid]["status"], "failed")
                self._receipt(cid, "failure", {"why": why, "result": r2["result"], "reasons": r2["reasons"][:3], "failing_jobs": [d["check"] for d in bad], "exit_codes": {d["check"]: d["exit_code"] for d in bad}, "stderr_digests": {d["check"]: d["stderr_digest"] for d in bad}, "source_tree_unchanged": rep2["source_tree_unchanged"], "sandbox_destroyed": rep2["sandbox_destroyed"]})
            # stale / mismatched evidence ----------------------------------------------------------------------------
            with self.subTest(check=cid, case="stale"):
                r = by[cid]
                other = dict(s, patch_hash="sha256:" + "e" * 64)
                d1 = VC.gate([r], other, registry=self.reg)
                self.assertEqual(d1["decision"], "BLOCK"); self.assertEqual(d1["per_check"][cid]["status"], "stale")
                d2 = VC.gate([r], dict(s, base_revision="c" * 40), registry=self.reg)
                self.assertEqual(d2["per_check"][cid]["status"], "stale")
                edited = json.loads(json.dumps(r)); edited["evidence_refs"][0]["ref"] = "sha256:" + "d" * 64  # evidence pointing elsewhere
                d3 = VC.gate([edited], s, registry=self.reg)
                self.assertEqual(d3["per_check"][cid]["status"], "tampered")
                d4 = VC.gate([r], s, registry=self.reg, now="2999-01-01T00:00:00+00:00")
                self.assertEqual(d4["per_check"][cid]["status"], "stale")
                self._receipt(cid, "stale", {"other_patch": d1["per_check"][cid]["status"], "other_revision": d2["per_check"][cid]["status"], "edited_evidence": d3["per_check"][cid]["status"], "expired": d4["per_check"][cid]["status"], "decision_hashes": [d1["decision_hash"], d2["decision_hash"], d3["decision_hash"], d4["decision_hash"]]})
        self.assertGreaterEqual(EL.verify(), self.rows)

    def test_workflow_cannot_reach_approval_over_failure_or_stale_results(self) -> None:
        if not all(self.bound(cid, "gate") for cid in CHECK_IDS):
            self.skipTest("gates not fully declared yet")
        # (a) a failing candidate: WF-08 blocks and WF-10 is unreachable
        d = Driver(self.base / "wf-fail", self.reg)
        d.drive("WF-06")
        d.run.run_step("WF-07", d.inputs_for("WF-07", recipe="test_break_manifest"))
        row = d.run.run_step("WF-08", d.inputs_for("WF-08"))
        self.assertEqual(row["outcome"], "BLOCKED", row); self.assertIn("verification", row["reason"])
        with self.assertRaises(lga.AdapterError) as ctx:  # approval is unreachable: the run is terminal/blocked before any human decision
            d.run.run_step("WF-10", d.inputs_for("WF-10", receipt={}, key=d.key))
        self.assert_source_untouched()
        self._receipt("VERIFY-ALL", "workflow_failure_blocks_approval", {"wf08": row["outcome"], "wf08_reason": row["reason"][:200], "wf10_refused": ctx.exception.code, "run_state": d.run.state})
        # (b) stale results: a pass for another candidate injected before the human decision → WF-10 refuses
        d2 = Driver(self.base / "wf-stale", self.reg)
        d2.drive("WF-09")
        self.assertIn("check_results", d2.run.artifacts); self.assertEqual(d2.run.artifacts["gate_decision"]["decision"], "PROCEED")
        other, opatch = forge(self.cand, self.contract, self.root, self.binding.base_revision, {"Suite04/SHA256SUMS.txt": "abcd  x\n"})
        _, stale = VC.run_checks(self.binding, self.contract, other, opatch, self.sandboxes, registry=self.reg)
        d2.run.artifacts["check_results"] = stale
        row = d2.run.run_step("WF-10", d2.inputs_for("WF-10"))
        self.assertEqual(row["outcome"], "BLOCKED", row); self.assertIn("stale", row["reason"])
        self._receipt("VERIFY-ALL", "workflow_stale_blocks_approval", {"wf10": row["outcome"], "reason": row["reason"][:200], "run_state": d2.run.state})
        self.assertGreaterEqual(EL.verify(), self.rows)

    def test_scenarios_are_well_formed(self) -> None:
        for sid, sc in self.scen.items():
            with self.subTest(scenario=sid):
                self.assertIn(sc["check_id"], self.checks["checks"]); self.assertTrue(sc["receipt_requirements"])
                self.assertEqual(set(sc["fixtures"]), {"passing", "failure", "stale"})


if __name__ == "__main__":
    unittest.main()
