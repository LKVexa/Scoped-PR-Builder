"""Governed workflow tests (Phase 06 / WF-01..12; stdlib unittest).

Registry loads and binds to existing suites; preconditions gate every step (a later state is unreachable until the
prior step SUCCEEDED); every attempt is persisted before and after as chained step records and the run replays from
them (T01); composed executors drive a real fixture repository end to end without synthesizing evidence or
permissions (T02); success predicates and fail-closed routes land failures in their terminal states (T03); structured
events surround every transition and retries are idempotent or newly identified (T04). Layers not yet applied skip.
"""
from __future__ import annotations

import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from adapters import approval_adapter as aa  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import controls as CT  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import workflow as W  # noqa: E402
from test_components import _git, make_repo  # noqa: E402

REPO_ROOT = HERE.parent.parent
D = "sha256:" + "0123456789abcdef" * 4
ROLE = "ScopedPrBuilderWorker"  # the schema-declared analysis role; tests extend its grants with the human-gated effects
ACTOR = {"identity": "operator@example", "role": ROLE}
INTENT = {"kind": "tech_debt_refactor", "title": "Regenerate stale Suite04 SHA256SUMS manifest", "description": "x", "allowed_paths": ["Suite04/SHA256SUMS.txt"], "max_changed_files": 1, "max_diff_lines": 10, "requested_by": "operator@example"}
ORDER = ["WF-01", "WF-02", "WF-03", "WF-04", "WF-05", "WF-06", "WF-07", "WF-08", "WF-09", "WF-10", "WF-11", "WF-12"]


def rule_set(reg, *, grant_all: bool = True):
    rs = copy.deepcopy(reg["contracts"]["policy_layer"]["examples"]["valid"])
    rs["grants"][ROLE] = ["repository.bind", "repository.read", "worktree.isolate", "diff.generate_inert", "verification.run_isolated", "review.render", "ledger.append", "patch.apply_isolated", "rollback.execute"] if grant_all else ["repository.read"]
    rs["require_human_approval"] = ["patch.apply_isolated", "rollback.execute"]
    return rs


class Driver:
    """Drives a WorkflowRun over a fixture repository with the inputs each step needs (human receipts issued through the
    approval adapter with a test key — the only stand-in for a person, and only inside tests)."""

    def __init__(self, base: Path, reg, wf=None, *, repo: Path | None = None) -> None:
        self.base, self.reg = base, reg
        self.wf = wf or W.load_workflow(registry=reg)
        self.repo = repo or make_repo(base)
        self.run_dir = base / "run"
        self.run = W.WorkflowRun(self.run_dir, run_id=lga.sha256_digest(str(self.run_dir)), workflow=self.wf, registry=reg)
        self.key = aa.load_or_create_key(base / "keys" / "approval.key", create=True)

    def inputs_for(self, sid: str, **over):
        base = {"WF-01": {"actor": ACTOR, "rule_set": rule_set(self.reg)}, "WF-02": {"repo": str(self.repo)}, "WF-03": {"intent": INTENT}, "WF-07": {"recipe": "regenerate_sha256sums_manifest"},
                "WF-10": {}, "WF-11": {"key": self.key}, "WF-12": {"reason": {"kind": "rollback", "cause": "test"}}}.get(sid, {})
        if sid == "WF-10" and "receipt" not in over:
            a = self.run.artifacts
            base = {"receipt": json.loads(aa.issue_receipt(self.run_dir, self.key, decision="APPROVE", approver_identity="reviewer@example", approver_channel="test", rationale="ok", candidate=a["candidate"], card=a["review_card"], report=a["verification_report"]).to_json()), "key": self.key}
        base.update(over)
        return base

    def drive(self, upto: str, **over) -> dict:
        row = None
        for sid in ORDER[: ORDER.index(upto) + 1]:
            if sid in self.run.completed:
                continue
            row = self.run.run_step(sid, self.inputs_for(sid, **(over if sid == upto else {})))
            if row["outcome"] != "SUCCEEDED":
                return row
        return row


class Fixture(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.wf = W.load_workflow(registry=self.reg)
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def bound(self, sid: str) -> bool:
        return sid in W._EXEC and sid in self.wf["steps"]


class TestRegistry(Fixture):
    def test_registry_loads_orders_and_binds(self) -> None:
        self.assertEqual(self.wf["computed_hash"], W.load_workflow(registry=self.reg)["computed_hash"])
        orders = sorted(int(s["order"]) for s in self.wf["steps"].values())
        self.assertEqual(orders, list(range(1, len(orders) + 1)))
        for sid, s in self.wf["steps"].items():
            with self.subTest(step=sid):
                for f in s["authoritative_suites"]:
                    self.assertTrue((REPO_ROOT / f).is_file(), f)
                self.assertTrue(s["preconditions"]["run_states"]); self.assertTrue(s["timestamps"]); self.assertTrue(s["terminal_states"])
                self.assertTrue(set(s["preconditions"]["run_states"]) <= set(CT.STATES))
        broken = copy.deepcopy(self.wf); sid = next(iter(broken["steps"]))
        broken["steps"][sid]["run_state_to"] = "APPROVED"; broken["steps"][sid]["run_state_from"] = ["INTAKE"]; broken["steps"][sid].pop("terminal_step", None); broken["steps"][sid].pop("intermediate_states", None)
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump({k: v for k, v in broken.items() if k != "computed_hash"}, f)
        with self.assertRaises(lga.AdapterError) as ctx:
            W.load_workflow(Path(f.name), registry=self.reg)
        self.assertEqual(ctx.exception.code, "workflow.registry_invalid")


class TestStateMachine(Fixture):
    """T01: preconditions, persistence, replay — with synthetic outputs where executors are not yet bound."""

    def _synthetic(self, run: W.WorkflowRun, sid: str) -> dict:
        s = self.wf["steps"][sid]
        att = run.start_step(sid, {})
        outputs = {e: D for e in s["transition_evidence"]}
        return run.finish_step(att, outputs=outputs)

    def test_next_state_unreachable_until_prior_step_succeeds(self) -> None:
        run = W.WorkflowRun(self.base / "run", run_id=D, workflow=self.wf, registry=self.reg)
        steps = [s for s in ORDER if s in self.wf["steps"] and not self.wf["steps"][s].get("terminal_step")]  # the abort/rollback step is reachable from every non-terminal state by design
        self.assertEqual(run.state, "INTAKE")
        self.assertTrue(run.next_state_reachable(steps[0]))
        for later in steps[1:]:
            self.assertFalse(run.next_state_reachable(later), later)
            with self.assertRaises(lga.AdapterError) as ctx:
                run.start_step(later, {})
            self.assertIn(ctx.exception.code, ("workflow.precondition_unmet", "workflow.state_mismatch"))
        with self.assertRaises(lga.AdapterError) as ctx:
            run.start_step("WF-99", {})
        self.assertEqual(ctx.exception.code, "workflow.step_unknown")

    def test_attempts_are_persisted_before_and_after_and_replay(self) -> None:
        if "success_predicate" in self.wf["steps"]["WF-01"]:
            self.skipTest("predicates bound: synthetic outputs no longer satisfy the step (covered by execution tests)")
        run = W.WorkflowRun(self.base / "run", run_id=D, workflow=self.wf, registry=self.reg)
        row = self._synthetic(run, "WF-01")
        self.assertEqual(row["outcome"], "SUCCEEDED"); self.assertEqual(run.state, self.wf["steps"]["WF-01"]["run_state_to"])
        recs = run.records()
        self.assertEqual([r["phase"] for r in recs], ["before", "after"]); self.assertEqual(recs[1]["before_record"], recs[0]["record_hash"])
        self.assertTrue(recs[0]["started_at"] and recs[1]["finished_at"])
        if "WF-02" in self.wf["steps"]:
            att = run.start_step("WF-02", {})
            with self.assertRaises(lga.AdapterError) as ctx:
                run.finish_step(att, outputs={})
            self.assertEqual(ctx.exception.code, "workflow.evidence_missing")
        again = W.WorkflowRun.load(self.base / "run", workflow=self.wf, registry=self.reg)
        self.assertEqual(again.state, run.state); self.assertEqual(sorted(again.completed), sorted(run.completed)); self.assertEqual(again.attempts, run.attempts)

    def test_failed_attempt_preserves_state_and_requires_explicit_retry(self) -> None:
        run = W.WorkflowRun(self.base / "run", run_id=D, workflow=self.wf, registry=self.reg)
        att = run.start_step("WF-01", {})
        row = run.finish_step(att, error=lga.AdapterError("tool.broken", "simulated"))
        self.assertIn(row["outcome"], ("FAILED", "BLOCKED")); self.assertEqual(row["error_code"], "tool.broken"); self.assertEqual(row["inputs_hash"], att["inputs_hash"])
        self.assertNotIn("WF-01", run.completed)
        if run.state not in CT.TERMINAL_STATES:
            with self.assertRaises(lga.AdapterError) as ctx:
                run.start_step("WF-01", {})
            self.assertEqual(ctx.exception.code, "workflow.retry_required")
            att2 = run.start_step("WF-01", {}, retry=True)
            self.assertEqual(att2["attempt_no"], 2)
        again = W.WorkflowRun.load(self.base / "run", workflow=self.wf, registry=self.reg)
        self.assertEqual(again.last_attempt["WF-01"]["error_code"], "tool.broken"); self.assertEqual(again.state, run.state)

    def test_unbound_step_is_not_executable(self) -> None:
        unbound = [s for s in self.wf["steps"] if s not in W._EXEC]
        if not unbound:
            self.skipTest("every step is composed")
        run = W.WorkflowRun(self.base / "run", run_id=D, workflow=self.wf, registry=self.reg)
        with self.assertRaises(lga.AdapterError) as ctx:
            run.run_step(unbound[0], {})
        self.assertEqual(ctx.exception.code, "workflow.step_not_executable")


class TestExecution(Fixture):
    """T02: composed steps over a real fixture; the orchestrator forwards only what it received."""

    def test_end_to_end_then_rollback(self) -> None:
        if not all(self.bound(s) for s in ORDER):
            self.skipTest("not every step is composed yet")
        d = Driver(self.base, self.reg, self.wf)
        row = d.drive("WF-11")
        self.assertEqual(row["outcome"], "SUCCEEDED", row["reason"]); self.assertEqual(d.run.state, "ARCHIVED")
        self.assertEqual([t["to"] for t in row["intermediate_transitions"]], ["APPLIED_ISOLATED"])
        self.assertTrue((d.run_dir / "archive" / "MANIFEST.json").is_file())
        rb = d.run.run_step("WF-12", d.inputs_for("WF-12"))
        self.assertEqual(rb["outcome"], "SUCCEEDED", rb["reason"]); self.assertEqual(d.run.state, "ROLLED_BACK")
        self.assertTrue(rb["outputs"]["rollback_proof"]["rollback_hash"])
        with self.assertRaises(lga.AdapterError) as ctx:
            d.run.start_step("WF-01", {}, retry=True)
        self.assertEqual(ctx.exception.code, "workflow.terminal")
        again = W.WorkflowRun.load(d.run_dir, workflow=self.wf, registry=self.reg)
        self.assertEqual(again.state, "ROLLED_BACK"); self.assertEqual(len(again.completed), 12)

    def test_no_synthesized_permissions_or_decisions(self) -> None:
        if not self.bound("WF-01"):
            self.skipTest("WF-01 not composed")
        d = Driver(self.base, self.reg, self.wf)
        row = d.run.run_step("WF-01", d.inputs_for("WF-01", rule_set=rule_set(self.reg, grant_all=False)))
        self.assertNotEqual(row["outcome"], "SUCCEEDED"); self.assertEqual(row["error_code"], "authority.denied")
        d2 = Driver(self.base / "two", self.reg, self.wf)
        ok = d2.run.run_step("WF-01", d2.inputs_for("WF-01"))
        self.assertEqual(ok["outcome"], "SUCCEEDED")
        auth = d2.run.artifacts["authority"]
        self.assertNotIn("patch.apply_isolated", auth["granted_effects"]); self.assertTrue(all(x["decided_now"] == "deny" for x in auth["deferred"]))
        if all(self.bound(s) for s in ORDER[:10]):
            d2.drive("WF-09")
            self.assertEqual(d2.run.state, "REVIEW_PENDING")
            row = d2.run.run_step("WF-10", {})
            self.assertNotEqual(row["outcome"], "SUCCEEDED"); self.assertEqual(row["error_code"], "workflow.human_decision_required")
            self.assertFalse(d2.run.next_state_reachable("WF-11"))

    def test_steps_refuse_out_of_order(self) -> None:
        if not all(self.bound(s) for s in ORDER[:3]):
            self.skipTest("WF-01..03 not composed")
        d = Driver(self.base, self.reg, self.wf)
        with self.assertRaises(lga.AdapterError) as ctx:
            d.run.run_step("WF-02", d.inputs_for("WF-02"))
        self.assertEqual(ctx.exception.code, "workflow.precondition_unmet")
        d.drive("WF-02")
        self.assertEqual(d.run.state, "BOUND")
        self.assertFalse(d.run.next_state_reachable("WF-04"))


class TestRoutes(Fixture):
    """T03: predicates and fail-closed routes."""

    def setUp(self) -> None:
        super().setUp()
        if not any("routes" in s for s in self.wf["steps"].values()):
            self.skipTest("routes not yet declared")

    def test_classification_covers_the_seven_kinds(self) -> None:
        self.assertEqual(W.classify_failure("authority.denied"), "authorization_failure"); self.assertEqual(W.classify_failure("freshness.stale"), "stale_context")
        self.assertEqual(W.classify_failure("plan.abstain"), "insufficient_evidence"); self.assertEqual(W.classify_failure("patch.too_large"), "tool_failure")
        self.assertEqual(W.classify_failure("verification.failed"), "verification_failure"); self.assertEqual(W.classify_failure("workflow.cancelled"), "cancellation"); self.assertEqual(W.classify_failure("component.timeout"), "timeout")
        for sid, s in self.wf["steps"].items():
            if "routes" in s:
                with self.subTest(step=sid):
                    self.assertEqual(set(s["routes"]), set(W.FAILURE_KINDS)); self.assertTrue(s["success_predicate"]["statement"])

    def test_authorization_failure_blocks(self) -> None:
        if not self.bound("WF-01") or "routes" not in self.wf["steps"]["WF-01"]:
            self.skipTest("WF-01 routes not declared")
        d = Driver(self.base, self.reg, self.wf)
        row = d.run.run_step("WF-01", d.inputs_for("WF-01", rule_set=rule_set(self.reg, grant_all=False)))
        self.assertEqual(row["outcome"], "BLOCKED"); self.assertEqual(d.run.state, "BLOCKED"); self.assertEqual(row["route"], "BLOCKED")

    def test_insufficient_evidence_abstains_and_stale_context_blocks(self) -> None:
        if not all(self.bound(s) for s in ORDER[:8]) or "routes" not in self.wf["steps"]["WF-06"] or "routes" not in self.wf["steps"]["WF-08"]:
            self.skipTest("WF-06/WF-08 routes not declared")
        d = Driver(self.base, self.reg, self.wf)
        (d.repo / "zzqx.md").write_text("zzqx qqwe\n"); _git(d.repo, "add", "-A"); _git(d.repo, "commit", "-q", "-m", "lonely")  # no token of this file occurs anywhere else: zero analogous examples
        for sid in ORDER[:5]:
            r = d.run.run_step(sid, d.inputs_for(sid) if sid != "WF-03" else {"intent": dict(INTENT, allowed_paths=["zzqx.md"], title="zzqx", description="qqwe")})
            self.assertEqual(r["outcome"], "SUCCEEDED", r["reason"])
        row = d.run.run_step("WF-06", {})
        self.assertEqual(row["outcome"], "ABSTAINED", row["reason"]); self.assertEqual(d.run.state, "ABSTAINED")
        d2 = Driver(self.base / "two", self.reg, self.wf)
        d2.drive("WF-07")
        (d2.repo / "Suite01" / "01_demo.jad").write_text("moved\n"); _git(d2.repo, "add", "-A"); _git(d2.repo, "commit", "-q", "-m", "moved")
        row = d2.run.run_step("WF-08", {})
        self.assertEqual(row["outcome"], "BLOCKED", row["reason"]); self.assertEqual(W.classify_failure(row["error_code"]), "stale_context")

    def test_tool_failure_retries_then_blocks_and_cancellation_cancels(self) -> None:
        if not all(self.bound(s) for s in ORDER[:4]) or "routes" not in self.wf["steps"]["WF-04"] or "routes" not in self.wf["steps"]["WF-12"]:
            self.skipTest("WF-04/WF-12 routes not declared")
        d = Driver(self.base, self.reg, self.wf)
        d.drive("WF-03")
        real = W._EXEC["WF-04"]
        W._EXEC["WF-04"] = lambda run, inputs: (_ for _ in ()).throw(W.WorkflowRefusal("component.timeout", "simulated"))
        try:
            first = d.run.run_step("WF-04", {})
            self.assertEqual(first["outcome"], "TIMEOUT"); self.assertEqual(d.run.state, "INTENT_ACCEPTED"); self.assertIsNone(first["route"])
            budget = int(self.wf["steps"]["WF-04"].get("max_attempts", 1))
            last = first
            for _ in range(budget - 1):
                last = d.run.run_step("WF-04", {}, retry=True)
            self.assertEqual(last["outcome"], "BLOCKED"); self.assertEqual(d.run.state, "BLOCKED")
        finally:
            W._EXEC["WF-04"] = real
        d2 = Driver(self.base / "two", self.reg, self.wf)
        d2.drive("WF-02")
        row = d2.run.run_step("WF-12", {"reason": {"kind": "abort", "cause": "operator cancelled", "code": "workflow.cancelled"}})
        self.assertEqual(row["outcome"], "CANCELLED"); self.assertEqual(d2.run.state, "CANCELLED")
        self.assertTrue(json.loads((d2.run_dir / "workflow" / "abort.json").read_text())["checkpoint"]["intact"])


class TestEvents(Fixture):
    """T04: structured events around every transition; idempotent replay vs new attempt identity."""

    def setUp(self) -> None:
        super().setUp()
        if not hasattr(W.WorkflowRun, "events"):
            self.skipTest("events layer not yet present")

    def test_events_surround_every_transition(self) -> None:
        if not all(self.bound(s) for s in ORDER[:3]):
            self.skipTest("WF-01..03 not composed")
        d = Driver(self.base, self.reg, self.wf)
        d.drive("WF-03")
        ev = d.run.events()
        self.assertTrue(ev)
        for sid in ORDER[:3]:
            kinds = [e["kind"] for e in ev if e["payload"].get("step_id") == sid]
            self.assertEqual(kinds[:3], ["runtime.step_started", "evidence.inputs", "provenance.attempt"], sid)
            self.assertEqual(kinds[-4:], ["evidence.outputs", "decision.outcome", "provenance.link", "runtime.step_finished"], sid)
        self.assertEqual({e["category"] for e in ev}, set(W.EVENT_CATEGORIES))
        links = [e for e in ev if e["kind"] == "provenance.link"]
        recs = {r["record_hash"] for r in d.run.records()}
        self.assertTrue(all(l["payload"]["before_record"] in recs and l["payload"]["after_record"] in recs for l in links))

    def test_retry_identity_is_idempotent_or_new(self) -> None:
        if not self.bound("WF-01"):
            self.skipTest("WF-01 not composed")
        d = Driver(self.base, self.reg, self.wf)
        real = W._EXEC["WF-01"]
        W._EXEC["WF-01"] = lambda run, inputs: (_ for _ in ()).throw(W.WorkflowRefusal("component.failed", "simulated"))
        try:
            first = d.run.run_step("WF-01", d.inputs_for("WF-01"))
        finally:
            W._EXEC["WF-01"] = real
        if d.run.state in CT.TERMINAL_STATES:
            self.skipTest("route terminal on first failure; identity semantics covered on a retryable step")
        mode = (self.wf["steps"]["WF-01"].get("idempotency") or {}).get("mode")
        second = d.run.run_step("WF-01", d.inputs_for("WF-01"), retry=True)
        self.assertEqual(second["attempt_no"], 2); self.assertEqual(second["replay_of"], first["attempt_id"])
        if mode == "idempotent_replay":
            self.assertEqual(second["attempt_id"], first["attempt_id"])
        else:
            self.assertNotEqual(second["attempt_id"], first["attempt_id"])
        self.assertEqual(second["outcome"], "SUCCEEDED")
        for sid, s in self.wf["steps"].items():
            if "idempotency" in s:
                self.assertIn(s["idempotency"]["mode"], ("idempotent_replay", "new_attempt"), sid)


if __name__ == "__main__":
    unittest.main()
