"""Authorized data intake tests (Phase 04 / DATA-01..07; stdlib unittest).

Every declared source: contract loads and binds to existing suites; admission from a pinned binding yields an
explicit state; excluded paths are never read; denied scope, stale binding, partial history, conflicting and
malformed material each land in their state and route to abstention/review; provenance and freshness are on every
item and every derived record; fixtures archive evidence receipts on the test/evidence ledger.
"""
from __future__ import annotations

import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from adapters import contracts as C  # noqa: E402
from adapters import intake as I  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402

REPO_ROOT = HERE.parent.parent
READ = ["repository.read"]


def _git(cwd: Path, *args: str) -> str:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t",
           "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z", "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z"}
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=True, env=env).stdout.strip()


def make_repo(base: Path, *, exports: bool = True, owners: int = 1, conflicting_manifests: bool = False, secrets: bool = True, conflicting_adrs: bool = False, duplicate_exports: bool = False) -> Path:
    root = base / "repo"; root.mkdir(parents=True)
    _git(root, "init", "-q")
    (root / "src").mkdir(); (root / "tests").mkdir(); (root / "docs" / "adr").mkdir(parents=True); (root / ".github").mkdir()
    (root / "src" / "app.py").write_text("def main():\n    return 1\n")
    (root / "src" / "core.ja").write_text("ja source 0.3\nmodule demo.core\nemit json demo\n")
    (root / "tests" / "test_app.py").write_text("import unittest\nclass T(unittest.TestCase):\n    def test_a(self):\n        self.assertTrue(True)\n")
    (root / "tests" / "conftest.py").write_text("# helpers\n")
    (root / "docs" / "adr" / "0001-record-architecture-decisions.md").write_text("# ADR 1\nWe record decisions.\n")
    if conflicting_adrs:
        (root / "docs" / "adr" / "0001-use-a-different-store.md").write_text("# ADR 1 (again)\nContradicts the other ADR 1.\n")
    (root / "README.md").write_text("# Demo\n")
    (root / "requirements.txt").write_text("requests==2.31.0\npyyaml>=6\n")
    (root / "package.json").write_text(json.dumps({"name": "demo", "dependencies": {"left-pad": "1.3.0", **({"requests": "2.30.0"} if conflicting_manifests else {})}}))
    if secrets:
        (root / ".env").write_text("TOKEN=should-never-be-read\n")
        (root / "src" / "id_rsa").write_text("PRIVATE KEY MATERIAL\n")
    (root / "CODEOWNERS").write_text("* @owner-team\nsrc/ @core-team\n")
    if owners > 1:
        (root / ".github" / "CODEOWNERS").write_text("* @other-team\n")
    if exports:
        (root / ".spb-intake").mkdir()
        pr = json.dumps({"id": 1, "title": "Add core", "state": "merged", "reviews": [{"by": "r1", "decision": "approved", "comment": "lgtm"}]}) + "\n"
        issue = json.dumps({"id": 7, "title": "Manifest stale", "state": "open", "labels": ["bug"]}) + "\n"
        (root / ".spb-intake" / "pull-requests.jsonl").write_text(pr * (2 if duplicate_exports else 1))
        (root / ".spb-intake" / "issues.jsonl").write_text(issue * (2 if duplicate_exports else 1))
    _git(root, "add", "-A"); _git(root, "commit", "-q", "-m", "c1")
    (root / "src" / "app.py").write_text("def main():\n    return 2\n")
    _git(root, "add", "-A"); _git(root, "commit", "-q", "-m", "c2")
    return root


class Fixture(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.sources = I.load_sources()
        self.tmp = tempfile.TemporaryDirectory()
        self.root = make_repo(Path(self.tmp.name))
        self.binding = lga.bind_repository(self.root)

    def tearDown(self) -> None:
        self.tmp.cleanup()


class TestContracts(Fixture):
    def test_registry_loads_binds_and_is_read_only(self) -> None:
        self.assertEqual(self.sources["computed_hash"], I.load_sources()["computed_hash"])
        for sid, s in self.sources["sources"].items():
            with self.subTest(source=sid):
                for f in s["authoritative_suites"]:
                    self.assertTrue((REPO_ROOT / f).is_file(), f)
                self.assertTrue(all(e.startswith(("repository.read", "artifact.read", "ledger.read")) for e in s["permission_scope"]))
                self.assertTrue(s["exclusion_rules"]["path_patterns"]); self.assertGreater(s["size_caps"]["max_item_bytes"], 0)
                self.assertEqual(set(s["states"]), set(I.STATES))

    def test_unknown_source_and_unbound_suite_fail_closed(self) -> None:
        with self.assertRaises(lga.AdapterError) as ctx:
            I.admit("DATA-99", self.binding, granted_effects=READ, sources=self.sources, registry=self.reg)
        self.assertEqual(ctx.exception.code, "intake.unknown_source")
        broken = copy.deepcopy(self.sources); sid = next(iter(broken["sources"]))
        broken["sources"][sid]["authoritative_suites"][0] = "Nope/99.jad"
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump({k: v for k, v in broken.items() if k != "computed_hash"}, f)
        with self.assertRaises(lga.AdapterError) as ctx:
            I.load_sources(Path(f.name))
        self.assertEqual(ctx.exception.code, "intake.suite_unbound")

    def test_denied_scope_reads_nothing(self) -> None:
        for sid in self.sources["sources"]:
            with self.subTest(source=sid):
                rec = I.admit(sid, self.binding, granted_effects=["artifact.read"], sources=self.sources, registry=self.reg)
                self.assertEqual(rec["state"], "DENIED"); self.assertEqual(rec["items"], []); self.assertIn("permission", rec["reason"])
                self.assertRegex(rec["intake_hash"], r"^sha256:[0-9a-f]{64}$")


class TestCollectors(Fixture):
    def _bound(self, sid):
        return sid in I.COLLECTORS and "binding" in self.sources["sources"][sid]

    def test_data01_tree_and_history(self) -> None:
        if not self._bound("DATA-01"):
            self.skipTest("DATA-01 collector not bound")
        rec = I.admit("DATA-01", self.binding, granted_effects=READ, sources=self.sources, registry=self.reg)
        self.assertEqual(rec["state"], "ADMITTED", rec["reason"])
        paths = {i["canonical_path"] for i in rec["items"] if i["kind"] == "source_blob"}
        self.assertIn("src/app.py", paths); self.assertNotIn(".env", paths); self.assertNotIn("src/id_rsa", paths)
        self.assertTrue(any(e["canonical_path"] == ".env" for e in rec["excluded"]))
        self.assertEqual(rec["history"]["reachable_commits"], 2); self.assertTrue(rec["history"]["complete"])
        self.assertEqual(sum(1 for i in rec["items"] if i["kind"] == "commit"), 2)

    def test_data02_manifests_and_conflicts(self) -> None:
        if not self._bound("DATA-02"):
            self.skipTest("DATA-02 collector not bound")
        rec = I.admit("DATA-02", self.binding, granted_effects=READ, sources=self.sources, registry=self.reg)
        self.assertEqual(rec["state"], "ADMITTED", rec["reason"])
        deps = {k for i in rec["items"] for k in i.get("dependencies", {})}
        self.assertTrue({"requests", "pyyaml", "left-pad"} <= deps)
        with tempfile.TemporaryDirectory() as t2:
            root = make_repo(Path(t2), conflicting_manifests=True)
            rec2 = I.admit("DATA-02", lga.bind_repository(root), granted_effects=READ, sources=self.sources, registry=self.reg)
            self.assertEqual(rec2["state"], "CONFLICTING"); self.assertIn("requests", rec2["reason"])

    def test_data03_tests(self) -> None:
        if not self._bound("DATA-03"):
            self.skipTest("DATA-03 collector not bound")
        rec = I.admit("DATA-03", self.binding, granted_effects=READ, sources=self.sources, registry=self.reg)
        self.assertEqual(rec["state"], "ADMITTED"); self.assertEqual(rec["tests"]["modules"], 1); self.assertEqual(rec["tests"]["helpers"], 1)

    def test_data04_and_data06_exports(self) -> None:
        for sid, kind in (("DATA-04", "pull_request"), ("DATA-06", "issue")):
            if not self._bound(sid):
                continue
            with self.subTest(source=sid):
                rec = I.admit(sid, self.binding, granted_effects=READ, sources=self.sources, registry=self.reg)
                self.assertEqual(rec["state"], "ADMITTED", rec["reason"]); self.assertEqual(rec["items"][0]["kind"], kind)
                with tempfile.TemporaryDirectory() as t2:
                    root = make_repo(Path(t2), exports=False)
                    rec2 = I.admit(sid, lga.bind_repository(root), granted_effects=READ, sources=self.sources, registry=self.reg)
                    self.assertEqual(rec2["state"], "UNAVAILABLE"); self.assertIn("not empty", rec2["reason"]); self.assertEqual(rec2["items"], [])
                    export = root / self.sources["sources"][sid]["identity"]["export_path"]
                    export.parent.mkdir(parents=True, exist_ok=True); export.write_text("{not json\n"); _git(root, "add", "-A"); _git(root, "commit", "-q", "-m", "bad export")
                    rec3 = I.admit(sid, lga.bind_repository(root), granted_effects=READ, sources=self.sources, registry=self.reg)
                    self.assertEqual(rec3["state"], "MALFORMED")
                    rec4 = I.admit(sid, lga.bind_repository(make_repo(Path(t2) / "dup", duplicate_exports=True)), granted_effects=READ, sources=self.sources, registry=self.reg)
                    self.assertEqual(rec4["state"], "CONFLICTING"); self.assertIn("duplicate", rec4["reason"])

    def test_data05_docs(self) -> None:
        if not self._bound("DATA-05"):
            self.skipTest("DATA-05 collector not bound")
        rec = I.admit("DATA-05", self.binding, granted_effects=READ, sources=self.sources, registry=self.reg)
        self.assertEqual(rec["state"], "ADMITTED"); self.assertEqual(rec["docs"]["adr"], 1); self.assertGreaterEqual(rec["docs"]["documentation"], 1)
        with tempfile.TemporaryDirectory() as t2:
            rec2 = I.admit("DATA-05", lga.bind_repository(make_repo(Path(t2), conflicting_adrs=True)), granted_effects=READ, sources=self.sources, registry=self.reg)
            self.assertEqual(rec2["state"], "CONFLICTING"); self.assertIn("0001", rec2["reason"])

    def test_data07_ownership_and_conflict(self) -> None:
        if not self._bound("DATA-07"):
            self.skipTest("DATA-07 collector not bound")
        rec = I.admit("DATA-07", self.binding, granted_effects=READ, sources=self.sources, registry=self.reg)
        self.assertEqual(rec["state"], "ADMITTED"); self.assertEqual(len(rec["ownership"]["rules"]), 2)
        with tempfile.TemporaryDirectory() as t2:
            root = make_repo(Path(t2), owners=2)
            rec2 = I.admit("DATA-07", lga.bind_repository(root), granted_effects=READ, sources=self.sources, registry=self.reg)
            self.assertEqual(rec2["state"], "CONFLICTING")


class TestProvenance(Fixture):
    def test_pin_before_index_and_stamped_items(self) -> None:
        if not hasattr(I, "pin"):
            self.skipTest("provenance layer not yet present")
        bound = [sid for sid in self.sources["sources"] if sid in I.COLLECTORS and self.sources["sources"][sid].get("provenance")]
        if not bound:
            self.skipTest("no source carries the provenance block yet")
        for sid in bound:
            with self.subTest(source=sid):
                rec = I.admit(sid, self.binding, granted_effects=READ, sources=self.sources, registry=self.reg)
                self.assertEqual(rec["pin"]["base_revision"], self.binding.base_revision); self.assertTrue(rec["pin"]["git_tree"].startswith("git-tree:"))
                for it in rec["items"]:
                    self.assertEqual(it["provenance_ref"], rec["pin"]["pin_hash"]); self.assertEqual(it["freshness_status"], "fresh"); self.assertEqual(it["base_revision"], self.binding.base_revision)
                if rec["items"]:
                    d = I.derive(rec, rec["items"][0], "index_entry", {"tokens": 3})
                    self.assertEqual(d["intake_ref"], rec["intake_hash"]); self.assertEqual(d["provenance_ref"], rec["pin"]["pin_hash"]); self.assertRegex(d["derived_hash"], r"^sha256:")
                    with self.assertRaises(lga.AdapterError):
                        I.derive(rec, dict(rec["items"][0], provenance_ref=None), "index_entry", {})

    def test_stale_binding_yields_stale_and_nothing_derives(self) -> None:
        if not hasattr(I, "pin"):
            self.skipTest("provenance layer not yet present")
        (self.root / "src" / "app.py").write_text("def main():\n    return 3\n"); _git(self.root, "add", "-A"); _git(self.root, "commit", "-q", "-m", "c3")
        rec = I.admit("DATA-01", self.binding, granted_effects=READ, sources=self.sources, registry=self.reg)
        self.assertEqual(rec["state"], "STALE"); self.assertEqual(rec["items"], [])
        with self.assertRaises(lga.AdapterError) as ctx:
            I.derive(rec, {}, "index_entry", {})
        self.assertEqual(ctx.exception.code, "intake.not_admitted")

    def test_pin_mismatch_fails_closed(self) -> None:
        if not hasattr(I, "verify_pin"):
            self.skipTest("provenance layer not yet present")
        p = I.pin(self.binding, self.root)
        I.verify_pin(p, self.binding, self.root)
        with self.assertRaises(lga.AdapterError) as ctx:
            I.verify_pin(dict(p, git_tree="git-tree:" + "0" * 40), self.binding, self.root)
        self.assertEqual(ctx.exception.code, "intake.pin_mismatch")


class TestRouting(Fixture):
    def test_every_state_routes_explicitly(self) -> None:
        if not hasattr(I, "route"):
            self.skipTest("routing layer not yet present")
        for state in I.STATES:
            r = I.route({"source_id": "DATA-01", "state": state, "reason": "", "intake_hash": "sha256:" + "1" * 64})
            self.assertEqual(r["route"], I.ROUTES[state]); self.assertEqual(r["may_infer"], state == "ADMITTED"); self.assertTrue(r["reason"] or state == "ADMITTED")
        with self.assertRaises(lga.AdapterError):
            I.route({"source_id": "DATA-01", "state": "GUESSED"})

    def test_require_admitted_abstains_or_surfaces(self) -> None:
        if not hasattr(I, "require_admitted"):
            self.skipTest("routing layer not yet present")
        records = I.admit_all(self.binding, granted_effects=READ, sources=self.sources, registry=self.reg)
        handled = [sid for sid, r in self.sources["sources"].items() if r.get("handling")]
        if not handled:
            self.skipTest("no source declares handling yet")
        self.assertEqual(I.require_admitted(records, handled), [])
        denied = dict(records, **{handled[0]: I.admit(handled[0], self.binding, granted_effects=[], sources=self.sources, registry=self.reg)})
        with self.assertRaises(lga.AdapterError) as ctx:
            I.require_admitted(denied, handled)
        self.assertEqual(ctx.exception.code, "intake.denied")
        with self.assertRaises(lga.AdapterError) as ctx:
            I.require_admitted({}, handled)
        self.assertEqual(ctx.exception.code, "intake.missing")
        with tempfile.TemporaryDirectory() as t2:
            root = make_repo(Path(t2), exports=False, owners=2)
            recs = I.admit_all(lga.bind_repository(root), granted_effects=READ, sources=self.sources, registry=self.reg)
            reviews = I.require_admitted(recs, handled)
            self.assertTrue({r["source_id"] for r in reviews} >= ({"DATA-04", "DATA-06", "DATA-07"} & set(handled)))
            frag = I.review_fragment(recs)
            self.assertEqual(frag["authority"], "display_only"); self.assertTrue(set(frag["needs_review"]) >= ({"DATA-04", "DATA-06", "DATA-07"} & set(handled)))
            html = I.render_fragment_html(frag, lambda v: str(v).replace("<", "&lt;"))
            self.assertIn("Evidence intake", html)


if __name__ == "__main__":
    unittest.main()
