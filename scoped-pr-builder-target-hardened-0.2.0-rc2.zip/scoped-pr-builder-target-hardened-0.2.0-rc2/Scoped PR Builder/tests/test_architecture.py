"""Data-driven tests for the architecture boundary registry (stdlib unittest).

Every declared boundary must bind to suite files that exist, reference registered
contracts, admit its passing crossing, and refuse every violating crossing with the
exact code recorded in the registry.
"""
from __future__ import annotations

import copy
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import architecture as A  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402


class TestBoundaries(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.b = A.load_boundaries(registry=self.reg)

    def test_registry_binds_to_existing_suites(self) -> None:
        for bid, e in self.b["boundaries"].items():
            with self.subTest(boundary=bid):
                self.assertTrue(e["authoritative_suites"])
                for s in e["authoritative_suites"]:
                    self.assertTrue((A.REPO_ROOT / s["file"]).is_file(), s["file"])
                self.assertIn(e["trust_level"], A.TRUST_LEVELS)
                self.assertEqual(e["failure_behavior"]["mode"], "fail_closed")

    def test_every_boundary_admits_and_refuses(self) -> None:
        for bid, e in self.b["boundaries"].items():
            with self.subTest(boundary=bid):
                r = A.check_crossing(e["examples"]["valid"], boundaries=self.b, registry=self.reg)
                self.assertEqual(r["verdict"], "ADMITTED")
                self.assertEqual(r["boundary_id"], bid)
                for i, bad in enumerate(e["examples"]["invalid"]):
                    with self.subTest(boundary=bid, invalid=i):
                        with self.assertRaises(lga.AdapterError) as ctx:
                            A.check_crossing(bad["message"], boundaries=self.b, registry=self.reg)
                        self.assertEqual(ctx.exception.code, bad["expect_code"], f"{bid} invalid[{i}] ({bad.get('why')}): {ctx.exception}")

    def test_generic_refusals(self) -> None:
        bid, e = next(iter(self.b["boundaries"].items()))
        good = e["examples"]["valid"]
        with self.assertRaises(lga.AdapterError) as ctx:
            A.check_crossing(dict(good, boundary_id="no_such_boundary"), boundaries=self.b, registry=self.reg)
        self.assertEqual(ctx.exception.code, "boundary.unknown")
        m = copy.deepcopy(good); m.pop("identity")
        with self.assertRaises(lga.AdapterError) as ctx:
            A.check_crossing(m, boundaries=self.b, registry=self.reg)
        self.assertEqual(ctx.exception.code, "boundary.identity_missing")
        m = copy.deepcopy(good); m["identity"]["base_revision"] = "HEAD"
        with self.assertRaises(lga.AdapterError) as ctx:
            A.check_crossing(m, boundaries=self.b, registry=self.reg)
        self.assertEqual(ctx.exception.code, "boundary.identity_invalid")

    def test_unbound_suite_fails_closed(self) -> None:
        broken = copy.deepcopy(self.b)
        bid = next(iter(broken["boundaries"]))
        broken["boundaries"][bid]["authoritative_suites"][0]["file"] = "Nope/99_missing.jad"
        import json, tempfile
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump({k: v for k, v in broken.items() if k != "computed_hash"}, f)
        with self.assertRaises(lga.AdapterError) as ctx:
            A.load_boundaries(Path(f.name), registry=self.reg)
        self.assertEqual(ctx.exception.code, "boundary.suite_unbound")


if __name__ == "__main__":
    unittest.main()
