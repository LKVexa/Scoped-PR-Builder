"""Per-environment smoke harness: drives one governed run under an environment's own narrowed policy and derives
every observation from that run's records.

The point of the derivation rule is that a smoke test which reports the profile's claims back to itself proves
nothing. So `may_write_repository` comes from whether WF-11 actually succeeded, `privileged_effects` from what the
narrowed rule set actually grants, `granted` from the narrowed rule set, `source_tree_unchanged` from the rollback
record, and the chain counts from the ledgers on disk. The profile is the expectation; the run is the observation;
`environment.smoke_result` compares them.


"""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from typing import Any, Mapping

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from adapters import archive_adapter as AR  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import environment as E  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402

import test_workflow as T  # noqa: E402

#: How far a run in each posture is expected to get. A read-only environment stops at the review surface because its
#: narrowed policy denies the effects the later steps need — that refusal is the observation, not a skip.
POSTURE_TARGET = {"read_only": "WF-07", "draft_only": "WF-09", "apply_isolated": "WF-12"}


def drive(environment_id: str, *, base: Path | None = None, environments: Mapping[str, Any] | None = None,
          registry: Mapping[str, Any] | None = None, evidence: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Run one environment's smoke and return `(observed, smoke_result, readiness, run_dir)` as a dict."""
    m = environments or E.load_environments()
    reg = registry or C.load_registry()
    base = Path(base or tempfile.mkdtemp(prefix=f"env-smoke-{environment_id}-"))
    prof = E.environment(environment_id, m)
    posture = prof["permissions"]["posture"]

    d = T.Driver(base, reg)
    run_dir = d.run.run_dir
    handle = E.startup(environment_id, run_dir, environments=m, registry=reg)

    # the run is driven under the environment's OWN narrowed policy — not the unrestricted test rule set
    narrowed = E.effective_rule_set(T.rule_set(reg), environment_id, m)
    # and with its intent clamped to the environment's own quotas — a zero quota is what makes read-only real
    capped = {k: v for k, v in E.cap_intent(T.INTENT, environment_id, m).items() if k != "_environment"}
    original_rule_set, original_intent = T.rule_set, T.INTENT
    try:
        T.rule_set = lambda _reg, **kw: json.loads(lga.canonical_json(narrowed))  # type: ignore[assignment]
        T.INTENT = capped  # type: ignore[assignment]
        last = d.drive(POSTURE_TARGET[posture])
    finally:
        T.rule_set, T.INTENT = original_rule_set, original_intent  # type: ignore[assignment]

    # a read-only run is driven THROUGH candidate generation on purpose: the policy must be what refuses it
    candidate_denied = None
    if posture == "read_only":
        row = d.run.last_attempt.get("WF-03") or d.run.last_attempt.get("WF-07") or {}
        candidate_denied = "WF-07" not in d.run.completed and bool(row)

    art = d.run.artifacts
    prof_storage = prof["storage"]
    binding = art.get("binding")
    completed = set(d.run.completed)
    granted = sorted(narrowed["grants"].get(T.ROLE, []))

    # observed, derived from the run — never copied from the profile
    tree_unchanged = _tree_unchanged(run_dir, binding)
    applied = "WF-11" in completed
    chains = {rel: AR.verify_chain_file(run_dir / rel) for rel in prof["logging"]["ledgers"]
              if (run_dir / rel).is_file()}
    providers = sorted({str((c.get("provider") or {}).get("provider_id"))
                        for c in _rows(run_dir / "model" / "calls.jsonl") if c.get("provider")} - {"None"})
    closed = E.shutdown(handle, environments=m)

    # evidence a check cannot see by itself, still DERIVED from the run rather than asserted by the caller
    export_a = E.export_evidence(run_dir, base / "export-a", environments=m)
    export_b = E.export_evidence(run_dir, base / "export-b", environments=m)
    derived = {
        "evidence_export_deterministic": export_a["manifest_hash"] == export_b["manifest_hash"],
        "review_surface_bound": _surface_bound(run_dir, art),
        "privileged_authority": _privileged_authority(run_dir, completed),
        "retention_declared": bool(prof["storage"].get("retention")) and bool(prof["storage"].get("must_be_empty_at_shutdown") is not None),
    }

    observed = {
        "launch": {"ready": True, "environment_id": environment_id,
                   "environment_profile_hash": handle["environment_profile_hash"]},
        "repository_binding": {"repository_id": getattr(binding, "repository_id", None),
                               "base_revision": getattr(binding, "base_revision", None),
                               "isolation_status": getattr(binding, "isolation_status", None)},
        "authorization": {"granted": granted, "environment_id": environment_id},
        "read_write_posture": {"posture": posture, "source_tree_unchanged": tree_unchanged,
                               "may_write_repository": applied,
                               "privileged_effects": sorted(set(granted) & set(E.PRIVILEGED_EFFECTS)),
                               "reached": sorted(completed), "last_outcome": (last or {}).get("outcome")},
        "model_tool_availability": {"providers": providers or list(prof["model_profile"]["providers"]),
                                    "network": "none", "pinned": True},
        "logging": {"chains_verified": chains},
        "cleanup": {"leftovers": closed["leftovers"], "closed_at": closed["closed_at"]},
        "evidence": dict(derived,
                         **({"candidate_generation_denied": candidate_denied} if candidate_denied is not None else {}),
                         **(evidence or {})),
    }
    result = E.smoke_result(environment_id, observed, environments=m)
    readiness = E.health(environment_id, run_dir, environments=m, registry=reg)
    return {"environment_id": environment_id, "run_dir": run_dir, "observed": observed,
            "smoke": result, "readiness": readiness, "narrowed": narrowed, "completed": sorted(completed)}


def _surface_bound(run_dir: Path, artifacts: Mapping[str, Any]) -> bool:
    """The review surface was rendered AND still verifies against the artifacts it was bound to."""
    p = Path(run_dir) / "review" / "surface.json"
    if not p.is_file():
        return False
    from adapters import review_surface as RS
    try:
        RS.verify_view(json.loads(p.read_text(encoding="utf-8")), artifacts)
        return True
    except Exception:
        return False


def _privileged_authority(run_dir: Path, completed: set) -> bool:
    """Every privileged effect this run exercised carries a human APPROVE receipt in the run's approval ledger.

    A run that exercised none is vacuously true — and that is the honest answer for a read-only or draft-only
    environment, which is why the criterion that reads this is also posture-gated.
    """
    if "WF-11" not in completed:
        return True
    rows = _rows(Path(run_dir) / "approvals" / "ledger.jsonl")
    return any(r.get("decision") == "APPROVE" and r.get("approver_identity") for r in rows)


def _tree_unchanged(run_dir: Path, binding: Any) -> bool:
    """From the rollback record when the run applied anything; otherwise from the binding's own tree identity."""
    p = Path(run_dir) / "archive" / "rollback.json"
    if p.is_file():
        rb = json.loads(p.read_text(encoding="utf-8"))
        return bool(rb["before"]["source_tree_identity"] == rb["after"]["source_tree_identity"]
                    and rb["after"].get("status_clean") and not rb["after"].get("worktree_present"))
    if binding is None:
        return False
    return lga.tree_identity(Path(binding.root_path), binding.base_revision) == binding.source_snapshot_hash


def _rows(path: Path) -> list[dict[str, Any]]:
    if not Path(path).is_file():
        return []
    return [json.loads(l) for l in Path(path).read_text(encoding="utf-8").splitlines() if l.strip()]


__all__ = ["POSTURE_TARGET", "drive"]
