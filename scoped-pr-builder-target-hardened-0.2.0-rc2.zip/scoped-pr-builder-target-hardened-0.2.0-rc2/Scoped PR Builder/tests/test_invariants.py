"""Platform invariants: the registry is complete, every invariant is enforced by a resolvable callable, and every
result is a contract-valid, replayable record derived from a real run (T01–T03).

The suite drives one governed run to completion and evaluates all 56 invariants against the records that run wrote.
Nothing here asserts an invariant by declaring it: an invariant is satisfied only when the run's own ledgers say so.
"""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from adapters import contracts as C  # noqa: E402
from adapters import invariants as I  # noqa: E402

_REG: dict = {}
_RUN: dict = {}


def _registry():
    """The invariant registry alone: the registry and enforcement tests read declarations, not runs."""
    if not _REG:
        reg = C.load_registry()
        _REG.update({"reg": reg, "invariants": I.load_invariants(registry=reg)})
    return _REG


def _run_once():
    """One governed run, shared by every test that needs observed behaviour: driving it repeatedly measures nothing
    extra. Imported lazily so the registry and enforcement tests do not depend on the observability adapter."""
    if not _RUN:
        from adapters import observability as OB
        import test_workflow as T
        base = Path(tempfile.mkdtemp(prefix="inv-suite-"))
        r = _registry()
        d = T.Driver(base, r["reg"])
        d.drive("WF-12")
        OB.write_report(d.run.run_dir)
        _RUN.update({"driver": d, "reg": r["reg"], "run_dir": d.run.run_dir, "invariants": r["invariants"]})
    return _RUN


class RegistryTests(unittest.TestCase):
    """T01 — the registry declares every invariant, platform-wide, bound to suites that exist."""

    def setUp(self):
        self.m = _registry()["invariants"]

    def test_every_declared_invariant_is_well_formed(self):
        by_family = Counter(e["family"] for e in self.m["invariants"].values())
        self.assertTrue(by_family, "the registry declares no invariants")
        self.assertLessEqual(set(by_family), set(I.FAMILIES))
        self.assertEqual(sum(by_family.values()), len(self.m["invariants"]))
        for iid, e in self.m["invariants"].items():
            self.assertTrue(I.ID_RE.match(iid), iid)
            self.assertEqual(e["family"], iid.split("-")[0])

    def test_no_invariant_is_prompt_only(self):
        for iid, e in self.m["invariants"].items():
            self.assertIs(e["platform_wide"]["prompt_only"], False, iid)
            self.assertTrue(e["platform_wide"]["mechanism"].strip(), iid)

    def test_a_prompt_only_invariant_is_refused(self):
        bad = json.loads(json.dumps(self.m))
        bad["invariants"]["XAUTH-01"]["platform_wide"] = {"prompt_only": True, "mechanism": "the prompt says so"}
        p = Path(tempfile.mkdtemp()) / "INVARIANTS.json"
        p.write_text(json.dumps({k: v for k, v in bad.items() if k != "computed_hash"}), encoding="utf-8")
        with self.assertRaises(I.InvariantRefusal) as cm:
            I.load_invariants(p)
        self.assertEqual(cm.exception.code, "invariant.registry_invalid")

    def test_an_unbound_suite_is_refused(self):
        bad = json.loads(json.dumps(self.m))
        bad["invariants"]["XAUTH-01"]["authoritative_suites"] = ["Suite99/does_not_exist.jad"]
        p = Path(tempfile.mkdtemp()) / "INVARIANTS.json"
        p.write_text(json.dumps({k: v for k, v in bad.items() if k != "computed_hash"}), encoding="utf-8")
        with self.assertRaises(I.InvariantRefusal) as cm:
            I.load_invariants(p)
        self.assertEqual(cm.exception.code, "invariant.suite_unbound")


class EnforcementTests(unittest.TestCase):
    """T02 — every invariant binds to a real callable; an unresolvable point is refused."""

    def setUp(self):
        self.m = _registry()["invariants"]

    def test_every_enforcement_point_resolves(self):
        m = I.enforcement_map(self.m)
        declared = [i for i, e in self.m["invariants"].items() if "enforcement" in e]
        self.assertEqual(sorted(m), sorted(declared))
        for iid, v in m.items():
            self.assertTrue(v["resolved"], iid)
            for point in [v["authoritative_point"], *v["defense_in_depth"]]:
                self.assertTrue(callable(I.resolve(point)), f"{iid} -> {point}")

    def test_the_one_deferred_invariant_names_what_the_host_must_provide(self):
        deferred = [iid for iid, v in I.enforcement_map(self.m).items() if v["deferred_to_host"]]
        self.assertIn(len(deferred), (0, 1), "at most one invariant may be deferred to the host")
        if not deferred:
            self.skipTest("XSEC-04 is not yet bound in this wave")
        self.assertEqual(deferred, ["XSEC-04"])
        reason = I.verify_enforcement("XSEC-04", self.m)["deferral_reason"]
        self.assertIn("host", reason.lower())
        self.assertGreater(len(reason), 80, "a deferral must say what the host provides and why, not merely defer")

    def test_an_unresolvable_point_is_refused(self):
        with self.assertRaises(I.InvariantRefusal) as cm:
            I.resolve("security.no_such_callable")
        self.assertEqual(cm.exception.code, "invariant.enforcement_unresolvable")

    def test_boundaries_carrying_many_invariants_are_visible(self):
        bound = [i for i, e in self.m["invariants"].items() if "enforcement" in e]
        if len(bound) < len(self.m["invariants"]):
            self.skipTest("the wave is still binding invariants; a shared boundary is only visible once they all are")
        cov = I.boundaries_covered(self.m)
        self.assertTrue(any(len(v) >= 3 for v in cov.values()),
                        "the map exists so a reviewer can see which single boundary many invariants rest on")

class RepresentationTests(unittest.TestCase):
    """T03 — every invariant is evaluated over the run's own records into a contract-valid, replayable result."""

    def setUp(self):
        r = _run_once()
        self.m, self.reg, self.run_dir = r["invariants"], r["reg"], r["run_dir"]
        self.ctx = I.observe_run(self.run_dir)

    def test_the_context_is_built_from_the_runs_own_records(self):
        self.assertEqual(self.ctx["context_version"], I.CONTEXT_VERSION)
        self.assertTrue(self.ctx["report_hash"].startswith("sha256:"))
        # every declared input of every invariant must be answerable from this context's namespaces
        namespaces = {k for k, v in self.ctx.items() if isinstance(v, dict)}
        for iid, e in self.m["invariants"].items():
            if "representation" not in e:
                continue
            for name in I.representation_of(e)["inputs"]:
                self.assertIn(name.split(".")[0], namespaces, f"{iid} declares input {name}")

    def test_every_invariant_evaluates_to_a_contract_valid_result(self):
        results = I.evaluate_all(self.ctx, invariants=self.m, registry=self.reg)
        declared = [i for i, e in self.m["invariants"].items() if "representation" in e]
        self.assertEqual(len(results), len(declared))
        for r in results:
            C.validate_payload("invariant_result", r, registry=self.reg)
            self.assertIn(r["result"], I.RESULTS)
            self.assertTrue(r["evidence"], f"{r['invariant_id']} claims a result with no evidence")

    def test_a_finished_governed_run_satisfies_every_invariant_it_can(self):
        results = I.evaluate_all(self.ctx, invariants=self.m, registry=self.reg)
        counts = Counter(r["result"] for r in results)
        bad = [(r["invariant_id"], r["reasons"]) for r in results if r["result"] in ("violated", "indeterminate")]
        self.assertEqual(bad, [], f"a clean run must not violate or leave undetermined any invariant: {bad}")
        self.assertLessEqual(counts["deferred"], 1, "at most one invariant (XSEC-04) is deferred to the host")
        self.assertEqual(counts["satisfied"] + counts["deferred"], len(results))

    def test_a_missing_input_is_indeterminate_never_satisfied(self):
        if "XPROV-06" not in self.m["invariants"] or "representation" not in self.m["invariants"]["XPROV-06"]:
            self.skipTest("XPROV-06 is not yet represented in this wave")
        r = I.evaluate("XPROV-06", {"prov": {}}, invariants=self.m, registry=self.reg)
        self.assertEqual(r["result"], "indeterminate")
        self.assertIn("not present", r["reasons"][0])

    def test_a_false_input_is_a_violation(self):
        if "XPROV-06" not in self.m["invariants"] or "representation" not in self.m["invariants"]["XPROV-06"]:
            self.skipTest("XPROV-06 is not yet represented in this wave")
        ctx = json.loads(json.dumps({k: v for k, v in self.ctx.items()}))
        ctx["prov"]["chains_verify"] = False
        r = I.evaluate("XPROV-06", ctx, invariants=self.m, registry=self.reg)
        self.assertEqual(r["result"], "violated")
        self.assertIn("prov.chains_verify", r["reasons"][0])

    def test_results_are_replayable_and_recorded(self):
        results = I.evaluate_all(self.ctx, invariants=self.m, registry=self.reg)
        again = I.evaluate_all(self.ctx, invariants=self.m, registry=self.reg)
        self.assertEqual([r["result_hash"] for r in results], [r["result_hash"] for r in again],
                         "the same context must produce the same result hashes")
        # record into a scratch run directory: the suite must not write into the run it is measuring
        scratch = Path(tempfile.mkdtemp(prefix="inv-results-"))
        rows = I.record_results(scratch, results)
        self.assertEqual(len(rows), len(results))
        back = I.recorded_results(scratch)
        self.assertEqual(len(back), len(results))
        self.assertEqual([r["result_hash"] for r in back], [r["result_hash"] for r in results])
        self.assertTrue(all(row["entry_hash"].startswith("sha256:") for row in rows),
                        "recorded results are chained, so a result cannot be edited after the fact")

class ExposureTests(unittest.TestCase):
    """T05 — compliance is exposed where it is read: observability, the review surface and the readiness checklist."""

    def setUp(self):
        r = _run_once()
        self.m, self.reg, self.run_dir = r["invariants"], r["reg"], r["run_dir"]
        self.exposed = {i: e for i, e in self.m["invariants"].items() if "exposure" in e}
        if not self.exposed:
            self.skipTest("no invariant is exposed yet in this wave")
        self.results = [r for r in I.evaluate_all(I.observe_run(self.run_dir), invariants=self.m, registry=self.reg)
                        if r["invariant_id"] in self.exposed]

    def test_every_invariant_declares_all_three_exposures(self):
        for iid, e in self.exposed.items():
            x = I.exposure_of(e)
            self.assertTrue(x["observability"] and x["review_section"] and x["readiness_item"], iid)

    def test_the_compliance_report_covers_every_family(self):
        rep = I.compliance_report(self.results, invariants=self.m, run_id="probe")
        self.assertLessEqual(set(rep["families"]), set(I.FAMILIES))
        self.assertEqual(sum(len(f["invariants"]) for f in rep["families"].values()), len(self.results))
        self.assertIn("evidence_only", rep["authority"])
        self.assertEqual(rep["blocking"], [])

    def test_the_review_fragment_is_display_only_and_never_summarises_a_blocker_away(self):
        rep = I.compliance_report(self.results, invariants=self.m)
        frag = I.review_fragment(rep)
        self.assertEqual(frag["authority"], "display_only")
        victim = sorted(self.exposed)[0]
        broken = [dict(r, result="violated") if r["invariant_id"] == victim else r for r in self.results]
        frag2 = I.review_fragment(I.compliance_report(broken, invariants=self.m))
        self.assertIn(victim, frag2["blocking"])
        self.assertIn(victim, [i for row in frag2["families"] for i in row["needs_review"]])

    def test_the_checklist_names_the_host_requirement_and_never_calls_it_satisfied(self):
        cl = I.readiness_checklist(self.results, invariants=self.m)
        if "XSEC-04" not in self.exposed:
            self.skipTest("XSEC-04 is not yet exposed in this wave")
        self.assertEqual(cl["host_requirements"], ["XSEC-04"])
        item = [i for i in cl["items"] if i["invariant_id"] == "XSEC-04"][0]
        self.assertEqual(item["result"], "deferred")
        self.assertTrue(item["deferred_to_host"])
        self.assertIn("HOST REQUIREMENT", item["item"])

    def test_compliance_is_archived_as_evidence_the_readiness_gate_can_read(self):
        """The gate reads the tool's own chained evidence ledger, so compliance is written there — one row per
        invariant, carrying the result, the enforcement point behind it and the hash of the result record."""
        import evidence_ledger as EL
        rep = I.compliance_report(self.results, invariants=self.m)
        rows = []
        for r in self.results:
            e = self.exposed[r["invariant_id"]]
            rows.append(EL.record(
                I.gate_invariant_id(r["invariant_id"], self.m), I.EVIDENCE_KIND,
                "PASS" if r["result"] in ("satisfied", "deferred", "not_applicable") else "FAIL",
                {"result": r["result"], "family": r["family"],
                 "authoritative_point": (e.get("enforcement") or {}).get("authoritative_point"),
                 "deferred_to_host": bool((e.get("enforcement") or {}).get("deferred_to_host")),
                 "readiness_item": I.exposure_of(e)["readiness_item"],
                 "result_hash": r["result_hash"], "invariants_hash": self.m["computed_hash"],
                 "compliance_report_hash": rep["report_hash"]}))
        self.assertEqual(len(rows), len(self.results))
        self.assertTrue(all(row["verdict"] == "PASS" for row in rows),
                        "a violated or indeterminate invariant is archived as FAIL and blocks the readiness receipt")

    def test_readiness_is_blocked_by_a_violated_or_unevaluated_invariant(self):
        victim = sorted(self.exposed)[0]
        with self.assertRaises(I.InvariantRefusal) as cm:
            I.require_invariants(results=[r for r in self.results if r["invariant_id"] != victim], invariants=self.m)
        self.assertEqual(cm.exception.code, "invariant.readiness_blocked")
        broken = [dict(r, result="violated") if r["invariant_id"] == victim else r for r in self.results]
        with self.assertRaises(I.InvariantRefusal):
            I.require_invariants(results=broken, invariants=self.m)
        self.assertTrue(I.require_invariants(results=self.results, invariants=self.m)["checklist_hash"])


if __name__ == "__main__":
    unittest.main()
