"""Deterministic tests for inert bounded patch generation (stdlib unittest)."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import evidence_retrieval as er  # noqa: E402
from adapters import intent_intake as ii  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import patch_generator as pg  # noqa: E402


def _git(cwd: Path, *args: str) -> str:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t",
           "GIT_COMMITTER_EMAIL": "t@t", "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z", "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z"}
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=True, env=env).stdout.strip()


class Fixture(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "repo"
        for d in ("Alpha", "Beta"):
            (self.root / d).mkdir(parents=True)
        _git(self.root, "init", "-q")
        (self.root / "Alpha" / "a1.deepml").write_text("deepml logic 0.3\nmodule a.one\n")
        (self.root / "Alpha" / "a2.deepml").write_text("deepml logic 0.3\nmodule a.two\n")
        (self.root / "Alpha" / "SHA256SUMS.txt").write_text("0000  01_Alpha/01_a1.deepml\n1111  01_Alpha/02_a2.deepml\n")
        (self.root / "Beta" / "SHA256SUMS.txt").write_text("2222  02_Beta/01_b.deepml\n")
        (self.root / "Beta" / "b.deepml").write_text("deepml logic 0.3\nmodule b\n")
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c1")
        self.binding = lga.bind_repository(self.root)
        self.contract = json.loads(ii.accept_intent({
            "kind": "tech_debt_refactor", "title": "Regenerate stale Alpha SHA256SUMS manifest",
            "description": "Alpha/SHA256SUMS.txt lists obsolete deepml paths; regenerate digests for existing files.",
            "allowed_paths": ["Alpha/SHA256SUMS.txt"], "max_changed_files": 1, "max_diff_lines": 20, "requested_by": "t",
        }, self.binding).to_json())
        self.plan = er.build_plan(self.contract, er.retrieve_examples(self.binding, self.contract))

    def tearDown(self) -> None:
        self.tmp.cleanup()


class TestPatch(Fixture):
    def test_generates_inert_bounded_patch(self) -> None:
        before = lga.tree_identity(self.root, self.binding.base_revision)
        cand, patch = pg.generate_candidate(self.binding, self.contract, self.plan, "regenerate_sha256sums_manifest")
        self.assertTrue(cand.inert)
        self.assertEqual(cand.canonical_paths, ("Alpha/SHA256SUMS.txt",))
        self.assertEqual(cand.files_changed, 1)
        self.assertEqual(cand.lines_deleted, 2)
        self.assertEqual(cand.lines_added, 2)
        self.assertEqual(cand.approval_state, "required_before_application")
        self.assertEqual(cand.bounded_patch_plan["approval_state"], "required_before_application")
        # patch content is the deterministic manifest for existing siblings
        a1 = hashlib.sha256((self.root / "Alpha" / "a1.deepml").read_bytes()).hexdigest()
        self.assertIn(f"+{a1}  a1.deepml", patch.decode())
        self.assertIn("diff --git a/Alpha/SHA256SUMS.txt b/Alpha/SHA256SUMS.txt", patch.decode())
        # repository untouched
        self.assertEqual(lga.tree_identity(self.root, self.binding.base_revision), before)
        self.assertEqual(_git(self.root, "status", "--porcelain"), "")
        self.assertEqual((self.root / "Alpha" / "SHA256SUMS.txt").read_text(), "0000  01_Alpha/01_a1.deepml\n1111  01_Alpha/02_a2.deepml\n")
        # applicable in principle (dry run only; never applied here)
        subprocess.run(["git", "apply", "--check", "-"], cwd=self.root, input=patch, check=True)
        pg.verify_candidate_hash(json.loads(cand.to_json()), patch)
        # deterministic
        cand2, patch2 = pg.generate_candidate(self.binding, self.contract, self.plan, "regenerate_sha256sums_manifest")
        self.assertEqual(cand.candidate_id, cand2.candidate_id)
        self.assertEqual(patch, patch2)

    def test_limits_and_scope_fail_closed(self) -> None:
        small = dict(self.contract, max_diff_lines=1)
        small_plan = dict(self.plan, scope_contract_hash=small["scope_contract_hash"])
        with self.assertRaises(lga.AdapterError) as ctx:
            pg.generate_candidate(self.binding, small, small_plan, "regenerate_sha256sums_manifest")
        self.assertEqual(ctx.exception.code, "patch.too_large")
        # plan that tries to reach outside the allowed scope
        widened = json.loads(json.dumps(self.plan))
        widened["operations"][0]["path"] = "Beta/SHA256SUMS.txt"
        with self.assertRaises(lga.AdapterError) as ctx:
            pg.generate_candidate(self.binding, self.contract, widened, "regenerate_sha256sums_manifest")
        self.assertEqual(ctx.exception.code, "scope.violation")

    def test_refusals(self) -> None:
        with self.assertRaises(lga.AdapterError) as ctx:
            pg.generate_candidate(self.binding, self.contract, self.plan, "invent_something")
        self.assertEqual(ctx.exception.code, "recipe.unregistered")
        with self.assertRaises(lga.AdapterError) as ctx:
            pg.generate_candidate(self.binding, self.contract, dict(self.plan, status="ABSTAIN"), "regenerate_sha256sums_manifest")
        self.assertEqual(ctx.exception.code, "patch.plan_not_planned")
        with self.assertRaises(lga.AdapterError) as ctx:
            pg.generate_candidate(self.binding, self.contract, dict(self.plan, scope_contract_hash="sha256:x"), "regenerate_sha256sums_manifest")
        self.assertEqual(ctx.exception.code, "patch.plan_mismatch")
        drifted = json.loads(json.dumps(self.plan))
        drifted["operations"][0]["source_content_hash"] = "sha256:stale"
        with self.assertRaises(lga.AdapterError) as ctx:
            pg.generate_candidate(self.binding, self.contract, drifted, "regenerate_sha256sums_manifest")
        self.assertEqual(ctx.exception.code, "patch.source_drift")

    def test_candidate_hash_tamper(self) -> None:
        cand, patch = pg.generate_candidate(self.binding, self.contract, self.plan, "regenerate_sha256sums_manifest")
        stored = json.loads(cand.to_json())
        with self.assertRaises(lga.AdapterError) as ctx:
            pg.verify_candidate_hash(stored, patch + b"\n+injected\n")
        self.assertEqual(ctx.exception.code, "candidate.patch_hash_mismatch")
        stored["base_revision"] = "0" * 40
        with self.assertRaises(lga.AdapterError) as ctx:
            pg.verify_candidate_hash(stored, patch)
        self.assertEqual(ctx.exception.code, "candidate.id_mismatch")


if __name__ == "__main__":
    unittest.main()
