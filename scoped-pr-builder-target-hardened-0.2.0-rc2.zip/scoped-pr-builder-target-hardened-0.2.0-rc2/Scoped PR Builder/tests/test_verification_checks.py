"""Independent verification gates (Phase 08 / VERIFY-01..07; stdlib unittest).

Fixture: the 66-suite fixture repository (test_components.make_repo) with one manifest candidate produced by the real
recipe; forged candidates (hand-built unified diffs over pinned blobs, hash-bound like real ones) drive the deterministic
failure paths. Every check executes through the SLICE-06 runner in a detached worktree; the source tree is never touched.
"""
from __future__ import annotations

import difflib
import json
import sys
import tempfile
import unittest
from pathlib import Path, PurePosixPath

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from adapters import contracts as C  # noqa: E402
from adapters import evidence_retrieval as er  # noqa: E402
from adapters import intent_intake as ii  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import patch_generator as pg  # noqa: E402
from adapters import verification_checks as VC  # noqa: E402
from adapters import verification_runner as vr  # noqa: E402
from test_components import _git, make_repo  # noqa: E402

REPO_ROOT = HERE.parent.parent
CHECK_IDS = [f"VERIFY-{n:02d}" for n in range(1, 8)]


def contract_for(binding, allowed, files=1, lines=10, title="Regenerate stale Suite04 SHA256SUMS manifest"):
    return json.loads(ii.accept_intent({"kind": "tech_debt_refactor", "title": title, "description": "x", "allowed_paths": list(allowed), "max_changed_files": files, "max_diff_lines": lines, "requested_by": "t"}, binding).to_json())


def forge(base_cand: dict, contract: dict, root: Path, revision: str, edits: dict[str, str]) -> tuple[dict, bytes]:
    """A hash-bound candidate for hand-written edits over pinned blobs (the same diff shape the generator emits)."""
    parts, changed, added, deleted = [], [], 0, 0
    for rel, new in edits.items():
        p = PurePosixPath(rel)
        cur = lga.read_blob(root, revision, p).decode("utf-8", errors="surrogateescape") if lga.path_exists_at(root, revision, p) else ""
        lines = list(difflib.unified_diff(cur.splitlines(keepends=True), new.splitlines(keepends=True), fromfile=f"a/{rel}", tofile=f"b/{rel}", n=3))
        parts.append(f"diff --git a/{rel} b/{rel}\n")
        parts.extend(line if line.endswith("\n") else line + "\n\\ No newline at end of file\n" for line in lines)
        changed.append(rel)
        added += sum(1 for l in lines if l.startswith("+") and not l.startswith("+++"))
        deleted += sum(1 for l in lines if l.startswith("-") and not l.startswith("---"))
    patch = "".join(parts).encode("utf-8", errors="surrogateescape")
    cand = dict(base_cand, scope_contract_hash=contract["scope_contract_hash"], intent_id=contract["intent_id"], canonical_paths=changed, files_changed=len(changed), lines_added=added, lines_deleted=deleted,
                patch_bytes=len(patch), patch_hash=lga.sha256_digest(patch), recipe="forged_for_test")
    cand["candidate_id"] = lga.sha256_digest(lga.canonical_json({"patch": cand["patch_hash"], "rev": cand["base_revision"], "scope": cand["scope_contract_hash"], "plan": cand["plan_hash"]}))
    return cand, patch


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.checks = VC.load_checks(registry=self.reg)
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.root = make_repo(self.base)
        self.binding = lga.bind_repository(self.root)
        self.contract = contract_for(self.binding, ["Suite04/SHA256SUMS.txt"])
        self.plan = er.build_plan(self.contract, er.retrieve_examples(self.binding, self.contract))
        cand, self.patch = pg.generate_candidate(self.binding, self.contract, self.plan, "regenerate_sha256sums_manifest")
        self.cand = json.loads(cand.to_json())
        self.sandboxes = self.base / "sandboxes"
        self.before = (lga.tree_identity(self.root, self.binding.base_revision), _git(self.root, "status", "--porcelain", "--untracked-files=all"))

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def assert_source_untouched(self) -> None:
        self.assertEqual((lga.tree_identity(self.root, self.binding.base_revision), _git(self.root, "status", "--porcelain", "--untracked-files=all")), self.before)

    def bound(self, cid: str, block: str | None = None) -> bool:
        c = self.checks["checks"].get(cid)
        return c is not None and (block is None or block in c)

    def subject(self, cand=None, contract=None):
        return VC.subject_of(self.binding, contract or self.contract, cand or self.cand)


class TestRegistryAndTypedResults(Base):
    def test_registry_loads_and_binds(self) -> None:
        ck = self.checks
        self.assertEqual(ck["computed_hash"], VC.load_checks(registry=self.reg)["computed_hash"])
        for cid, c in ck["checks"].items():
            with self.subTest(check=cid):
                self.assertEqual(c["typed_result"]["enum"], list(VC.RESULTS))
                self.assertTrue(c["evidence_requirements"]); self.assertTrue(c["independence"])
                for f in c["authoritative_suites"]:
                    self.assertTrue((REPO_ROOT / f).is_file(), f)
        broken = json.loads(json.dumps({k: v for k, v in ck.items() if k != "computed_hash"}))
        if broken["checks"]:
            first = next(iter(broken["checks"])); broken["checks"][first]["typed_result"]["enum"] = ["pass", "fail"]
            with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
                json.dump(broken, f)
            with self.assertRaises(lga.AdapterError) as ctx:
                VC.load_checks(Path(f.name), registry=self.reg)
            self.assertEqual(ctx.exception.code, "verify.registry_invalid")

    def test_typed_result_vocabulary_is_closed_and_fail_closed(self) -> None:
        if not self.checks["checks"]:
            self.skipTest("no checks yet")
        c = next(iter(self.checks["checks"].values())); s = self.subject()
        ref = [{"kind": "job_record", "ref": "sha256:" + "0" * 64, "job": "x", "verdict": "PASS"}]
        r = VC.typed_result(c, "pass", s, executed=True, executor={"suite": "x", "worker": "w", "job_ids": []}, evidence_refs=ref, summary="ok", registry=self.reg)
        self.assertEqual(r["result"], "pass"); VC.verify_result(r, registry=self.reg)
        C.validate_payload("verification_check_result", r, registry=self.reg)
        for bad in ("PASS", "ok", "skipped", "warning"):
            with self.assertRaises(lga.AdapterError) as ctx:
                VC.typed_result(c, bad, s, executed=True, executor=None, evidence_refs=ref, summary="x", registry=self.reg)
            self.assertEqual(ctx.exception.code, "verify.result_invalid")
        with self.assertRaises(lga.AdapterError) as ctx:  # a pass without executed evidence is not a pass
            VC.typed_result(c, "pass", s, executed=True, executor=None, evidence_refs=[], summary="x", registry=self.reg)
        self.assertEqual(ctx.exception.code, "verify.result_invalid")
        with self.assertRaises(lga.AdapterError) as ctx:  # a pass that was not executed is not a pass
            VC.typed_result(c, "pass", s, executed=False, executor=None, evidence_refs=ref, summary="x", registry=self.reg)
        self.assertEqual(ctx.exception.code, "verify.result_invalid")
        for kind in ("fail", "blocked", "indeterminate"):
            with self.assertRaises(lga.AdapterError):  # every non-pass needs reasons
                VC.typed_result(c, kind, s, executed=True, executor=None, evidence_refs=ref, summary="x", registry=self.reg)
            r2 = VC.typed_result(c, kind, s, executed=kind != "blocked", executor=None, evidence_refs=ref, summary="x", reasons=["because"], registry=self.reg)
            self.assertEqual(r2["result"], kind)
        tampered = dict(r, result="fail")
        with self.assertRaises(lga.AdapterError) as ctx:
            VC.verify_result(tampered, registry=self.reg)
        self.assertEqual(ctx.exception.code, "verify.result_tampered")
        with self.assertRaises(lga.AdapterError):  # the subject is mandatory and complete
            VC.typed_result(c, "pass", dict(s, patch_hash=""), executed=True, executor=None, evidence_refs=ref, summary="x", registry=self.reg)

    def test_subject_binding_refuses_mismatch(self) -> None:
        with self.assertRaises(lga.AdapterError) as ctx:
            VC.subject_of(self.binding, self.contract, dict(self.cand, base_revision="b" * 40))
        self.assertEqual(ctx.exception.code, "verify.binding_mismatch")
        with self.assertRaises(lga.AdapterError):
            VC.results_by_check([{"check_id": "VERIFY-01"}, {"check_id": "VERIFY-01"}])


class TestExecution(Base):
    def test_every_bound_check_executes_against_exact_subject(self) -> None:
        bound = [cid for cid in CHECK_IDS if self.bound(cid, "execution")]
        if not bound:
            self.skipTest("no execution bindings yet")
        report, results = VC.run_checks(self.binding, self.contract, self.cand, self.patch, self.sandboxes, registry=self.reg)
        self.assert_source_untouched()
        self.assertTrue(report["sandbox_destroyed"]); self.assertTrue(report["source_tree_unchanged"])
        by = VC.results_by_check(results)
        for cid in bound:
            with self.subTest(check=cid):
                r = by[cid]
                self.assertEqual(r["result"], "pass", (cid, r["summary"], r["reasons"]))
                self.assertTrue(r["executed"]); self.assertTrue(r["executor"]["job_ids"])
                self.assertEqual(r["subject"], self.subject())
                kinds = {e["kind"] for e in r["evidence_refs"]}
                self.assertTrue({"job_record", "verification_report", "patch", "revision", "scope_contract"} <= kinds, kinds)
                self.assertEqual(r["executor"]["suite"], self.checks["checks"][cid]["execution"]["through"])
                self.assertTrue(all(d["stdout_digest"] for d in r["diagnostics"]))
                VC.verify_result(r, registry=self.reg)

    def test_patch_not_matching_candidate_never_reaches_a_sandbox(self) -> None:
        if not any(self.bound(cid, "execution") for cid in CHECK_IDS):
            self.skipTest("no execution bindings yet")
        with self.assertRaises(lga.AdapterError) as ctx:
            VC.run_checks(self.binding, self.contract, self.cand, self.patch + b"\n", self.sandboxes, registry=self.reg)
        self.assertEqual(ctx.exception.code, "candidate.patch_hash_mismatch"); self.assertFalse(self.sandboxes.exists())

    def test_report_for_another_subject_is_refused(self) -> None:
        if not any(self.bound(cid, "execution") for cid in CHECK_IDS):
            self.skipTest("no execution bindings yet")
        report, _ = VC.run_checks(self.binding, self.contract, self.cand, self.patch, self.sandboxes, registry=self.reg)
        other, _ = forge(self.cand, self.contract, self.root, self.binding.base_revision, {"Suite04/SHA256SUMS.txt": "abcd  x\n"})
        with self.assertRaises(lga.AdapterError) as ctx:
            VC.derive_results(report, binding=self.binding, contract=self.contract, candidate=other, registry=self.reg)
        self.assertEqual(ctx.exception.code, "verify.report_mismatch")

    def test_downstream_checks_are_blocked_not_passed_when_the_runner_stops(self) -> None:
        if not self.bound("VERIFY-01", "execution"):
            self.skipTest("VERIFY-01 not bound")
        # a patch that does not apply: applicability FAIL → VERIFY-01 fail, every later bound check blocked (never pass)
        cand, patch = forge(self.cand, self.contract, self.root, self.binding.base_revision, {"Suite04/SHA256SUMS.txt": "x\n"})
        patch = patch.replace(b"-0000  04_Old/04_demo.jad", b"-9999  nope")
        cand = dict(cand, patch_hash=lga.sha256_digest(patch)); cand["candidate_id"] = lga.sha256_digest(lga.canonical_json({"patch": cand["patch_hash"], "rev": cand["base_revision"], "scope": cand["scope_contract_hash"], "plan": cand["plan_hash"]}))
        _, results = VC.run_checks(self.binding, self.contract, cand, patch, self.sandboxes, registry=self.reg)
        by = VC.results_by_check(results)
        self.assertEqual(by["VERIFY-01"]["result"], "fail")
        for cid in CHECK_IDS[1:]:
            if self.bound(cid, "execution"):
                self.assertEqual(by[cid]["result"], "blocked", cid); self.assertFalse(by[cid]["executed"])
        self.assert_source_untouched()


class TestGate(Base):
    def _results(self):
        report, results = VC.run_checks(self.binding, self.contract, self.cand, self.patch, self.sandboxes, registry=self.reg)
        return report, results

    def test_gate_proceeds_only_on_complete_fresh_executed_passes(self) -> None:
        if not hasattr(VC, "gate") or not all(self.bound(cid, "execution") for cid in CHECK_IDS):
            self.skipTest("gate or execution bindings not present yet")
        report, results = self._results(); s = self.subject()
        d = VC.gate(results, s, registry=self.reg)
        self.assertEqual(d["decision"], "PROCEED", d["per_check"]); self.assertEqual(d["blocking"], []); self.assertEqual(set(d["mandatory"]), set(CHECK_IDS))
        self.assertEqual(VC.require_gate(results, s, stage="test", registry=self.reg)["decision_hash"], d["decision_hash"])
        by = VC.results_by_check(results)
        # missing
        d = VC.gate([r for r in results if r["check_id"] != "VERIFY-03"], s, registry=self.reg)
        self.assertEqual(d["decision"], "BLOCK"); self.assertEqual(d["per_check"]["VERIFY-03"]["status"], "missing")
        # stale: another patch
        d = VC.gate(results, dict(s, patch_hash="sha256:" + "f" * 64), registry=self.reg)
        self.assertEqual(d["decision"], "BLOCK"); self.assertTrue(all(v["status"] == "stale" for v in d["per_check"].values()))
        # stale: too old
        d = VC.gate(results, s, registry=self.reg, now="2999-01-01T00:00:00+00:00")
        self.assertEqual(d["decision"], "BLOCK"); self.assertEqual(d["per_check"]["VERIFY-01"]["status"], "stale")
        # tampered result (an edited verdict) never satisfies
        forged = dict(by["VERIFY-02"], result="pass", summary="edited")
        forged["result_hash"] = lga.sha256_digest("x")
        d = VC.gate([forged if r["check_id"] == "VERIFY-02" else r for r in results], s, registry=self.reg)
        self.assertEqual(d["per_check"]["VERIFY-02"]["status"], "tampered"); self.assertEqual(d["decision"], "BLOCK")
        # skipped / blocked / indeterminate / fail: rebuilt through the typed-result boundary (sealed), still block
        c = self.checks["checks"]["VERIFY-06"]; ref = by["VERIFY-06"]["evidence_refs"]
        for kind, executed, status in (("blocked", False, "skipped"), ("indeterminate", True, "indeterminate"), ("fail", True, "failed")):
            alt = VC.typed_result(c, kind, s, executed=executed, executor=by["VERIFY-06"]["executor"], evidence_refs=ref, summary="x", reasons=["r"], registry=self.reg)
            d = VC.gate([alt if r["check_id"] == "VERIFY-06" else r for r in results], s, registry=self.reg)
            self.assertEqual(d["per_check"]["VERIFY-06"]["status"], status, kind); self.assertEqual(d["decision"], "BLOCK")
        with self.assertRaises(lga.AdapterError) as ctx:
            VC.require_gate(results[:-1], s, stage="test", registry=self.reg)
        self.assertEqual(ctx.exception.code, "verify.gate_blocked")

    def test_assertions_are_not_inputs(self) -> None:
        if not hasattr(VC, "gate"):
            self.skipTest("gate not present yet")
        s = self.subject()
        # a planner/model "assertion" carries no executed job evidence and cannot be sealed as a pass at all
        assertion = {"check_id": "VERIFY-01", "result": "pass", "summary": "the model says it applies", "subject": s}
        d = VC.gate([], s, registry=self.reg)
        self.assertEqual(d["decision"], "BLOCK"); self.assertTrue(all(v["status"] == "missing" for v in d["per_check"].values()))
        d = VC.gate([assertion], s, registry=self.reg)  # a bare assertion is not a receipt: refused as tampered/unsealed, never interpreted
        self.assertEqual(d["decision"], "BLOCK"); self.assertEqual(d["per_check"]["VERIFY-01"]["status"], "tampered")


class TestReproducibility(Base):
    def test_capture_rides_with_every_result(self) -> None:
        if not hasattr(VC, "reproducibility") or not all(self.bound(cid, "execution") for cid in CHECK_IDS):
            self.skipTest("reproducibility not present yet")
        report, results = VC.run_checks(self.binding, self.contract, self.cand, self.patch, self.sandboxes, registry=self.reg)
        self.assertIn("artifact_hashes", report); self.assertTrue(report["artifact_hashes"]["changed_files"])
        for r in results:
            with self.subTest(check=r["check_id"]):
                rep = r["reproducibility"]
                self.assertTrue(rep["tool_versions"]["python"]); self.assertTrue(rep["tool_versions"]["git"]); self.assertTrue(rep["environment"]["platform"])
                self.assertEqual(rep["fixture_identity"]["base_revision"], self.binding.base_revision); self.assertEqual(rep["fixture_identity"]["base_tree"], report["artifact_hashes"]["base_tree"])
                self.assertIsNotNone(rep["timing"]["duration_s"]); self.assertTrue(rep["timing"]["jobs"])
                self.assertIsNotNone(rep["resource_usage"]); self.assertGreaterEqual(rep["resource_usage"]["utime_s"] + rep["resource_usage"]["stime_s"], 0)
                self.assertEqual(rep["artifact_hashes"]["patch_hash"], self.cand["patch_hash"]); self.assertEqual(rep["artifact_hashes"]["report_hash"], report["report_hash"])
                self.assertTrue(rep["artifact_hashes"]["stdout_digests"]); self.assertTrue(all(d["stdout_tail"] is not None and d["stderr_tail"] is not None for d in r["diagnostics"]))
                VC.verify_reproducibility(r); VC.verify_result(r, registry=self.reg)  # capture is outside the sealed verdict
                edited = json.loads(json.dumps(r)); edited["reproducibility"]["tool_versions"]["git"] = "git version 0"
                with self.assertRaises(lga.AdapterError) as ctx:
                    VC.verify_reproducibility(edited)
                self.assertEqual(ctx.exception.code, "verify.reproducibility_tampered")
        # two runs over the same subject agree on every identity-bearing part except timing/resource usage
        _, again = VC.run_checks(self.binding, self.contract, self.cand, self.patch, self.sandboxes, registry=self.reg)
        a, b = VC.results_by_check(results), VC.results_by_check(again)
        for cid in CHECK_IDS:
            self.assertEqual(a[cid]["reproducibility"]["artifact_hashes"]["changed_files"], b[cid]["reproducibility"]["artifact_hashes"]["changed_files"])
            self.assertEqual(a[cid]["reproducibility"]["tool_versions"], b[cid]["reproducibility"]["tool_versions"])
            self.assertEqual(a[cid]["result"], b[cid]["result"])


if __name__ == "__main__":
    unittest.main()
