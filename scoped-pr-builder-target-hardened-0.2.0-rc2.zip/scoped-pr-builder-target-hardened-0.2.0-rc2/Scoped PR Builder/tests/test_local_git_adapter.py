"""Deterministic tests for the Scoped PR Builder local-Git adapter (stdlib unittest).

Run from the repository root:
    python3 -m unittest discover -s "Scoped PR Builder/tests" -t "Scoped PR Builder" -v
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path, PurePosixPath

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import local_git_adapter as lga  # noqa: E402


def _git(cwd: Path, *args: str) -> str:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t",
           "GIT_COMMITTER_EMAIL": "t@t", "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z", "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z"}
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=True, env=env).stdout.strip()


class FixtureRepo(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "repo"
        self.root.mkdir()
        _git(self.root, "init", "-q")
        (self.root / "src").mkdir()
        (self.root / "src" / "a.txt").write_text("alpha\n")
        (self.root / "docs").mkdir()
        (self.root / "docs" / "d.md").write_text("doc\n")
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c1")
        self.c1 = _git(self.root, "rev-parse", "HEAD")

    def tearDown(self) -> None:
        self.tmp.cleanup()


class TestPathConfinement(unittest.TestCase):
    def test_relative_ok(self) -> None:
        self.assertEqual(lga.relative_path("src/a.txt"), PurePosixPath("src/a.txt"))

    def test_rejects_escape_and_absolute(self) -> None:
        for bad in ["", "/etc/passwd", "../x", "src/../../x", "C:\\x", "a\\b", "a\x00b", "src/./a"]:
            with self.subTest(bad=bad):
                with self.assertRaises(lga.AdapterError):
                    lga.relative_path(bad)

    def test_within_and_scope(self) -> None:
        allowed = lga.validated_roots(["src"], "allowed")
        self.assertTrue(lga.within(PurePosixPath("src/a.txt"), allowed))
        self.assertFalse(lga.within(PurePosixPath("docs/d.md"), allowed))
        lga.require_within_scope([PurePosixPath("src/a.txt")], allowed)
        with self.assertRaises(lga.AdapterError) as ctx:
            lga.require_within_scope([PurePosixPath("docs/d.md")], allowed)
        self.assertEqual(ctx.exception.code, "scope.violation")
        with self.assertRaises(lga.AdapterError):
            lga.require_within_scope([PurePosixPath("src/secret.txt")], allowed, forbidden=lga.validated_roots(["src/secret.txt"], "forbidden"))

    def test_empty_scope_fails_closed(self) -> None:
        with self.assertRaises(lga.AdapterError) as ctx:
            lga.validated_roots([], "allowed")
        self.assertEqual(ctx.exception.code, "scope.empty")

    def test_native_path_containment_does_not_confuse_sibling_prefixes(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            repo = base / "repo"
            child = repo / "nested" / "run"
            sibling = base / "repo-old"
            child.mkdir(parents=True)
            sibling.mkdir()
            self.assertTrue(lga.path_within(child, repo))
            self.assertTrue(lga.path_within(repo, repo))
            self.assertFalse(lga.path_within(repo, repo, allow_equal=False))
            self.assertFalse(lga.path_within(sibling, repo))


class TestBinding(FixtureRepo):
    def test_bind_pins_full_revision_and_snapshot(self) -> None:
        b = lga.bind_repository(self.root)
        self.assertEqual(b.base_revision, self.c1)
        self.assertEqual(len(b.base_revision), 40)
        self.assertTrue(b.source_snapshot_hash.startswith("sha256:"))
        self.assertEqual(b.dirty_file_count, 0)
        self.assertEqual(b.adapter_version, lga.ADAPTER_VERSION)
        # deterministic identity: same repo/revision -> same snapshot hash
        self.assertEqual(b.source_snapshot_hash, lga.tree_identity(self.root, self.c1))
        # canonical JSON round-trips with sorted keys
        self.assertIn('"base_revision"', b.to_json())

    def test_bind_non_root_and_non_repo_fail_closed(self) -> None:
        with self.assertRaises(lga.AdapterError) as ctx:
            lga.bind_repository(self.root / "src")
        self.assertEqual(ctx.exception.code, "repository.not_root")
        with self.assertRaises(lga.AdapterError):
            lga.bind_repository(Path(self.tmp.name) / "nope")

    def test_bind_unresolved_revision_fails_closed(self) -> None:
        with self.assertRaises(lga.AdapterError) as ctx:
            lga.bind_repository(self.root, "deadbeef")
        self.assertEqual(ctx.exception.code, "revision.unresolved")

    def test_dirty_detection_and_require_clean(self) -> None:
        (self.root / "src" / "a.txt").write_text("alpha\nbeta\n")
        b = lga.bind_repository(self.root)
        self.assertEqual(b.dirty_file_count, 1)
        with self.assertRaises(lga.AdapterError) as ctx:
            lga.bind_repository(self.root, require_clean=True)
        self.assertEqual(ctx.exception.code, "worktree.dirty")

    def test_revalidate_detects_moved_head(self) -> None:
        b = lga.bind_repository(self.root)
        lga.revalidate_binding(b)
        (self.root / "src" / "b.txt").write_text("b\n")
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c2")
        with self.assertRaises(lga.AdapterError) as ctx:
            lga.revalidate_binding(b)
        self.assertEqual(ctx.exception.code, "freshness.stale")

    def test_read_blob_and_changed_paths(self) -> None:
        self.assertEqual(lga.read_blob(self.root, self.c1, PurePosixPath("src/a.txt")), b"alpha\n")
        with self.assertRaises(lga.AdapterError):
            lga.read_blob(self.root, self.c1, PurePosixPath("src/missing.txt"))
        (self.root / "src" / "a.txt").write_text("changed\n")
        (self.root / "new.txt").write_text("n\n")
        self.assertEqual(lga.changed_paths(self.root, self.c1), (PurePosixPath("new.txt"), PurePosixPath("src/a.txt")))


class TestWorktrees(FixtureRepo):
    def test_isolated_worktree_lifecycle(self) -> None:
        dest = Path(self.tmp.name) / "wt" / "iso1"
        wt = lga.worktree_add(self.root, dest, self.c1)
        self.assertTrue((wt / "src" / "a.txt").is_file())
        self.assertEqual(_git(wt, "rev-parse", "HEAD"), self.c1)
        # work in the isolated tree does not touch the source tree
        (wt / "src" / "a.txt").write_text("isolated\n")
        self.assertEqual((self.root / "src" / "a.txt").read_text(), "alpha\n")
        lga.worktree_remove(self.root, wt)
        self.assertFalse(wt.exists())

    def test_nested_worktree_rejected(self) -> None:
        with self.assertRaises(lga.AdapterError) as ctx:
            lga.worktree_add(self.root, self.root / "inner", self.c1)
        self.assertEqual(ctx.exception.code, "worktree.nested")

    def test_remove_refuses_unregistered_directory_without_deleting_it(self) -> None:
        victim = Path(self.tmp.name) / "unrelated-data"
        victim.mkdir()
        marker = victim / "keep.txt"
        marker.write_text("must survive\n")
        with self.assertRaises(lga.AdapterError) as ctx:
            lga.worktree_remove(self.root, victim)
        self.assertEqual(ctx.exception.code, "worktree.unregistered")
        self.assertTrue(marker.is_file())
        self.assertEqual(marker.read_text(), "must survive\n")


if __name__ == "__main__":
    unittest.main()
