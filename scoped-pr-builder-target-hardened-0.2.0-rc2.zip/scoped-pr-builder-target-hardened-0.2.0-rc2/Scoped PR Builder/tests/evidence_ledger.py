"""Test/evidence ledger helper (Phase 01 / API-*-T05).

Test results are stored as hash-chained rows: each row carries the scenario id, the verdict, the
repository revision under test, and the digest of the assertion set. The ledger path is taken from
``SPB_EVIDENCE_LEDGER``; without it a run-local ledger under a temporary directory is used so the
test suite never writes into the repository on its own. Rows are appended through the same chain
primitive as the run audit ledger, so the evidence ledger is verifiable with ``verify_chain_file``.
"""
from __future__ import annotations

import os
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from adapters import local_git_adapter as lga
from adapters.archive_adapter import _chain_append, verify_chain_file

REPO_ROOT = Path(__file__).resolve().parent.parent.parent


def ledger_path() -> Path:
    env = os.environ.get("SPB_EVIDENCE_LEDGER")
    if env:
        return Path(env)
    return Path(tempfile.gettempdir()) / "spb-evidence" / "TEST_LEDGER.jsonl"


def revision_under_test() -> str:
    try:
        return subprocess.run(["git", "rev-parse", "HEAD"], cwd=REPO_ROOT, capture_output=True, text=True, check=True).stdout.strip()
    except Exception:  # pragma: no cover
        return "unknown"


def record(scenario_id: str, kind: str, verdict: str, assertions: Mapping[str, Any], *, path: Path | None = None) -> dict[str, Any]:
    """Append one evidence row; returns the chained entry. Never overwrites, never rewrites."""
    p = path or ledger_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    row = {"record_schema": "suite52.evaluation.test_evidence/TestEvidenceRecord", "scenario_id": scenario_id, "kind": kind, "verdict": verdict,
           "revision": revision_under_test(), "assertions_hash": lga.sha256_digest(lga.canonical_json(assertions)), "assertion_count": len(assertions), "at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    return _chain_append(p, row)


def verify(path: Path | None = None) -> int:
    return verify_chain_file(path or ledger_path())


__all__ = ["ledger_path", "record", "revision_under_test", "verify"]
