"""The vendored redaction core (adapters/vendor_redaction.py; MIT, amplifier-bundle-redaction) is verified two ways:
its bytes below the provenance header still match the donor digest recorded in THIRD-PARTY-NOTICES.md, and the donor's own
public-API tests (tests/vendor/redaction/, copied verbatim) pass against the copy through a unittest wrapper."""
from __future__ import annotations

import hashlib
import importlib.util
import sys
import types
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import vendor_redaction as R  # noqa: E402

DONOR_SHA256 = "63463694d9f1f8cdb7701a1b1023721858687a3514be92fd3bec213eb95c9652"
VENDOR_DIR = HERE / "vendor" / "redaction"


def _donor_tests():
    sys.modules.setdefault("redaction", R)  # the donor tests import the package by its upstream name
    for name in ("test_mask_text", "test_token_patterns"):
        spec = importlib.util.spec_from_file_location(f"vendor_redaction_{name}", VENDOR_DIR / f"{name}.py")
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        for attr in sorted(dir(mod)):
            obj = getattr(mod, attr)
            if attr.startswith("test_") and isinstance(obj, types.FunctionType):
                yield f"{name}.{attr}", obj
            elif attr.startswith("Test") and isinstance(obj, type):
                inst = obj()
                for m in sorted(dir(obj)):
                    if m.startswith("test_") and callable(getattr(inst, m)):
                        yield f"{name}.{attr}.{m}", getattr(inst, m)


class TestVendoredRedaction(unittest.TestCase):
    def test_bytes_match_donor_digest(self) -> None:
        src = Path(R.__file__).read_bytes()
        body = src[src.index(b'"""'):]  # everything from the donor's own module docstring onward
        self.assertEqual(hashlib.sha256(body).hexdigest(), DONOR_SHA256, "vendored module body differs from the donor bytes")
        self.assertTrue(src.startswith(b"# Scoped PR Builder"))

    def test_public_api(self) -> None:
        secret = "ghp_" + "ABCdef0123456789XYZ"
        self.assertEqual(R.mask_text(f"token {secret}"), "token [REDACTED:SECRET]")
        self.assertEqual(R.mask_text("sha256:" + "a" * 64), "sha256:" + "a" * 64)
        self.assertEqual(R.scrub({"note": f"x {secret}", "id": "sha256:" + "b" * 64})["id"], "sha256:" + "b" * 64)

    def test_donor_suites_pass_against_the_copy(self) -> None:
        ran = 0
        for name, fn in _donor_tests():
            with self.subTest(donor_test=name):
                fn()
            ran += 1
        self.assertGreaterEqual(ran, 30)


if __name__ == "__main__":
    unittest.main()
