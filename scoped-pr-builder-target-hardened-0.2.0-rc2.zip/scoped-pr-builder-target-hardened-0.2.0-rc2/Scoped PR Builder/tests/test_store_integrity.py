"""Store integrity evidence (Phase 07 / STORE-*-T05; stdlib unittest), driven by tests/scenarios/stores.json.

For every declared store: create/read/replay, conflicting write, partial write, retention/deletion (tombstone or
refusal for immutable stores, TTL purge, legal hold), tamper attempt and recovery (checkpoint → loss → restore), plus the
records bound from one real workflow run. Every case leaves a chained receipt on the test/evidence ledger
(``SPB_EVIDENCE_LEDGER``; run-local otherwise) carrying the ledger heads and material hashes it observed.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import evidence_ledger as EL  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import store as S  # noqa: E402
from test_store import PROV, payload_for  # noqa: E402
from test_workflow import Driver  # noqa: E402

SCENARIOS = HERE / "scenarios" / "stores.json"


class TestStoreIntegrity(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.st = S.load_stores(registry=self.reg)
        self.scen = json.loads(SCENARIOS.read_text(encoding="utf-8")).get("scenarios", {}) if SCENARIOS.is_file() else {}
        if not self.scen:
            self.skipTest("no store scenarios yet")
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.rows = 0

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def _receipt(self, sid: str, case: str, body: dict, verdict: str = "PASS") -> None:
        EL.record(f"store:{sid}:{case}", "store_integrity", verdict, {"store_id": sid, "case": case, **body})
        self.rows += 1

    def _fresh(self, name: str) -> S.Store:
        return S.Store(self.base / name, stores=self.st, registry=self.reg)

    def test_scenarios(self) -> None:
        active = [sid for sid in self.st["stores"] if f"store:{sid}" in self.scen]
        # ---- bound from one real run (all active stores at once) ---------------------------------------------------
        d = Driver(self.base / "wf", self.reg)
        r = d.drive("WF-11")
        self.assertEqual(r["outcome"], "SUCCEEDED", r["reason"])
        bound = S.Store(d.run_dir, stores=self.st, registry=self.reg)
        out = S.bind_run(bound, d.run_dir, only=active)
        for sid in active:
            with self.subTest(store=sid, case="bound_from_run"):
                self.assertGreater(out[sid]["written"], 0)
                self._receipt(sid, "bound_from_run", {"written": out[sid]["written"], "rows": out[sid]["rows"], "head": bound.head(sid), "material_hash": bound.material_hash(sid), "run_id": d.run.run_id})
        for sid in active:
            s = self.st["stores"][sid]; w = s["ownership"]["writers"][0]; sc = self.scen[f"store:{sid}"]
            store = self._fresh(sid.lower())
            # create / read / replay ----------------------------------------------------------------------------------
            with self.subTest(store=sid, case="create_read_replay"):
                r1 = store.put(sid, payload_for(self.st, sid, 1), writer=w, provenance=PROV)
                self.assertEqual(store.get(sid, r1["record_id"])["record_hash"], r1["record_hash"])
                again = self._fresh(sid.lower())
                self.assertEqual(again.material_hash(sid), store.material_hash(sid)); self.assertEqual(again.head(sid), r1["entry_hash"])
                self._receipt(sid, "create_read_replay", {"record_id": r1["record_id"], "head": r1["entry_hash"], "material_hash": store.material_hash(sid)})
            # conflicting write --------------------------------------------------------------------------------------
            with self.subTest(store=sid, case="conflicting_write"):
                with self.assertRaises(lga.AdapterError) as ctx:
                    store.put(sid, payload_for(self.st, sid, 2), writer=w, provenance=PROV, expected_head="genesis")
                self.assertEqual(ctx.exception.code, "store.conflict"); self.assertEqual(len(store.rows(sid)), 1)
                self._receipt(sid, "conflicting_write", {"refused_with": ctx.exception.code, "rows_after": 1})
            # partial write ------------------------------------------------------------------------------------------
            with self.subTest(store=sid, case="partial_write"):
                p = store.path(sid); p.write_text(p.read_text(encoding="utf-8") + '{"torn": tr', encoding="utf-8")
                with self.assertRaises(lga.AdapterError) as ctx:
                    store.rows(sid)
                rep = store.recover(sid)
                self.assertEqual(rep["verdict"], "RECOVERED"); self.assertEqual(rep["rows"], 1); self.assertEqual(rep["quarantined"], 1)
                self._receipt(sid, "partial_write", {"refused_with": ctx.exception.code, "recovery": rep["verdict"], "rows": rep["rows"], "quarantined": rep["quarantined"]})
            # retention / deletion -----------------------------------------------------------------------------------
            with self.subTest(store=sid, case="retention_deletion"):
                rid = r1["record_id"]
                if s["retention"]["mode"] == "append_only_tombstone":
                    w6 = self.st["stores"]["STORE-06"]["ownership"]["writers"][0]
                    store.set_legal_hold(sid, rid, hold=True, writer=w6, provenance=PROV, reason="hold")
                    with self.assertRaises(lga.AdapterError) as ctx:
                        store.tombstone(sid, rid, writer=w, reason="delete")
                    self.assertEqual(ctx.exception.code, "store.legal_hold")
                    store.set_legal_hold(sid, rid, hold=False, writer=w6, provenance=PROV, reason="released")
                    t = store.tombstone(sid, rid, writer=w, reason="delete")
                    self.assertIsNone(store.get(sid, rid)); self.assertEqual(t["tombstone"]["payload_hash_retained"], r1["payload_hash"])
                    r3 = store.put(sid, payload_for(self.st, sid, 3), writer=w, provenance=PROV, retention={"ttl_days": 1})
                    purged = store.purge_expired(sid, writer=w, now="2999-01-01T00:00:00+00:00")
                    self.assertIn(r3["record_id"], purged["purged"])
                    body = {"mode": s["retention"]["mode"], "legal_hold_refused": "store.legal_hold", "tombstoned": rid, "ttl_purged": r3["record_id"], "rows_retained": len(store.rows(sid))}
                else:
                    with self.assertRaises(lga.AdapterError) as ctx:
                        store.tombstone(sid, rid, writer=w, reason="delete")
                    self.assertEqual(ctx.exception.code, "store.immutable"); self.assertIsNotNone(store.get(sid, rid))
                    body = {"mode": s["retention"]["mode"], "deletion_refused": ctx.exception.code, "rows_retained": len(store.rows(sid))}
                self._receipt(sid, "retention_deletion", body)
            # tamper attempt -----------------------------------------------------------------------------------------
            with self.subTest(store=sid, case="tamper_attempt"):
                p = store.path(sid); lines = p.read_text(encoding="utf-8").splitlines(); e = json.loads(lines[0]); e["payload"]["note"] = "tampered"; lines[0] = lga.canonical_json(e)
                p.write_text("\n".join(lines) + "\n", encoding="utf-8")
                with self.assertRaises(lga.AdapterError) as ctx:
                    store.rows(sid)
                rep = store.recover(sid)
                self.assertEqual(rep["verdict"], "TAMPERED" if len(lines) > 1 else "RECOVERED"); self.assertGreaterEqual(rep["quarantined"], 1)
                self._receipt(sid, "tamper_attempt", {"refused_with": ctx.exception.code, "recovery": rep["verdict"], "rows_kept": rep["rows"], "quarantined": rep["quarantined"]})
            # recovery from checkpoint ---------------------------------------------------------------------------------
            with self.subTest(store=sid, case="recovery"):
                store2 = self._fresh(sid.lower() + "-ck")
                rr = store2.put(sid, payload_for(self.st, sid, 9), writer=w, provenance=PROV)
                man = store2.checkpoint(self.base / (sid.lower() + "-ckpt"))
                os.remove(store2.path(sid))
                res = store2.restore(self.base / (sid.lower() + "-ckpt"))
                self.assertEqual(res["restored"], [f"{sid}.jsonl"]); self.assertEqual(store2.head(sid), rr["entry_hash"])
                self._receipt(sid, "recovery", {"checkpoint_hash": man["checkpoint_hash"], "restored": res["restored"], "head_after": store2.head(sid)})
        self.assertGreaterEqual(EL.verify(), self.rows)

    def test_scenarios_are_well_formed(self) -> None:
        for sid, sc in self.scen.items():
            with self.subTest(scenario=sid):
                self.assertIn(sc["store_id"], self.st["stores"]); self.assertTrue(sc["receipt_requirements"])
                self.assertEqual(set(sc["cases"]), {"bound_from_run", "create_read_replay", "conflicting_write", "partial_write", "retention_deletion", "tamper_attempt", "recovery"})


if __name__ == "__main__":
    unittest.main()
