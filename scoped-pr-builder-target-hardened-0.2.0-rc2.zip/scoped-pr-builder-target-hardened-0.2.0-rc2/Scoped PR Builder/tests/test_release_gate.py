"""Production readiness: eight release-gate assertions over the tool's own chained evidence (T01–T05).

Every test here runs against the real archived evidence ledger, not a fixture — the point of this gate is what it
says about this tool, and a gate tested only against invented receipts would prove nothing about it.
"""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from adapters import contracts as C  # noqa: E402
from adapters import release_gate as R  # noqa: E402
from adapters.archive_adapter import _chain_append  # noqa: E402

_S: dict = {}


def _state():
    """Shared state, built lazily: the receipt collection and binding machinery arrive in a later wave than the
    registry loader, so the registry tests must not depend on them existing yet."""
    if not _S:
        reg = C.load_registry()
        _S.update({"reg": reg, "readiness": R.load_readiness(registry=reg)})
        _S["rows"] = R.ledger_rows() if hasattr(R, "ledger_rows") else []
        _S["bindings"] = R.binding_fragments(registry=reg) if hasattr(R, "binding_fragments") else {}
    return _S


def _ledger_of(rows, drop_kind=None, mutate=None):
    """A chained ledger built from `rows`, optionally without one kind or with each row mutated.

    The chain is rebuilt so it still verifies: these fixtures change what evidence EXISTS, never whether the ledger
    is intact — a broken chain is a different failure, tested separately.
    """
    p = Path(tempfile.mkdtemp()) / "TEST_LEDGER.jsonl"
    for r in rows:
        if drop_kind and r.get("kind") == drop_kind:
            continue
        body = {k: v for k, v in r.items() if k not in ("prev_hash", "entry_hash")}
        _chain_append(p, mutate(body) if mutate else body)
    return p


class RegistryTests(unittest.TestCase):
    """T01 — eight assertions, each naming the exact receipts that satisfy it."""

    def setUp(self):
        self.m = _state()["readiness"]

    def test_every_declared_assertion_is_complete(self):
        self.assertTrue(self.m["assertions"])
        for aid, a in self.m["assertions"].items():
            self.assertIn(aid, R.ASSERTION_IDS)
            for key in R.ASSERTION_REQUIRED:
                self.assertIn(key, a, f"{aid} lacks {key}")
            self.assertTrue(a["evidence"], aid)

    def test_an_assertion_with_no_evidence_selector_is_refused(self):
        bad = json.loads(json.dumps({k: v for k, v in self.m.items() if k != "computed_hash"}))
        bad["assertions"]["PROD-01"]["evidence"] = []
        p = Path(tempfile.mkdtemp()) / "READINESS.json"
        p.write_text(json.dumps(bad), encoding="utf-8")
        with self.assertRaises(R.ReleaseRefusal) as cm:
            R.load_readiness(p)
        self.assertEqual(cm.exception.code, "release.evidence_undeclared")

    def test_a_selector_naming_an_unknown_binding_is_refused(self):
        bad = json.loads(json.dumps({k: v for k, v in self.m.items() if k != "computed_hash"}))
        bad["assertions"]["PROD-01"]["evidence"][0]["binds_to"] = "not_a_registry"
        p = Path(tempfile.mkdtemp()) / "READINESS.json"
        p.write_text(json.dumps(bad), encoding="utf-8")
        with self.assertRaises(R.ReleaseRefusal) as cm:
            R.load_readiness(p)
        self.assertEqual(cm.exception.code, "release.selector_invalid")

    def test_an_unbound_suite_is_refused(self):
        bad = json.loads(json.dumps({k: v for k, v in self.m.items() if k != "computed_hash"}))
        bad["assertions"]["PROD-01"]["authoritative_suites"] = ["Suite99/nope.jaops"]
        p = Path(tempfile.mkdtemp()) / "READINESS.json"
        p.write_text(json.dumps(bad), encoding="utf-8")
        with self.assertRaises(R.ReleaseRefusal) as cm:
            R.load_readiness(p)
        self.assertEqual(cm.exception.code, "release.suite_unbound")


class CollectionTests(unittest.TestCase):
    """T02 — receipts are collected by immutable id and binding hash, never by status text."""

    def setUp(self):
        s = _state()
        self.m, self.rows, self.b = s["readiness"], s["rows"], s["bindings"]

    def test_the_ledger_chain_is_verified_before_any_receipt_is_read(self):
        p = _ledger_of(self.rows[:20])
        lines = p.read_text(encoding="utf-8").splitlines()
        row = json.loads(lines[5]); row["verdict"] = "FAIL"; row["assertion_count"] = 0; lines[5] = json.dumps(row)
        p.write_text("\n".join(lines) + "\n", encoding="utf-8")
        with self.assertRaises(R.ReleaseRefusal) as cm:
            R.ledger_rows(p)
        self.assertEqual(cm.exception.code, "release.ledger_broken")

    def test_every_binding_resolves_to_the_fragment_its_receipts_carry(self):
        used = {sel["binds_to"] for a in self.m["assertions"].values() for sel in a["evidence"] if sel["binds_to"]}
        self.assertTrue(used)
        for name in used:
            self.assertIsNotNone(self.b[name]["fragments"], f"{name} could not be read")
            found = R.collect({"kind": "x", "id_prefix": "x", "binds_to": name, "min_receipts": 1},
                              self.rows, self.b)
            self.assertTrue(found["acceptable_fragments"], name)

    def test_a_receipt_bound_to_a_superseded_registry_reads_as_stale(self):
        moved = {k: dict(v) for k, v in self.b.items()}
        moved["matrix"] = {"fragments": ["0" * 32], "binding": "a registry that has since changed"}
        sel = {"kind": "qualification_scenario", "id_prefix": "qualification:", "binds_to": "matrix",
               "min_receipts": 1}
        found = R.collect(sel, self.rows, moved)
        self.assertEqual(found["current"], 0)
        self.assertGreater(found["stale"], 0)
        self.assertEqual(R.classify(found)[0], "stale")

    def test_a_not_applicable_receipt_is_neither_evidence_for_nor_against(self):
        found = R.collect({"kind": "intake_fixture", "id_prefix": "intake:", "binds_to": None, "min_receipts": 1},
                          self.rows, self.b)
        self.assertGreater(found["neutral"], 0, "the ledger holds not-applicable receipts to reason about")
        self.assertEqual(R.classify(found)[0], "satisfied")
        self.assertEqual(found["passing"] + found["neutral"], found["current"])
        starved = dict(found, min_receipts=found["passing"] + 1)
        self.assertEqual(R.classify(starved)[0], "indeterminate")

    def test_a_failing_receipt_makes_the_evidence_conflicting(self):
        p = _ledger_of(self.rows, mutate=lambda r: dict(r, verdict="FAIL")
                       if r.get("kind") == "review_e2e" else r)
        found = R.collect({"kind": "review_e2e", "id_prefix": "review:", "binds_to": "review", "min_receipts": 1},
                          R.ledger_rows(p), self.b)
        status, why = R.classify(found)
        self.assertEqual(status, "conflicting")
        self.assertIn("FAIL", why)


class GateTests(unittest.TestCase):
    """T03 — anything but satisfied blocks GO, and the gate says what would unblock it."""

    def setUp(self):
        self.s = _state()

    def _need(self, *aids):
        missing = [a for a in aids if a not in self.s["readiness"]["assertions"]]
        if missing:
            self.skipTest(f"{missing} not declared yet in this wave")

    def test_the_gate_reaches_go_on_the_tools_own_current_evidence(self):
        """The whole point of the gate: on this tool's own archived evidence, does it say GO?

        Skipped while the readiness registry is still being assembled, because PROD-08's receipt binds to that
        registry — publishing the limitations mid-wave would make the receipt stale at the very next item, so
        `absent` is the correct reading until the registry is final and the document is published. The skip names
        that; it never passes on an unpublished release.
        """
        d = R.gate(registry=self.s["reg"])
        if len(self.s["readiness"]["assertions"]) < len(R.ASSERTION_IDS):
            self.skipTest(f"the readiness registry is still being assembled "
                          f"({len(self.s['readiness']['assertions'])} of {len(R.ASSERTION_IDS)} assertions declared)")
        if d["blocking"] == ["PROD-08"]:
            self.skipTest("the limitations document has not been published yet; PROD-08 is correctly `absent` and "
                          "the gate is correctly NO_GO — publish with release_gate.publish_limitations and archive "
                          "the receipt, then this asserts GO")
        self.assertEqual(d["decision"], "GO",
                         f"blocking {d['blocking']}: {[r['why'] for r in R.remediation_list(d)][:4]}")
        self.assertEqual(d["blocking"], [])
        self.assertEqual(sorted(d["per_assertion"]), sorted(self.s["readiness"]["assertions"]))
        self.assertIn("evidence_only", d["authority"])

    def test_absent_evidence_blocks_and_names_its_remediation(self):
        self._need("PROD-05")
        p = _ledger_of(self.s["rows"], drop_kind="review_e2e")
        d = R.gate(ledger=p, registry=self.s["reg"])
        self.assertEqual(d["decision"], "NO_GO")
        self.assertIn("PROD-05", d["blocking"])
        rem = R.remediation_list(d)
        self.assertTrue(rem)
        self.assertTrue(all(r["do"] for r in rem))
        self.assertIn("absent", {r["status"] for r in rem})
        with self.assertRaises(R.ReleaseRefusal) as cm:
            R.require_go(ledger=p, registry=self.s["reg"])
        self.assertEqual(cm.exception.code, "release.gate_blocked")

    def test_conflicting_evidence_blocks_even_when_a_pass_is_present(self):
        self._need("PROD-05")
        rows = list(self.s["rows"])
        first = next(r for r in rows if r.get("kind") == "review_e2e")
        broken = dict(first, verdict="FAIL")
        p = _ledger_of(rows + [broken])
        d = R.gate(ledger=p, registry=self.s["reg"])
        self.assertEqual(d["decision"], "NO_GO")
        self.assertIn("PROD-05", d["blocking"])
        self.assertIn("conflicting", {r["status"] for r in R.remediation_list(d)})

    def test_a_waiver_shaped_input_blocks_wherever_it_appears(self):
        if not self.s["readiness"]["assertions"]:
            self.skipTest("no assertion declared yet in this wave")
        for label, inputs in [("top level", {"force": True}),
                              ("value", {"mode": "bypass_gate"}),
                              ("nested", {"ci": {"options": {"skip_checks": "true"}}}),
                              ("list", {"flags": ["--override-gate"]})]:
            with self.subTest(label):
                d = R.gate(inputs=inputs, registry=self.s["reg"])
                self.assertEqual(d["decision"], "NO_GO")
                self.assertTrue(d["waivers_refused"])
                statuses = {v["status"] for v in d["detail"].values()}
                self.assertIn("waived_without_authority", statuses)

    def test_every_blocking_status_has_a_remediation(self):
        for status in R.BLOCKING_STATUSES:
            self.assertIn(status, R.REMEDIATION, f"{status} blocks with nothing to do about it")

    def test_an_assertion_is_satisfied_only_when_all_of_its_evidence_is(self):
        d = R.gate(registry=self.s["reg"])
        for aid, v in d["detail"].items():
            statuses = {s["status"] for s in v["selectors"]}
            self.assertEqual(v["status"] == "satisfied", statuses == {"satisfied"}, aid)


class ReleaseRecordTests(unittest.TestCase):
    """T04 — the decision is recorded with the versions, approvals, residual risks, limitations and rollback state."""

    def setUp(self):
        self.s = _state()
        self.root = Path(tempfile.mkdtemp())
        (self.root / "release").mkdir(parents=True)
        self.d = R.gate(registry=self.s["reg"])

    def test_the_record_carries_everything_a_later_reader_needs(self):
        rec = R.record_decision(self.d, root=self.root, registry=self.s["reg"],
                                approvals=[{"identity": "release-manager@example", "channel": "cli",
                                            "rationale": "evidence reviewed; accepting the XSEC-04 host requirement"}])
        for key in R.RECORD_REQUIRED:
            self.assertIn(key, rec, key)
        self.assertEqual(rec["decision"], self.d["decision"])
        self.assertEqual(rec["decision_hash"], self.d["decision_hash"])
        self.assertEqual(len(rec["approvals"]), 1)
        self.assertTrue(rec["evaluator_versions"]["release_gate"].startswith(R.ADAPTER_ID))
        self.assertEqual(len(R.release_records(self.root)), 1)

    def test_approvals_are_recorded_never_manufactured(self):
        with self.assertRaises(Exception) as cm:
            R.record_decision(self.d, root=self.root, registry=self.s["reg"],
                              approvals=[{"identity": "planner", "channel": "model", "rationale": "looks good"}])
        self.assertEqual(getattr(cm.exception, "code", ""), "security.sec07.model_channel")
        with self.assertRaises(R.ReleaseRefusal) as cm2:
            R.record_decision(self.d, root=self.root, registry=self.s["reg"],
                              approvals=[{"identity": "rm@example", "channel": "cli", "rationale": "  "}])
        self.assertEqual(cm2.exception.code, "release.approval_incomplete")

    def test_go_requires_human_readiness_approval(self):
        if self.d["decision"] == "GO":
            with self.assertRaises(R.ReleaseRefusal) as cm:
                R.record_decision(self.d, root=self.root, registry=self.s["reg"])
            self.assertEqual(cm.exception.code, "release.human_approval_required")
        else:
            rec = R.record_decision(self.d, root=self.root, registry=self.s["reg"])
            self.assertEqual(rec["approvals"], [])
            self.assertEqual(rec["decision"], self.d["decision"])

    def test_residual_risks_are_read_from_the_declarations_not_written_by_hand(self):
        risks = R.residual_risks(self.d)
        self.assertTrue(risks, "a GO with no residual risks would claim nothing is left to know")
        kinds = {r["kind"] for r in risks}
        self.assertIn("host_requirement", kinds)
        host = [r for r in risks if r["kind"] == "host_requirement"]
        self.assertEqual([r["id"] for r in host], ["XSEC-04"])
        self.assertTrue(all(r["detail"] for r in host))

    def test_rollback_readiness_is_read_from_receipts_not_from_a_runbook(self):
        rb = R.rollback_readiness()
        self.assertTrue(rb["exercised"])
        self.assertGreater(rb["evidence"]["workflow_integration"], 0)
        self.assertGreater(rb["evidence"]["environment_smoke"], 0)
        empty = R.rollback_readiness(ledger=_ledger_of([r for r in self.s["rows"]
                                                        if r.get("kind") not in ("workflow_integration",
                                                                                 "environment_smoke")]))
        self.assertFalse(empty["exercised"])
        self.assertIn("cannot be claimed", empty["statement"])

    def test_the_release_ledger_is_chained(self):
        approvals=[{"identity":"release-manager@example","channel":"cli","rationale":"reviewed"}] if self.d["decision"] == "GO" else []
        R.record_decision(self.d, root=self.root, registry=self.s["reg"], approvals=approvals)
        R.record_decision(self.d, root=self.root, registry=self.s["reg"], approvals=approvals)
        rows = R.release_records(self.root)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[1]["prev_hash"], rows[0]["entry_hash"])


class BypassResistanceTests(unittest.TestCase):
    """T05 — a deliberate gate-failure fixture and a complete passing fixture, proving the decision follows the
    receipts alone: not model output, not a worker's status, not what a UI happens to render."""

    def setUp(self):
        self.s = _state()
        if not self.s["readiness"]["assertions"]:
            self.skipTest("no assertion declared yet in this wave")

    def _complete(self):
        d = R.gate(registry=self.s["reg"])
        if d["blocking"] in ([], ["PROD-08"]):
            return d
        self.skipTest(f"the passing fixture is not complete in this wave: blocking {d['blocking']}")

    def test_the_complete_passing_fixture_reaches_go(self):
        d = R.gate(registry=self.s["reg"])
        if len(self.s["readiness"]["assertions"]) < len(R.ASSERTION_IDS) or d["blocking"] == ["PROD-08"]:
            self.skipTest("the readiness registry is still being assembled, or the limitations are not yet published")
        self.assertEqual(d["decision"], "GO", d["blocking"])
        self.assertEqual(d["waivers_refused"], [])

    def test_the_deliberate_failure_fixture_reaches_no_go(self):
        p = _ledger_of(self.s["rows"], drop_kind="qualification_scenario")
        d = R.gate(ledger=p, registry=self.s["reg"])
        self.assertEqual(d["decision"], "NO_GO")
        resting = {a for a, v in self.s["readiness"]["assertions"].items()
                   if any(sel["kind"] == "qualification_scenario" for sel in v["evidence"])}
        self.assertTrue(resting <= set(d["blocking"]), f"{resting - set(d['blocking'])} rest on the removed evidence")

    def test_no_bypass_of_the_passing_fixture(self):
        base = self._complete()
        proof = R.assert_no_bypass(base, registry=self.s["reg"])
        self.assertEqual(proof["verdict"], "NO_BYPASS")
        self.assertEqual(sorted(proof["vectors"]), sorted(R.BYPASS_VECTORS))
        self.assertTrue(all(v["unchanged"] for v in proof["vectors"].values()))

    def test_no_bypass_of_the_failing_fixture(self):
        """The direction that matters: model output, a green worker and a green UI must not turn NO_GO into GO."""
        p = _ledger_of(self.s["rows"], drop_kind="qualification_scenario")
        base = R.gate(ledger=p, registry=self.s["reg"])
        self.assertEqual(base["decision"], "NO_GO")
        proof = R.assert_no_bypass(base, ledger=p, registry=self.s["reg"])
        self.assertEqual(proof["verdict"], "NO_BYPASS")
        for vector, v in proof["vectors"].items():
            self.assertEqual(v["decision"], "NO_GO", f"{vector} turned a NO_GO into {v['decision']}")

    def test_a_bypass_that_changed_the_decision_would_be_caught(self):
        base = R.gate(registry=self.s["reg"])
        flipped = "GO" if base["decision"] == "NO_GO" else "NO_GO"
        with self.assertRaises(R.ReleaseRefusal) as cm:
            R.assert_no_bypass(dict(base, decision=flipped), registry=self.s["reg"])
        self.assertEqual(cm.exception.code, "release.bypass_possible")

    def test_every_declared_bypass_vector_is_exercised(self):
        for vector in R.BYPASS_VECTORS:
            payload = R.bypass_attempt(vector)
            self.assertTrue(payload)
            self.assertEqual(R._waivers(payload), [],
                             "these vectors must be subtler than a waiver keyword — they assert the outcome rather "
                             "than asking for it to be skipped")
        with self.assertRaises(R.ReleaseRefusal):
            R.bypass_attempt("some_vector_nobody_declared")


class LimitationsTests(unittest.TestCase):
    """T05 — the published limitations, and the check that keeps them from drifting from the declarations."""

    def setUp(self):
        self.s = _state()
        if not (R.OVERLAY_ROOT / R.LIMITATIONS_PATH).is_file():
            self.skipTest("the limitations document is not published yet in this wave")

    def test_every_declared_limitation_is_published(self):
        v = R.verify_limitations(registry=self.s["reg"])
        self.assertGreaterEqual(v["published"], len(R.NON_GOALS))
        self.assertEqual(v["host_requirements"], ["XSEC-04"])

    def test_the_document_is_generated_from_the_declarations(self):
        text = R.render_limitations(registry=self.s["reg"])
        for i in R.declared_limitations(registry=self.s["reg"]):
            self.assertIn(i["id"], text, f"{i['id']} is declared but not rendered")
        self.assertIn(self.s["readiness"]["computed_hash"], text)

    def test_an_unpublished_limitation_is_caught(self):
        root = Path(tempfile.mkdtemp())
        (root / "release").mkdir(parents=True)
        text = R.render_limitations(registry=self.s["reg"])
        (root / R.LIMITATIONS_PATH).write_text(text.replace("NON-GOAL-04", "NON-GOAL-XX"), encoding="utf-8")
        with self.assertRaises(R.ReleaseRefusal) as cm:
            R.verify_limitations(root=root, registry=self.s["reg"])
        self.assertEqual(cm.exception.code, "release.limitations_incomplete")
        self.assertIn("NON-GOAL-04", str(cm.exception))

    def test_a_document_that_names_no_readiness_registry_is_caught(self):
        root = Path(tempfile.mkdtemp())
        (root / "release").mkdir(parents=True)
        text = R.render_limitations(registry=self.s["reg"]).replace(self.s["readiness"]["computed_hash"], "sha256:" + "0" * 64)
        (root / R.LIMITATIONS_PATH).write_text(text, encoding="utf-8")
        with self.assertRaises(R.ReleaseRefusal) as cm:
            R.verify_limitations(root=root, registry=self.s["reg"])
        self.assertIn("readiness registry", str(cm.exception))

    def test_publishing_generates_the_document_and_verifies_it(self):
        root = Path(tempfile.mkdtemp())
        v = R.publish_limitations(root=root, registry=self.s["reg"])
        self.assertTrue((root / R.LIMITATIONS_PATH).is_file())
        self.assertEqual(v["host_requirements"], ["XSEC-04"])

    def test_an_absent_document_is_caught(self):
        with self.assertRaises(R.ReleaseRefusal) as cm:
            R.verify_limitations(root=Path(tempfile.mkdtemp()), registry=self.s["reg"])
        self.assertEqual(cm.exception.code, "release.limitations_unpublished")

    def test_the_receipt_binds_to_the_readiness_registry(self):
        rid = R.gate_limitations_id(self.s["readiness"])
        self.assertTrue(rid.startswith("limitations:published@"))
        self.assertIn(self.s["readiness"]["computed_hash"][7:39], rid)

    def test_the_published_limitations_are_archived_as_evidence(self):
        """The gate reads this receipt for PROD-08, so it is written to the tool's own chained ledger."""
        import evidence_ledger as EL
        v = R.verify_limitations(registry=self.s["reg"])
        row = EL.record(v["receipt_id"], R.EVIDENCE_KIND, "PASS",
                        {"published": v["published"], "host_requirements": v["host_requirements"],
                         "non_goals": v["non_goals"], "document_hash": v["document_hash"],
                         "readiness_hash": v["readiness_hash"]})
        self.assertEqual(row["verdict"], "PASS")
        self.assertEqual(row["kind"], R.EVIDENCE_KIND)


if __name__ == "__main__":
    unittest.main()
