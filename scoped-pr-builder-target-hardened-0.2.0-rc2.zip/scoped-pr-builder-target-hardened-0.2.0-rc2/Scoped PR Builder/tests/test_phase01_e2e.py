"""Phase 01 cross-layer contract tests (T05; stdlib unittest), driven by tests/scenarios/*.json.

boundaries.json  ARCH-*-T05  one end-to-end scenario per boundary: identity preservation across every admitted
                             crossing, provenance closure (chain verified, head == last envelope ref, parent links
                             contiguous), absence of unauthorized effects (no admitted effect outside the boundary's
                             allowed set; every refused step is on the ledger with its class).
controls.json    IMPL-*-T05  focused unit cases plus one end-to-end scenario per control proving the allowed path and
                             the blocking/abstention path, with review/audit exposure.
api.json         API-*-T05   schema conformance, backward/forward compatibility, invalid-payload and replay cases per
                             API contract; every result is stored on the test/evidence ledger.
"""
from __future__ import annotations

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from adapters import architecture as A  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import controls as K  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import wiring as W  # noqa: E402
import evidence_ledger as EL  # noqa: E402

REPO_ROOT = HERE.parent.parent
SCENARIOS = HERE / "scenarios"


def _load(name):
    p = SCENARIOS / name
    return json.loads(p.read_text(encoding="utf-8")) if p.is_file() else {}


def _identity(reg):
    return copy.deepcopy(reg["contracts"]["api_envelope"]["examples"]["valid"]["identity"])


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.b = A.load_boundaries(registry=self.reg)
        self.w = W.load_wiring(boundaries=self.b, registry=self.reg)
        self.tmp = tempfile.TemporaryDirectory()

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def new_run(self, name):
        run = W.Run(Path(self.tmp.name) / name, _identity(self.reg), repo_root=REPO_ROOT, registry=self.reg, boundaries=self.b, wiring=self.w)
        try:  # Phase 02: guarded effects cross with satisfied guardrails here; blocking paths are covered by the guardrail suites
            from adapters import guardrails as GR
            rules = GR.load_rules(registry=self.reg)
            orig = run.cross

            def cross(bid, effect, cid, payload, **kw):
                if "guardrail_facts" not in kw:
                    kw["guardrail_facts"] = {rid: r["examples"]["pass"] for rid, r in rules["rules"].items() if effect in r["evaluates_on"]}
                return orig(bid, effect, cid, payload, **kw)
            run.cross = cross
        except Exception:
            pass
        return run

    def evidence(self, sid, kind, verdict, assertions):
        return EL.record(sid, kind, verdict, assertions)


class TestBoundaryScenarios(Base):
    """ARCH-*-T05."""

    def test_boundary_scenarios(self) -> None:
        scen = _load("boundaries.json").get("scenarios", {})
        if not scen:
            self.skipTest("no boundary scenarios yet")
        for sid, sc in scen.items():
            with self.subTest(scenario=sid):
                bid = sc["boundary_id"]
                entry = self.b["boundaries"][bid]
                run = self.new_run(f"b-{bid}")
                envelopes, refused, assertions = [], [], {}
                for i, step in enumerate(sc["steps"]):
                    kwargs = {"direction": step.get("direction", "inbound")}
                    if step.get("declared_version"):
                        kwargs["declared_version"] = step["declared_version"]
                    ident = None
                    if step.get("identity_override"):
                        ident = run.current_identity(); ident.update(step["identity_override"])
                        if step["identity_override"].get("provenance_ref") == "@previous":
                            ident["provenance_ref"] = envelopes[-1]["provenance_link"]["parent_ref"] if envelopes else run.provenance_head
                    if ident is not None:
                        kwargs["identity"] = ident
                    if step.get("idempotent"):
                        kwargs["idempotency_key"] = K.idempotency_key(run.identity["run_id"], f"{bid}.s{i}", {"payload": step.get("payload")})
                    if step["expect"] == "ADMITTED":
                        out = run.cross(bid, step["effect"], step["contract"], step.get("payload"), **kwargs)
                        self.assertEqual(out["crossing"]["verdict"], "ADMITTED")
                        envelopes.append(out)
                        assertions[f"step{i}"] = "ADMITTED"
                    else:
                        with self.assertRaises(lga.AdapterError) as ctx:
                            run.cross(bid, step["effect"], step["contract"], step.get("payload"), **kwargs)
                        self.assertEqual(ctx.exception.code, step["expect"], f"{sid} step {i} ({step.get('why')}): {ctx.exception}")
                        refused.append((step["effect"], ctx.exception.code))
                        assertions[f"step{i}"] = ctx.exception.code
                # identity preservation
                for out in envelopes:
                    for f in entry["identity_policy"]["immutable_across"]:
                        self.assertEqual(out["envelope"]["identity"][f], run.identity[f], f"{sid}: identity field {f} changed across the boundary")
                # provenance closure
                links = run._provenance_links()
                self.assertEqual(len(links), len(envelopes))
                self.assertEqual(run.provenance_head, envelopes[-1]["envelope"]["identity"]["provenance_ref"])
                for prev, link in zip([None] + links[:-1], links):
                    self.assertEqual(link["parent_ref"], prev["entry_hash"] if prev else run.identity.get("provenance_ref"))
                    self.assertEqual(link["boundary_id"], bid)
                # absence of unauthorized effects
                audit = run.audit_entries()
                admitted = [a for a in audit if a["verdict"] == "ADMITTED"]
                self.assertTrue(all(a["effect"] in entry["allowed_effects"] for a in admitted), f"{sid}: an effect outside the allowed set was admitted")
                self.assertFalse(any(a["effect"] in entry["denied_effects"] and a["verdict"] == "ADMITTED" for a in audit))
                denied = [a for a in audit if a["verdict"] == "DENIED"]
                self.assertEqual(len(denied), len(refused))
                self.assertTrue(all(a["denial_class"] in W.FAILURE_CLASSES and a["fail_closed"] for a in denied))
                self.assertEqual(len(envelopes), sc["closure"]["admitted"]); self.assertEqual(len(refused), sc["closure"]["refused"])
                self.evidence(sid, "boundary_e2e", "PASS", assertions)


class TestControlScenarios(Base):
    """IMPL-*-T05."""

    def test_control_scenarios(self) -> None:
        scen = _load("controls.json").get("scenarios", {})
        if not scen:
            self.skipTest("no control scenarios yet")
        for sid, sc in scen.items():
            with self.subTest(scenario=sid):
                cid = sc["control_id"]
                assertions = {}
                for i, case in enumerate(sc["unit"]):
                    if case["expect"] == "ENFORCED":
                        rec = K.run_control(cid, copy.deepcopy(case["input"]), registry=self.reg)
                        self.assertEqual(rec["verdict"], "ENFORCED")
                        for k, v in case.get("assert_result", {}).items():
                            self.assertEqual(rec["result"].get(k), v, f"{sid} unit {i}: result.{k}")
                    else:
                        with self.assertRaises(K.ControlRefusal) as ctx:
                            K.run_control(cid, copy.deepcopy(case["input"]), registry=self.reg)
                        self.assertEqual(ctx.exception.code, case["expect"], f"{sid} unit {i} ({case.get('why')})")
                        self.assertEqual(ctx.exception.failure_record["transition_to"], case.get("transition", "BLOCKED"))
                    assertions[f"unit{i}"] = case["expect"]
                run = self.new_run(f"c-{cid}")
                outcomes = []
                for i, step in enumerate(sc["e2e"]["steps"]):
                    if step["expect"] == "ENFORCED":
                        rec = K.run_control(step["control"], copy.deepcopy(step["input"]), registry=self.reg, run=run)
                        self.assertTrue(rec["exposure"]["exposed"])
                        outcomes.append(("ENFORCED", None))
                    else:
                        with self.assertRaises(K.ControlRefusal) as ctx:
                            K.run_control(step["control"], copy.deepcopy(step["input"]), registry=self.reg, run=run)
                        self.assertEqual(ctx.exception.code, step["expect"], f"{sid} e2e {i}")
                        outcomes.append(("REFUSED", ctx.exception.failure_record["transition_to"]))
                    assertions[f"e2e{i}"] = step["expect"]
                audit = run.audit_entries()
                self.assertEqual([a["verdict"] for a in audit], [o[0] for o in outcomes])
                self.assertEqual(audit[-1]["transition_to"], sc["e2e"]["expect_final_transition"])
                self.assertIn(sc["e2e"]["expect_final_transition"], K.TERMINAL_STATES)
                self.assertTrue(all(a["effect"].startswith("control.") for a in audit))
                self.evidence(sid, "control_e2e", "PASS", assertions)


class TestApiScenarios(Base):
    """API-*-T05."""

    def test_api_scenarios(self) -> None:
        scen = _load("api.json").get("scenarios", {})
        if not scen:
            self.skipTest("no api scenarios yet")
        for sid, sc in scen.items():
            with self.subTest(scenario=sid):
                cid = sc["contract_id"]
                e = self.reg["contracts"][cid]
                assertions = {}
                # schema conformance
                r = C.validate_payload(cid, copy.deepcopy(sc["conformance"]), registry=self.reg)
                self.assertEqual(r["verdict"], "VALID"); assertions["conformance"] = "VALID"
                # invalid payloads
                for i, bad in enumerate(sc["invalid"]):
                    with self.assertRaises(lga.AdapterError) as ctx:
                        C.validate_payload(cid, copy.deepcopy(bad["payload"]), registry=self.reg)
                    self.assertEqual(ctx.exception.code, bad["expect_code"]); assertions[f"invalid{i}"] = ctx.exception.code
                # backward / forward compatibility
                for i, case in enumerate(sc["compatibility"]):
                    self.assertEqual(K.compatibility(case["declared"], e["version"]), case["expect"], f"{sid} compat {i}")
                    assertions[f"compat{i}"] = case["expect"]
                    if case["expect"] != "COMPATIBLE":
                        with self.assertRaises(lga.AdapterError):
                            K.require_compatible(case["declared"], e["version"])
                # replay
                rp = sc["replay"]
                run = self.new_run(f"a-{cid}")
                if rp.get("via_port"):
                    p = rp["via_port"]
                    key = K.idempotency_key(run.identity["run_id"], f"{p['boundary_id']}.replay", {"payload": p["payload"]})
                    first = run.cross(p["boundary_id"], p["effect"], p["contract"], p["payload"], direction=p.get("direction", "inbound"), idempotency_key=key)
                    again = run.cross(p["boundary_id"], p["effect"], p["contract"], p["payload"], direction=p.get("direction", "inbound"), idempotency_key=key)
                    self.assertEqual((first["replay"], again["replay"]), ("EXECUTE", "REPLAY_SAME"))
                    with self.assertRaises(lga.AdapterError) as ctx:
                        run.cross(p["boundary_id"], p["effect"], p["contract"], p["mutated_payload"], direction=p.get("direction", "inbound"), idempotency_key=key)
                    self.assertEqual(ctx.exception.code, "idempotency.conflict")
                    self.assertEqual(sum(1 for a in run.audit_entries() if a.get("idempotency_key") == key and a["verdict"] == "ADMITTED"), 1)
                else:
                    key = K.idempotency_key(run.identity["run_id"], rp["step"], rp["inputs"])
                    h = lga.sha256_digest(lga.canonical_json(sc["conformance"]))
                    ledger = []
                    self.assertEqual(K.replay_check(ledger, key, h), "EXECUTE"); ledger.append({"idempotency_key": key, "result_hash": h})
                    self.assertEqual(K.replay_check(ledger, key, h), "REPLAY_SAME")
                    with self.assertRaises(lga.AdapterError):
                        K.replay_check(ledger, key, "sha256:" + "0" * 64)
                assertions["replay"] = "EXECUTE,REPLAY_SAME,conflict-refused"
                entry = self.evidence(sid, "api_contract", "PASS", assertions)
                self.assertRegex(entry["entry_hash"], r"^sha256:[0-9a-f]{64}$")
        # the evidence ledger itself must verify
        self.assertGreaterEqual(EL.verify(), len(scen))


if __name__ == "__main__":
    unittest.main()
