"""Data-driven tests for control bindings (Phase 01 / IMPL-*-T02; stdlib unittest).

Every registered control that carries a ``binding`` must name a scaffold suite file that exists,
an overlay adapter entry that is callable, and a demo the dispatcher executes: the demo input runs
to an enforced record, and every violating demo input is refused with its recorded code.
"""
from __future__ import annotations

import copy
import importlib
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import contracts as C  # noqa: E402
from adapters import controls as K  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import wiring as W  # noqa: E402

REPO_ROOT = HERE.parent.parent


class TestControlBindings(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.bound = {cid: e for cid, e in self.reg["contracts"].items() if "binding" in e}
        if not self.bound:
            self.skipTest("no control bindings registered yet")

    def test_bindings_point_at_existing_scaffold_and_callable_adapter(self) -> None:
        for cid, e in self.bound.items():
            with self.subTest(control=cid):
                b = e["binding"]
                self.assertTrue((REPO_ROOT / b["scaffold_suite"]).is_file(), b["scaffold_suite"])
                mod, _, fn = b["adapter"].rpartition(".")
                self.assertTrue(callable(getattr(importlib.import_module(f"adapters.{mod}"), fn, None)), b["adapter"])
                self.assertIn(cid, K.CONTROL_HANDLERS, f"{cid}: no run_control handler")

    def test_demo_executes_and_refuses(self) -> None:
        for cid, e in self.bound.items():
            with self.subTest(control=cid):
                demo = e["binding"]["demo"]
                rec = K.run_control(cid, copy.deepcopy(demo["input"]), registry=self.reg)
                self.assertEqual(rec["control_id"], cid)
                self.assertEqual(rec["verdict"], "ENFORCED")
                self.assertRegex(rec["control_hash"], r"^sha256:[0-9a-f]{64}$")
                for i, bad in enumerate(demo["invalid"]):
                    with self.subTest(control=cid, invalid=i):
                        with self.assertRaises(lga.AdapterError) as ctx:
                            K.run_control(cid, copy.deepcopy(bad["input"]), registry=self.reg)
                        self.assertEqual(ctx.exception.code, bad["expect_code"], f"{cid} invalid[{i}] ({bad.get('why')}): {ctx.exception}")

    def test_error_states_and_provenance_fields(self) -> None:
        """IMPL-*-T03: refusals land in declared error states with fail-closed transitions; enforced records carry provenance fields."""
        declared = {cid: e for cid, e in self.bound.items() if "error_states" in e}
        if not declared:
            self.skipTest("no error states declared yet")
        for cid, e in declared.items():
            with self.subTest(control=cid):
                codes = {s["code"]: s for s in e["error_states"]}
                for s in e["error_states"]:
                    self.assertIn(s["transition"], K.TERMINAL_STATES)
                rec = K.run_control(cid, copy.deepcopy(e["binding"]["demo"]["input"]), registry=self.reg)
                for f in e.get("provenance_fields", []):
                    self.assertTrue(f in rec or f in rec["result"], f"{cid}: provenance field {f} missing")
                for i, bad in enumerate(e["binding"]["demo"]["invalid"]):
                    with self.assertRaises(K.ControlRefusal) as ctx:
                        K.run_control(cid, copy.deepcopy(bad["input"]), registry=self.reg)
                    fr = ctx.exception.failure_record
                    self.assertEqual(fr["code"], bad["expect_code"])
                    self.assertIn(fr["transition_to"], K.TERMINAL_STATES)
                    self.assertTrue(fr["code"] in codes or fr["code"] in K.GENERIC_ERROR_STATES, f"{cid}: {fr['code']} not declared")
                    self.assertRegex(fr["failure_hash"], r"^sha256:[0-9a-f]{64}$")
        # an undeclared error can never proceed silently: it is converted into control.undeclared_error (BLOCKED)
        cid = next(iter(declared))
        original = K.CONTROL_HANDLERS[cid]
        K.CONTROL_HANDLERS[cid] = lambda p, r: (_ for _ in ()).throw(lga.AdapterError("mystery.code", "undeclared"))
        try:
            with self.assertRaises(K.ControlRefusal) as ctx:
                K.run_control(cid, copy.deepcopy(declared[cid]["binding"]["demo"]["input"]), registry=self.reg)
            self.assertEqual(ctx.exception.code, "control.undeclared_error")
            self.assertEqual(ctx.exception.failure_record["transition_to"], "BLOCKED")
        finally:
            K.CONTROL_HANDLERS[cid] = original

    def test_exposure_to_review_surface_and_audit_trail(self) -> None:
        """IMPL-*-T04: decision-relevant control results (enforced or refused) reach the review card and the audit chain."""
        exposed = {cid: e for cid, e in self.bound.items() if "review_exposure" in e}
        if not exposed:
            self.skipTest("no review exposure declared yet")
        with tempfile.TemporaryDirectory() as tmp:
            identity = copy.deepcopy(self.reg["contracts"]["api_envelope"]["examples"]["valid"]["identity"])
            run = W.Run(Path(tmp) / "run", identity, repo_root=REPO_ROOT, registry=self.reg)
            for cid, e in exposed.items():
                exp = e["review_exposure"]
                with self.subTest(control=cid):
                    rec = K.run_control(cid, copy.deepcopy(e["binding"]["demo"]["input"]), registry=self.reg, run=run)
                    self.assertTrue(rec["exposure"]["exposed"])
                    frag = rec["exposure"]["fragment"]
                    self.assertEqual(frag["card_section"], exp["card_section"])
                    self.assertEqual(set(frag["fields"]), set(exp["fields"]))
                    self.assertTrue(all(v is not None for v in frag["fields"].values()), f"{cid}: exposed field missing")
                    last = run.audit_entries()[-1]
                    self.assertEqual(last["effect"], exp["audit_effect"]); self.assertEqual(last["verdict"], "ENFORCED")
                    self.assertEqual(last["record_hash"], rec["control_hash"])
                    bad = e["binding"]["demo"]["invalid"][0]
                    with self.assertRaises(K.ControlRefusal) as ctx:
                        K.run_control(cid, copy.deepcopy(bad["input"]), registry=self.reg, run=run)
                    last = run.audit_entries()[-1]
                    self.assertEqual(last["verdict"], "REFUSED"); self.assertEqual(last["denial_code"], ctx.exception.code)
                    self.assertEqual(last["transition_to"], ctx.exception.failure_record["transition_to"])
                    self.assertEqual(last["record_hash"], ctx.exception.failure_record["failure_hash"])
            # the audit chain stays verifiable after mixed enforced/refused exposure
            self.assertGreaterEqual(len(run.audit_entries()), 2 * len(exposed))

    def test_unknown_control_refused(self) -> None:
        with self.assertRaises(lga.AdapterError) as ctx:
            K.run_control("no_such_control", {}, registry=self.reg)
        self.assertEqual(ctx.exception.code, "control.unknown")
        cid = next(iter(self.bound))
        with self.assertRaises(lga.AdapterError) as ctx:
            K.run_control(cid, "not-an-object", registry=self.reg)
        self.assertEqual(ctx.exception.code, "control.malformed")


if __name__ == "__main__":
    unittest.main()
