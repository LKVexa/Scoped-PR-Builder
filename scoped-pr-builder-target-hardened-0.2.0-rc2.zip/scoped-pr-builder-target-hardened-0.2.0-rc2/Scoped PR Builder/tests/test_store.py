"""Persistence store tests (Phase 07 / STORE-01..07; stdlib unittest).

Registry loads and binds to existing suites; records carry stable identity, schema version, ownership, classification,
retention and provenance and are written only through Store.put into chained ledgers (T01); every store is fed from the
adapters' run artifacts — model/UI principals cannot write (T02); transactions, immutability/tamper detection, version
checks and locks, tombstones under legal hold, checkpoints and recovery (T03); restart/replay reconstructs the same
material state and flags stale inputs (T04). Layers not yet applied skip.
"""
from __future__ import annotations

import copy
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from adapters import contracts as C  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import store as S  # noqa: E402
from test_workflow import Driver, _git  # noqa: E402

REPO_ROOT = HERE.parent.parent
D = "sha256:" + "0123456789abcdef" * 4
REV = "a" * 40
PROV = {"run_id": D, "repository_id": D, "base_revision": REV, "source_snapshot_hash": D, "produced_by": "tests", "source_ledger": "tests", "source_entry_hash": D}


def payload_for(st, sid, n=1):
    keys = st["stores"][sid]["identity"]["key_fields"]
    p = {k: (f"value-{n}" if k not in ("run_id", "record_hash", "receipt_hash", "evidence_id", "entry_hash", "sha256", "step_record_hash", "attempt_id") else "sha256:" + f"{n:064x}") for k in keys}
    p["note"] = f"payload {n}"
    return p


class Fixture(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.st = S.load_stores(registry=self.reg)
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.store = S.Store(self.base / "run", stores=self.st, registry=self.reg)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def first(self):
        return next(iter(self.st["stores"]))


class TestRegistryAndRecords(Fixture):
    def test_registry_loads_and_binds(self) -> None:
        self.assertEqual(self.st["computed_hash"], S.load_stores(registry=self.reg)["computed_hash"])
        for sid, s in self.st["stores"].items():
            with self.subTest(store=sid):
                for f in s["authoritative_suites"]:
                    self.assertTrue((REPO_ROOT / f).is_file(), f)
                self.assertTrue(s["identity"]["key_fields"] and s["ownership"]["writers"] and s["provenance_fields"])
                self.assertFalse(set(s["ownership"]["writers"]) & set(S.FORBIDDEN_WRITERS))
        broken = copy.deepcopy(self.st); sid = self.first(); broken["stores"][sid]["ownership"]["writers"] = ["model"]
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump({k: v for k, v in broken.items() if k != "computed_hash"}, f)
        with self.assertRaises(lga.AdapterError) as ctx:
            S.load_stores(Path(f.name), registry=self.reg)
        self.assertEqual(ctx.exception.code, "store.registry_invalid")

    def test_put_get_identity_and_envelope(self) -> None:
        for sid, s in self.st["stores"].items():
            with self.subTest(store=sid):
                w = s["ownership"]["writers"][0]
                row = self.store.put(sid, payload_for(self.st, sid), writer=w, provenance=PROV)
                self.assertEqual(row["lifecycle"], "SEALED"); self.assertEqual(row["schema_version"], s["schema_version"]); self.assertEqual(row["classification"], s["classification"])
                self.assertEqual(row["record_id"], S.record_id(s, payload_for(self.st, sid))); self.assertRegex(row["record_hash"], r"^sha256:"); self.assertRegex(row["entry_hash"], r"^sha256:")
                self.assertEqual(self.store.get(sid, row["record_id"])["payload_hash"], row["payload_hash"])
                again = self.store.put(sid, dict(payload_for(self.st, sid), note="changed"), writer=w, provenance=PROV)
                self.assertEqual(again["record_id"], row["record_id"]); self.assertNotEqual(again["payload_hash"], row["payload_hash"])
                self.assertEqual(self.store.get(sid, row["record_id"])["payload_hash"], again["payload_hash"], "the latest sealed version is current; the earlier row is retained in the chain")
                self.assertEqual(len(self.store.rows(sid)), 2); self.assertEqual(self.store.verify(sid)["verdict"], "PASS")

    def test_writers_provenance_classification_identity_fail_closed(self) -> None:
        sid = self.first(); s = self.st["stores"][sid]; w = s["ownership"]["writers"][0]
        for bad in ("model", "ui", "anonymous", "someone_else"):
            with self.assertRaises(lga.AdapterError) as ctx:
                self.store.put(sid, payload_for(self.st, sid), writer=bad, provenance=PROV)
            self.assertEqual(ctx.exception.code, "store.writer_forbidden", bad)
        with self.assertRaises(lga.AdapterError) as ctx:
            self.store.put(sid, payload_for(self.st, sid), writer=w, provenance={k: v for k, v in PROV.items() if k != "base_revision"})
        self.assertEqual(ctx.exception.code, "store.provenance_incomplete")
        if s["classification"] != "public":
            with self.assertRaises(lga.AdapterError) as ctx:
                self.store.put(sid, payload_for(self.st, sid), writer=w, provenance=PROV, classification="public")
            self.assertEqual(ctx.exception.code, "store.classification_lowered")
        with self.assertRaises(lga.AdapterError) as ctx:
            self.store.put(sid, {"note": "no keys"}, writer=w, provenance=PROV)
        self.assertEqual(ctx.exception.code, "store.identity_incomplete")
        with self.assertRaises(lga.AdapterError) as ctx:
            self.store.put("STORE-99", {}, writer=w, provenance=PROV)
        self.assertEqual(ctx.exception.code, "store.unknown")
        self.assertEqual(self.store.rows(sid), [])


class TestBindings(Fixture):
    """T02: stores are fed from a real run's artifacts; no other write path exists."""

    def setUp(self) -> None:
        super().setUp()
        if not hasattr(S, "bind_run"):
            self.skipTest("bindings not yet present")

    def _run(self, upto="WF-11"):
        d = Driver(self.base / "wf", self.reg)
        r = d.drive(upto)
        self.assertEqual(r["outcome"], "SUCCEEDED", r["reason"])
        return d

    def test_bind_run_persists_every_bound_store(self) -> None:
        bound = [sid for sid in self.st["stores"] if sid in S._BINDERS]
        if not bound:
            self.skipTest("no store bound yet")
        d = self._run()
        store = S.Store(d.run_dir, stores=self.st, registry=self.reg)
        out = S.bind_run(store, d.run_dir)
        for sid in bound:
            with self.subTest(store=sid):
                self.assertTrue(out[sid]["bound"]); self.assertGreater(out[sid]["written"], 0, sid)
                rows = store.rows(sid)
                self.assertTrue(all(r["writer"] in self.st["stores"][sid]["ownership"]["writers"] for r in rows))
                self.assertTrue(all(r["provenance"]["run_id"] == d.run.run_id and r["provenance"]["base_revision"] == d.run.artifacts["binding"].base_revision for r in rows))
        again = S.bind_run(store, d.run_dir)
        self.assertTrue(all(again[sid]["written"] == 0 for sid in bound), "binding is idempotent per identity")
        with self.assertRaises(lga.AdapterError) as ctx:
            S.bind_run(store, self.base / "nowhere")
        self.assertEqual(ctx.exception.code, "store.run_unbound")

    def test_model_and_ui_cannot_write_bound_stores(self) -> None:
        for sid in self.st["stores"]:
            for who in ("model", "ui"):
                with self.assertRaises(lga.AdapterError) as ctx:
                    self.store.put(sid, payload_for(self.st, sid), writer=who, provenance=PROV)
                self.assertEqual(ctx.exception.code, "store.writer_forbidden")


class TestSemantics(Fixture):
    """T03: transactions, immutability + tamper detection, version check + lock, tombstones/legal hold/retention, checkpoint + recovery."""

    def setUp(self) -> None:
        super().setUp()
        if not hasattr(S.Store, "recover"):
            self.skipTest("semantics layer not yet present")
        self.sid = next(sid for sid, s in self.st["stores"].items() if s["retention"]["mode"] == "append_only_tombstone")
        self.w = self.st["stores"][self.sid]["ownership"]["writers"][0]

    def test_version_check_and_lock(self) -> None:
        r1 = self.store.put(self.sid, payload_for(self.st, self.sid, 1), writer=self.w, provenance=PROV)
        with self.assertRaises(lga.AdapterError) as ctx:
            self.store.put(self.sid, payload_for(self.st, self.sid, 2), writer=self.w, provenance=PROV, expected_head="genesis")
        self.assertEqual(ctx.exception.code, "store.conflict")
        r2 = self.store.put(self.sid, payload_for(self.st, self.sid, 2), writer=self.w, provenance=PROV, expected_head=r1["entry_hash"])
        self.assertEqual(r2["prev_hash"], r1["entry_hash"])
        lock = self.store.path(self.sid).with_suffix(".lock"); lock.write_text("held")
        with self.assertRaises(lga.AdapterError) as ctx:
            self.store.put(self.sid, payload_for(self.st, self.sid, 3), writer=self.w, provenance=PROV)
        self.assertEqual(ctx.exception.code, "store.locked"); lock.unlink()
        self.assertEqual(len(self.store.rows(self.sid)), 2)

    def test_partial_write_and_tamper_are_detected_and_recovered(self) -> None:
        for n in (1, 2, 3):
            self.store.put(self.sid, payload_for(self.st, self.sid, n), writer=self.w, provenance=PROV)
        p = self.store.path(self.sid)
        good = p.read_text(encoding="utf-8")
        p.write_text(good + '{"record_schema": "overlay.scoped_pr_builder.store/StoreRecord", "store_id": "' + self.sid + '", "partial', encoding="utf-8")
        with self.assertRaises(lga.AdapterError) as ctx:
            self.store.rows(self.sid)
        self.assertEqual(ctx.exception.code, "store.chain_broken")
        rep = self.store.recover(self.sid)
        self.assertEqual(rep["verdict"], "RECOVERED"); self.assertEqual(rep["rows"], 3); self.assertEqual(rep["quarantined"], 1); self.assertTrue(Path(rep["quarantine"]).is_file())
        self.assertEqual(len(self.store.rows(self.sid)), 3)
        lines = p.read_text(encoding="utf-8").splitlines()
        e = json.loads(lines[1]); e["payload"]["note"] = "altered after sealing"; lines[1] = lga.canonical_json(e)
        p.write_text("\n".join(lines) + "\n", encoding="utf-8")
        with self.assertRaises(lga.AdapterError) as ctx:
            self.store.rows(self.sid)
        self.assertEqual(ctx.exception.code, "store.chain_broken")
        rep = self.store.recover(self.sid)
        self.assertEqual(rep["verdict"], "TAMPERED"); self.assertEqual(rep["rows"], 1); self.assertEqual(rep["quarantined"], 2)

    def test_tombstone_legal_hold_and_retention(self) -> None:
        r = self.store.put(self.sid, payload_for(self.st, self.sid, 1), writer=self.w, provenance=PROV)
        rid = r["record_id"]
        w6 = self.st["stores"]["STORE-06"]["ownership"]["writers"][0]
        self.store.set_legal_hold(self.sid, rid, hold=True, writer=w6, provenance=PROV, reason="litigation")
        with self.assertRaises(lga.AdapterError) as ctx:
            self.store.tombstone(self.sid, rid, writer=self.w, reason="user request")
        self.assertEqual(ctx.exception.code, "store.legal_hold")
        self.store.set_legal_hold(self.sid, rid, hold=False, writer=w6, provenance=PROV, reason="released")
        t = self.store.tombstone(self.sid, rid, writer=self.w, reason="user request")
        self.assertEqual(t["lifecycle"], "TOMBSTONED"); self.assertEqual(t["payload"], {}); self.assertEqual(t["tombstone"]["payload_hash_retained"], r["payload_hash"])
        self.assertIsNone(self.store.get(self.sid, rid)); self.assertEqual(len(self.store.rows(self.sid)), 2, "the original row is retained; deletion is a tombstone")
        immutable = next(sid for sid, s in self.st["stores"].items() if s["retention"]["mode"] == "append_only")
        wi = self.st["stores"][immutable]["ownership"]["writers"][0]
        ri = self.store.put(immutable, payload_for(self.st, immutable, 1), writer=wi, provenance=PROV)
        with self.assertRaises(lga.AdapterError) as ctx:
            self.store.tombstone(immutable, ri["record_id"], writer=wi, reason="x")
        self.assertEqual(ctx.exception.code, "store.immutable")
        r2 = self.store.put(self.sid, payload_for(self.st, self.sid, 2), writer=self.w, provenance=PROV, retention={"ttl_days": 1})
        purged = self.store.purge_expired(self.sid, writer=self.w, now="2999-01-01T00:00:00+00:00")
        self.assertIn(r2["record_id"], purged["purged"]); self.assertIsNone(self.store.get(self.sid, r2["record_id"]))

    def test_checkpoint_and_restore(self) -> None:
        r1 = self.store.put(self.sid, payload_for(self.st, self.sid, 1), writer=self.w, provenance=PROV)
        man = self.store.checkpoint(self.base / "ckpt")
        self.assertIn(f"{self.sid}.jsonl", man["files"]); self.assertEqual(man["files"][f"{self.sid}.jsonl"]["head"], r1["entry_hash"])
        with self.assertRaises(lga.AdapterError):
            self.store.checkpoint(self.store.base / "inside")
        self.store.put(self.sid, payload_for(self.st, self.sid, 2), writer=self.w, provenance=PROV)
        self.assertEqual(self.store.restore(self.base / "ckpt")["restored"], [], "a longer live chain is never overwritten by an older checkpoint")
        os.remove(self.store.path(self.sid))
        self.assertEqual(self.store.restore(self.base / "ckpt")["restored"], [f"{self.sid}.jsonl"]); self.assertEqual(self.store.head(self.sid), r1["entry_hash"])
        p = self.store.path(self.sid); lines = p.read_text().splitlines(); e = json.loads(lines[0]); e["payload"]["note"] = "diverged"; p.write_text(lga.canonical_json(e) + "\n")
        with self.assertRaises(lga.AdapterError) as ctx:
            self.store.restore(self.base / "ckpt")
        self.assertEqual(ctx.exception.code, "store.restore_conflict")


class TestReplay(Fixture):
    """T04: restart/replay reconstructs the same material state; stale inputs are flagged, never reused."""

    def setUp(self) -> None:
        super().setUp()
        if not hasattr(S, "resume"):
            self.skipTest("replay layer not yet present")

    def test_material_state_is_reconstructed_and_stale_inputs_flagged(self) -> None:
        d = Driver(self.base / "wf", self.reg)
        r = d.drive("WF-09")
        self.assertEqual(r["outcome"], "SUCCEEDED", r["reason"])
        store = S.Store(d.run_dir, stores=self.st, registry=self.reg)
        S.bind_run(store, d.run_dir)
        before = {sid: store.material_hash(sid) for sid in self.st["stores"] if store.path(sid).is_file()}
        rep = S.resume(d.run_dir, binding=d.run.artifacts["binding"], stores=self.st, registry=self.reg)
        self.assertEqual(rep["workflow"]["run_state"], "REVIEW_PENDING"); self.assertTrue(rep["workflow"]["resumable"]); self.assertEqual(rep["stale_inputs"], []); self.assertTrue(rep["may_continue"])
        self.assertEqual({sid: v["material_hash"] for sid, v in rep["stores"].items()}, before)
        S.assert_fresh(rep)
        rep2 = S.resume(d.run_dir, binding=d.run.artifacts["binding"], stores=self.st, registry=self.reg)
        self.assertEqual(rep2["resume_hash"], rep["resume_hash"], "two restarts yield the same material state")
        (d.repo / "Suite01" / "01_demo.jad").write_text("moved\n"); _git(d.repo, "add", "-A"); _git(d.repo, "commit", "-q", "-m", "moved")
        live = lga.bind_repository(d.repo)
        rep3 = S.resume(d.run_dir, binding=live, stores=self.st, registry=self.reg)
        self.assertTrue(rep3["stale_inputs"]); self.assertFalse(rep3["may_continue"])
        with self.assertRaises(lga.AdapterError) as ctx:
            S.assert_fresh(rep3)
        self.assertEqual(ctx.exception.code, "store.stale_input")
        cur = store.current("STORE-03", binding=live) if store.path("STORE-03").is_file() else {"current": {}, "stale": {"x": 1}}
        self.assertEqual(cur["current"], {}); self.assertTrue(cur["stale"])


if __name__ == "__main__":
    unittest.main()
