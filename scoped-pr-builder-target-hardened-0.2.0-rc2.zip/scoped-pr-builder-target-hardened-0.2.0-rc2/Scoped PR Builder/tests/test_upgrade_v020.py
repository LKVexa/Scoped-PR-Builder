import json, subprocess, sys, tempfile, unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent; sys.path.insert(0,str(HERE.parent))
from adapters import forge_adapter as F
from adapters import hard_limits as H
from adapters import local_model_provider as M
from adapters import patch_generator as P
from adapters import release_gate as R

class UpgradeV020(unittest.TestCase):
    def test_hard_caps_match_rules(self):
        self.assertEqual(H.hard_caps(),{'max_changed_files':25,'max_diff_lines':400})
    def test_recipe_catalog_is_registered_and_unknown_stays_refused(self):
        for name in ('trim_trailing_whitespace','ensure_final_newline','py_unused_imports','normalize_sha256sums','regenerate_sha256sums_manifest'):
            self.assertIn(name,P.RECIPES)
    def test_forge_grant_is_exact_and_expiring(self):
        exp=(datetime.now(timezone.utc)+timedelta(minutes=5)).isoformat()
        g=F.ForgeGrant('github','o/r','pr.create','human',exp)
        self.assertIs(F.require_grant(g,provider='github',repository='o/r',action='pr.create'),g)
        with self.assertRaises(Exception): F.require_grant(g,provider='github',repository='o/other',action='pr.create')
    def test_codeowners_last_match_wins(self):
        text='* @all\nsrc/* @src\nsrc/critical.py @critical @security\n'
        r=F.reviewers_for_paths(['src/critical.py'],text)
        self.assertEqual(r['reviewers'],['@critical','@security'])
    def test_forge_checks_are_head_bound(self):
        r=F.required_checks_state([{'name':'test','head_sha':'a','status':'success'},{'name':'lint','head_sha':'b','status':'success'}],['test','lint'],head_sha='a')
        self.assertFalse(r['ready']); self.assertEqual(r['missing'],['lint'])
    def test_model_only_proposes_registered_recipe(self):
        spec=M.LocalModelSpec('ollama','x','sha256:' + 'a'*64)
        good=lambda payload:{'recipe_name':'trim_trailing_whitespace','recipe_args':{},'evidence_refs':[],'rationale':'x','confidence':.9}
        self.assertEqual(M.propose_recipe(spec,good,{}, {'trim_trailing_whitespace'})['recipe_name'],'trim_trailing_whitespace')
        low=lambda payload:{'recipe_name':'trim_trailing_whitespace','recipe_args':{},'evidence_refs':[],'rationale':'x','confidence':.2}
        with self.assertRaises(Exception): M.propose_recipe(spec,low,{}, {'trim_trailing_whitespace'})
