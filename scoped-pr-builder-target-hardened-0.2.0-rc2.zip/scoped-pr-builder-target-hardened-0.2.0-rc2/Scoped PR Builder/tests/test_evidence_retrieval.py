"""Deterministic tests for Suite 51/Funnel evidence retrieval and planning (stdlib unittest)."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from adapters import evidence_retrieval as er  # noqa: E402
from adapters import intent_intake as ii  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402


def _git(cwd: Path, *args: str) -> str:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t",
           "GIT_COMMITTER_EMAIL": "t@t", "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z", "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z"}
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, check=True, env=env).stdout.strip()


class Fixture(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "repo"
        for d in ("Alpha", "Beta", "Gamma", "bin"):
            (self.root / d).mkdir(parents=True)
        _git(self.root, "init", "-q")
        (self.root / "Alpha" / "SHA256SUMS.txt").write_text("aaaa  01_Alpha/01_alpha_direction.deepml\nbbbb  01_Alpha/02_alpha_priorities.deepml\n")
        (self.root / "Beta" / "SHA256SUMS.txt").write_text("cccc  02_Beta/01_beta_direction.deepml\ndddd  02_Beta/02_beta_priorities.deepml\n")
        (self.root / "Gamma" / "SHA256SUMS.txt").write_text("cccc  02_Beta/01_beta_direction.deepml\ndddd  02_Beta/02_beta_priorities.deepml\n")  # exact duplicate of Beta
        (self.root / "Alpha" / "MANIFEST.json").write_text('{"scripts": {"alpha_direction.deepml": {}, "alpha_priorities.deepml": {}}}\n')
        (self.root / "Beta" / "notes.md").write_text("unrelated prose about cooking recipes\n")
        (self.root / "bin" / "blob.bin").write_bytes(b"\x00\x01\x02binary")
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c1")
        self.binding = lga.bind_repository(self.root)
        self.contract = json.loads(ii.accept_intent({
            "kind": "tech_debt_refactor", "title": "Regenerate stale Alpha SHA256SUMS manifest",
            "description": "Alpha/SHA256SUMS.txt lists obsolete deepml paths; regenerate digests for existing files.",
            "allowed_paths": ["Alpha/SHA256SUMS.txt"], "max_changed_files": 1, "max_diff_lines": 20, "requested_by": "t",
        }, self.binding).to_json())

    def tearDown(self) -> None:
        self.tmp.cleanup()


class TestRetrieval(Fixture):
    def test_tokenizer(self) -> None:
        self.assertEqual(er.tokenize("04_Compass/01_compass_direction.deepml"), ["04", "compass", "01", "compass", "direction", "deepml"])
        self.assertEqual(er.tokenize("camelCaseName HTTPServer"), ["camel", "case", "name", "http", "server"])

    def test_bm25_ranks_shared_terms(self) -> None:
        m = er.BM25().fit([["graph", "trees"], ["cooking", "recipes"], ["graph", "survey"]])
        self.assertGreater(m.score(["graph"], 0), 0.0)
        self.assertEqual(m.score(["graph"], 1), 0.0)

    def test_retrieval_targets_examples_dedup_and_shape(self) -> None:
        b = er.retrieve_examples(self.binding, self.contract)
        kinds = {e["canonical_path"]: e["evidence_kind"] for e in b.evidence}
        self.assertEqual(kinds["Alpha/SHA256SUMS.txt"], "target_source")
        examples = [e for e in b.evidence if e["evidence_kind"] == "analogous_example"]
        paths = [e["canonical_path"] for e in examples]
        self.assertIn("Alpha/MANIFEST.json", paths)
        self.assertIn("Beta/SHA256SUMS.txt", paths)
        self.assertNotIn("Gamma/SHA256SUMS.txt", paths)  # exact duplicate funnelled out
        self.assertNotIn("Beta/notes.md", paths)  # no shared terms -> score 0 -> excluded
        self.assertNotIn("bin/blob.bin", paths)  # binary skipped
        for e in b.evidence:
            self.assertEqual(e["match_status"], "exact_pinned")
            self.assertTrue(e["exact_locator"].startswith(e["canonical_path"] + "@" + self.binding.base_revision))
            self.assertEqual(e["source_snapshot_hash"], self.binding.source_snapshot_hash)
            for k in ("evidence_id", "retrieval_id", "content_hash", "podium_receipt", "sophia_judgment", "charlotte_validation", "landon_status"):
                self.assertIn(k, e)
        self.assertEqual(b.authority["relation_status"], "repository_only")
        self.assertEqual(b.authority["authority_order"], "repository_evidence_over_memory_over_model")
        # deterministic ids across runs
        b2 = er.retrieve_examples(self.binding, self.contract)
        self.assertEqual([e["evidence_id"] for e in b.evidence], [e["evidence_id"] for e in b2.evidence])

    def test_plan_is_advisory_bounded_and_hash_bound(self) -> None:
        b = er.retrieve_examples(self.binding, self.contract)
        plan = er.build_plan(self.contract, b)
        self.assertEqual(plan["status"], "PLANNED")
        self.assertEqual(plan["authority"], "advisory_only")
        self.assertEqual(len(plan["operations"]), 1)
        self.assertEqual(plan["operations"][0]["path"], "Alpha/SHA256SUMS.txt")
        self.assertEqual(plan["operations"][0]["limits"]["max_diff_lines"], 20)
        self.assertIn("mint_approvals", plan["cannot"])
        self.assertEqual(plan["rollback"]["checkpoint_revision"], self.binding.base_revision)
        body = {k: v for k, v in plan.items() if k not in ("plan_hash", "created_at")}
        self.assertEqual(lga.sha256_digest(lga.canonical_json(body)), plan["plan_hash"])

    def test_abstain_when_evidence_insufficient(self) -> None:
        # Remove every analogous file so nothing but the target remains.
        for p in ("Alpha/MANIFEST.json", "Beta/SHA256SUMS.txt", "Gamma/SHA256SUMS.txt"):
            (self.root / p).unlink()
        _git(self.root, "add", "-A")
        _git(self.root, "commit", "-q", "-m", "c2")
        binding = lga.bind_repository(self.root)
        contract = json.loads(ii.accept_intent({
            "kind": "tech_debt_refactor", "title": "Regenerate stale Alpha SHA256SUMS manifest",
            "description": "x", "allowed_paths": ["Alpha/SHA256SUMS.txt"], "max_changed_files": 1, "max_diff_lines": 20, "requested_by": "t",
        }, binding).to_json())
        plan = er.build_plan(contract, er.retrieve_examples(binding, contract))
        self.assertEqual(plan["status"], "ABSTAIN")
        self.assertEqual(plan["uncertainty"]["evidence_sufficiency"], "insufficient")
        self.assertEqual(plan["operations"][0]["path"], "Alpha/SHA256SUMS.txt")

    def test_fail_closed(self) -> None:
        wrong = dict(self.contract, base_revision="0" * 40)
        with self.assertRaises(lga.AdapterError) as ctx:
            er.retrieve_examples(self.binding, wrong)
        self.assertEqual(ctx.exception.code, "retrieval.binding_mismatch")
        b = er.retrieve_examples(self.binding, self.contract)
        with self.assertRaises(lga.AdapterError) as ctx:
            er.build_plan(dict(self.contract, scope_contract_hash="sha256:other"), b)
        self.assertEqual(ctx.exception.code, "plan.evidence_mismatch")


if __name__ == "__main__":
    unittest.main()
