"""Enforcement tests for the guardrails at orchestration and effect boundaries (Phase 02 / PAPER-GRD-*-T03).

Orchestration boundary: ``wiring.Run.cross`` evaluates every rule that applies to the requested effect and
refuses with ``guardrail.deny`` / ``guardrail.abstain`` / ``guardrail.diagnostic`` — every decision (including
PASS) is on the run audit ledger. Effect boundary: ``approval_adapter.apply_isolated`` evaluates all four rules
on facts derived from the artifacts under application; a blocking decision refuses before any worktree exists.
"""
from __future__ import annotations

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from adapters import approval_adapter as aa  # noqa: E402
from adapters import architecture as A  # noqa: E402
from adapters import contracts as C  # noqa: E402
from adapters import guardrails as G  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import wiring as W  # noqa: E402
from test_guardrails_composition import Fixture  # noqa: E402

REPO_ROOT = HERE.parent.parent


def _identity(reg):
    return copy.deepcopy(reg["contracts"]["api_envelope"]["examples"]["valid"]["identity"])


class TestOrchestrationBoundary(unittest.TestCase):
    def setUp(self) -> None:
        self.reg = C.load_registry()
        self.b = A.load_boundaries(registry=self.reg)
        self.w = W.load_wiring(boundaries=self.b, registry=self.reg)
        self.rules = G.load_rules(registry=self.reg)
        self.tmp = tempfile.TemporaryDirectory()
        self.run = W.Run(Path(self.tmp.name) / "run", _identity(self.reg), repo_root=REPO_ROOT, registry=self.reg, boundaries=self.b, wiring=self.w)
        self.ex = self.b["boundaries"]["deterministic_tools"]["examples"]["valid"]

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def _cross(self, facts=None, effect="diff.generate_inert"):
        return self.run.cross("deterministic_tools", effect, self.ex["payload_contract"], self.ex["payload"], direction=self.ex["direction"], guardrail_facts=facts)

    def test_guarded_effect_without_facts_abstains_and_blocks(self) -> None:
        if not any(r.get("enforcement") for r in self.rules["rules"].values()):
            self.skipTest("no enforcement declared yet")
        with self.assertRaises(lga.AdapterError) as ctx:
            self._cross(None)
        self.assertEqual(ctx.exception.code, "guardrail.abstain")
        rows = self.run.audit_entries()
        evals = [r for r in rows if r["effect"] == "guardrail.evaluate"]
        self.assertEqual({r["rule_id"] for r in evals}, {rid for rid, r in self.rules["rules"].items() if "diff.generate_inert" in r["evaluates_on"]})
        self.assertTrue(all(r["verdict"] == "ABSTAIN" and r["blocking"] for r in evals))
        self.assertEqual(rows[-1]["verdict"], "DENIED"); self.assertEqual(rows[-1]["denial_code"], "guardrail.abstain")
        self.assertIn(rows[-1]["denial_class"], W.FAILURE_CLASSES)

    def test_pass_facts_admit_and_are_audited(self) -> None:
        applicable = {rid: r for rid, r in self.rules["rules"].items() if "diff.generate_inert" in r["evaluates_on"] and r.get("enforcement")}
        if not applicable:
            self.skipTest("no enforcement declared yet")
        facts = {rid: r["examples"]["pass"] for rid, r in self.rules["rules"].items() if "diff.generate_inert" in r["evaluates_on"]}
        out = self._cross(facts)
        self.assertEqual(out["crossing"]["verdict"], "ADMITTED")
        self.assertEqual(len(out["guardrail_decisions"]), len(facts))
        self.assertTrue(all(d["state"] == "PASS" for d in out["guardrail_decisions"]))
        self.assertEqual(out["audit_entry"]["guardrail_decisions"], [d["decision_hash"] for d in out["guardrail_decisions"]])

    def test_deny_and_diagnostic_refuse_with_recorded_reason(self) -> None:
        applicable = [rid for rid, r in self.rules["rules"].items() if "diff.generate_inert" in r["evaluates_on"] and r.get("enforcement")]
        if not applicable:
            self.skipTest("no enforcement declared yet")
        for state in ("deny", "diagnostic"):
            facts = {rid: self.rules["rules"][rid]["examples"]["pass"] for rid in applicable}
            facts[applicable[0]] = self.rules["rules"][applicable[0]]["examples"][state]
            with self.assertRaises(G.GuardrailRefusal) as ctx:
                self._cross(facts)
            self.assertEqual(ctx.exception.code, f"guardrail.{state}")
            self.assertTrue(any(d["state"] == state.upper() for d in ctx.exception.decisions))
            last = self.run.audit_entries()[-1]
            self.assertEqual(last["denial_code"], f"guardrail.{state}"); self.assertTrue(last["reason"])
            self.assertEqual(last["denial_class"], "unauthorized" if state == "deny" else "malformed")

    def test_unguarded_effect_is_untouched(self) -> None:
        out = self._cross(None, effect="analysis.run_deterministic")
        self.assertEqual(out["crossing"]["verdict"], "ADMITTED")
        self.assertEqual(out.get("guardrail_decisions"), [])

    def test_no_implicit_fallback_widens_scope(self) -> None:
        """A PASS on one rule never substitutes for a missing rule: partial facts still block."""
        applicable = [rid for rid, r in self.rules["rules"].items() if "diff.generate_inert" in r["evaluates_on"] and r.get("enforcement")]
        if len(applicable) < 2:
            self.skipTest("fewer than two enforced rules on this effect")
        facts = {applicable[0]: self.rules["rules"][applicable[0]]["examples"]["pass"]}
        with self.assertRaises(G.GuardrailRefusal) as ctx:
            self._cross(facts)
        self.assertEqual(ctx.exception.code, "guardrail.abstain")
        states = {d["rule_id"]: d["state"] for d in ctx.exception.decisions}
        self.assertEqual(states[applicable[0]], "PASS"); self.assertEqual(states[applicable[1]], "ABSTAIN")


class TestEffectBoundary(Fixture):
    def test_apply_is_gated_by_all_four_rules(self) -> None:
        if not all(r.get("enforcement") for r in self.rules["rules"].values()):
            self.skipTest("not every rule is enforced yet")
        base = Path(self.tmp.name)
        rc = self.receipt("APPROVE")
        rec = aa.apply_isolated(binding=self.binding, contract=self.contract, candidate=self.cand, patch=self.patch, report=self.report, card=self.card, receipt=rc, key=self.key, run_dir=self.run_dir, worktree_parent=base / "applied-ok")
        self.assertRegex(rec.guardrails_hash, r"^sha256:[0-9a-f]{64}$")
        saved = json.loads((self.run_dir / "guardrails" / f"patch_apply_isolated-{self.cand['candidate_id'][7:19]}.json").read_text())
        self.assertTrue({d["rule_id"] for d in saved["decisions"]} >= {"GRD-01", "GRD-02", "GRD-03", "GRD-04"})  # Phase 03 adds capability rules at apply
        self.assertTrue(all(d["state"] == "PASS" for d in saved["decisions"]))
        self.assertEqual(saved["decisions_hash"], rec.guardrails_hash)
        lga.worktree_remove(self.root, Path(rec.applied_worktree))
        # a deliberately tightened rule blocks the same application before any worktree exists
        original = G.load_rules
        tight = copy.deepcopy(self.rules); tight["rules"]["GRD-01"]["parameters"]["hard_max_diff_lines"] = 1
        G.load_rules = lambda *a, **k: tight
        try:
            rc2 = self.receipt("APPROVE")
            with self.assertRaises(G.GuardrailRefusal) as ctx:
                aa.apply_isolated(binding=self.binding, contract=self.contract, candidate=self.cand, patch=self.patch, report=self.report, card=self.card, receipt=rc2, key=self.key, run_dir=self.run_dir, worktree_parent=base / "applied-blocked")
            self.assertEqual(ctx.exception.code, "guardrail.deny")
            self.assertFalse((base / "applied-blocked").exists())
            self.assertEqual(lga.git(self.root, "worktree", "list").count("applied-blocked"), 0)
        finally:
            G.load_rules = original


if __name__ == "__main__":
    unittest.main()
