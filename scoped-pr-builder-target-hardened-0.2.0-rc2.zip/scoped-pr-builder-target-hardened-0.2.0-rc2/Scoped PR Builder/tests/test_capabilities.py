"""Composition + enforcement + exposure tests for the core capability rules (Phase 03 / PAPER-CAP-01..05).

Facts for each capability are derived from real overlay artifacts (accepted contract, retrieval bundle + plan,
candidate, verification report); the rules are enforced at the effect boundaries inside the adapters that produce
those artifacts and at the ports; the review card exposes every capability's state before the pending action.
"""
from __future__ import annotations

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from adapters import architecture as A  # noqa: E402
from adapters import evidence_retrieval as er  # noqa: E402
from adapters import guardrails as G  # noqa: E402
from adapters import intent_intake as ii  # noqa: E402
from adapters import local_git_adapter as lga  # noqa: E402
from adapters import patch_generator as pg  # noqa: E402
from adapters import review_renderer as rr  # noqa: E402
from adapters import wiring as W  # noqa: E402
from test_guardrails_composition import Fixture  # noqa: E402

REPO_ROOT = HERE.parent.parent
CAPS = ("CAP-01", "CAP-02", "CAP-03", "CAP-04", "CAP-05")


def _identity(reg):
    return copy.deepcopy(reg["contracts"]["api_envelope"]["examples"]["valid"]["identity"])


class TestCapabilityComposition(Fixture):
    def _composed(self, rid):
        return rid in self.rules["rules"] and "composition" in self.rules["rules"][rid]

    def test_cap01_scope_intent_from_contract(self) -> None:
        if not self._composed("CAP-01"):
            self.skipTest("CAP-01 not composed")
        f = G.facts_scope_intent(self.contract)
        self.assertTrue(f["hash_verified"]); self.assertEqual(self.ev("CAP-01", f, "evidence.retrieve")["state"], "PASS")
        bad = dict(self.contract, max_diff_lines=self.contract["max_diff_lines"] + 1)
        d = self.ev("CAP-01", G.facts_scope_intent(bad), "evidence.retrieve")
        self.assertEqual(d["state"], "DENY"); self.assertIn("hash", d["reason"])
        empty = dict(self.contract, allowed_paths=[])
        f2 = G.facts_scope_intent(empty); f2["hash_verified"] = True
        self.assertEqual(self.ev("CAP-01", f2, "plan.propose")["state"], "DENY")
        with self.assertRaises(lga.AdapterError):  # the intake itself refuses an unscoped intent before the rule is ever needed
            ii.accept_intent({"kind": "tech_debt_refactor", "title": "x", "description": "x", "allowed_paths": [], "max_changed_files": 1, "max_diff_lines": 5, "requested_by": "t"}, self.binding)

    def test_cap02_analogous_evidence_from_bundle_and_plan(self) -> None:
        if not self._composed("CAP-02"):
            self.skipTest("CAP-02 not composed")
        f = G.facts_analogous_evidence(self.bundle, self.plan)
        self.assertGreaterEqual(f["example_count"], 1); self.assertTrue(f["exact_pinned"])
        self.assertEqual(self.ev("CAP-02", f, "plan.propose")["state"], "PASS")
        invented = copy.deepcopy(self.plan); invented["operations"][0]["guided_by_examples"] = ["sha256:" + "e" * 64]
        d = self.ev("CAP-02", G.facts_analogous_evidence(self.bundle, invented), "plan.propose")
        self.assertEqual(d["state"], "DENY"); self.assertIn("invented", d["reason"])
        starved = copy.deepcopy(self.plan); starved["status"] = "PLANNED"
        bundle_no_examples = type(self.bundle)(**{**self.bundle.__dict__, "evidence": [e for e in self.bundle.evidence if e["evidence_kind"] != "analogous_example"]})
        starved["operations"][0]["guided_by_examples"] = []
        d = self.ev("CAP-02", G.facts_analogous_evidence(bundle_no_examples, starved), "plan.propose")
        self.assertEqual(d["state"], "DENY")
        abstained = copy.deepcopy(self.plan); abstained["status"] = "ABSTAIN"; abstained["abstain_reason"] = "insufficient analogous evidence"; abstained["operations"][0]["guided_by_examples"] = []
        self.assertEqual(self.ev("CAP-02", G.facts_analogous_evidence(bundle_no_examples, abstained), "plan.propose")["state"], "PASS")

    def test_cap03_atomic_diff_from_candidate(self) -> None:
        if not self._composed("CAP-03"):
            self.skipTest("CAP-03 not composed")
        f = G.facts_atomic_bounded_diff(self.cand)
        self.assertEqual((f["files_changed"], f["hunks"], f["single_recipe"], f["inert"]), (1, 1, True, True))
        self.assertEqual(self.ev("CAP-03", f, "diff.generate_inert")["state"], "PASS")
        self.assertEqual(self.ev("CAP-03", G.facts_atomic_bounded_diff(dict(self.cand, recipe="a+b")), "diff.generate_inert")["state"], "DENY")
        self.assertEqual(self.ev("CAP-03", G.facts_atomic_bounded_diff(dict(self.cand, inert=False)), "patch.apply_isolated")["state"], "DENY")
        big = dict(self.cand, lines_added=self.cand["limit_profile"]["max_diff_lines"] + 1)
        self.assertEqual(self.ev("CAP-03", G.facts_atomic_bounded_diff(big), "diff.generate_inert")["state"], "DENY")
        self.assertEqual(self.ev("CAP-03", G.facts_atomic_bounded_diff(dict(self.cand, hunks=0)), "diff.generate_inert")["state"], "DIAGNOSTIC")

    def test_cap04_halt_from_report_and_plan(self) -> None:
        if not self._composed("CAP-04"):
            self.skipTest("CAP-04 not composed")
        f = G.facts_halt_on_failure(self.report, self.plan)
        self.assertEqual(f["verdict"], "PASS"); self.assertEqual(self.ev("CAP-04", f, "review.render")["state"], "PASS")
        failed = copy.deepcopy(self.report); failed["verdict"] = "FAIL"; failed["jobs"][0]["verdict"] = "FAIL"; failed["jobs"][0]["summary"] = "patch does not apply"
        d = self.ev("CAP-04", G.facts_halt_on_failure(failed, self.plan), "review.render")
        self.assertEqual(d["state"], "DENY"); self.assertIn("halt", d["reason"]); self.assertIn("patch does not apply", d["reason"])
        silent = copy.deepcopy(self.report); silent["verdict"] = "FAIL"
        self.assertEqual(self.ev("CAP-04", G.facts_halt_on_failure(silent, self.plan), "review.render")["state"], "DIAGNOSTIC")
        low = copy.deepcopy(self.plan); low["status"] = "ABSTAIN"; low["abstain_reason"] = "insufficient analogous evidence"; low["uncertainty"]["evidence_sufficiency"] = "insufficient"
        d = self.ev("CAP-04", G.facts_halt_on_failure(None, low), "review.render")
        self.assertEqual(d["state"], "ABSTAIN"); self.assertIn("halt", d["reason"])

    def test_cap05_knowledge_gaps_from_plan(self) -> None:
        if not self._composed("CAP-05"):
            self.skipTest("CAP-05 not composed")
        f = G.facts_knowledge_gaps(self.plan)
        self.assertTrue(all(c["evidence_refs"] for c in f["claims"])); self.assertEqual(self.ev("CAP-05", f, "plan.propose")["state"], "PASS")
        invented = copy.deepcopy(self.plan); invented["operations"][0]["guided_by_examples"] = []
        d = self.ev("CAP-05", G.facts_knowledge_gaps(invented), "plan.propose")
        self.assertEqual(d["state"], "DENY"); self.assertIn("invented", d["reason"])
        hidden = G.facts_knowledge_gaps(self.plan, evidence_gaps=["naming convention for manifests unknown"]); hidden["surfaced"] = False
        self.assertEqual(self.ev("CAP-05", hidden, "plan.propose")["state"], "DENY")
        surfaced = G.facts_knowledge_gaps(self.plan, evidence_gaps=["naming convention for manifests unknown"])
        d = self.ev("CAP-05", surfaced, "review.render")
        self.assertEqual(d["state"], "PASS"); self.assertIn("surfaced", d["reason"])
        promoted = dict(f, memory_promotion="unverified_promoted")
        self.assertEqual(self.ev("CAP-05", promoted, "plan.propose")["state"], "DIAGNOSTIC")


class TestCapabilityEnforcement(Fixture):
    def _enforced(self, rid):
        return rid in self.rules["rules"] and "enforcement" in self.rules["rules"][rid]

    def test_effect_boundaries_inside_adapters(self) -> None:
        enforced = [r for r in CAPS if self._enforced(r)]
        if not enforced:
            self.skipTest("no capability enforcement yet")
        original = G.load_rules
        tight = copy.deepcopy(self.rules)
        try:
            if "CAP-01" in enforced:
                tight["rules"]["CAP-01"]["parameters"]["allowed_kinds"] = ["nothing"]
                G.load_rules = lambda *a, **k: tight
                with self.assertRaises(G.GuardrailRefusal) as ctx:
                    ii.accept_intent({"kind": "tech_debt_refactor", "title": "Regenerate", "description": "x", "allowed_paths": ["Suite04/SHA256SUMS.txt"], "max_changed_files": 1, "max_diff_lines": 10, "requested_by": "t"}, self.binding)
                self.assertEqual(ctx.exception.code, "guardrail.deny")
                tight["rules"]["CAP-01"]["parameters"]["allowed_kinds"] = ["tech_debt_refactor"]
            if "CAP-02" in enforced or "CAP-05" in enforced:
                G.load_rules = lambda *a, **k: tight
                if "CAP-02" in enforced:
                    tight["rules"]["CAP-02"]["parameters"]["min_examples"] = 99
                    with self.assertRaises(G.GuardrailRefusal) as ctx:
                        er.build_plan(self.contract, self.bundle)
                    self.assertEqual(ctx.exception.code, "guardrail.deny")
                    tight["rules"]["CAP-02"]["parameters"]["min_examples"] = 1
                plan = er.build_plan(self.contract, self.bundle)
                self.assertEqual(plan["status"], "PLANNED")
            if "CAP-03" in enforced:
                tight["rules"]["CAP-03"]["parameters"]["max_hunks_per_file"] = 0
                G.load_rules = lambda *a, **k: tight
                with self.assertRaises(G.GuardrailRefusal) as ctx:
                    pg.generate_candidate(self.binding, self.contract, self.plan, "regenerate_sha256sums_manifest")
                self.assertEqual(ctx.exception.code, "guardrail.deny")
                tight["rules"]["CAP-03"]["parameters"]["max_hunks_per_file"] = 8
                cand, _ = pg.generate_candidate(self.binding, self.contract, self.plan, "regenerate_sha256sums_manifest")
                self.assertEqual(cand.candidate_id, self.cand["candidate_id"])
        finally:
            G.load_rules = original

    def test_orchestration_boundary_for_capabilities(self) -> None:
        enforced = [r for r in CAPS if self._enforced(r)]
        if not enforced:
            self.skipTest("no capability enforcement yet")
        b = A.load_boundaries(registry=self.reg); w = W.load_wiring(boundaries=b, registry=self.reg)
        with tempfile.TemporaryDirectory() as tmp:
            run = W.Run(Path(tmp) / "run", _identity(self.reg), repo_root=REPO_ROOT, registry=self.reg, boundaries=b, wiring=w)
            ex = b["boundaries"]["model_reasoning"]["examples"]["valid"]
            facts = {rid: r["examples"]["pass"] for rid, r in self.rules["rules"].items() if "plan.propose" in r["evaluates_on"]}
            out = run.cross("model_reasoning", "plan.propose", ex["payload_contract"], ex["payload"], direction=ex["direction"], guardrail_facts=facts)
            self.assertTrue({d["rule_id"] for d in out["guardrail_decisions"]} >= {r for r in enforced if "plan.propose" in self.rules["rules"][r]["evaluates_on"]})
            for rid in enforced:
                if "plan.propose" not in self.rules["rules"][rid]["evaluates_on"]:
                    continue
                bad = dict(facts, **{rid: self.rules["rules"][rid]["examples"]["deny"]})
                with self.assertRaises(G.GuardrailRefusal) as ctx:
                    run.cross("model_reasoning", "plan.propose", ex["payload_contract"], ex["payload"], direction=ex["direction"], guardrail_facts=bad)
                self.assertEqual(ctx.exception.code, "guardrail.deny")
                self.assertEqual(run.audit_entries()[-1]["denial_code"], "guardrail.deny")

    def test_apply_time_facts_cover_capabilities(self) -> None:
        if not all(self._enforced(r) for r in ("CAP-03", "CAP-04")):
            self.skipTest("CAP-03/CAP-04 not enforced yet")
        rc = self.receipt("APPROVE")
        facts = G.apply_time_facts(self.binding, self.contract, self.cand, self.patch, self.card, self.report, rc, self.run_dir, self.key)
        self.assertIn("CAP-03", facts); self.assertIn("CAP-04", facts)
        decisions = G.enforce("patch.apply_isolated", facts, registry=self.reg)
        self.assertTrue({d["rule_id"] for d in decisions} >= {"GRD-01", "GRD-02", "GRD-03", "GRD-04", "CAP-03", "CAP-04"})


class TestCapabilityExposure(Fixture):
    def test_card_exposes_capabilities(self) -> None:
        exposed = [r for r in CAPS if r in self.rules["rules"] and self.rules["rules"][r].get("review_exposure")]
        if not exposed:
            self.skipTest("no capability exposure yet")
        card = rr.build_review_card(json.loads(self.binding.to_json()), self.contract, self.bundle.evidence, self.bundle.authority, self.plan, self.cand, self.patch, self.report, context=self.context)
        rows = {r["rule_id"]: r for r in card["guardrails"]["rules"]}
        for rid in exposed:
            with self.subTest(rule=rid):
                self.assertIn(rid, rows)
                self.assertEqual(rows[rid]["state"], "PASS", rows[rid]["reason"])
                self.assertTrue(rows[rid]["effect"] and rows[rid]["satisfied_by"])
        html = rr.render_html(card)
        for rid in exposed:
            self.assertIn(self.rules["rules"][rid]["title"], html)


if __name__ == "__main__":
    unittest.main()
