# Third-Party Notices — Scoped PR Builder overlay

Every donor part pulled from the GitHub Junkyard into this overlay is listed here with its
license. Donor originals are never modified; the copies pulled for review live in the yard
office work order `_YARDOFFICE/work-orders/scoped-pr-builder-20260903-0210/donor-parts/`.
Machine-readable lineage for every entry is in `PROVENANCE.jsonl`.

## AutoSaddler — MIT

- **Donor repository (yard name, verbatim):** `AutoSaddler` (working-tree clone; no `.git` in the yard copy, so no upstream commit id is available — the donor file digests below pin the exact bytes used)
- **Parts:** `src/autosaddler/v2/harness/git.py` (sha256 `f1954980a7de245643dc8395f40743c096da9ebf04671181487d6e3c4ca1d97a`), `src/autosaddler/v2/core/domain.py` (sha256 `5eef01051cd82b38ac20eb8c5ae7944065248c5f00cd4357941a49e9e0a65eae`)
- **Used in:** `adapters/local_git_adapter.py` — git/worktree/path-confinement primitives and canonical-JSON/sha256 helpers (ADAPTED; see module docstring for the exact transformation); `adapters/verification_runner.py` — per-changed-path verifier pattern and verdict shape from `src/autosaddler/v2/plugins/meta_are/verification.py` (sha256 `05455fde3de0df4754ffa9707e6bd41e7bf7221093453329dd0ab06c40451dc0`, ADAPTED)
- **License text (copied verbatim from the donor's `LICENSE`, sha256 `1126322e2cc8d165adc4c792eeb195717de2bcc7b39be1ce77959d78e87ef685`):**

```
MIT License

Copyright (c) 2026

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## AzureSearch-MRC — MIT

- **Donor repository (yard name, verbatim):** `AzureSearch-MRC.git` (bare mirror clone; HEAD `25886cf2241a73e23d5d68ab66ddc6dfff09b222`, blob `c14bb9278f0a8a0d5d236a5baddfb858e889860c`)
- **Part:** `MRC/bm25.py` (sha256 `585866640d9a9c37cde43b8af1b3cca27f0b3f82ba15fd0a7f3dc7537023dff0`)
- **Used in:** `adapters/evidence_retrieval.py` — `BM25.fit` / `BM25.score` and the idf formula (ADAPTED: code-aware tokenizer, per-document scoring, deterministic tie-breaks; logging/main/stopwords dropped)
- **License text (copied verbatim from the donor's `LICENSE`, sha256 `c2cfccb812fe482101a8f04597dfc5a9991a6b2748266c47ac91b6a5aae15383`):**

```
    MIT License

    Copyright (c) Microsoft Corporation.

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE
```

## amplifier-bundle-redaction — MIT

- **Donor repository (yard name, verbatim):** `amplifier-bundle-redaction` (working-tree copy; no `.git` in the yard copy, so no upstream commit id is available — the donor file digests below pin the exact bytes used)
- **Parts:** `redaction/__init__.py` (sha256 `63463694d9f1f8cdb7701a1b1023721858687a3514be92fd3bec213eb95c9652`), `tests/test_mask_text.py` (sha256 `a445747d970eb85399e1e36b50891c75636baa20c2523a70ec7495e9b3faa9fb`), `tests/test_token_patterns.py` (sha256 `8334dcdb3755948a9008bc289a28d3878934e4062eb0f7fb2472817a6932a5e3`)
- **Used in:** `adapters/vendor_redaction.py` — the zero-dependency secrets/PII masker (`mask_text`, `scrub`, `SECRET_PATTERNS`, `PII_PATTERNS`, `Redactor`) copied verbatim with a provenance header (REUSE; no changes to the module body); `tests/vendor/redaction/` — the donor's public-API tests copied verbatim and run by `tests/test_vendor_redaction.py`; composed by `adapters/security.py` for SEC-03 (secrets never forwarded) and SEC-06 (output classification before display/export)
- **License text (copied verbatim from the donor's `LICENSE`, sha256 `c2cfccb812fe482101a8f04597dfc5a9991a6b2748266c47ac91b6a5aae15383`):**

```
    MIT License

    Copyright (c) Microsoft Corporation.

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE
```
