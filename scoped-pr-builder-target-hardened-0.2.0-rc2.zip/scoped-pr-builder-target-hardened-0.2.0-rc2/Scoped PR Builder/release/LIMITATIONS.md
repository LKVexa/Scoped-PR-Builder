# Release classification update

Any historical `GO` record with an empty `approvals` array is classified as **legacy pilot-sha256sums-only evidence**, not general production readiness. New `GO` records require a human readiness approval.

# Known limitations and non-goals

Generated from the tool's own declarations — the invariant registry, the environment profiles and the
declared non-goals. It is published against the readiness registry, so declaring a new release-gate
assertion without republishing this document makes the published-limitations receipt stale and blocks
the gate.

Readiness registry: `sha256:9df9f09bc6ccc6bc5b98f664c21dfe5ad644518608898beaae1ae60d9ca1e322`

## Host requirements

Properties this tool does not implement and does not claim. A host deploying it must provide them.

- **XSEC-04 — Encrypt data in transit and at rest.**
  this tool declares network: none and writes nothing at rest outside the run directory it is given, so it can provide integrity at rest (every ledger is a hash chain) but not confidentiality at rest or transport encryption; the host must supply disk encryption for the run directory and TLS for any transport it adds. Recorded as a host requirement, never as a satisfied invariant.

## Non-goals

Deliberate boundaries, not gaps. Each is a thing the tool does not do, stated so that nobody has to
infer it from silence.

- **NON-GOAL-01** — It does not decide whether a change is a good idea. It produces a bounded, inert candidate and a review surface; the judgement, and the accountability for it, stay with the human reviewer.

- **NON-GOAL-02** — It does not run in production against live traffic. Every effect happens in an isolated worktree under a run directory outside the repository, and the source tree is proven unchanged afterwards.

- **NON-GOAL-03** — It does not reach the network. `network: none` is declared in every environment profile and enforced by the qualification harness refusing a run that attempts a connection; it is not a kernel-level egress block.

- **NON-GOAL-04** — It does not provide confidentiality at rest or transport encryption (XSEC-04). It provides integrity at rest by hash-chaining every ledger; the host supplies disk encryption and TLS.

- **NON-GOAL-05** — It does not sandbox at the container, namespace or VM level. Isolation here is process-level and path-level.

- **NON-GOAL-06** — It does not compile or semantically validate JA suite files. Cross-reference checking passes 66/66; compile-level validation of the overlay's JA surfaces remains INDETERMINATE.

- **NON-GOAL-07** — It does not replace a security review by people. It provides the threat registry, the adversarial evidence and the refusal codes a reviewer needs, and records what was and was not examined.

- **NON-GOAL-08** — It does not measure monetary cost. The bound provider is a deterministic in-process advisor with no metered spend; a host binding a metered provider supplies cost per call.
