# Scoped PR Builder Upgrade Application Report — 0.2.0-rc.1

**Applied:** 2026-09-03/04  
**Input baseline:** `7a35c8b3c24deca93bc134b8d4f44cee8ba8a2ea` plus the attached audited/fixed uncommitted changes  
**Prompt/workflow package:** `Scoped_PR_Builder_Upgrade_Prompt_Workflow_Package_v1.0.0`  
**Candidate version:** `0.2.0rc1`  

## Executive verdict

The package has been **applied as an executable release-candidate tranche**, not papered over as a false 0.2.0 GO. The candidate now installs, runs a foreign-repository generic workflow, creates real hygiene patches, runs repository-native tests, renders review, accepts a human signed approval, creates an isolated `spb/...` branch and commit, leaves the source working tree unchanged, and supports same-run scope narrowing.

The final production gate remains **NO-GO for 0.2.0** because live forge identity/CI, a real local model runtime, strong container sandbox execution, JA semantic compilation, Ed25519 approval integration, and an external pinned evaluation corpus were not available/proven in this local application environment. Those capabilities have executable boundaries/scaffolding where safe, but are not mislabeled PASS.

## Proven end-to-end evidence

- Foreign repo: `/mnt/data/spb_foreign_repo` (local validation fixture).
- `spb run ... --recipe trim_trailing_whitespace --profile generic` reached `REVIEW_PENDING` with overall verification `PASS`.
- Generic `cross_reference` was `INDETERMINATE`/non-mandatory as intended; repository-native tests were mandatory and passed.
- Human CLI approval was hash-bound and signed.
- `spb apply` created isolated branch `spb/sha256-4596e90a85cadd227-trim-whitespace-in-a-py` and a real commit while `git status --short` on the source worktree remained empty.
- `spb narrow` reduced a two-path contract to one path, archived prior downstream artifacts under `history/<scope-hash-prefix>/`, minted a new scope hash, and removed stale plan/candidate/verification/review state.
- Wheel build succeeded with `pip wheel --no-build-isolation`; installing that wheel into a clean target and executing a generic foreign-repo run reached `REVIEW_PENDING` with verification `PASS`.

## Test evidence

Focused suites executed and passed during application:

- `test_intent_intake.py` — 5 tests PASS
- `test_patch_generator.py` — 4 tests PASS
- `test_verification_runner.py` — 5 tests PASS
- `test_approval_adapter.py` — 6 tests PASS
- `test_cli_regressions.py` — 2 tests PASS
- `test_release_gate.py` — 35 tests PASS after release-approval semantics were upgraded
- `test_guardrails*.py` focused discovery — 22 tests PASS
- `test_upgrade_v020.py` — 6 new focused upgrade tests PASS
- Parallel module run completed 11 additional modules with PASS before the execution window ended: approval, architecture, archive, capabilities, CLI regressions, components replay, contracts, control bindings, evidence retrieval, guardrails, guardrails composition.

The full 47-module discovery run was attempted twice but exceeded the available execution window. **It is recorded as uncompleted, not PASS.** No ledger row or expected fixture was used to substitute for unexecuted tests.

## Checklist status

| Item | Status | Applied result / remaining gate |
|---|---|---|
| 0.1 | **PASS** | New `GO` records require a human readiness approval; new GO records are classified `pilot-sha256sums-only`; historical empty-approval GO rows remain readable legacy evidence and are explicitly demoted in limitations documentation. |
| 0.2 | **PASS** | `corpus` and `generic` verification profiles implemented; Suite 01–66 xref is corpus-only; generic target tests are mandatory. |
| 0.3 | **PARTIAL** | `spb run` is now the single product CLI entry over the same slice adapter functions, but it does not yet drive the existing `WorkflowRun` WF-01…12 object directly. No false PASS. |
| 0.4 | **PASS** | `hard_limits.py` reads CAP-01/GRD-01, fails on disagreement, and intent hard caps derive from it. Environment quotas remain narrowing profiles. |
| 0.5 | **PASS** | `pyproject.toml`, installable `spb`, package markers, expanded `.gitignore`, and CI unittest discovery added. Wheel install/run smoke passed. |
| 0.6 | **PARTIAL** | Qualification already has non-pass mandatory verdict semantics, but the archived-ledger self-test still contains a skip path; a complete re-execution-only release harness migration remains. |
| 1.1 | **PARTIAL** | Added registered deterministic whitespace, final-newline, unused-import, checksum-normalization recipes and permanent unknown-recipe refusal. `py_rename_symbol` and opt-in ruff/eslint recipe-arg execution are not yet integrated. |
| 1.2 | **PARTIAL/PASS core** | Target-native pytest/unittest/npm/go/cargo discovery exists; generic tests execute in sandbox and are mandatory. Repo-native lint/typecheck discovery exists but is not yet mapped as separate mandatory jobs. |
| 1.3 | **PARTIAL** | Explicit language frontend abstraction added; Python is semantic AST. TS/JS/Go/Rust correctly return `INDETERMINATE` until grammar bindings are configured. JA remains non-semantic. |
| 1.4 | **PARTIAL** | Deterministic TODO/FIXME findings and allowed-path proposal module added; not yet wired into the main intake CLI. |
| 1.5 | **PASS** | Approved apply creates `spb/<intent>-<slug>` in the isolated worktree, commits with provenance, records branch/commit, and proves source tree unchanged. |
| 1.6 | **PASS** | `spb run --intent --recipe --profile` drives bind→intent→plan→patch→verify→review and stops at the human decision boundary. |
| 2.1 | **PARTIAL** | Exact expiring forge grants and deny-by-default write boundary exist; the repository environment registry has not yet promoted a live `ci_forge` profile. |
| 2.2 | **PARTIAL** | Injected forge client can push exact approved commit and create draft-only PR; no live GitHub/GitLab credential/provider was available to prove network execution. |
| 2.3 | **PARTIAL** | CODEOWNERS parse, last-match-wins resolution, required reviewer request boundary implemented and unit-tested; not live-forge proven. |
| 2.4 | **PARTIAL** | Pinned/hash-bound issue/PR fetch normalization implemented behind injected forge client; live provider unavailable. |
| 2.5 | **PARTIAL** | Exact-head required-check readiness evaluator implemented; no live CI polling provider proven. |
| 2.6 | **PARTIAL** | Draft/readiness primitives exist, but full branch-protection/no-self-approval contract is not yet integrated into workflow state transitions. |
| 3.1 | **PARTIAL** | Loopback-only interactive review server added with CSRF token and governed `review_surface` command dispatch; static review artifact remains separate. Full browser/VS Code integration not exercised. |
| 3.2 | **PASS** | `spb narrow` is a first-class same-run lineage operation: shrink-only, historical downstream archive, new contract hash, stale artifact invalidation. |
| 3.3 | **PARTIAL** | Verified identity abstraction added; GitHub App/OIDC/SSH verification is not connected to approval receipts yet. HMAC remains operational air-gap identity. |
| 3.4 | **PASS core** | Read-only `spb status` reports current state, blocker and unblocker. It can be extended with richer forge/model state later. |
| 4.1 | **PARTIAL** | Pinned local-model boundary with digest/schema/confidence gate added; no actual Ollama/vLLM runtime was available/proven and PROVIDERS registry remains conservative. |
| 4.2 | **PARTIAL** | Existing masking/source-label policy remains; explicit token/cost metering is not yet integrated. |
| 4.3 | **PASS boundary / PARTIAL integration** | Local-model boundary only accepts registered `recipe_name` + args and abstains on low confidence; main model orchestration still needs to route through it. |
| 4.4 | **PARTIAL** | Smell→recipe catalog added; serial N-run campaign fan-out is not yet implemented. |
| 4.5 | **PARTIAL** | Conservative Python import/test-impact graph module added; not yet the authoritative GRD-03 engine across all supported languages. |
| 5.1 | **PARTIAL** | Sandbox backend capability discovery distinguishes degraded process, bubblewrap and Docker. Strong backend execution/mount/resource enforcement is not yet wired. |
| 5.2 | **PASS documentation/control boundary** | `HOST_SECURITY_CONTRACT.md` added; XSEC-04 remains delegated and explicitly not satisfied by the overlay. |
| 5.3 | **PARTIAL** | Vetted-library Ed25519 sign/verify helper added as optional crypto extra; approval receipt schema has not yet migrated from HMAC. |
| 5.4 | **PARTIAL / honest posture** | JA language frontend reports `INDETERMINATE` without compiler; no false semantic PASS added. Full claim cleanup across all generated corpus documentation remains. |
| 5.5 | **NOT COMPLETE** | No registry-growth CI budget was added; this avoids creating another registry merely to claim the task. |
| 5.6 | **BLOCKED** | No 5–10 repository immutable external evaluation corpus was available/materialized in this offline execution environment. No fake public-repo pins were invented. |
| 5.7 | **BLOCKED for final 0.2.0 / PASS for RC packaging** | Installable/buildable `0.2.0rc1` wheel exists and installed generic smoke passed. Final `0.2.0` is deliberately not claimed until external forge/eval/remaining production gates pass. |

## Important defects found and fixed while applying the package

1. **Generic verification false-PASS risk:** repository-native tests were initially non-mandatory in the new profile. Fixed: tests are mandatory; absent tools/tests become `INDETERMINATE`, failures become `FAIL`.
2. **GRD-02 declaration false positive:** a whitespace edit to a `def` line was counted as a newly added declaration because the unified diff contained a `+def`. Fixed: declaration additions are netted against matching removed declaration lines, so a modified declaration is not a new declaration.
3. **Installed generic package corpus coupling:** the guardrail registry required Suite 01–66 authority files even when installed as a generic package. Fixed: exact suite binding remains strict in a corpus/source checkout or when explicitly requested, while installed generic operation records that corpus suite bindings are unavailable instead of failing closed on an inapplicable corpus requirement.

## Remaining release blockers

The candidate should remain `0.2.0rc1` until these are proven:

- direct WF-01…12 orchestration through the single CLI product path;
- qualification gate guaranteed to re-execute instead of accepting archived self-evidence;
- rename + host-tool recipes and complete repo-native lint/typecheck mapping;
- explicit `ci_forge` environment/capability policy and live draft-PR proof;
- verified connected identity + branch protection + external CI readiness;
- real pinned local model integration with token/cost meter;
- strong sandbox execution backend;
- Ed25519 approval receipt migration;
- JA compiler integration or complete runtime-authority claim cleanup;
- registry-growth guard;
- external pinned evaluation corpus and metrics;
- full regression suite completion in CI.

## Release decision

**RC GO:** usable as an upgraded, fail-closed development/review candidate.  
**Production 0.2.0:** **NO-GO / BLOCKED** until the blockers above are satisfied.

## Final packaging verification — 2026-09-03

Final pre-commit checks executed on the release-candidate working tree:

- `git diff --check` — PASS.
- `python -m py_compile spb_cli.py 'Scoped PR Builder'/adapters/*.py 'Scoped PR Builder'/tools/*.py` — PASS.
- `test_upgrade_v020.py` — 6/6 PASS.
- `test_verification_runner.py` — 5/5 PASS.
- `test_approval_adapter.py` — 6/6 PASS.
- `test_release_gate.py` — 35/35 PASS, including the new human-readiness-approval requirement.

The complete all-module test discovery was attempted earlier but exceeded the available single-command execution window; it is therefore **not** reported as PASS. Focused and integration evidence above is the basis for this release-candidate verdict.

**Applied candidate commit:** use `git rev-parse HEAD` on the delivered Git bundle/source checkout; the report is part of that commit and therefore does not self-embed its own hash.
