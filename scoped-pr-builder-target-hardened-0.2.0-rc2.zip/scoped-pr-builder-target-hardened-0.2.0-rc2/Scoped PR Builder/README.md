# Scoped PR Builder — unnumbered composition overlay

The Scoped PR Builder for Tech-Debt Removal is an **integration overlay**: it composes existing,
authoritative Suite 01–66 behavior into one governed refactor workflow. It owns *composition only*.
It never renumbers, forks, or duplicates a suite's contract, and it holds no write authority of its
own — every effect it sequences is granted, validated, executed, explained, and recorded by the
suite that owns that domain.

Corpus status inherited from the repository: `provisional-generated-not-production-compiler-validated`.
The JA21 surfaces below are specification-level programs; the `adapters/` Python modules are the
reference executable path that mirrors them field-for-field (Python 3.10+, standard library only).

## Bounded responsibility

| The overlay does | The overlay never does |
| --- | --- |
| Bind one repository/worktree/revision and pin it for the run | Read from a working copy instead of the pinned revision |
| Accept one narrow refactor intent as a hash-bound scope contract | Widen scope through fallback, defaults, or model output |
| Retrieve exact local evidence and derive an *advisory* plan | Treat model output as evidence, verification, or approval |
| Produce one inert, bounded candidate patch | Apply anything to the source worktree |
| Run independent verification in a throwaway sandbox | Substitute a model assertion for a test receipt |
| Render a display-only review surface | Record or imply a decision |
| Require a hash-bound, signed, expiring human approval | Mint, replay, or extend an approval |
| Apply only in an isolated worktree after full revalidation | Skip freshness, scope, or receipt revalidation |
| Archive state/provenance/audit and prove rollback | Erase lineage or rewrite ledgers |

## Authority map (which suite owns what)

| Concern | Authoritative suite(s) | Overlay surface that composes it |
| --- | --- | --- |
| Repository context, symbols, dependencies, freshness, worktrees | Suite 40 Repository Context Engine; 58.1/58.8 | `adapters/repository_context_adapter.py`, `scoped_pr_builder_adapters.jasp` |
| Exact local evidence, evidence authority, working-set funnelling | Suite 51 Repository Retrieval and Memory; Suite 09 Funnel | `adapters/evidence_retrieval.py` |
| Planning and impact | Chatbot 47.2/47.5, Orchestrator, Compass, Action Cards 49.11 | `adapters/evidence_retrieval.py` (advisory plan), `scoped_pr_builder_orchestrator.jaa` |
| Bounded diff/patch, confinement, hash-bound approval | Suite 50 Diff Patch and Review; Release Plane 43.2/43.8 | `adapters/patch_generator.py`, `adapters/approval_adapter.py` |
| Authorization, capability, least privilege, policy gates | Chair (13), Capability and Security Plane (44), Capability Manifests (55), Safety Gate (28) | `scoped_pr_builder_policy.jasec` |
| Sandboxed build/test/lint/verification | Suites 56/57/60/65; Release Plane 43.1 | `adapters/verification_runner.py`, `scoped_pr_builder_runtime.jaops` |
| Human review surface | Full Stack UI (26), Action Cards (49), Core Studio (39) | `adapters/review_renderer.py`, `scoped_pr_builder_review.jaui` |
| State, provenance, audit, archive, rollback | Filing Cabinet (12), Archive Ledger (29), Observer (01), Cypher (11), Anthology (02), Tables (08) | `adapters/archive_adapter.py`, `scoped_pr_builder_state.dmk`, `scoped_pr_builder_contract.jad` |
| Model/provider routing | Local Model Provider and Health (54), deepML Worker (27) | reserved: `scoped_pr_builder_orchestrator.jaa` tool slots (advisory only) |
| Evaluation and content defense | Evaluation and Content Defense (52), Safety Gate (28) | `scoped_pr_builder_evaluation.jate`, `tests/test_adversarial_pilot.py` |
| Release and rollback | Release Plane (43), Sandbox Engine 65.26 | `adapters/archive_adapter.py` (rollback proof) |

## Overlay manifest (source TODO §2)

| Surface | Profile | Bounded responsibility | Status |
| --- | --- | --- | --- |
| `README.md` | markdown | this manifest: responsibility, authority map, conventions | established (OVERLAY-01) |
| `scoped_pr_builder_contract.jad` | `ja.data` | `ScopedPrRunContractRecord`: run/repo/worktree/revision/snapshot/scope/policy/tool identities; versioned run-state vocabulary | established (SLICE-01, OVERLAY-02) |
| `scoped_pr_builder_policy.jasec` | `ja.security` | roles, grants, deny-by-default, approval + freshness + confinement revalidation for apply/rollback | established (SLICE-01, OVERLAY-03) |
| `scoped_pr_builder_orchestrator.jaa` | `ja.agent` | sequences the governed path through authoritative suites; halts on denial or missing evidence | established (SLICE-01, OVERLAY-04) |
| `scoped_pr_builder_runtime.jaops` | `ja.operations` | offline runtime workspace: one worker per stage, network disabled, rollback on health failure | established (OVERLAY-05) |
| `scoped_pr_builder_adapters.jasp` | `ja.service` | the local-Git adapter service (bind/isolate); message fields mirror `adapters/local_git_adapter.py` | established (SLICE-01, OVERLAY-06) |
| `scoped_pr_builder_review.jaui` | `ja.interface` | display-only review surface: evidence, diff, uncertainty, verification, rollback, approval controls | established (OVERLAY-07) |
| `scoped_pr_builder_evaluation.jate` | `ja.training` | offline benchmark/regression gates with fail-closed thresholds | established (OVERLAY-08) |
| `scoped_pr_builder_state.dmk` | `deepml.kernel` | append-only run-state data source mirrored from the contract schema | established (SLICE-01, OVERLAY-09) |

## Reference executable path

| Module | Composes | Introduced |
| --- | --- | --- |
| `adapters/local_git_adapter.py` | Suite 40.5 worktrees, 50.6 confinement | SLICE-01 |
| `adapters/repository_context_adapter.py` | Suite 40.1–40.5 records | SLICE-02 |
| `adapters/intent_intake.py` | scope contract (50.6, Chair) | SLICE-03 |
| `adapters/evidence_retrieval.py` | Suite 51.1/51.4, Funnel; advisory plan | SLICE-04 |
| `adapters/patch_generator.py` | Suite 50.1/50.2 inert bounded patch | SLICE-05 |
| `adapters/verification_runner.py` | Suites 56/57/60 sandboxed checks | SLICE-06 |
| `adapters/review_renderer.py` | Action Cards 49.1–49.14, Full Stack UI | SLICE-07 |
| `adapters/approval_adapter.py` | Suite 50.5 approval, Chair 13, Release Plane 43.8 | SLICE-08 |
| `adapters/archive_adapter.py` | Filing Cabinet 12, Archive Ledger 29, Observer 01 | SLICE-09 |
| `contracts/REGISTRY.json` + `adapters/contracts.py` | versioned contract registry (schema, examples, Tables/08 registration row) and the closed stdlib validator | ARCH-01-T01 |
| `architecture/boundaries.json` + `adapters/architecture.py` | explicit boundary registry (authoritative suites, trust, effects, I/O contracts) and the crossing check | ARCH-01-T01 |
| `adapters/controls.py` | executable controls named by registry entries: state machine, policy decision, audit, uncertainty, idempotency, semver, offline gate | ARCH-01-T01 (bound by IMPL/API-T01) |
| `architecture/wiring.json` + `adapters/wiring.py` | boundary ports: stable ids, bounded/validated envelopes, identity pinning, chained audit of crossings and denials, idempotent replay | ARCH-01-T02 |
| `adapters/controls.run_control` + registry `binding` blocks | control dispatcher: each bound control names its scaffold suite, its adapter entry and an executed demo (enforced + refused) | IMPL-01-T02 |
| `adapters/wiring.Run` identity pinning + `provenance.jsonl` | identity carried across every boundary: immutable fields, provenance head advanced per crossing, trace vector (cV 2.1 pattern) | ARCH-01-T03 |
| `adapters/wiring.Run.classify` + boundary `failure_behavior.classes` | fail-closed classes (unavailable/stale/unauthorized/malformed/version_incompatible): every denial classified and recorded with its reason; availability checked at crossing time | ARCH-01-T04 |
| `adapters/controls.expose` + registry `review_exposure` | decision-relevant control results (enforced and refused) rendered as display-only card fragments and chained on the run audit ledger | IMPL-01-T04 |
| `tests/test_phase01_e2e.py` + `tests/scenarios/*.json` + `tests/evidence_ledger.py` | cross-layer contract scenarios per boundary/control/API contract; results chained on the test/evidence ledger (`evidence/TEST_LEDGER.jsonl`) | ARCH-01-T05 |
| `guardrails/RULES.json` + `adapters/guardrails.py` | paper guardrails as versioned, executable rules: PASS / DENY / ABSTAIN / DIAGNOSTIC, hash-bound decisions, facts schemas, examples per state | PAPER-GRD-01-T01 |
| `guardrails.enforce` at `wiring.Run.cross` and `approval_adapter.apply_isolated` | guardrails enforced at the orchestration boundary (every port) and the effect boundary (isolated apply): PASS / DENY / ABSTAIN / DIAGNOSTIC, every decision audited, no fallback | PAPER-GRD-01-T03 |
| `review_renderer` guardrails section + `guardrails.review_fragment` | every paper rule shown before the state-changing action: statement, current state, current values, blocking reason, what satisfies it (display-only, hash-bound, re-evaluated at apply) | PAPER-GRD-01-T04 |
| `guardrails/RULES.json` CAP-01..05 + capability predicates | the five paper capabilities as executable rules (scope_intent, analogous_evidence, atomic_bounded_diff, halt_on_failure, knowledge_gap_surfacing) with facts from real artifacts | PAPER-CAP-01-T01 |
| `intake/SOURCES.json` + `adapters/intake.py` | authorized intake contracts per evidence source (identity, read-only scope, pinned revision, freshness, exclusions) → intake_record with eight explicit states | DATA-01…07-T01 |
| `components/COMPONENTS.json` + `adapters/components.py` | typed, versioned component interfaces (inputs/outputs/errors/bounds/provenance/capabilities) and the single invocation boundary that seals every result to its exact pinned inputs | COMP-01…11-T01 |
| `workflow/WORKFLOW.json` + `adapters/workflow.py` | the twelve paper workflow steps as versioned states/transitions over the run-state machine; every attempt persisted before and after as chained step records, replayable | WF-01…12-T01 |
| `store/STORES.json` + `adapters/store.py` | persistence stores: one record kind per concern (run state, artifact metadata, evidence/provenance, approvals, versions, retention/privacy, audit) written only through a chained, append-only ledger per store | STORE-01…07-T01 |
| `verification/CHECKS.json` + `adapters/verification_checks.py` | independent verification checks: one typed result (pass/fail/blocked/indeterminate) per mandatory condition, derived only from sandboxed job records; the gate consumes these receipts | VERIFY-01…07 |
| `security/THREATS.json` + `adapters/security.py` | security and content defense: one explicit threat per condition with its trust-boundary rule, deny codes and audit event; every denial is a chained row on the run's security trail before the refusal propagates | SEC-01…08 |
| `model/PROVIDERS.json` + `adapters/model_orchestration.py` | model orchestration and abstention: pinned approved providers, versioned prompt policy, source-labeled authorized context, recorded calls, schema-validated advisory output routed to accept / abstention / human review; the model path mints nothing | MODEL-01…07 |
| `review/REVIEW.json` + `adapters/review_surface.py` | human review and approval surface: one declared reviewer behavior per requirement (original evidence byte-exact, analyzed vs not analyzed, narrow-and-rerun, reject without side effects, require evidence, approval identity/timestamp/scope, human accountability); everything shown hash-bound; every action a typed command | HUMAN-01…07 |
| `qualification/MATRIX.json` + `adapters/qualification.py` + `tests/qualification_harness.py` | test and adversarial qualification: one named deterministic fixture and scenario per mandatory requirement (unit, integration, adversarial, end-to-end), each isolated, version-pinned, network-free, asserted against an exact expected outcome, evidence-bearing and mandatory in the offline gate | TEST-UNIT-01, TEST-INT-01, TEST-ADV-01…07, TEST-E2E-01…06 |
| `tools/spb.py` | pilot command line over the adapters (no authority of its own) | SLICE-02…09 |
| `tests/` | deterministic unit + adversarial tests (`python3 "Scoped PR Builder/tests/<module>.py"`) | SLICE-01…10 |

Run artifacts are written to a run directory that must lie **outside** the repository root; the
overlay refuses to write inside the bound repository.

## Conventions

- Every JA21 surface declares its language header, a stable `overlay.scoped_pr_builder.*` module
  identity, `policy no_network`, the five analytical participants (SOPHIA, CHARLOTTE, LANDON,
  Professor, Podium) where the profile expects them, an assertion, and one emission.
- Identities are content-addressed (`sha256:` digests over canonical JSON); revisions are full
  40-character commit ids; every artifact carries the hash of the artifact it was derived from.
- Missing, stale, malformed, conflicting, unauthorized, or indeterminate inputs fail closed with a
  stable `AdapterError` code; INDETERMINATE is never reported as PASS.
- Donor material pulled from the GitHub Junkyard is recorded in `PROVENANCE.jsonl` (append-only)
  and attributed in `THIRD-PARTY-NOTICES.md`; donor originals are never modified.

## Non-goals

Production readiness, certification of any parent requirement, a JA compiler, network access,
model-driven patch generation without the same bounds, and any write to the source worktree.


## 0.2.0-rc.1 executable upgrade candidate

This candidate adds an installable `spb` CLI, generic verification, real deterministic hygiene recipes, repository-native tests, isolated branch/commit application, `spb run`, `spb status`, and same-run `spb narrow`. See `UPGRADE_APPLICATION_STATUS.md` for the 34-item gate ledger. The final 0.2.0 production claim is intentionally blocked until live forge/CI/identity, local-model, strong-sandbox, JA/evaluation and remaining release gates are proven.


## 0.2.0-rc.2 comparative hardening
RC2 uses 0.2.0-rc.1 as the functional superset of the audited/fixed tree and adds validation/security/test-discovery hardening found during a direct bundle comparison. The prior RC1 application report is retained as historical evidence; `HARDENING_RC2_STATUS.md`, `BUNDLE_COMPARISON.md`, and `MASTER_TODO.md` describe the newer assessment. Production 0.2.0 remains blocked on the environment-dependent gates listed there.
