---
document: DOC-11 — Incident and rollback runbook
owner: the Scoped PR Builder overlay maintainers
generated_by: scoped_pr_builder.documentation/0.1.0 (generator `incident_runbook`)
generated_at: 2026-09-03T23:22:05+00:00
knowledge_repository: 41.1/runbook
---

# DOC-11 — Incident and rollback runbook

> **This document is generated from the registries it describes.** It is not edited by hand: any change made here is overwritten on the next generation, and the freshness check refuses a document that no longer matches its sources. To change what it says, change the implementation.

## Provenance of this document

- **Owner:** the Scoped PR Builder overlay maintainers
- **Last validated against:** `environments` @ `025885e3bbe78d71`, `workflow` @ `4822ed12a3494213`
- **Last validated at:** set at generation time
- **Authoritative suites:** `Release Plane/43.13_Release_Plane_Rollback.jaops`, `Indexing Storage Resources Logs and Recovery/58.4_Diagnostics.jaops`

### Assumptions

What this document takes as given. If one of these stops being true, the document is wrong even though its hashes still match.

- Rollback is exercised by every applying run rather than followed from memory.
- Every declared failure kind routes fail-closed; a run never advances on failure.

### Known gaps

What this document does **not** cover, stated here rather than left to be discovered.

- The incidents listed are the ones this tool can detect and name. An incident originating outside it — a host compromise, a repository supply-chain problem — is out of scope here.
- There is no paging or alerting integration; `observability.alerts` produces the alerts, and routing them is the host's.

### Change triggers

Changing any of these makes this document stale. The freshness check detects it; these are stated so a reader knows what to watch without running it.

- a failure kind or its route changes
- an environment's quotas change
- the rollback proof changes shape

## Rollback

Rollback is not a procedure someone follows from memory; it is a code path every applying run exercises. `archive_adapter.prove_rollback` re-checks the source tree identity and the absence of any linked worktree after an isolated apply, and records the proof.

**To roll back a run that applied a candidate:**

1. The run has already done it. WF-12 rolls back by default and the run reaches `ROLLED_BACK`; `archive/rollback.json` carries the before/after tree identities and the verdict.
2. To confirm: the `before.source_tree_identity` and `after.source_tree_identity` must be equal, `after.status_clean` true, and `after.worktree_present` false.
3. If they are not equal, the source tree changed and this is an incident — go to *Unclean state* below.

## Failure kinds and where they route

Every failure is one of a declared set, and each routes fail-closed. A failure that is not one of these does not route forward — the run stays where it is and does not advance.

| failure kind | routes to |
|---|---|
| `authorization_failure` | `BLOCKED` |
| `stale_context` | `BLOCKED` |
| `insufficient_evidence` | `ABSTAINED` |
| `tool_failure` | `RETRY_THEN_BLOCKED` |
| `verification_failure` | `BLOCKED` |
| `cancellation` | `CANCELLED` |
| `timeout` | `RETRY_THEN_BLOCKED` |

## Incidents

### A ledger chain does not verify

Symptom: `archive.chain_broken` or `archive.chain_tampered`, or a release gate reporting `release.ledger_broken`.

This means a row was edited or removed. **The correct response is not to regenerate the ledger.** The run's evidence is no longer trustworthy: quarantine the run directory, and treat every conclusion drawn from it as unproven. A gate that reads a broken chain yields no receipts at all, deliberately — partial evidence from a tampered ledger is worse than none.

### Unclean state after an apply

Symptom: `environment.unclean_shutdown`, or a rollback proof whose tree identities differ.

The shutdown records the leftovers and refuses rather than tidying them away, so the evidence of what happened is intact. Inspect `environment/lifecycle.jsonl` for the shutdown row, then the leftover paths it names. Nothing is cleaned automatically because a later run must not inherit that state silently.

### An approval no longer applies

Symptom: `approval.stale_inputs` or `approval.invalidated` at WF-10 or at the effect boundary.

This is working as intended: a bound input changed, or a human command invalidated the approval. A new human decision is required. There is no override.

### The release gate says NO_GO

The decision carries a remediation list saying what would unblock each assertion. `stale` means re-run the suite that issues those receipts; `conflicting` means investigate the failing one and do **not** re-run until you know why it failed.

## Quotas by environment

A run that exceeds these is refused at generation rather than truncated.

| environment | max run seconds | max changed files | max diff lines |
|---|---|---|---|
| `developer_sandbox` | 1800 | 5 | 200 |
| `ci_validation` | 3600 | 5 | 200 |
| `staging` | 3600 | 5 | 200 |
| `production_read_only` | 900 | 0 | 0 |
| `privileged_execution` | 3600 | 5 | 200 |
| `isolated_test_tenant` | 3600 | 5 | 200 |

---

_Generated from 2 registry/registries by `scoped_pr_builder.documentation` (`incident_runbook`). Documentation registry `af4b762e936d9e21`._
