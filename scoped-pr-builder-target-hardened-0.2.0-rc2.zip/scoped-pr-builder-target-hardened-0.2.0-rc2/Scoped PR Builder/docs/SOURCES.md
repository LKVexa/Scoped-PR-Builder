---
document: DOC-03 — Source and connector inventory
owner: the Scoped PR Builder overlay maintainers
generated_by: scoped_pr_builder.documentation/0.1.0 (generator `source_inventory`)
generated_at: 2026-09-03T23:22:01+00:00
knowledge_repository: 41.1/sources
---

# DOC-03 — Source and connector inventory

> **This document is generated from the registries it describes.** It is not edited by hand: any change made here is overwritten on the next generation, and the freshness check refuses a document that no longer matches its sources. To change what it says, change the implementation.

## Provenance of this document

- **Owner:** the Scoped PR Builder overlay maintainers
- **Last validated against:** `intake` @ `09e3da657787e812`, `environments` @ `025885e3bbe78d71`
- **Last validated at:** set at generation time
- **Authoritative suites:** `Knowledge Repository/41.5_Knowledge_Repository_Suite_References.jad`, `Repository Context Engine/40.1_Repository_Context_Engine_Context.jad`, `Repository Retrieval and Memory/51.5_Repository_Retrieval_and_Memory_Freshness_and_Provenance.jad`

### Assumptions

What this document takes as given. If one of these stops being true, the document is wrong even though its hashes still match.

- The only external connector is a local git repository opened read-only.
- Every environment profile declares `network: none`, enforced by the qualification harness refusing a run that attempts a connection.

### Known gaps

What this document does **not** cover, stated here rather than left to be discovered.

- This inventories what the tool connects to, not what a host might place around it.
- `network: none` is a declaration the harness enforces, not a kernel-level egress block.

### Change triggers

Changing any of these makes this document stale. The freshness check detects it; these are stated so a reader knows what to watch without running it.

- a source is admitted or withdrawn
- an environment's network mode changes
- a new connector adapter is introduced

## Admitted sources

| source | bound by | permission scope | size caps |
|---|---|---|---|
| `DATA-01` | repository_binding (Suite 40.5): repository_id, worktree | `repository.read` | {'max_commits': 5000, 'max_item_bytes':  |
| `DATA-02` | well-known manifest names at the pinned revision (pyproj | `repository.read` | {'max_item_bytes': 1048576, 'max_items': |
| `DATA-03` | test directories, test_*/ *_test modules, conftest/fixtu | `repository.read` | {'max_item_bytes': 524288, 'max_items':  |
| `DATA-04` | an authorized, committed JSONL export at export_path (Pl | `repository.read` | {'max_item_bytes': 8388608, 'max_items': |
| `DATA-05` | markdown/text under adr, design, architecture, rfc or de | `repository.read` | {'max_item_bytes': 1048576, 'max_items': |
| `DATA-06` | an authorized, committed JSONL export at export_path (Pl | `repository.read` | {'max_item_bytes': 8388608, 'max_items': |
| `DATA-07` | CODEOWNERS at the root, .github/ or docs/ at the pinned  | `repository.read` | {'max_item_bytes': 262144, 'max_items':  |

## Connectors

This tool has one external connector — a local git repository, opened read-only — and no others. It declares `network: none` in every environment profile, so there is no HTTP client, no API client and no message bus to inventory.

| connector | adapter | posture | how it is bound |
|---|---|---|---|
| local git repository | `adapters/local_git_adapter` | read-only; worktrees under the run directory | the operator supplies the path at bind time |
| model provider | `adapters/model_orchestration` | in-process deterministic advisor, pinned | declared in `model/PROVIDERS.json`; an unapproved provider is refused |

## Network posture by environment

| environment | network | posture | max changed files |
|---|---|---|---|
| `developer_sandbox` | none | draft_only | 5 |
| `ci_validation` | none | draft_only | 5 |
| `staging` | none | apply_isolated | 5 |
| `production_read_only` | none | read_only | 0 |
| `privileged_execution` | none | apply_isolated | 5 |
| `isolated_test_tenant` | none | apply_isolated | 5 |

---

_Generated from 2 registry/registries by `scoped_pr_builder.documentation` (`source_inventory`). Documentation registry `af4b762e936d9e21`._
