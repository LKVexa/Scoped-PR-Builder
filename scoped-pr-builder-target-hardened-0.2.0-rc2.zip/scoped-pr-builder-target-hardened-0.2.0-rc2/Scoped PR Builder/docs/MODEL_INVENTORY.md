---
document: DOC-06 — Model and tool inventory
owner: the Scoped PR Builder overlay maintainers
generated_by: scoped_pr_builder.documentation/0.1.0 (generator `model_inventory`)
generated_at: 2026-09-03T23:22:03+00:00
knowledge_repository: 41.1/model_inventory
---

# DOC-06 — Model and tool inventory

> **This document is generated from the registries it describes.** It is not edited by hand: any change made here is overwritten on the next generation, and the freshness check refuses a document that no longer matches its sources. To change what it says, change the implementation.

## Provenance of this document

- **Owner:** the Scoped PR Builder overlay maintainers
- **Last validated against:** `model` @ `a16e6bf7cb7f550d`, `components` @ `38428b02cfcd7135`
- **Last validated at:** set at generation time
- **Authoritative suites:** `Local Model Provider and Health/54.6_Local_Model_Provider_Contract.jasp`, `Sandbox and Offline Runtime/63.3_Tests.jaops`

### Assumptions

What this document takes as given. If one of these stops being true, the document is wrong even though its hashes still match.

- The bound provider is a deterministic in-process advisor; there is no metered spend and no network call.
- Model output is untrusted: it is schema-validated and cannot mint permissions, approvals or verification.

### Known gaps

What this document does **not** cover, stated here rather than left to be discovered.

- No monetary cost is recorded, because none is metered. A host binding a metered provider supplies cost per call.
- Token accounting is not tracked; call counts and purposes are.

### Change triggers

Changing any of these makes this document stale. The freshness check detects it; these are stated so a reader knows what to watch without running it.

- a provider is added, removed or re-pinned
- the model output contract changes
- a tool component's capabilities change

## Model providers

| provider | kind | model | version | pinned | network | output contract |
|---|---|---|---|---|---|---|
| `deterministic-advisor` | deterministic_local | deterministic-advisor | 0.1.0 | yes | none | `model_output` |


## What model output may never do

These are refused structurally: the fields are rejected by the output contract before anything reads them, and the refusal is by name rather than by heuristic.

| cannot | meaning |
|---|---|
| `mint_permissions` | grant itself or anything else an effect |
| `mint_approvals` | produce or assert a human approval |
| `assert_verification` | claim a verification verdict |
| `expand_scope` | widen the accepted scope contract |

## Tools

Tool invocations are argv vectors, never shell strings. An element carrying control bytes, or an absolute path outside the sandbox and overlay, is refused at `security.validate_argv`.

| component | title | timeout (s) | max output bytes |
|---|---|---|---|
| `COMP-01` | Repository parser and symbol index | 120 | 104857600 |
| `COMP-02` | AST/CST and semantic code graph | 120 | 209715200 |
| `COMP-03` | Dependency/build graph | 60 | 104857600 |
| `COMP-04` | Repository-convention learner | 120 | 52428800 |
| `COMP-05` | Change-impact engine | 60 | 52428800 |
| `COMP-06` | Refactoring planner | 60 | 20971520 |
| `COMP-07` | Atomic patch/diff generator | 60 | 10485760 |
| `COMP-08` | Incremental compiler/test runner | 600 | 52428800 |
| `COMP-09` | Patch-size/scope governor | 10 | 1048576 |
| `COMP-10` | Human review/approval UI | 30 | 20971520 |
| `COMP-11` | Rollback/checkpoint manager | 60 | 10485760 |

---

_Generated from 2 registry/registries by `scoped_pr_builder.documentation` (`model_inventory`). Documentation registry `af4b762e936d9e21`._
