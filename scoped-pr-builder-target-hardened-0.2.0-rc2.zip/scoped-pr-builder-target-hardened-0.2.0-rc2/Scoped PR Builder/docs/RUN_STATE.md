---
document: DOC-08 — Run-state schema
owner: the Scoped PR Builder overlay maintainers
generated_by: scoped_pr_builder.documentation/0.1.0 (generator `run_state_schema`)
generated_at: 2026-09-03T23:22:04+00:00
knowledge_repository: 41.1/run_state
---

# DOC-08 — Run-state schema

> **This document is generated from the registries it describes.** It is not edited by hand: any change made here is overwritten on the next generation, and the freshness check refuses a document that no longer matches its sources. To change what it says, change the implementation.

## Provenance of this document

- **Owner:** the Scoped PR Builder overlay maintainers
- **Last validated against:** `workflow` @ `4822ed12a3494213`, `contracts` @ `fcf0321f6d5bb145`
- **Last validated at:** set at generation time
- **Authoritative suites:** `Knowledge Repository/41.10_Knowledge_Repository_Operational_Workflows.jad`, `Filing Cabinet/12_filing_cabinet_ledgers.jad`

### Assumptions

What this document takes as given. If one of these stops being true, the document is wrong even though its hashes still match.

- A transition is admitted only when it is declared and its required evidence is present as a sha256 digest.
- A terminal state admits no further transition.

### Known gaps

What this document does **not** cover, stated here rather than left to be discovered.

- The state machine is per run. Concurrency between runs is out of scope: each run has its own directory and shares nothing.
- Retry and replay semantics are summarised; `workflow/WORKFLOW.json` declares them per step.

### Change triggers

Changing any of these makes this document stale. The freshness check detects it; these are stated so a reader knows what to watch without running it.

- a state or transition is added or removed
- a transition's required evidence changes
- a workflow step's state change is re-declared

## Run states

14 states, of which 4 are terminal. A run in a terminal state admits no further transition — the refusal is `state.terminal`.

```
  INTAKE → BOUND → INTENT_ACCEPTED → PLANNED → PATCH_INERT → VERIFIED → REVIEW_PENDING → APPROVED → APPLIED_ISOLATED → ARCHIVED

  terminal: ABSTAINED, BLOCKED, CANCELLED, ROLLED_BACK
```

## Declared transitions and their required evidence

A transition is admitted only when it is declared AND the evidence it names is present as a sha256 digest. This is why a run cannot skip forward: the evidence for the step it skipped does not exist.

| from | to | required evidence |
|---|---|---|
| `APPLIED_ISOLATED` | `ARCHIVED` | `('manifest_hash',)` |
| `APPROVED` | `APPLIED_ISOLATED` | `('applied_record_hash',)` |
| `BOUND` | `INTENT_ACCEPTED` | `('scope_contract_hash',)` |
| `INTAKE` | `BOUND` | `('worktree_hash',)` |
| `INTENT_ACCEPTED` | `PLANNED` | `('plan_hash',)` |
| `PATCH_INERT` | `VERIFIED` | `('report_hash',)` |
| `PLANNED` | `PATCH_INERT` | `('patch_hash',)` |
| `REVIEW_PENDING` | `APPROVED` | `('receipt_hash',)` |
| `VERIFIED` | `REVIEW_PENDING` | `('card_hash',)` |

## Workflow steps

12 declared steps.

| step | title | state change | transition evidence |
|---|---|---|---|
| `WF-01` | Authenticate and establish authority | `INTAKE` → `INTAKE` | `authority_hash` |
| `WF-02` | Pin the target artifacts and revisions | `INTAKE` → `BOUND` | `worktree_hash` |
| `WF-03` | Collect only authorized evidence | `BOUND` → `INTENT_ACCEPTED` | `scope_contract_hash` |
| `WF-04` | Normalize and index the evidence | `INTENT_ACCEPTED` → `INTENT_ACCEPTED` | `index_hash` |
| `WF-05` | Run deterministic analysis first where applicabl | `INTENT_ACCEPTED` → `INTENT_ACCEPTED` | `retrieval_id` |
| `WF-06` | Run model reasoning only over authorized, proven | `INTENT_ACCEPTED` → `PLANNED` | `plan_hash` |
| `WF-07` | Generate a bounded draft/recommendation/artifact | `PLANNED` → `PATCH_INERT` | `patch_hash` |
| `WF-08` | Verify the output using independent tools or che | `PATCH_INERT` → `VERIFIED` | `report_hash` |
| `WF-09` | Expose evidence, uncertainty, scope, and verific | `VERIFIED` → `REVIEW_PENDING` | `card_hash` |
| `WF-10` | Require the paper-specified human decision/appro | `REVIEW_PENDING` → `APPROVED` | `receipt_hash` |
| `WF-11` | Record the full evidence and decision trail | `APPROVED` → `ARCHIVED` | `applied_record_hash`, `manifest_hash` |
| `WF-12` | Rollback/abort cleanly if scope, evidence, autho | `INTAKE, BOUND, INTENT_ACCEPTED, PLANNED, PATCH_INERT, VERIFIED, REVIEW_PENDING, APPROVED, APPLIED_ISOLATED, ARCHIVED` → `ROLLED_BACK` | `rollback_hash` |

---

_Generated from 2 registry/registries by `scoped_pr_builder.documentation` (`run_state_schema`). Documentation registry `af4b762e936d9e21`._
