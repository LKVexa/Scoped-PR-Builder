---
document: DOC-07 — Provenance schema
owner: the Scoped PR Builder overlay maintainers
generated_by: scoped_pr_builder.documentation/0.1.0 (generator `provenance_schema`)
generated_at: 2026-09-03T23:22:03+00:00
knowledge_repository: 41.1/provenance
---

# DOC-07 — Provenance schema

> **This document is generated from the registries it describes.** It is not edited by hand: any change made here is overwritten on the next generation, and the freshness check refuses a document that no longer matches its sources. To change what it says, change the implementation.

## Provenance of this document

- **Owner:** the Scoped PR Builder overlay maintainers
- **Last validated against:** `contracts` @ `fcf0321f6d5bb145`
- **Last validated at:** set at generation time
- **Authoritative suites:** `Archive Ledger/29.5_Archive_Ledger_Provenance.jad`, `Filing Cabinet/12_filing_cabinet_ledgers.jad`, `Repository Retrieval and Memory/51.5_Repository_Retrieval_and_Memory_Freshness_and_Provenance.jad`

### Assumptions

What this document takes as given. If one of these stops being true, the document is wrong even though its hashes still match.

- Every ledger the tool writes is a hash chain, and an edited row refuses the effect that reads it.
- A material AI finding is an operation in the refactoring plan, grounded by that plan's own evidence refs.

### Known gaps

What this document does **not** cover, stated here rather than left to be discovered.

- This documents the schemas and the chain, not the retention of any particular run's evidence.
- Cross-run provenance (linking two runs over the same repository) is not modelled.

### Change triggers

Changing any of these makes this document stale. The freshness check detects it; these are stated so a reader knows what to watch without running it.

- a provenance-carrying contract is added or its version changes
- the chain primitive changes
- the grounding classification changes

## Provenance contracts

Each is a registered schema, validated at the boundary that produces it. The `examples.invalid` payloads in the registry are executable: every one is asserted to be refused.

| contract | version | title |
|---|---|---|
| `artifact_record` | 0.1.0 | Canonical artifact identity record (Filing Cabinet 12 / Cypher 1 |
| `audit_event` | 0.1.0 | Privileged-effect audit event (Observer 01 shaped, hash-chained) |
| `audit_logging` | 0.1.0 | Audit logging for retrievals, model/tool calls, artifacts, appro |
| `evidence_record` | 0.1.0 | Exact local evidence record (Suite 51.1 shaped, Funnel-annotated |
| `evidence_reference` | 0.1.0 | Explicit schema for evidence/provenance references |
| `freshness_pinning` | 0.1.0 | Source freshness and revision pinning so analyses reproduce |
| `immutable_ids` | 0.1.0 | Immutable run ID and artifact IDs (content-addressed) |
| `intake_record` | 0.1.0 | Authorized intake record (one explicit state per evidence source |
| `provenance_link` | 0.1.0 | One output→inputs lineage link (Archive Ledger 29.5 shaped) |
| `provenance_model` | 0.1.0 | Provenance model linking outputs to source artifacts, analyzer r |
| `run_state_entry` | 0.1.0 | Append-only, hash-chained run-state entry (overlay state.dmk row |
| `run_state_machine` | 0.1.0 | Versioned workflow state machine: start, analysis, review, appro |
| `store_record` | 0.1.0 | Persistence record envelope (stable identity, schema version, ow |

## The chain

Every ledger this tool writes is a hash chain: each row carries `prev_hash`, and its own `entry_hash` is the digest of the row including that link. An edited row breaks the chain, and the effect that reads it refuses.

```
  row[0].prev_hash = 'genesis'
  row[n].prev_hash = row[n-1].entry_hash
  row[n].entry_hash = sha256(canonical_json(row[n] without entry_hash))
```

The approval ledger is the one exception in shape, deliberately: its first row links to the candidate id rather than to `genesis`, so a receipt chain from another candidate cannot be spliced onto the front of it.

## What grounds a finding

A material AI finding is an operation in `plan/refactoring_plan.json`. It is grounded when every evidence id it cites resolves in that plan's own `evidence_refs` and the operation's recorded source hash still matches the evidence captured for that path, at the revision the run pinned. `observability.grounding` classifies each operation as grounded, stale, unresolvable or unsupported.

---

_Generated from 1 registry/registries by `scoped_pr_builder.documentation` (`provenance_schema`). Documentation registry `af4b762e936d9e21`._
