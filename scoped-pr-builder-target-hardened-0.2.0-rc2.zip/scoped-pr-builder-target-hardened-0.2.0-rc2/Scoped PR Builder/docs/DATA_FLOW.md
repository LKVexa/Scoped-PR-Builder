---
document: DOC-02 — Data flow and trust boundaries
owner: the Scoped PR Builder overlay maintainers
generated_by: scoped_pr_builder.documentation/0.1.0 (generator `data_flow`)
generated_at: 2026-09-03T23:22:01+00:00
knowledge_repository: 41.1/data_flow
---

# DOC-02 — Data flow and trust boundaries

> **This document is generated from the registries it describes.** It is not edited by hand: any change made here is overwritten on the next generation, and the freshness check refuses a document that no longer matches its sources. To change what it says, change the implementation.

## Provenance of this document

- **Owner:** the Scoped PR Builder overlay maintainers
- **Last validated against:** `threats` @ `e619605224dac5ce`, `intake` @ `09e3da657787e812`, `boundaries` @ `dddea2df85cb0b8d`
- **Last validated at:** set at generation time
- **Authoritative suites:** `Capability and Security Plane/44.3_Capability_and_Security_Plane_Trust_Boundaries.jasec`, `Evaluation and Content Defense/52.6_Evaluation_and_Content_Defense_Prompt_Injection_Defense.jasec`, `Repository Context Engine/40.1_Repository_Context_Engine_Context.jad`

### Assumptions

What this document takes as given. If one of these stops being true, the document is wrong even though its hashes still match.

- Repository content, documentation, tickets, logs, tool output and model output are all untrusted by default; the flow below is drawn on that basis.
- The tool declares `network: none`, so no data enters or leaves other than through the bound repository.

### Known gaps

What this document does **not** cover, stated here rather than left to be discovered.

- The diagram shows the governed path. Failure routes (abstention, block, rollback) are in the run-state document rather than drawn here.
- Data volumes and retention windows per store are not shown; `store/STORES.json` declares them.

### Change triggers

Changing any of these makes this document stale. The freshness check detects it; these are stated so a reader knows what to watch without running it.

- a threat's trust boundary or deny conditions change
- an admitted source is added or removed
- a boundary is added or removed

## Trust boundaries

Each row is a boundary where data changes trust level. The deny conditions are enforced in code at that boundary — they are not advice to a model.

| threat | trust boundary | title | denied when |
|---|---|---|---|
| `SEC-01` | {'rule': 'Everything read from the repository, documentation, tickets, logs or tool output is data: it is marked untrusted, scanned for directive shapes, and can neither authorize an effect nor satisfy a check. Authorization comes only from a signed human receipt on a human channel; validation only from executed check receipts; plans stay advisory.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['repository_content', 'documentation', 'tickets', 'logs', 'tool_output', 'model_output']} | Prompt injection from repository/docs/tickets/logs i | {'code': 'security.sec01.untrusted_channel_authorization', 'condition': 'an approval arrives through a model/content channel (model, agent, repository, doc, ticket, log)'}, {'code': 'security.sec01.plan_claims_authority', 'condition': 'an advisory plan claims any authority other than advisory_only'} |
| `SEC-02` | {'rule': 'Tool invocations are argv vectors, never shell strings; every path is canonical and repository-relative and every changed path lies inside the allowed roots and outside the forbidden ones — at intent intake, plan targets, the sandbox runner and the application boundary.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['repository_content', 'tool_output', 'model_output']} | Tool-call argument validation blocks command/path/sc | {'code': 'security.sec02.path_escape', 'condition': 'a path is absolute, traverses, or is not repository-relative'}, {'code': 'security.sec02.path_injection', 'condition': 'a path or tool argument carries control bytes, a home reference or an option shape, or names a location outside the sandbox/overlay'} |
| `SEC-03` | {'rule': 'Secret-bearing files are never admitted as analogous evidence; evidence records carry hashes, never text; sandbox job output is masked before it is recorded; a candidate that would add secret material is refused at application; the masker is the vetted MIT redaction core.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['repository_content', 'tool_output', 'logs']} | Secrets are never copied into model context unless e | {'code': 'security.sec03.secret_in_candidate', 'condition': 'the added lines of a candidate contain secret-shaped values'}, {'code': 'security.sec03.secret_forwarded', 'condition': 'text bound for a model context, log, UI or export was not passed through the masker'} |
| `SEC-04` | {'rule': 'Every artifact names its repository/revision/snapshot; retrieval, components and the application boundary refuse any artifact that names another tenant.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['repository_content', 'tool_output']} | Cross-project/tenant data leakage tests exist | {'code': 'security.sec04.foreign_repository', 'condition': 'an artifact names another repository or source snapshot'}, {'code': 'security.sec04.foreign_revision', 'condition': 'an artifact is bound to another revision of this repository'} |
| `SEC-05` | {'rule': 'Writes to stores require a declared writer; repository effects require an explicit allow decision and a verified human APPROVE receipt; a model/untrusted actor is refused outright; the source worktree is never written.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['model_output', 'tool_output']} | Unauthorized write attempts fail closed | {'code': 'security.sec05.model_actor', 'condition': 'the acting principal is a model/untrusted channel'}, {'code': 'security.sec05.write_denied', 'condition': 'the policy decision for the write is not an explicit allow, or the store writer is undeclared'} |
| `SEC-06` | {'rule': 'Every review card carries a classification (restricted / confidential / internal) and shows only the masked rendering; the archive classifies every text artifact and refuses to export restricted content.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['model_output', 'tool_output', 'repository_content']} | Sensitive generated output is classified before disp | {'code': 'security.sec06.unclassified_export', 'condition': 'an artifact classified restricted would leave the run unmasked'} |
| `SEC-07` | {'rule': 'A decision is recorded only through a human channel, signed with the approval key the model never holds, chained in the ledger with a unique nonce and a non-future timestamp; anything else is fabricated.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['model_output', 'repository_content', 'tool_output']} | Human approval tokens cannot be fabricated by model  | {'code': 'security.sec07.model_channel', 'condition': 'the approval channel is a model/agent/content channel'}, {'code': 'security.sec07.fabricated_token', 'condition': 'the receipt lacks a ledger HMAC signature or claims an impossible issue time'} |
| `SEC-08` | {'rule': 'Every ledger is hash-chained and append-only; only named adapters write; every effect boundary re-verifies every chain before acting; audit rows carry identifiers and hashes, never payload content.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['model_output', 'tool_output']} | Audit records cannot be modified by the model | {'code': 'security.sec08.audit_tampered', 'condition': 'a chained ledger no longer links or hashes'}, {'code': 'security.sec08.model_writer', 'condition': 'a model/ui/anonymous principal attempts to append audit or state records'} |

## Sources and how they enter

Nothing is analysed that was not admitted here. Each source is pinned at admission and re-checked for freshness before it is used.

| source | permission scope | freshness rule | authoritative suite |
|---|---|---|---|
| `DATA-01` | `repository.read` | {'history_completeness': 'a shallow repository or a  | `Repository Context Engine/40.1_Repository_Context_Engine_Context.jad` |
| `DATA-02` | `repository.read` | {'disagreement': 'manifests pinning one dependency d | `Repository Context Engine/40.3_Repository_Context_Engine_Dependencies.jad` |
| `DATA-03` | `repository.read` | {'absence': "no test suite is UNAVAILABLE — never 'n | `Translation Build Test and Evaluation Jobs/57.4_Test_Jobs.jaops` |
| `DATA-04` | `repository.read` | {'absence': 'no export is UNAVAILABLE — the history  | `Plug/14.3_Plug_Data_Adapters.jasp` |
| `DATA-05` | `repository.read` | {'disagreement': 'a reused ADR number is CONFLICTING | `Knowledge Repository/41.1_Knowledge_Repository_Documentation.jad` |
| `DATA-06` | `repository.read` | {'absence': 'no export is UNAVAILABLE — the history  | `Plug/14.3_Plug_Data_Adapters.jasp` |
| `DATA-07` | `repository.read` | {'disagreement': 'more than one ownership file is CO | `Capability Manifests and Permissions/55.2_Command_Permissions.jasec` |

## Flow

```
  repository (read-only, pinned revision)
        │  bind + pin  ──────────────────────────────► suite40/binding.json
        ▼
  intake: admit, stamp, verify pin ──────────────────► intake/
        ▼
  deterministic analyzers (symbols, deps, graph) ────► index/
        ▼   [TRUST BOUNDARY: everything below treats repository content as DATA]
  retrieval (BM25 over the pinned tree, bounded) ────► plan/refactoring_plan.json:evidence_refs
        ▼   [TRUST BOUNDARY: model output is untrusted and schema-validated]
  model boundary (sealed sources, no minting) ───────► model/calls.jsonl
        ▼
  plan → candidate patch (INERT, never applied here) ► candidate/
        ▼
  verification in an isolated worktree ──────────────► verification/
        ▼   [TRUST BOUNDARY: a human decides; the tool cannot]
  review surface (bound, hash-sealed) ───────────────► review/surface.json
        ▼
  human approval receipt (signed, TTL, scope-bound) ─► approvals/ledger.jsonl
        ▼
  apply in an isolated worktree, then rollback ──────► applied/, archive/rollback.json
```

Declared boundaries: 10. Every arrow above that crosses a trust boundary is a refusal point, not a checkpoint: the default is to refuse.

---

_Generated from 3 registry/registries by `scoped_pr_builder.documentation` (`data_flow`). Documentation registry `af4b762e936d9e21`._
