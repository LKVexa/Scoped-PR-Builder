---
document: DOC-04 — Permission matrix
owner: the Scoped PR Builder overlay maintainers
generated_by: scoped_pr_builder.documentation/0.1.0 (generator `permission_matrix`)
generated_at: 2026-09-03T23:22:02+00:00
knowledge_repository: 41.1/permissions
---

# DOC-04 — Permission matrix

> **This document is generated from the registries it describes.** It is not edited by hand: any change made here is overwritten on the next generation, and the freshness check refuses a document that no longer matches its sources. To change what it says, change the implementation.

## Provenance of this document

- **Owner:** the Scoped PR Builder overlay maintainers
- **Last validated against:** `environments` @ `025885e3bbe78d71`, `policy` @ `2c19bf5ca2d68903`
- **Last validated at:** set at generation time
- **Authoritative suites:** `Capability and Security Plane/44.2_Capability_and_Security_Plane_Permissions.jasec`, `Diff Patch and Review/50.5_Diff_Patch_and_Review_Human_Approval.ja`

### Assumptions

What this document takes as given. If one of these stops being true, the document is wrong even though its hashes still match.

- Effective authority is the policy's grants intersected with the environment's allowed effects; an environment can only narrow.
- Conflict resolution is `explicit_deny_wins` and an ungranted effect is denied by default.

### Known gaps

What this document does **not** cover, stated here rather than left to be discovered.

- The matrix shows declared authority, not what any run exercised. The per-run answer is in that run's own policy decision rows.
- Role granularity is coarse: this tool declares a single operator role.

### Change triggers

Changing any of these makes this document stale. The freshness check detects it; these are stated so a reader knows what to watch without running it.

- an environment's allowed effects or human-approval requirements change
- a policy rule line is added or removed
- the effect vocabulary changes

## Effects by environment

The effective authority of a run is the policy's grants INTERSECTED with the environment's allowed effects. An environment can only narrow; there is no code path that adds a grant.

| effect | developer sandbox | ci validation | staging | production read only | privileged execution | isolated test tenant |
|---|---|---|---|---|---|---|
| `diff.generate_inert` | yes | yes | yes | yes | yes | yes |
| `ledger.append` | yes | yes | yes | yes | yes | yes |
| `patch.apply_isolated` | — | — | human gate | — | human gate | human gate |
| `repository.bind` | yes | yes | yes | yes | yes | yes |
| `repository.read` | yes | yes | yes | yes | yes | yes |
| `review.render` | yes | yes | yes | yes | yes | yes |
| `rollback.execute` | — | — | human gate | — | human gate | human gate |
| `store.write` | yes | yes | yes | yes | human gate | yes |
| `verification.run_isolated` | yes | yes | yes | yes | yes | yes |
| `worktree.isolate` | yes | yes | yes | yes | yes | yes |

## Privileged effects

Two effects touch a repository: `patch.apply_isolated` and `rollback.execute`. Both require a verified human APPROVE receipt at `security.guard_write`, and both are refused to any model or untrusted principal by name, in every environment.

## Policy rules in force

185 declared rule lines in `scoped_pr_builder_policy.jasec`. Conflict resolution is `explicit_deny_wins`; an ungranted effect is denied by default.

---

_Generated from 2 registry/registries by `scoped_pr_builder.documentation` (`permission_matrix`). Documentation registry `af4b762e936d9e21`._
