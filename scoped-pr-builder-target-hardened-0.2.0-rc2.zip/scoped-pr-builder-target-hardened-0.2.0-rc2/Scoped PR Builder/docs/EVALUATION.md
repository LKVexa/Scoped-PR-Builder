---
document: DOC-10 — Evaluation plan and benchmark corpus
owner: the Scoped PR Builder overlay maintainers
generated_by: scoped_pr_builder.documentation/0.1.0 (generator `evaluation_plan`)
generated_at: 2026-09-03T23:22:05+00:00
knowledge_repository: 41.1/evaluation
---

# DOC-10 — Evaluation plan and benchmark corpus

> **This document is generated from the registries it describes.** It is not edited by hand: any change made here is overwritten on the next generation, and the freshness check refuses a document that no longer matches its sources. To change what it says, change the implementation.

## Provenance of this document

- **Owner:** the Scoped PR Builder overlay maintainers
- **Last validated against:** `matrix` @ `b7b7d484008f9b22`
- **Last validated at:** set at generation time
- **Authoritative suites:** `Evaluation and Content Defense/52.5_Evaluation_and_Content_Defense_Permanent_Evaluation.jasec`, `Sandbox and Offline Runtime/63.3_Tests.jaops`

### Assumptions

What this document takes as given. If one of these stops being true, the document is wrong even though its hashes still match.

- The corpus is built from this repository itself; there is no network in any environment.
- Ground truth is the matrix's own declared expectations, not a human label set.

### Known gaps

What this document does **not** cover, stated here rather than left to be discovered.

- Grounding and false-positive behaviour are measured against declared expectations. There is no external benchmark to compare against, and none is claimed.
- The corpus is representative of this tool's own task, not of software repositories in general.

### Change triggers

Changing any of these makes this document stale. The freshness check detects it; these are stated so a reader knows what to watch without running it.

- a scenario is added, removed or re-declared
- a fixture changes
- a scenario's declared expectation changes

## The corpus

The evaluation corpus is built from this repository itself — named fixtures, not downloaded data. There is no network in any environment, so an offline corpus is the only kind this tool has.

| fixture | what it is |
|---|---|
| `suite_corpus` | the repository's own suites, bound read-only at a pinned revision |
| `injection_corpus` | planted directive-shaped content, treated as data |
| `lonely_target` | a target with no analogous examples — the abstention case |
| `failing_tests` | a candidate whose verification fails |
| `second_repository` | a foreign repository, for cross-tenant refusal |
| `oversized_intent` | an intent past the hard caps |

## Scenarios

| scenario | kind | mandatory | fixture | title |
|---|---|---|---|---|
| `TEST-ADV-01` | adversarial | **yes** | `injection_corpus` | Adversarial: directive-shaped repository content i |
| `TEST-ADV-02` | adversarial | **yes** | `lonely_target` | Adversarial: missing evidence abstains, a stale bi |
| `TEST-ADV-03` | adversarial | **yes** | `oversized_intent` | Adversarial: an oversized scope request is refused |
| `TEST-ADV-04` | adversarial | **yes** | `suite_corpus` | Adversarial: undeclared store writers, model princ |
| `TEST-ADV-05` | adversarial | **yes** | `injection_corpus` | Adversarial: secret-bearing files never become evi |
| `TEST-ADV-06` | adversarial | **yes** | `suite_corpus` | Adversarial: evidence references outside the autho |
| `TEST-ADV-07` | adversarial | **yes** | `suite_corpus` | Adversarial: model-channel, forged and self-signed |
| `TEST-E2E-01` | end_to_end | **yes** | `suite_corpus` | End to end: intent through verified candidate, hum |
| `TEST-E2E-02` | end_to_end | **yes** | `suite_corpus` | End to end: the reviewer rejects — no application, |
| `TEST-E2E-03` | end_to_end | **yes** | `suite_corpus` | End to end: the reviewer narrows the scope and the |
| `TEST-E2E-04` | end_to_end | **yes** | `failing_tests` | End to end: a deterministic tool failure inside th |
| `TEST-E2E-05` | end_to_end | **yes** | `lonely_target` | End to end: missing context abstains at the plan a |
| `TEST-E2E-06` | end_to_end | **yes** | `suite_corpus` | End to end: the declared rollback executes and pro |
| `TEST-INT-01` | integration | **yes** | `suite_corpus` | Integration pipeline: binding, intake, retrieval,  |
| `TEST-UNIT-01` | unit | **yes** | `suite_corpus` | Unit primitives: parser, schema validator, policy  |

## How quality is measured

Ground truth here is the matrix's own declared expectations — the exact state, effects, changed paths, evidence closure and approval outcome each scenario must produce. Confusion is defined against the guardrail firing:

- **false negative** — a scenario whose declared outcome is a refusal that did not refuse;
- **false positive** — a scenario whose declared outcome is not a refusal that refused anyway;
- scenarios with no declared expectation are counted `ungrounded` and excluded from every rate, rather than assumed correct.

Grounding is measured mechanically rather than judged: every planned operation is classified against the evidence set it cites and the revision the run pinned. Review burden is measured alongside completion — items presented, decisions demanded, round trips — and never replaced by it.

## The gate

For every mandatory scenario the tool's own chained evidence ledger must hold a current PASS receipt bound to the matrix hash. Missing, stale, failed or indeterminate blocks release. Waiver-shaped inputs are refused by name: the component under evaluation cannot excuse itself from the matrix.

---

_Generated from 1 registry/registries by `scoped_pr_builder.documentation` (`evaluation_plan`). Documentation registry `af4b762e936d9e21`._
