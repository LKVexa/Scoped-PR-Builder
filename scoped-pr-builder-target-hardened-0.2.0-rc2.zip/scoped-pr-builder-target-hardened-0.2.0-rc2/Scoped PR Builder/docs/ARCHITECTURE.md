---
document: DOC-01 — Architecture
owner: the Scoped PR Builder overlay maintainers
generated_by: scoped_pr_builder.documentation/0.1.0 (generator `architecture`)
generated_at: 2026-09-03T23:22:00+00:00
knowledge_repository: 41.1/architecture
---

# DOC-01 — Architecture

> **This document is generated from the registries it describes.** It is not edited by hand: any change made here is overwritten on the next generation, and the freshness check refuses a document that no longer matches its sources. To change what it says, change the implementation.

## Provenance of this document

- **Owner:** the Scoped PR Builder overlay maintainers
- **Last validated against:** `boundaries` @ `dddea2df85cb0b8d`, `wiring` @ `5b269da591ca6f2f`, `components` @ `38428b02cfcd7135`
- **Last validated at:** set at generation time
- **Authoritative suites:** `Knowledge Repository/41.1_Knowledge_Repository_Documentation.jad`, `Knowledge Repository/41.2_Knowledge_Repository_Architecture_Records.jad`, `Knowledge Repository/41.9_Knowledge_Repository_Architecture_Catalog.jad`

### Assumptions

What this document takes as given. If one of these stops being true, the document is wrong even though its hashes still match.

- Every crossing goes through a declared boundary; a component that bypasses `architecture.check_crossing` would not appear here, and nothing in this document would reveal it.
- The component table is truncated for readability; `components/COMPONENTS.json` is authoritative.

### Known gaps

What this document does **not** cover, stated here rather than left to be discovered.

- This is a structural view, not a runtime one: it says what may cross which boundary, not what a particular run did. `observability.trace` answers the second question, per run.
- Sequence and timing between components are not represented.

### Change triggers

Changing any of these makes this document stale. The freshness check detects it; these are stated so a reader knows what to watch without running it.

- a boundary is added, removed or re-contracted
- a port is bound to a different adapter
- a component's declared capabilities change

## Boundaries

Every crossing in this tool goes through a declared boundary. A message naming no boundary, or one not declared here, is refused at `architecture.check_crossing` rather than routed. `denied_effects` is the column to read: those are refused at the boundary regardless of what any caller asks for.

| boundary | layer | trust level | allows | denies |
|---|---|---|---|---|
| `artifact_identity` | Canonical artifact and identity layer | `deterministic_trusted` | `artifact.register`, `artifact.read` | `artifact.mutate`, `artifact.reassign_id`, `ledger.rewrite` |
| `connector_adaptor` | Connector/adaptor layer for authorized source systems | `untrusted_input` | `repository.bind`, `repository.read`, `worktree.isolate` | `repository.write_source`, `network.egress`, `approval.mint` |
| `deterministic_tools` | Deterministic analysis/tool layer | `isolated_executor` | `analysis.run_deterministic`, `diff.generate_inert`, `verification.run_isolated` | `patch.apply_source`, `network.egress`, `verification.assert` |
| `human_review_approval` | Human review and approval interface | `human_authority` | `review.render`, `approval.issue_by_human` | `approval.mint_by_model`, `approval.replay`, `approval.extend` |
| `model_reasoning` | Model reasoning/orchestration layer | `advisory_only` | `model.infer_advisory`, `plan.propose` | `approval.mint`, `evidence.mint`, `verification.assert` |
| `observability_evaluation` | Observability/evaluation subsystem | `append_only_ledger` | `event.emit`, `metric.record`, `ledger.read` | `event.suppress`, `metric.fabricate`, `ledger.rewrite` |
| `policy_enforcement` | Policy/authority enforcement layer | `deterministic_trusted` | `policy.decide`, `capability.check` | `policy.override`, `approval.mint`, `scope.expand` |
| `provenance_ledger` | Provenance/evidence ledger | `append_only_ledger` | `ledger.append`, `ledger.read` | `ledger.rewrite`, `ledger.delete`, `evidence.mint` |
| `retrieval_query` | Retrieval/graph/query layer | `deterministic_trusted` | `repository.read`, `evidence.retrieve` | `repository.write_source`, `memory.promote_unverified`, `evidence.mint` |
| `state_context_store` | Persistent state/context store | `append_only_ledger` | `state.append`, `state.read` | `state.rewrite`, `state.delete`, `ledger.rewrite` |

## Ports and the adapters that serve them

A port is where the overlay meets something across a boundary. Each names one serving adapter, the contracts it accepts and emits, and which of its effects are guarded as privileged.

| port | boundary | adapter | inbound contracts | privileged effects guarded |
|---|---|---|---|---|
| `port:artifact_identity` | `artifact_identity` | `scoped_pr_builder.archive_adapter` | `artifact_record` | `yes` |
| `port:connector_adaptor` | `connector_adaptor` | `scoped_pr_builder.local_git_adapter` | `bind_request` | `yes` |
| `port:deterministic_tools` | `deterministic_tools` | `scoped_pr_builder.verification_runner` | `tool_job_request` | `yes` |
| `port:human_review_approval` | `human_review_approval` | `scoped_pr_builder.approval_adapter` | `review_render_request` | `yes` |
| `port:model_reasoning` | `model_reasoning` | `scoped_pr_builder.evidence_retrieval` | `advisory_request` | `yes` |
| `port:observability_evaluation` | `observability_evaluation` | `scoped_pr_builder.archive_adapter` | `audit_event` | `yes` |
| `port:policy_enforcement` | `policy_enforcement` | `scoped_pr_builder.controls` | `policy_request` | `yes` |
| `port:provenance_ledger` | `provenance_ledger` | `scoped_pr_builder.archive_adapter` | `provenance_link` | `yes` |
| `port:retrieval_query` | `retrieval_query` | `scoped_pr_builder.evidence_retrieval` | `retrieval_request` | `yes` |
| `port:state_context_store` | `state_context_store` | `scoped_pr_builder.archive_adapter` | `run_state_entry` | `yes` |

## Components

11 declared components. Each declares its interface bounds — file counts, output sizes and timeouts — which are enforced rather than advisory: a component exceeding them is refused.

| component | title | timeout (s) | max files | authoritative suite |
|---|---|---|---|---|
| `COMP-01` | Repository parser and symbol index | 120 | 20000 | `Repository Context Engine/40.2_Repository_Context_Engine_Symbols.jad` |
| `COMP-02` | AST/CST and semantic code graph | 120 | — | `Repository Context Engine/40.2_Repository_Context_Engine_Symbols.jad` |
| `COMP-03` | Dependency/build graph | 60 | — | `Repository Context Engine/40.3_Repository_Context_Engine_Dependencies.jad` |
| `COMP-04` | Repository-convention learner | 120 | — | `Repository Retrieval and Memory/51.2_Repository_Retrieval_and_Memory_Repository_Retrieval.jad` |
| `COMP-05` | Change-impact engine | 60 | — | `Action Cards/49.11_Action_Cards_Impact.jaui` |
| `COMP-06` | Refactoring planner | 60 | — | `Chatbot/47.2_Chatbot_Planning.jaa` |
| `COMP-07` | Atomic patch/diff generator | 60 | — | `Diff Patch and Review/50.1_Diff_Patch_and_Review_Bounded_Diff_Production.ja` |
| `COMP-08` | Incremental compiler/test runner | 600 | — | `Translation Build Test and Evaluation Jobs/57.3_Build_Jobs.jaops` |
| `COMP-09` | Patch-size/scope governor | 10 | — | `Diff Patch and Review/50.1_Diff_Patch_and_Review_Bounded_Diff_Production.ja` |
| `COMP-10` | Human review/approval UI | 30 | — | `Full Stack UI/26.3_Full_Stack_UI_Dashboards.jaui` |
| `COMP-11` | Rollback/checkpoint manager | 60 | — | `Filing Cabinet/12_filing_cabinet_rollback_records.jad` |

---

_Generated from 3 registry/registries by `scoped_pr_builder.documentation` (`architecture`). Documentation registry `af4b762e936d9e21`._
