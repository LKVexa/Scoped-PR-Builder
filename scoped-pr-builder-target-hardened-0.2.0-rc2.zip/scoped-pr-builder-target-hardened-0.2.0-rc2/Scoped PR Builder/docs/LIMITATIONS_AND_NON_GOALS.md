---
document: DOC-12 — Known limitations and non-goals
owner: the Scoped PR Builder overlay maintainers
generated_by: scoped_pr_builder.documentation/0.1.0 (generator `limitations`)
generated_at: 2026-09-03T23:22:06+00:00
knowledge_repository: 41.1/limitations
---

# DOC-12 — Known limitations and non-goals

> **This document is generated from the registries it describes.** It is not edited by hand: any change made here is overwritten on the next generation, and the freshness check refuses a document that no longer matches its sources. To change what it says, change the implementation.

## Provenance of this document

- **Owner:** the Scoped PR Builder overlay maintainers
- **Last validated against:** `invariants` @ `0cb96951f2a7391c`, `readiness` @ `9df9f09bc6ccc6bc`
- **Last validated at:** set at generation time
- **Authoritative suites:** `Release Plane/43.6_Release_Plane_Release_Evidence.jaops`, `Knowledge Repository/41.6_Knowledge_Repository_Suite_Documentation.jad`

### Assumptions

What this document takes as given. If one of these stops being true, the document is wrong even though its hashes still match.

- A limitation declared in a registry and not published here is caught by the release gate.
- Non-goals are deliberate boundaries rather than gaps.

### Known gaps

What this document does **not** cover, stated here rather than left to be discovered.

- This lists what the tool does not do. It cannot list what nobody has thought to declare, which is why the gate binds it to the readiness registry rather than trusting it to be complete.
- `release/LIMITATIONS.md` is the release gate's own copy, published against the readiness registry; this document is the Knowledge Repository's, and both are generated from the same declarations.

### Change triggers

Changing any of these makes this document stale. The freshness check detects it; these are stated so a reader knows what to watch without running it.

- a platform invariant becomes deferred to the host, or stops being
- a non-goal is added or removed
- a release-gate assertion is added or removed

## Host requirements

Properties this tool does not implement and does not claim. A host deploying it must provide them.

### XSEC-04 — Encrypt data in transit and at rest.

this tool declares network: none and writes nothing at rest outside the run directory it is given, so it can provide integrity at rest (every ledger is a hash chain) but not confidentiality at rest or transport encryption; the host must supply disk encryption for the run directory and TLS for any transport it adds. Recorded as a host requirement, never as a satisfied invariant.

## Non-goals

Deliberate boundaries, not gaps. Each is stated so nobody has to infer it from silence.

- **NON-GOAL-01** — It does not decide whether a change is a good idea. It produces a bounded, inert candidate and a review surface; the judgement, and the accountability for it, stay with the human reviewer.

- **NON-GOAL-02** — It does not run in production against live traffic. Every effect happens in an isolated worktree under a run directory outside the repository, and the source tree is proven unchanged afterwards.

- **NON-GOAL-03** — It does not reach the network. `network: none` is declared in every environment profile and enforced by the qualification harness refusing a run that attempts a connection; it is not a kernel-level egress block.

- **NON-GOAL-04** — It does not provide confidentiality at rest or transport encryption (XSEC-04). It provides integrity at rest by hash-chaining every ledger; the host supplies disk encryption and TLS.

- **NON-GOAL-05** — It does not sandbox at the container, namespace or VM level. Isolation here is process-level and path-level.

- **NON-GOAL-06** — It does not compile or semantically validate JA suite files. Cross-reference checking passes 66/66; compile-level validation of the overlay's JA surfaces remains INDETERMINATE.

- **NON-GOAL-07** — It does not replace a security review by people. It provides the threat registry, the adversarial evidence and the refusal codes a reviewer needs, and records what was and was not examined.

- **NON-GOAL-08** — It does not measure monetary cost. The bound provider is a deterministic in-process advisor with no metered spend; a host binding a metered provider supplies cost per call.

## Where this is enforced

`release_gate.verify_limitations` refuses when a declared limitation is missing from the published document, and the published-limitations receipt binds to the readiness registry — so declaring a new release-gate assertion without republishing makes the receipt stale and blocks the gate.

---

_Generated from 2 registry/registries by `scoped_pr_builder.documentation` (`limitations`). Documentation registry `af4b762e936d9e21`._


## Release classification

Historical empty-approval `GO` rows are legacy `pilot-sha256sums-only` evidence. They do not authorize a general production release.
