---
document: DOC-09 — Human approval policy
owner: the Scoped PR Builder overlay maintainers
generated_by: scoped_pr_builder.documentation/0.1.0 (generator `approval_policy`)
generated_at: 2026-09-03T23:22:04+00:00
knowledge_repository: 41.1/approval_policy
---

# DOC-09 — Human approval policy

> **This document is generated from the registries it describes.** It is not edited by hand: any change made here is overwritten on the next generation, and the freshness check refuses a document that no longer matches its sources. To change what it says, change the implementation.

## Provenance of this document

- **Owner:** the Scoped PR Builder overlay maintainers
- **Last validated against:** `review` @ `08cde14e0ccfc0e4`, `environments` @ `025885e3bbe78d71`
- **Last validated at:** set at generation time
- **Authoritative suites:** `Diff Patch and Review/50.5_Diff_Patch_and_Review_Human_Approval.ja`, `Capability and Security Plane/44.4_Capability_and_Security_Plane_Approvals.jasec`

### Assumptions

What this document takes as given. If one of these stops being true, the document is wrong even though its hashes still match.

- The run cannot leave REVIEW_PENDING without a signed human approval receipt; the state machine declares no other edge.
- Accountability rests with the human reviewer; the AI is advisory only.

### Known gaps

What this document does **not** cover, stated here rather than left to be discovered.

- This states the policy the tool enforces. Who in an organisation is authorised to be that reviewer is the host's decision, and the tool records the identity rather than validating the role.
- The reviewer surface is a rendered HTML page and a typed-command executor; there is no interactive server.

### Change triggers

Changing any of these makes this document stale. The freshness check detects it; these are stated so a reader knows what to watch without running it.

- a reviewer behavior or its side effects change
- the fields an approval binds to change
- an environment's human-approval requirements change

## Where a human decides

The run cannot leave `REVIEW_PENDING` without a signed human approval receipt. The state machine declares no other edge, so this is structural rather than procedural.

## Reviewer actions

| requirement | reviewer action | applies patch | safety rule |
|---|---|---|---|
| `HUMAN-01` | `inspect_evidence` | no | inspect_evidence is non-applying: bracketed by the effect proof  |
| `HUMAN-02` | `inspect_evidence` | no | the coverage view is display-only; no command over it can apply |
| `HUMAN-03` | `narrow_scope` | no | narrow_scope cannot apply: effect proof; the rerun is a new run  |
| `HUMAN-04` | `reject` | no | reject cannot apply: effect proof; REJECT supersedes and invalid |
| `HUMAN-05` | `request_evidence` | no | request_evidence cannot apply: effect proof; prior APPROVE inval |
| `HUMAN-06` | `approve` | **yes** | approve records a receipt only; application happens at WF-11 aft |
| `HUMAN-07` | `approve` | **yes** | cancel cannot apply: effect proof; prior APPROVE invalidated; th |

## What an approval is bound to

A receipt is valid only over exactly the artifacts it was issued for. If any of them changes, the receipt is stale and a new human decision is required — `approval.stale_inputs`.

| bound field | what it pins |
|---|---|
| `candidate_id` | the candidate being approved |
| `patch_hash` | the exact diff shown |
| `base_revision` | the repository revision it applies to |
| `scope_contract_hash` | the accepted scope |
| `card_hash` | the review card the human saw |
| `verification_report_hash` | the verification result they saw |

## What cannot approve

- A model, agent, assistant, planner, tool, repository, document, ticket or log channel — refused by name at `security.require_human_channel` (`security.sec07.model_channel`).
- A receipt whose signature was not produced by the run's own approval key (`security.sec07.fabricated_token`).
- A receipt past its declared TTL (`approval.expired`).
- A receipt a later human command invalidated — reject, cancel, request-evidence or narrow-scope (`approval.invalidated`).

## Accountability

The accountable party is the human reviewer, named on the surface and in the audit record. The AI is declared advisory only, with an explicit cannot-list, and accountability never rests with it.

## Which environments require a human gate

| environment | posture | requires human approval for |
|---|---|---|
| `developer_sandbox` | draft_only | — |
| `ci_validation` | draft_only | — |
| `staging` | apply_isolated | patch.apply_isolated, rollback.execute |
| `production_read_only` | read_only | — |
| `privileged_execution` | apply_isolated | patch.apply_isolated, rollback.execute, store.write |
| `isolated_test_tenant` | apply_isolated | patch.apply_isolated, rollback.execute |

---

_Generated from 2 registry/registries by `scoped_pr_builder.documentation` (`approval_policy`). Documentation registry `af4b762e936d9e21`._
