# Host Security Contract (XSEC-04)

XSEC-04 remains **deferred to the host** and MUST NOT be reported satisfied by this overlay.

- Run-directory confidentiality at rest is a host responsibility (for example BitLocker, LUKS, fscrypt, or FileVault as appropriate).
- Forge transport, when a connected profile is enabled, must use TLS with certificate verification.
- Air-gap profiles retain `network: none`.
- Host attestations are evidence of an external requirement, not proof that the overlay itself implements encryption at rest.
