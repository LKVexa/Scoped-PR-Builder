---
document: DOC-05 — Threat model
owner: the Scoped PR Builder overlay maintainers
generated_by: scoped_pr_builder.documentation/0.1.0 (generator `threat_model`)
generated_at: 2026-09-03T23:22:02+00:00
knowledge_repository: 41.1/threat_model
---

# DOC-05 — Threat model

> **This document is generated from the registries it describes.** It is not edited by hand: any change made here is overwritten on the next generation, and the freshness check refuses a document that no longer matches its sources. To change what it says, change the implementation.

## Provenance of this document

- **Owner:** the Scoped PR Builder overlay maintainers
- **Last validated against:** `threats` @ `e619605224dac5ce`, `invariants` @ `0cb96951f2a7391c`
- **Last validated at:** set at generation time
- **Authoritative suites:** `Capability and Security Plane/44.7_Capability_and_Security_Plane_Security.jasec`, `Evaluation and Content Defense/52.6_Evaluation_and_Content_Defense_Prompt_Injection_Defense.jasec`, `Capability and Security Plane/44.3_Capability_and_Security_Plane_Trust_Boundaries.jasec`

### Assumptions

What this document takes as given. If one of these stops being true, the document is wrong even though its hashes still match.

- Every threat is enforced at an effect boundary, not by instructing a model.
- Adversarial evidence for each threat is archived in the tool's own chained evidence ledger.

### Known gaps

What this document does **not** cover, stated here rather than left to be discovered.

- This covers threats to the tool's own governance. It does not model threats to the host, the operating system, or the repository's own supply chain.
- XSEC-04 (encryption in transit and at rest) is not implemented here; it is a host requirement and is listed as such rather than as a control.

### Change triggers

Changing any of these makes this document stale. The freshness check detects it; these are stated so a reader knows what to watch without running it.

- a threat is added, removed or re-scoped
- an XSEC invariant's enforcement point changes
- a refusal code changes

## Threats

Each threat names the trust boundary it lives at, the conditions that deny it, and the audit event it writes. Every one is enforced at an effect boundary in code.

| threat | title | trust boundary | refusal codes |
|---|---|---|---|
| `SEC-01` | Prompt injection from repository/docs/tickets/logs | {'rule': 'Everything read from the repository, documentation, tickets, logs or tool output is data: it is marked untrusted, scanned for directive shapes, and can neither authorize an effect nor satisfy a check. Authorization comes only from a signed human receipt on a human channel; validation only from executed check receipts; plans stay advisory.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['repository_content', 'documentation', 'tickets', 'logs', 'tool_output', 'model_output']} | `security.sec01.untrusted_channel_authorization`, `security.sec01.plan_claims_authority`, `security.sec01.evidence_not_marked_untrusted` |
| `SEC-02` | Tool-call argument validation blocks command/path/ | {'rule': 'Tool invocations are argv vectors, never shell strings; every path is canonical and repository-relative and every changed path lies inside the allowed roots and outside the forbidden ones — at intent intake, plan targets, the sandbox runner and the application boundary.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['repository_content', 'tool_output', 'model_output']} | `security.sec02.path_escape`, `security.sec02.path_injection`, `security.sec02.scope_injection` |
| `SEC-03` | Secrets are never copied into model context unless | {'rule': 'Secret-bearing files are never admitted as analogous evidence; evidence records carry hashes, never text; sandbox job output is masked before it is recorded; a candidate that would add secret material is refused at application; the masker is the vetted MIT redaction core.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['repository_content', 'tool_output', 'logs']} | `security.sec03.secret_in_candidate`, `security.sec03.secret_forwarded` |
| `SEC-04` | Cross-project/tenant data leakage tests exist | {'rule': 'Every artifact names its repository/revision/snapshot; retrieval, components and the application boundary refuse any artifact that names another tenant.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['repository_content', 'tool_output']} | `security.sec04.foreign_repository`, `security.sec04.foreign_revision` |
| `SEC-05` | Unauthorized write attempts fail closed | {'rule': 'Writes to stores require a declared writer; repository effects require an explicit allow decision and a verified human APPROVE receipt; a model/untrusted actor is refused outright; the source worktree is never written.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['model_output', 'tool_output']} | `security.sec05.model_actor`, `security.sec05.write_denied`, `security.sec05.unauthorized_write` |
| `SEC-06` | Sensitive generated output is classified before di | {'rule': 'Every review card carries a classification (restricted / confidential / internal) and shows only the masked rendering; the archive classifies every text artifact and refuses to export restricted content.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['model_output', 'tool_output', 'repository_content']} | `security.sec06.unclassified_export` |
| `SEC-07` | Human approval tokens cannot be fabricated by mode | {'rule': 'A decision is recorded only through a human channel, signed with the approval key the model never holds, chained in the ledger with a unique nonce and a non-future timestamp; anything else is fabricated.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['model_output', 'repository_content', 'tool_output']} | `security.sec07.model_channel`, `security.sec07.fabricated_token`, `security.sec07.replayed_token` |
| `SEC-08` | Audit records cannot be modified by the model | {'rule': 'Every ledger is hash-chained and append-only; only named adapters write; every effect boundary re-verifies every chain before acting; audit rows carry identifiers and hashes, never payload content.', 'trusted_only': ['signed human receipts on human channels', 'executed check receipts', 'hash-bound contracts and bindings'], 'untrusted': ['model_output', 'tool_output']} | `security.sec08.audit_tampered`, `security.sec08.model_writer` |

## Security invariants and where they are enforced

The XSEC family of platform invariants, with the callable that is authoritative for each. An invariant whose enforcement point does not resolve is refused at load, so nothing here is aspirational.

| invariant | statement | enforced at |
|---|---|---|
| `XSEC-01` | Classify data before model/tool access. | `security.classify_output` |
| `XSEC-02` | Redact or exclude sensitive data where not required. | `security.minimize_for_audit` |
| `XSEC-03` | Prevent cross-tenant/project leakage. | `security.assert_tenant` |
| `XSEC-04` | Encrypt data in transit and at rest. | **DEFERRED TO HOST** |
| `XSEC-05` | Keep secrets out of prompts, logs, generated artifacts, and model context. | `security.protect_secrets` |
| `XSEC-06` | Maintain configurable retention and deletion policies. | `store.purge_expired` |
| `XSEC-07` | Threat-model prompt injection and malicious repository/artifact content. | `security.load_threats` |

### Not implemented by this tool

**XSEC-04 — Encrypt data in transit and at rest.**

this tool declares network: none and writes nothing at rest outside the run directory it is given, so it can provide integrity at rest (every ledger is a hash chain) but not confidentiality at rest or transport encryption; the host must supply disk encryption for the run directory and TLS for any transport it adds. Recorded as a host requirement, never as a satisfied invariant.

This is a host requirement. It is recorded as `deferred`, never as satisfied, and it appears as a residual risk on every release record.

---

_Generated from 2 registry/registries by `scoped_pr_builder.documentation` (`threat_model`). Documentation registry `af4b762e936d9e21`._
