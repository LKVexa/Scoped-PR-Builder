"""Scoped PR Builder — typed component boundary (Phase 05 / COMP-01..11).

``components/COMPONENTS.json`` declares one versioned interface per analysis / planning / patching / rollback
component: inputs and outputs (each bound to a registered contract, an adapter-verified artifact or a plain value),
the error codes the component may raise, hard bounds (timeout, output size, failure budget, scope), the provenance
fields every output carries, the capabilities (effects) the caller must have granted, and the authoritative suite
the component composes. ``invoke`` is the only way to run a component: it validates the interface, the inputs and
the granted capabilities, dispatches to the executable implementation registered for the component (T03), and
returns a sealed ``component_result`` whose outputs are schema-valid and bound to the exact pinned inputs.

Nothing here has authority of its own: components read the pinned revision, produce artifacts and decisions, and
refuse — they never mint permissions, approvals or verification receipts.

Build provenance: BUILD_NEW envelope; components compose the existing overlay adapters (see COMPONENTS.json).
"""
from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, is_dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Mapping, Sequence

from . import contracts as C
from . import local_git_adapter as lga
from . import security as _SEC

COMPONENTS_VERSION = "scoped_pr_builder.components/0.1.0"
COMPONENTS_PATH = Path(__file__).resolve().parent.parent / "components" / "COMPONENTS.json"
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
RESULT_SCHEMA = "overlay.scoped_pr_builder.components/ComponentResult"
COMPONENT_REQUIRED = ("component_id", "version", "title", "interface", "authoritative_suites", "introduced_by")
INTERFACE_REQUIRED = ("inputs", "outputs", "errors", "bounds", "provenance_fields", "capabilities")
BOUNDS_REQUIRED = ("timeout_s", "max_output_items", "max_output_bytes", "max_failures")
INPUT_KINDS = ("binding", "contract", "artifact", "bytes", "value", "path")
GENERIC_ERRORS = ("component.unknown", "component.not_executable", "component.input_missing", "component.input_invalid", "component.capability_missing", "component.binding_mismatch", "component.output_invalid", "component.failed")
_IMPL: dict[str, Callable[..., dict[str, Any]]] = {}


class ComponentRefusal(lga.AdapterError):
    """Raised by the component boundary; the code is one of the interface's declared errors or a generic one."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def register_impl(component_id: str):
    def deco(fn):
        _IMPL[component_id] = fn
        return fn
    return deco


def canon(value: Any) -> Any:
    """JSON-canonical view of any input/output value: dataclasses → dicts, bytes → digest, paths → str, tuples → lists."""
    if is_dataclass(value) and not isinstance(value, type):
        return canon(asdict(value))
    if isinstance(value, (bytes, bytearray)):
        return {"bytes_sha256": lga.sha256_digest(bytes(value)), "size": len(value)}
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(k): canon(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [canon(v) for v in (sorted(value) if isinstance(value, (set, frozenset)) else value)]
    return value


def digest(value: Any) -> str:
    return lga.sha256_digest(lga.canonical_json(canon(value)))


def load_components(path: Path = COMPONENTS_PATH, *, registry: Mapping[str, Any] | None = None, repo_root: Path = REPO_ROOT) -> dict[str, Any]:
    if not Path(path).is_file():
        raise ComponentRefusal("component.registry_missing", f"component registry not found: {path}")
    reg = registry or C.load_registry()
    comps = json.loads(Path(path).read_text(encoding="utf-8"))
    if comps.get("components_version") != COMPONENTS_VERSION:
        raise ComponentRefusal("component.registry_invalid", "unsupported components_version")
    for cid, c in (comps.get("components") or {}).items():
        missing = [k for k in COMPONENT_REQUIRED if k not in c]
        if missing or c["component_id"] != cid or not C.SEMVER_RE.match(c["version"]):
            raise ComponentRefusal("component.registry_invalid", f"{cid}: missing {missing} / id or version invalid")
        iface = c["interface"]
        imissing = [k for k in INTERFACE_REQUIRED if k not in iface]
        if imissing or any(k not in iface["bounds"] for k in BOUNDS_REQUIRED):
            raise ComponentRefusal("component.registry_invalid", f"{cid}: interface lacks {imissing or 'bounds'}")
        if int(iface["bounds"]["max_failures"]) != 0:
            raise ComponentRefusal("component.registry_invalid", f"{cid}: failure budget must be 0 (no retries at the boundary)")
        for name, spec in {**iface["inputs"], **iface["outputs"]}.items():
            if spec.get("kind") not in INPUT_KINDS:
                raise ComponentRefusal("component.registry_invalid", f"{cid}: {name}: unknown kind {spec.get('kind')!r}")
            ref = spec.get("ref", "")
            if spec["kind"] == "contract" and ref not in reg["contracts"]:
                raise ComponentRefusal("component.registry_invalid", f"{cid}: {name}: contract {ref!r} not registered")
        for e in iface["errors"]:
            if not isinstance(e, Mapping) or not e.get("code") or not e.get("meaning"):
                raise ComponentRefusal("component.registry_invalid", f"{cid}: every error needs code + meaning")
        if not iface["provenance_fields"]:
            raise ComponentRefusal("component.registry_invalid", f"{cid}: provenance fields required")
        for f in c["authoritative_suites"]:
            if not (Path(repo_root) / f).is_file():
                raise ComponentRefusal("component.suite_unbound", f"{cid}: authoritative suite file does not exist: {f}")
    body = {k: v for k, v in comps.items() if k != "components_hash"}
    comps["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return comps


@dataclass(frozen=True)
class ComponentResult:
    """Sealed envelope: exact inputs → outputs, provenance, observed bounds. Hash-bound; validated as component_result."""

    record_schema: str
    component_id: str
    component_version: str
    inputs_hash: str
    input_identities: dict[str, Any]
    outputs: dict[str, Any]
    output_hash: str
    provenance: dict[str, Any]
    bounds_observed: dict[str, Any]
    capabilities_used: list[str]
    invoked_at: str
    result_hash: str

    def to_json(self) -> str:
        return lga.canonical_json(asdict(self))


def _input_identity(name: str, spec: Mapping[str, Any], value: Any) -> Any:
    """The identity a result binds to for one input: hashes/ids for artifacts, digests for bytes, canonical values otherwise."""
    v = canon(value)
    if isinstance(v, Mapping):
        ids = {k: v[k] for k in sorted(v) if k.endswith(("_hash", "_id", "_revision")) and isinstance(v[k], str)}
        return ids or {"digest": digest(v)}
    return v


def _check_inputs(c: Mapping[str, Any], inputs: Mapping[str, Any]) -> dict[str, Any]:
    iface = c["interface"]
    unknown = sorted(set(inputs) - set(iface["inputs"]))
    if unknown:
        raise ComponentRefusal("component.input_invalid", f"{c['component_id']}: undeclared inputs rejected {unknown}")
    idents = {}
    for name, spec in iface["inputs"].items():
        if name not in inputs or inputs[name] is None:
            if spec.get("required", True):
                raise ComponentRefusal("component.input_missing", f"{c['component_id']}: required input {name!r} missing; nothing is assumed")
            continue
        value = inputs[name]
        kind = spec["kind"]
        if kind == "binding" and not isinstance(value, lga.RepositoryBinding):
            raise ComponentRefusal("component.input_invalid", f"{c['component_id']}: {name} must be a RepositoryBinding")
        if kind == "bytes" and not isinstance(value, (bytes, bytearray)):
            raise ComponentRefusal("component.input_invalid", f"{c['component_id']}: {name} must be bytes")
        if kind == "contract":
            payload = canon(value)
            try:
                C.validate_payload(spec["ref"], payload)
            except lga.AdapterError as exc:
                raise ComponentRefusal("component.input_invalid", f"{c['component_id']}: {name} is not a valid {spec['ref']}: {exc}") from exc
        if kind == "artifact" and spec.get("record_schema") and canon(value).get("record_schema") != spec["record_schema"]:
            raise ComponentRefusal("component.input_invalid", f"{c['component_id']}: {name} is not a {spec['record_schema']} record")
        if kind == "artifact" and spec.get("required_keys"):
            cv = canon(value)
            missing_keys = [k for k in spec["required_keys"] if not isinstance(cv, Mapping) or k not in cv]
            if missing_keys:
                raise ComponentRefusal("component.input_invalid", f"{c['component_id']}: {name} lacks {missing_keys}")
        if kind == "value" and spec.get("enum") and value not in spec["enum"]:
            raise ComponentRefusal("component.input_invalid", f"{c['component_id']}: {name} must be one of {spec['enum']}")
        idents[name] = _input_identity(name, spec, value)
    return idents


def _required_capabilities(c: Mapping[str, Any], inputs: Mapping[str, Any]) -> list[str]:
    caps = list(c["interface"]["capabilities"])
    for key, extra in (c["interface"].get("action_capabilities") or {}).items():
        if inputs.get("action") == key:
            caps += list(extra)
    return sorted(set(caps))


def _binding_of(inputs: Mapping[str, Any]) -> lga.RepositoryBinding | None:
    for v in inputs.values():
        if isinstance(v, lga.RepositoryBinding):
            return v
    return None


def invoke(component_id: str, inputs: Mapping[str, Any], *, granted_effects: Sequence[str], components: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None,
           sandbox: Path | None = None, run: Any = None) -> ComponentResult:
    """Run one component behind its typed boundary. Fails closed on unknown component, undeclared/missing/invalid
    inputs, ungranted capabilities, a binding that no longer matches the repository, or outputs that do not validate."""
    reg = registry or C.load_registry()
    comps = components or load_components(registry=reg)
    c = comps["components"].get(component_id)
    if c is None:
        raise ComponentRefusal("component.unknown", f"no such component {component_id!r}")
    _reject_overrides(c, inputs)
    idents = _check_inputs(c, inputs)
    _enforce_scope(c, inputs)
    needed = _required_capabilities(c, inputs)
    missing = [e for e in needed if e not in granted_effects]
    if missing:
        raise ComponentRefusal("component.capability_missing", f"{component_id}: capabilities not granted: {missing}")
    binding = _binding_of(inputs)
    if binding is not None:
        try:
            lga.revalidate_binding(binding)
        except lga.AdapterError as exc:
            raise ComponentRefusal("component.binding_mismatch", f"{component_id}: {exc.code}: {exc}") from exc
    impl = _IMPL.get(component_id)
    if impl is None:
        raise ComponentRefusal("component.not_executable", f"{component_id}: interface declared, executable boundary not yet bound (T03)")
    ctx = {"binding": binding, "granted_effects": sorted(granted_effects), "sandbox": Path(sandbox) if sandbox else None, "bounds": dict(c["interface"]["bounds"]), "run": run, "registry": reg, "component": c}
    started = time.monotonic()
    outputs = _execute(c, impl, inputs, ctx)
    elapsed = round(time.monotonic() - started, 3)
    return _enforce_bounds(c, _seal(c, inputs, idents, outputs, needed, elapsed, reg, run))


def _execute(c: Mapping[str, Any], impl: Callable[..., dict[str, Any]], inputs: Mapping[str, Any], ctx: Mapping[str, Any]) -> dict[str, Any]:
    """Run the implementation; a refusal it raises passes through (declared error), anything else is one failure — no retry."""
    declared = {e["code"] for e in c["interface"]["errors"]} | set(GENERIC_ERRORS)
    try:
        return impl(dict(inputs), ctx)
    except ComponentRefusal:
        raise
    except lga.AdapterError as exc:
        if exc.code in declared:
            raise ComponentRefusal(exc.code, f"{c['component_id']}: {exc}") from exc
        raise ComponentRefusal("component.failed", f"{c['component_id']}: {exc.code}: {exc}") from exc


def _validate_outputs(c: Mapping[str, Any], outputs: Mapping[str, Any], reg: Mapping[str, Any]) -> dict[str, Any]:
    iface = c["interface"]
    unknown = sorted(set(outputs) - set(iface["outputs"]))
    if unknown:
        raise ComponentRefusal("component.output_invalid", f"{c['component_id']}: undeclared outputs {unknown}")
    out = {}
    for name, spec in iface["outputs"].items():
        if name not in outputs:
            if spec.get("required", True):
                raise ComponentRefusal("component.output_invalid", f"{c['component_id']}: output {name!r} missing")
            continue
        value = canon(outputs[name])
        val = spec.get("validation", "")
        if val.startswith("contract:"):
            try:
                C.validate_payload(val.split(":", 1)[1], value, registry=reg)
            except lga.AdapterError as exc:
                raise ComponentRefusal("component.output_invalid", f"{c['component_id']}: {name}: {exc}") from exc
        elif val.startswith("record_schema:"):
            if not isinstance(value, Mapping) or value.get("record_schema") != val.split(":", 1)[1]:
                raise ComponentRefusal("component.output_invalid", f"{c['component_id']}: {name} lacks record_schema {val.split(':', 1)[1]}")
        if spec.get("required_keys"):
            missing_keys = [k for k in spec["required_keys"] if not isinstance(value, Mapping) or k not in value]
            if missing_keys:
                raise ComponentRefusal("component.output_invalid", f"{c['component_id']}: {name} lacks {missing_keys}")
        out[name] = value
    return out


def _seal(c: Mapping[str, Any], inputs: Mapping[str, Any], idents: Mapping[str, Any], raw: Mapping[str, Any], caps: Sequence[str], elapsed: float, reg: Mapping[str, Any], run: Any) -> ComponentResult:
    outputs = _validate_outputs(c, raw, reg)
    binding = _binding_of(inputs)
    prov = {"repository_id": binding.repository_id if binding else None, "worktree_id": binding.worktree_id if binding else None, "base_revision": binding.base_revision if binding else None,
            "source_snapshot_hash": binding.source_snapshot_hash if binding else None, "component_version": c["version"], "components_hash": None, "authoritative_suites": list(c["authoritative_suites"])}
    for f in c["interface"]["provenance_fields"]:
        if f in prov and prov[f] is None and binding is not None:
            raise ComponentRefusal("component.output_invalid", f"{c['component_id']}: provenance field {f} unresolved")
    volatile = c["interface"].get("volatile_fields", [])
    stable = {k: _strip_volatile(v, volatile) for k, v in outputs.items() if k not in volatile}
    output_hash = digest(stable)
    inputs_hash = digest(idents)
    items = sum(_count_items(v) for v in outputs.values())
    size = len(lga.canonical_json(outputs).encode("utf-8"))
    observed = {"elapsed_s": elapsed, "output_items": items, "output_bytes": size, "failures": 0}
    body = {"record_schema": RESULT_SCHEMA, "component_id": c["component_id"], "component_version": c["version"], "inputs_hash": inputs_hash, "input_identities": dict(idents), "outputs": outputs, "output_hash": output_hash,
            "provenance": prov, "bounds_observed": observed, "capabilities_used": list(caps), "invoked_at": _now()}
    body["result_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in body.items() if k not in ("invoked_at",)}))
    C.validate_payload("component_result", {k: v for k, v in body.items() if k != "outputs"}, registry=reg)
    if run is not None and hasattr(run, "_audit"):
        run._audit(effect="component.invoke", component_id=c["component_id"], component_version=c["version"], inputs_hash=inputs_hash, output_hash=output_hash, result_hash=body["result_hash"], capabilities=list(caps), bounds_observed=observed)
    return ComponentResult(**body)


def _strip_volatile(value: Any, volatile: Sequence[str]) -> Any:
    if isinstance(value, Mapping):
        return {k: _strip_volatile(v, volatile) for k, v in value.items() if k not in volatile}
    if isinstance(value, list):
        return [_strip_volatile(v, volatile) for v in value]
    return value


def _count_items(value: Any) -> int:
    if isinstance(value, list):
        return len(value) + sum(_count_items(v) for v in value if isinstance(v, (list, dict)))
    if isinstance(value, Mapping):
        return sum(_count_items(v) for v in value.values())
    return 0


def replay_check(a: ComponentResult, b: ComponentResult) -> dict[str, Any]:
    """Two invocations over the exact same pinned inputs must yield the same output hash (deterministic replay)."""
    same_inputs = a.inputs_hash == b.inputs_hash and a.component_id == b.component_id and a.component_version == b.component_version
    return {"component_id": a.component_id, "same_inputs": same_inputs, "same_outputs": a.output_hash == b.output_hash, "deterministic": same_inputs and a.output_hash == b.output_hash, "inputs_hash": a.inputs_hash, "output_hash": a.output_hash, "replay_output_hash": b.output_hash}


__all__ = ["COMPONENTS_PATH", "COMPONENTS_VERSION", "ComponentRefusal", "ComponentResult", "GENERIC_ERRORS", "canon", "digest", "invoke", "load_components", "register_impl", "replay_check"]


# --------------------------------------------------------------------------- #
# T03 — executable component boundaries (each composes the existing overlay adapter for its suite; every output is
# derived from the pinned revision only, carries provenance, and is validated by the envelope before it is returned)
# --------------------------------------------------------------------------- #
import ast as _ast
import re as _re

from . import archive_adapter as _ar
from . import evidence_retrieval as _er
from . import guardrails as _gr
from . import patch_generator as _pg
from . import repository_context_adapter as _rca
from . import review_renderer as _rr
from . import verification_runner as _vr

NS = "overlay.scoped_pr_builder.components"


def _prov(binding: lga.RepositoryBinding) -> dict[str, Any]:
    return {"repository_id": binding.repository_id, "worktree_id": binding.worktree_id, "base_revision": binding.base_revision, "source_snapshot_hash": binding.source_snapshot_hash}


def _sealed(rec: dict[str, Any], hash_key: str, *, exclude: Sequence[str] = ()) -> dict[str, Any]:
    rec[hash_key] = lga.sha256_digest(lga.canonical_json({k: v for k, v in rec.items() if k != hash_key and k not in exclude}))
    return rec


def _bind_check(binding: lga.RepositoryBinding, art: Mapping[str, Any], cid: str) -> None:
    if art.get("base_revision") != binding.base_revision or (art.get("repository_id") and art["repository_id"] != binding.repository_id):
        _SEC.record_denial("SEC-04", "security.sec04.foreign_repository" if art.get("repository_id") and art["repository_id"] != binding.repository_id else "security.sec04.foreign_revision", f"{cid}: input artifact bound elsewhere", subject={"component": cid})  # SEC-04-T02
        raise ComponentRefusal("component.binding_mismatch", f"{cid}: input artifact is bound to another repository/revision")


# @@ COMP-01
@register_impl("COMP-01")
def _impl_symbol_index(inputs: Mapping[str, Any], ctx: Mapping[str, Any]) -> dict[str, Any]:
    """COMP-01 Repository parser and symbol index: Suite 40.2 symbol records + 40.3 dependency records + 40.1 context
    for the pinned revision (repository_context_adapter), re-keyed into a content-addressed, replayable index."""
    b: lga.RepositoryBinding = inputs["binding"]
    bundle = _rca.build_context(Path(b.root_path), b.base_revision, max_files=int(inputs.get("max_files") or ctx["bounds"].get("max_files", 20000)))
    if bundle.binding["base_revision"] != b.base_revision or bundle.binding["source_snapshot_hash"] != b.source_snapshot_hash:
        raise ComponentRefusal("component.binding_mismatch", "COMP-01: parsed tree is not the pinned tree")
    keep = ("symbol_id", "file_path", "language_profile", "symbol_kind", "qualified_name", "signature_hash", "definition_span", "visibility", "source_hash")
    symbols = [{k: s[k] for k in keep} for s in bundle.symbols]
    by_file: dict[str, list[str]] = {}
    for s in symbols:
        by_file.setdefault(s["file_path"], []).append(s["symbol_id"])
    dkeep = ("dependency_id", "source_node", "target_node", "dependency_kind", "constraint_digest", "resolution_status", "cycle_status", "source_hash", "dependency_hash")
    deps = [{k: d[k] for k in dkeep} for d in bundle.dependencies]
    index = {"record_schema": f"{NS}/SymbolIndex", **_prov(b), "context_id": bundle.context["context_id"], "context_hash": bundle.context["context_hash"], "language_profile": bundle.context["language_profile"],
             "file_count": bundle.context["file_count"], "symbol_count": len(symbols), "parse_errors": sum(1 for s in symbols if s["symbol_kind"] == "parse_error"), "symbols": symbols, "by_file": by_file}
    index["index_id"] = lga.sha256_digest(lga.canonical_json({"ctx": index["context_id"], "snap": b.source_snapshot_hash}))
    _sealed(index, "index_hash")
    drec = {"record_schema": f"{NS}/DependencyRecords", **_prov(b), "index_id": index["index_id"], "count": len(deps), "unresolved": sum(1 for d in deps if d["resolution_status"] == "unresolved"), "dependencies": deps}
    _sealed(drec, "records_hash")
    return {"symbol_index": index, "dependency_records": drec}
# @@ COMP-02
_CALL_RE = _re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(")


def _py_calls(text: str) -> list[str]:
    try:
        tree = _ast.parse(text)
    except SyntaxError:
        return []
    names = []
    for node in _ast.walk(tree):
        if isinstance(node, _ast.Call):
            f = node.func
            if isinstance(f, _ast.Name):
                names.append(f.id)
            elif isinstance(f, _ast.Attribute):
                names.append(f.attr)
    return sorted(set(names))


@register_impl("COMP-02")
def _impl_code_graph(inputs: Mapping[str, Any], ctx: Mapping[str, Any]) -> dict[str, Any]:
    """COMP-02 AST/CST and semantic code graph: files, symbols, suites and externals as nodes; containment, resolved
    file dependencies, suite references, externals and (Python, via ast) call edges resolved to indexed symbols."""
    b: lga.RepositoryBinding = inputs["binding"]
    idx, deps = inputs["symbol_index"], inputs["dependency_records"]
    _bind_check(b, idx, "COMP-02"); _bind_check(b, deps, "COMP-02")
    if deps["index_id"] != idx["index_id"]:
        raise ComponentRefusal("component.input_invalid", "COMP-02: dependency records belong to another symbol index")
    nodes: dict[str, dict[str, Any]] = {}
    edges: list[dict[str, Any]] = []

    def node(nid: str, kind: str, label: str, **extra: Any) -> str:
        nodes.setdefault(nid, {"node_id": nid, "kind": kind, "label": label, **extra})
        return nid

    def edge(kind: str, src: str, dst: str, resolution: str = "resolved", **extra: Any) -> None:
        edges.append({"edge_id": lga.sha256_digest(f"{kind}|{src}|{dst}"), "kind": kind, "source": src, "target": dst, "resolution": resolution, **extra})

    by_name: dict[str, list[dict[str, Any]]] = {}
    for s in idx["symbols"]:
        f = node(f"file:{s['file_path']}", "file", s["file_path"], language_profile=s["language_profile"])
        sid = node(f"symbol:{s['symbol_id']}", "symbol", s["qualified_name"], symbol_kind=s["symbol_kind"], path=s["file_path"], span=s["definition_span"])
        edge("contains", f, sid)
        by_name.setdefault(s["qualified_name"].rsplit(".", 1)[-1], []).append(s)
    for d in deps["dependencies"]:
        src = node(f"file:{d['source_node']}", "file", d["source_node"])
        if d["dependency_kind"] == "data_source":
            if d["resolution_status"] == "resolved":
                edge("depends_on", src, node(f"file:{d['target_node']}", "file", d["target_node"]), cycle=d["cycle_status"] == "cycle")
            else:
                edge("depends_on", src, node(f"missing:{d['target_node']}", "missing", d["target_node"]), resolution="unresolved")
        elif d["dependency_kind"] == "suite_reference":
            edge("references_suite", src, node(f"suite:{d['target_node']}", "suite", d["target_node"]), resolution=d["resolution_status"])
        else:
            edge(d["dependency_kind"], src, node(f"external:{d['target_node']}", "external", d["target_node"]), resolution="external")
    ambiguous, calls = 0, 0
    for path in sorted(idx["by_file"]):
        if not path.endswith(".py"):
            continue
        text = lga.read_blob(Path(b.root_path), b.base_revision, PurePosixPath(path)).decode("utf-8", errors="replace")
        callers = [s for s in idx["symbols"] if s["file_path"] == path]
        for name in _py_calls(text):
            cands = by_name.get(name, [])
            same = [c for c in cands if c["file_path"] == path]
            target = same[0] if len(same) == 1 else (cands[0] if len(cands) == 1 else None)
            if target is None:
                ambiguous += 1 if len(cands) > 1 else 0
                continue
            for caller in callers or [None]:
                src = f"symbol:{caller['symbol_id']}" if caller else f"file:{path}"
                if src != f"symbol:{target['symbol_id']}":
                    edge("calls", src, f"symbol:{target['symbol_id']}", via="python.ast")
                    calls += 1
    edges.sort(key=lambda e: (e["kind"], e["source"], e["target"]))
    seen, uniq = set(), []
    for e in edges:
        if e["edge_id"] not in seen:
            seen.add(e["edge_id"]); uniq.append(e)
    graph = {"record_schema": f"{NS}/CodeGraph", **_prov(b), "derived_from": {"index_id": idx["index_id"], "index_hash": idx["index_hash"], "records_hash": deps["records_hash"]},
             "node_count": len(nodes), "edge_count": len(uniq), "edge_kinds": sorted({e["kind"] for e in uniq}), "ambiguous_calls": ambiguous, "call_edges": calls,
             "nodes": [nodes[k] for k in sorted(nodes)], "edges": uniq}
    graph["graph_id"] = lga.sha256_digest(lga.canonical_json({"idx": idx["index_id"], "rev": b.base_revision}))
    _sealed(graph, "graph_hash")
    return {"code_graph": graph}
# @@ COMP-03
def _scc(adj: Mapping[str, set[str]]) -> list[list[str]]:
    """Tarjan's strongly connected components (iterative, deterministic order)."""
    index, low, on, stack, out, counter = {}, {}, set(), [], [], [0]

    def visit(v: str) -> None:
        index[v] = low[v] = counter[0]; counter[0] += 1
        stack.append(v); on.add(v)
        for w in sorted(adj.get(v, ())):
            if w not in index:
                visit(w); low[v] = min(low[v], low[w])
            elif w in on:
                low[v] = min(low[v], index[w])
        if low[v] == index[v]:
            comp = []
            while True:
                w = stack.pop(); on.discard(w); comp.append(w)
                if w == v:
                    break
            out.append(sorted(comp))
    for v in sorted(adj):
        if v not in index:
            visit(v)
    return out


@register_impl("COMP-03")
def _impl_dependency_graph(inputs: Mapping[str, Any], ctx: Mapping[str, Any]) -> dict[str, Any]:
    """COMP-03 Dependency/build graph: file → file / suite / external edges from the 40.3 records, cycles (SCCs),
    a deterministic build order for the acyclic part, and declared packages from an ADMITTED DATA-02 intake record."""
    b: lga.RepositoryBinding = inputs["binding"]
    deps = inputs["dependency_records"]
    _bind_check(b, deps, "COMP-03")
    adj: dict[str, set[str]] = {}
    edges = []
    for d in deps["dependencies"]:
        adj.setdefault(d["source_node"], set())
        if d["dependency_kind"] == "data_source" and d["resolution_status"] == "resolved":
            adj[d["source_node"]].add(d["target_node"]); adj.setdefault(d["target_node"], set())
        edges.append({"source": d["source_node"], "target": d["target_node"], "kind": d["dependency_kind"], "resolution": d["resolution_status"], "dependency_id": d["dependency_id"]})
    comps = _scc(adj)
    cycles = [c for c in comps if len(c) > 1 or (len(c) == 1 and c[0] in adj.get(c[0], ()))]
    cyclic = {n for c in cycles for n in c}
    indeg = {n: 0 for n in adj if n not in cyclic}
    for s, ts in adj.items():
        if s in cyclic:
            continue
        for t in ts:
            if t in indeg:
                indeg[t] += 1
    ready, order = sorted(n for n, k in indeg.items() if k == 0), []
    while ready:
        n = ready.pop(0); order.append(n)
        for t in sorted(adj.get(n, ())):
            if t in indeg:
                indeg[t] -= 1
                if indeg[t] == 0:
                    ready.append(t); ready.sort()
    manifests, gaps = None, []
    intake = inputs.get("manifest_intake")
    if intake is not None:
        if intake.get("source_id") != "DATA-02":
            raise ComponentRefusal("component.input_invalid", "COMP-03: manifest_intake must be the DATA-02 intake record")
        if intake["state"] == "ADMITTED" and intake.get("base_revision") == b.base_revision:
            manifests = {"intake_hash": intake["intake_hash"], "files": [{"path": i["canonical_path"], "content_hash": i["content_hash"], "dependencies": i.get("dependencies", {})} for i in intake["items"]]}
        else:
            gaps.append(f"manifest intake is {intake['state']} (or bound elsewhere); declared packages are unknown, not empty")
    else:
        gaps.append("no manifest intake supplied; declared packages are unknown, not empty")
    graph = {"record_schema": f"{NS}/DependencyGraph", **_prov(b), "derived_from": {"index_id": deps["index_id"], "records_hash": deps["records_hash"]}, "node_count": len(adj), "edge_count": len(edges),
             "edges": edges, "cycles": cycles, "build_order_status": "cyclic" if cycles else "acyclic", "build_order": order, "declared_packages": manifests, "gaps": gaps,
             "unresolved": sorted({e["target"] for e in edges if e["resolution"] == "unresolved"})}
    graph["graph_id"] = lga.sha256_digest(lga.canonical_json({"recs": deps["records_hash"], "rev": b.base_revision}))
    _sealed(graph, "graph_hash")
    return {"dependency_graph": graph}
# @@ COMP-04
_SNAKE = _re.compile(r"^[a-z_][a-z0-9_]*$")
_CAMEL = _re.compile(r"^[A-Z][A-Za-z0-9]*$")
_NUMBERED = _re.compile(r"^\d+(\.\d+)?_")


@register_impl("COMP-04")
def _impl_convention_learner(inputs: Mapping[str, Any], ctx: Mapping[str, Any]) -> dict[str, Any]:
    """COMP-04 Repository-convention learner: naming, structure, error-handling and testing conventions observed
    deterministically from exact pinned analogous examples (Suite 51.2 retrieval) and the symbol index — never invented."""
    b: lga.RepositoryBinding = inputs["binding"]
    contract, idx = inputs["scope_contract"], inputs["symbol_index"]
    _bind_check(b, contract, "COMP-04"); _bind_check(b, idx, "COMP-04")
    bundle = _er.retrieve_examples(b, contract, intake=inputs.get("intake"))
    examples = [e for e in bundle.evidence if e["evidence_kind"] == "analogous_example"]
    targets = [e for e in bundle.evidence if e["evidence_kind"] == "target_source"]
    ex_paths = [e["canonical_path"] for e in examples]
    names = [p.rsplit("/", 1)[-1] for p in ex_paths]
    numbered = sum(1 for n in names if _NUMBERED.match(n))
    ext_counts: dict[str, int] = {}
    for n in names:
        ext_counts[n.rsplit(".", 1)[-1] if "." in n else ""] = ext_counts.get(n.rsplit(".", 1)[-1] if "." in n else "", 0) + 1
    tgt_dirs = sorted({p.rsplit("/", 1)[0] if "/" in p else "" for p in (t["canonical_path"] for t in targets)})
    ex_dirs = sorted({p.rsplit("/", 1)[0] if "/" in p else "" for p in ex_paths})
    sym_names = [s["qualified_name"].rsplit(".", 1)[-1] for s in idx["symbols"] if s["symbol_kind"] in ("function", "class")]
    snake = sum(1 for n in sym_names if _SNAKE.match(n)); camel = sum(1 for n in sym_names if _CAMEL.match(n))
    texts = {}
    for e in examples:
        texts[e["canonical_path"]] = lga.read_blob(Path(b.root_path), b.base_revision, PurePosixPath(e["canonical_path"])).decode("utf-8", errors="replace")
    err_tokens = ("deny", "fail closed", "refuse", "raise ", "assert", "abstain", "require ")
    err_hits = {t: sum(1 for x in texts.values() if t in x) for t in err_tokens}
    test_paths = [p for p in idx["by_file"] if "test" in p.lower()]
    conventions = {
        "naming": {"numbered_prefix_ratio": round(numbered / len(names), 3) if names else None, "dominant_extension": max(ext_counts.items(), key=lambda kv: (kv[1], kv[0]))[0] if ext_counts else None, "symbol_style": "snake_case" if snake >= camel and snake else ("CamelCase" if camel else None), "symbol_style_counts": {"snake_case": snake, "CamelCase": camel}},
        "structure": {"target_dirs": tgt_dirs, "example_dirs": ex_dirs, "examples_share_target_dir": bool(set(tgt_dirs) & set(ex_dirs)), "readme_present": any(p.lower().endswith("readme.md") for p in idx["by_file"]) or any(n.lower().startswith("readme") for n in names)},
        "error_handling": {"tokens_in_examples": err_hits, "fail_closed_vocabulary_present": any(err_hits[t] for t in ("deny", "fail closed", "refuse", "abstain"))},
        "testing": {"test_files_indexed": len(test_paths), "examples_include_tests": any("test" in p.lower() for p in ex_paths)},
    }
    profile = {"record_schema": f"{NS}/ConventionProfile", **_prov(b), "scope_contract_hash": contract["scope_contract_hash"], "retrieval_id": bundle.retrieval_id, "index_id": idx["index_id"],
               "evidence_refs": [{"evidence_id": e["evidence_id"], "path": e["canonical_path"], "content_hash": e["content_hash"]} for e in examples],
               "example_count": len(examples), "confidence": "high" if len(examples) >= 3 else ("medium" if examples else "low"), "conventions": conventions,
               "cannot": ["invent conventions without examples", "widen scope", "read outside the pinned revision"]}
    profile["profile_id"] = lga.sha256_digest(lga.canonical_json({"scope": contract["scope_contract_hash"], "retrieval": bundle.retrieval_id, "idx": idx["index_id"]}))
    _sealed(profile, "profile_hash")
    return {"convention_profile": profile, "evidence_bundle": canon(bundle)}
# @@ COMP-05
_HUNK_RE = _re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")


def _diff_ranges(patch_text: str) -> dict[str, list[tuple[int, int]]]:
    """Changed line ranges (old-file coordinates) per path from a unified diff."""
    out: dict[str, list[tuple[int, int]]] = {}
    path = None
    for line in patch_text.splitlines():
        if line.startswith("--- "):
            p = line[4:].strip()
            path = None if p == "/dev/null" else p[2:] if p.startswith("a/") else p
        elif line.startswith("+++ ") and path is None:
            p = line[4:].strip()
            path = p[2:] if p.startswith("b/") else p
        elif line.startswith("@@") and path:
            m = _HUNK_RE.match(line)
            if m:
                start = int(m.group(1)); count = int(m.group(2) or 1)
                out.setdefault(path, []).append((start, max(start + count - 1, start)))
    return out


@register_impl("COMP-05")
def _impl_change_impact(inputs: Mapping[str, Any], ctx: Mapping[str, Any]) -> dict[str, Any]:
    """COMP-05 Change-impact engine (Action Cards 49.11): touched symbols from diff hunks × symbol spans, direct and
    bounded-transitive dependents over the code/dependency graphs, affected tests, blast radius and risk band."""
    b: lga.RepositoryBinding = inputs["binding"]
    cand, patch = inputs["candidate"], inputs["patch"]
    _bind_check(b, cand, "COMP-05")
    _pg.verify_candidate_hash(cand, patch)
    idx, cg, dg = inputs["symbol_index"], inputs["code_graph"], inputs["dependency_graph"]
    for a in (idx, cg, dg):
        _bind_check(b, a, "COMP-05")
    depth_cap = int(ctx["bounds"].get("max_transitive_depth", 5))
    ranges = _diff_ranges(patch.decode("utf-8", errors="replace"))
    changed = sorted(set(cand["canonical_paths"]) | set(ranges))
    touched = []
    for s in idx["symbols"]:
        if s["file_path"] in ranges:
            m = _re.match(r"^L(\d+)-L(\d+)$", s["definition_span"])
            if m:
                l0, l1 = int(m.group(1)), int(m.group(2))
                if any(not (r1 < l0 or r0 > l1) for r0, r1 in ranges[s["file_path"]]):
                    touched.append({"symbol_id": s["symbol_id"], "qualified_name": s["qualified_name"], "kind": s["symbol_kind"], "path": s["file_path"]})
    rev: dict[str, set[str]] = {}
    for e in cg["edges"]:
        if e["kind"] in ("depends_on", "calls") and e["resolution"] == "resolved":
            rev.setdefault(e["target"], set()).add(e["source"])
    for e in dg["edges"]:
        if e["kind"] == "data_source" and e["resolution"] == "resolved":
            rev.setdefault(f"file:{e['target']}", set()).add(f"file:{e['source']}")
    sym_file = {f"symbol:{s['symbol_id']}": s["file_path"] for s in idx["symbols"]}
    seeds = {f"file:{p}" for p in changed} | {f"symbol:{t['symbol_id']}" for t in touched}
    frontier, seen, depth_of, explored = set(seeds), set(seeds), {}, 0
    for depth in range(1, depth_cap + 1):
        nxt = set()
        for n in frontier:
            for m in rev.get(n, ()):
                if m not in seen:
                    seen.add(m); nxt.add(m); depth_of[m] = depth
        if not nxt:
            break
        frontier, explored = nxt, depth
    truncated = any(m not in seen for n in frontier for m in rev.get(n, ()))  # unexplored dependents beyond the depth bound

    def to_file(n: str) -> str | None:
        return n[5:] if n.startswith("file:") else sym_file.get(n)

    dependents = sorted({f for n in seen - seeds for f in [to_file(n)] if f and f not in changed})
    direct = sorted({f for n, d in depth_of.items() if d == 1 for f in [to_file(n)] if f and f not in changed})
    stems = {c.rsplit("/", 1)[-1].rsplit(".", 1)[0].lower() for c in changed}
    tests = sorted({p for p in set(dependents) | set(changed) if "test" in p.lower()} | {p for p in idx["by_file"] if "test" in p.lower() and any(st and st in p.lower() for st in stems)})
    suites = sorted({e["target"][6:] for e in cg["edges"] if e["kind"] == "references_suite" and e["source"] in seeds})
    radius = {"files_changed": len(changed), "symbols_touched": len(touched), "direct_dependents": len(direct), "transitive_dependents": len(dependents), "affected_tests": len(tests), "depth_explored": explored, "depth_cap": depth_cap, "truncated": truncated}
    risk = "high" if (radius["transitive_dependents"] > 10 or truncated) else ("medium" if radius["transitive_dependents"] > 0 or radius["symbols_touched"] > 0 else "low")
    rep = {"record_schema": f"{NS}/ImpactReport", **_prov(b), "candidate_id": cand["candidate_id"], "patch_hash": cand["patch_hash"], "scope_contract_hash": cand["scope_contract_hash"],
           "derived_from": {"index_id": idx["index_id"], "graph_id": cg["graph_id"], "dependency_graph_id": dg["graph_id"]}, "changed_paths": changed, "touched_symbols": touched, "direct_dependents": direct,
           "transitive_dependents": dependents, "affected_tests": tests, "suites_referenced": suites, "blast_radius": radius, "risk_band": risk, "authority": "advisory_only"}
    rep["impact_id"] = lga.sha256_digest(lga.canonical_json({"cand": cand["candidate_id"], "graph": cg["graph_id"], "dg": dg["graph_id"]}))
    _sealed(rep, "impact_hash")
    return {"impact_report": rep}
# @@ COMP-06
@register_impl("COMP-06")
def _impl_refactoring_planner(inputs: Mapping[str, Any], ctx: Mapping[str, Any]) -> dict[str, Any]:
    """COMP-06 Refactoring planner (Chatbot 47.2 planning): the advisory-only plan comes through the model boundary
    (adapters/model_orchestration: pinned approved provider, source-labeled authorized context, versioned prompt, recorded
    call, validated + routed output — MODEL-*-T02); an optional convention profile is attached as guidance, never authority."""
    from . import model_orchestration as _MO
    b: lga.RepositoryBinding = inputs["binding"]
    contract = inputs["scope_contract"]
    _bind_check(b, contract, "COMP-06")
    eb = inputs["evidence_bundle"]
    if eb.get("scope_contract_hash") != contract["scope_contract_hash"] or eb.get("base_revision") != b.base_revision:
        raise ComponentRefusal("component.input_invalid", "COMP-06: evidence bundle is not bound to this contract/revision")
    bundle = _er.EvidenceBundle(**{k: eb[k] for k in ("adapter_id", "adapter_version", "retrieval_id", "repository_id", "worktree_id", "base_revision", "source_snapshot_hash", "scope_contract_hash", "query_tokens_digest", "corpus_size", "evidence", "authority")})
    prof = inputs.get("convention_profile")
    if prof is not None and prof.get("scope_contract_hash") != contract["scope_contract_hash"]:
        raise ComponentRefusal("component.input_invalid", "COMP-06: convention profile belongs to another scope contract")
    run_dir = inputs.get("run_dir")
    res = _MO.invoke("deterministic-advisor", binding=b, scope_contract=contract, bundle=bundle, analyzer_inputs={"convention_profile": prof} if prof is not None else {}, run_dir=Path(run_dir) if run_dir else None, run_id=getattr(ctx.get("run"), "run_id", None), registry=ctx.get("registry"))
    route = res["route"]
    if route["route"] == "human_review":
        raise ComponentRefusal("component.model_output_refused", f"COMP-06: model output routed to human review ({route['reason_code']}): {route['detail']}")
    plan = dict((res["output"] or res["raw_output"])["plan"])
    if route["route"] == "abstain" and plan.get("status") != "ABSTAIN":  # the route is honoured, the plan is not repaired
        plan["status"] = "ABSTAIN"; plan["abstain_reason"] = f"{route['reason_code']}: {route['detail']}"; plan["uncertainty"] = dict(plan.get("uncertainty") or {}, evidence_sufficiency="insufficient")
    plan["model_call_id"] = res["record"]["call_id"]
    if prof is not None:
        plan["conventions_guidance"] = {"profile_id": prof["profile_id"], "profile_hash": prof["profile_hash"], "confidence": prof["confidence"], "authority": "advisory_only"}
    plan["plan_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in plan.items() if k not in ("plan_hash", "created_at")}))
    call = {"call_id": res["record"]["call_id"], "provider": res["provider"], "prompt_hash": res["prompt"]["prompt_hash"], "policy_version": res["prompt"]["policy_version"], "authorized_set_hash": res["sources"]["authorized_set_hash"], "route": {k: route[k] for k in ("route", "reason_code", "detail")},
            "abstention": route.get("abstention"), "refusals": res["refusals"], "record_hash": res["record"]["entry_hash"], "persisted": res["record"]["persisted"]}
    return {"refactoring_plan": plan, "model_call": call}
# @@ COMP-07
@register_impl("COMP-07")
def _impl_patch_generator(inputs: Mapping[str, Any], ctx: Mapping[str, Any]) -> dict[str, Any]:
    """COMP-07 Atomic patch/diff generator (50.1/50.2): one inert bounded candidate from a PLANNED plan and a registered
    deterministic recipe (patch_generator.generate_candidate, CAP-03 gated); the diff is returned as text with its hash."""
    b: lga.RepositoryBinding = inputs["binding"]
    contract, plan = inputs["scope_contract"], inputs["refactoring_plan"]
    _bind_check(b, contract, "COMP-07")
    cand, patch = _pg.generate_candidate(b, contract, plan, inputs["recipe"])
    c = json.loads(cand.to_json())
    return {"candidate": c, "patch": patch, "patch_text": patch.decode("utf-8", errors="replace")}
# @@ COMP-08
@register_impl("COMP-08")
def _impl_test_runner(inputs: Mapping[str, Any], ctx: Mapping[str, Any]) -> dict[str, Any]:
    """COMP-08 Incremental compiler/test runner (57.3/57.4, 60.2/60.3): isolated verification of one candidate in a
    throwaway worktree; test jobs are selected from an impact report when one is supplied (incremental) else run in full."""
    b: lga.RepositoryBinding = inputs["binding"]
    contract, cand, patch = inputs["scope_contract"], inputs["candidate"], inputs["patch"]
    _bind_check(b, contract, "COMP-08"); _bind_check(b, cand, "COMP-08")
    sandbox = ctx["sandbox"]
    if sandbox is None:
        raise ComponentRefusal("component.input_invalid", "COMP-08: a sandbox parent outside the repository is required")
    root = lga.canonical_root(Path(b.root_path))
    if lga.path_within(Path(sandbox), root):
        raise ComponentRefusal("component.input_invalid", "COMP-08: sandbox parent must lie outside the bound repository")
    impact = inputs.get("impact_report")
    if impact is not None:
        if impact.get("candidate_id") != cand["candidate_id"]:
            raise ComponentRefusal("component.input_invalid", "COMP-08: impact report describes another candidate")
        selected = sorted(t for t in impact["affected_tests"] if t.rsplit("/", 1)[-1].startswith("test_") and t.endswith(".py"))
        selection = {"mode": "incremental" if selected else "full", "selected_tests": selected, "impact_hash": impact["impact_hash"],
                     "note": "only the test modules the impact report names are run; an empty selection is not evidence of safety, so the full suite runs"}
    else:
        selection = {"mode": "full", "selected_tests": [], "impact_hash": None, "note": "no impact report: the full suite runs"}
    timeout = int(min(int(ctx["bounds"]["timeout_s"]), int(inputs.get("timeout_s") or ctx["bounds"]["timeout_s"])))
    from . import verification_checks as _vc  # VERIFY-*-T02: typed per-check results derived from the runner's job records only
    r, results = _vc.run_checks(b, contract, cand, patch, Path(sandbox), timeout=timeout, run_tests=True, select_tests=selection["selected_tests"] or None, registry=ctx.get("registry"))
    return {"verification_report": r, "test_selection": selection, "check_results": results}
# @@ COMP-09
@register_impl("COMP-09")
def _impl_scope_governor(inputs: Mapping[str, Any], ctx: Mapping[str, Any]) -> dict[str, Any]:
    """COMP-09 Patch-size/scope governor (55.3 action scope, 50.6 confinement): evaluates GRD-01, CAP-01 and CAP-03 over
    the candidate and contract plus path confinement; ALLOW only when every decision is PASS and every path is confined."""
    contract, cand = inputs["scope_contract"], inputs["candidate"]
    if cand.get("scope_contract_hash") != contract["scope_contract_hash"]:
        raise ComponentRefusal("component.input_invalid", "COMP-09: candidate belongs to another scope contract")
    facts = {"GRD-01": _gr.facts_bounded_size(cand, contract), "CAP-01": _gr.facts_scope_intent(contract), "CAP-03": _gr.facts_atomic_bounded_diff(cand)}
    decisions = [_gr.evaluate("GRD-01", facts["GRD-01"], effect="diff.generate_inert", registry=ctx["registry"]), _gr.evaluate("CAP-01", facts["CAP-01"], effect="evidence.retrieve", registry=ctx["registry"]),
                 _gr.evaluate("CAP-03", facts["CAP-03"], effect="diff.generate_inert", registry=ctx["registry"])]
    allowed = tuple(PurePosixPath(p) for p in contract["allowed_paths"]); forbidden = tuple(PurePosixPath(p) for p in contract.get("forbidden_paths", ()))
    violations = [p for p in cand["canonical_paths"] if not lga.within(PurePosixPath(p), allowed) or lga.within(PurePosixPath(p), forbidden)]
    states = [d["state"] for d in decisions]
    verdict = "REFUSE" if violations or "DENY" in states or "DIAGNOSTIC" in states else ("ABSTAIN" if "ABSTAIN" in states else "ALLOW")
    dec = {"record_schema": f"{NS}/GovernorDecision", "candidate_id": cand["candidate_id"], "patch_hash": cand["patch_hash"], "scope_contract_hash": contract["scope_contract_hash"], "base_revision": cand["base_revision"],
           "verdict": verdict, "decisions": decisions, "confinement": {"within_scope": not violations, "violations": violations, "allowed_paths": list(contract["allowed_paths"]), "forbidden_paths": list(contract.get("forbidden_paths", []))},
           "limit_profile": dict(cand["limit_profile"]), "observed": {"files_changed": cand["files_changed"], "lines_changed": int(cand["lines_added"]) + int(cand["lines_deleted"]), "hunks": cand["hunks"]},
           "reason": "; ".join(f"{d['rule_id']}={d['state']}" for d in decisions) + (f"; confinement violations {violations}" if violations else ""), "cannot": ["widen the limit profile", "waive confinement", "approve"]}
    dec["decision_id"] = lga.sha256_digest(lga.canonical_json({"cand": cand["candidate_id"], "scope": contract["scope_contract_hash"]}))
    _sealed(dec, "decision_hash", exclude=("decisions",))
    dec["decisions_hash"] = lga.sha256_digest(lga.canonical_json([d["decision_hash"] for d in decisions]))
    return {"governor_decision": dec}
# @@ COMP-10
@register_impl("COMP-10")
def _impl_review_ui(inputs: Mapping[str, Any], ctx: Mapping[str, Any]) -> dict[str, Any]:
    """COMP-10 Human review/approval UI (26.3 dashboards, 50.5 human approval): the Action-Cards review card and its
    HTML for a human; the approval gate stays PENDING_HUMAN — this component can neither issue nor bypass approvals."""
    b: lga.RepositoryBinding = inputs["binding"]
    card = _rr.build_review_card(json.loads(b.to_json()), inputs["scope_contract"], inputs["evidence"], inputs["authority"], inputs["refactoring_plan"], inputs["candidate"], inputs["patch"], inputs["verification_report"],
                                 context=None, intake=inputs.get("intake"))
    if inputs.get("impact_report") is not None:
        imp = inputs["impact_report"]
        if imp.get("candidate_id") != inputs["candidate"]["candidate_id"]:
            raise ComponentRefusal("component.input_invalid", "COMP-10: impact report describes another candidate")
        card["impact"] = {"impact_id": imp["impact_id"], "impact_hash": imp["impact_hash"], "risk_band": imp["risk_band"], "blast_radius": imp["blast_radius"], "authority": "display_only"}
        card["card_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in card.items() if k not in ("card_hash", "rendered_at")}))
    html = _rr.render_html(card)
    gate = {"state": "PENDING_HUMAN", "required_effect": "approval.issue_by_human", "binds_to": list(card["approval_controls"]["binds_to"]), "card_hash": card["card_hash"],
            "note": "a decision must be issued by a human through approval_adapter.issue_receipt and verified by approval_adapter.verify_receipt; this component renders and cannot decide"}
    return {"review_card": card, "html": html, "approval_gate": gate}
# @@ COMP-11
@register_impl("COMP-11")
def _impl_rollback_manager(inputs: Mapping[str, Any], ctx: Mapping[str, Any]) -> dict[str, Any]:
    """COMP-11 Rollback/checkpoint manager (Filing Cabinet 12 rollback records, 43.5/43.13, 65.26): a checkpoint is the
    pinned identity of the source tree; a rollback executes the declared method (discard the isolated worktree) and
    proves the checkpoint intact (archive_adapter.prove_rollback)."""
    b: lga.RepositoryBinding = inputs["binding"]
    root = lga.canonical_root(Path(b.root_path))
    if inputs["action"] == "checkpoint":
        cp = {"record_schema": f"{NS}/CheckpointRecord", **_prov(b), "head": lga.git(root, "rev-parse", "HEAD"), "git_tree": "git-tree:" + lga.git(root, "rev-parse", f"{b.base_revision}^{{tree}}"),
              "dirty_file_count": b.dirty_file_count, "restore_method": "discard_isolated_worktree_and_verify_tree_identity", "source_tree_identity": lga.tree_identity(root, b.base_revision)}
        if cp["source_tree_identity"] != b.source_snapshot_hash:
            raise ComponentRefusal("component.binding_mismatch", "COMP-11: the tree at the pinned revision is not the pinned snapshot")
        cp["checkpoint_id"] = lga.sha256_digest(lga.canonical_json({"rev": b.base_revision, "tree": cp["git_tree"], "repo": b.repository_id}))
        _sealed(cp, "checkpoint_hash")
        return {"checkpoint": cp}
    run_dir = Path(inputs["run_dir"]).resolve()
    if lga.path_within(run_dir, root):
        raise ComponentRefusal("component.input_invalid", "COMP-11: run directory must lie outside the bound repository")
    record = _ar.prove_rollback(run_dir, b)
    after = lga.tree_identity(root, b.base_revision)
    proof = {"record_schema": f"{NS}/RollbackProof", **_prov(b), "rollback_record": record, "rollback_id": record["rollback_id"], "verdict": record["verdict"], "checkpoint_verified": after == b.source_snapshot_hash,
             "restore_method": "discard_isolated_worktree_and_verify_tree_identity"}
    if not proof["checkpoint_verified"] or record["verdict"] != "PASS":
        raise ComponentRefusal("rollback.checkpoint_mismatch", "COMP-11: the source tree does not match the checkpoint after rollback")
    _sealed(proof, "rollback_hash")
    return {"rollback_proof": proof}


# --------------------------------------------------------------------------- #
# T04 — limits at the component boundary: scope, resource, timeout, failure; widening and gate bypass are refused    #
# --------------------------------------------------------------------------- #
OVERRIDE_KEYS = {
    "component.human_gate_bypass": ("bypass_human_gate", "auto_approve", "approval_override", "decision", "approver", "approver_identity", "skip_review", "skip_verification", "force", "assume_approved"),
    "component.scope_widening": ("widen_scope", "extra_allowed_paths", "override_limits", "unbounded", "ignore_forbidden_paths", "raise_limits", "no_limits", "allow_all_paths"),
}
LIMIT_ERRORS = ("component.scope_widening", "component.human_gate_bypass", "component.bounds_exceeded", "component.timeout")


def _reject_overrides(c: Mapping[str, Any], inputs: Mapping[str, Any]) -> None:
    """Any input that would widen scope or step around a human gate is refused by name before anything is read."""
    for code, keys in OVERRIDE_KEYS.items():
        hit = sorted(k for k in inputs if k in keys)
        if hit:
            raise ComponentRefusal(code, f"{c['component_id']}: refused inputs {hit} — the boundary cannot widen scope or bypass a human gate")


def _paths_within(paths: Sequence[str], contract: Mapping[str, Any]) -> list[str]:
    allowed = tuple(PurePosixPath(p) for p in contract.get("allowed_paths", ()))
    forbidden = tuple(PurePosixPath(p) for p in contract.get("forbidden_paths", ()))
    return [p for p in paths if not lga.within(PurePosixPath(p), allowed) or lga.within(PurePosixPath(p), forbidden)]


def _enforce_scope(c: Mapping[str, Any], inputs: Mapping[str, Any]) -> None:
    """Scope limit: artifacts crossing the boundary may not reach beyond the scope contract they cite; resource inputs
    may not exceed the declared bounds. COMP-09 ('governed') decides confinement itself and is not pre-empted."""
    lim = c["interface"].get("limits") or {}
    bounds = c["interface"]["bounds"]
    scope = lim.get("scope")
    contract = inputs.get("scope_contract")
    if scope == "candidate_within_contract" and contract is not None and inputs.get("candidate") is not None:
        cand = inputs["candidate"]
        if cand.get("scope_contract_hash") != contract.get("scope_contract_hash"):
            raise ComponentRefusal("component.scope_widening", f"{c['component_id']}: candidate cites another scope contract")
        bad = _paths_within(list(cand.get("canonical_paths", ())), contract)
        if bad:
            raise ComponentRefusal("component.scope_widening", f"{c['component_id']}: candidate reaches outside the scope contract: {bad}")
    if scope == "plan_within_contract" and contract is not None and inputs.get("refactoring_plan") is not None:
        plan = inputs["refactoring_plan"]
        if plan.get("scope_contract_hash") != contract.get("scope_contract_hash"):
            raise ComponentRefusal("component.scope_widening", f"{c['component_id']}: plan cites another scope contract")
        bad = _paths_within([op.get("path", "") for op in plan.get("operations", [])], contract)
        if bad:
            raise ComponentRefusal("component.scope_widening", f"{c['component_id']}: plan operations reach outside the scope contract: {bad}")
        if len(plan.get("operations", [])) > int(contract.get("max_changed_files", 0)):
            raise ComponentRefusal("component.scope_widening", f"{c['component_id']}: plan proposes more files than the contract allows")
    for key, bound in (("max_files", "max_files"), ("timeout_s", "timeout_s"), ("max_depth", "max_transitive_depth")):
        if inputs.get(key) is not None and bound in bounds and int(inputs[key]) > int(bounds[bound]):
            raise ComponentRefusal("component.bounds_exceeded", f"{c['component_id']}: {key}={inputs[key]} exceeds the declared bound {bounds[bound]}")


def _enforce_bounds(c: Mapping[str, Any], result: ComponentResult) -> ComponentResult:
    """Resource + timeout limits over the sealed result: an oversized or overdue result is discarded, never trimmed."""
    b = c["interface"]["bounds"]; o = result.bounds_observed
    if float(o["elapsed_s"]) > float(b["timeout_s"]):
        raise ComponentRefusal("component.timeout", f"{c['component_id']}: {o['elapsed_s']}s exceeds timeout {b['timeout_s']}s; result discarded")
    if int(o["output_items"]) > int(b["max_output_items"]) or int(o["output_bytes"]) > int(b["max_output_bytes"]):
        raise ComponentRefusal("component.bounds_exceeded", f"{c['component_id']}: output {o['output_items']} items / {o['output_bytes']} bytes exceeds {b['max_output_items']} / {b['max_output_bytes']}; result discarded, not truncated")
    if int(o.get("failures", 0)) > int(b["max_failures"]):
        raise ComponentRefusal("component.failed", f"{c['component_id']}: failure budget exhausted")
    return result


__all__ += ["LIMIT_ERRORS", "OVERRIDE_KEYS"]
