"""Scoped PR Builder — Suite 40 (Repository Context Engine) composition adapter.

Binds ONE repository/worktree/revision through the local-Git adapter and produces
deterministic records shaped exactly like the authoritative Suite 40 schemas:

  40.1 RepositoryContextRecord     -> ``context``
  40.2 RepositorySymbolRecord      -> ``symbols``      (one per declared symbol)
  40.3 RepositoryDependencyRecord  -> ``dependencies`` (one per edge)
  40.4 RepositoryFreshnessRecord   -> ``freshness``
  40.5 RepositoryWorktreeRecord    -> ``worktree``

Suite 40 stays authoritative for the record contracts; this adapter only *executes*
the extraction locally, from the pinned revision (``git show``), never from a
possibly-dirty working copy, so every record is reproducible from
``base_revision``. No model is involved: symbols and dependencies come from
deterministic lexical rules (JA21 family) and ``ast`` (Python).

The 8S coupling columns declared by the ``.jad`` schemas are bound by the ``.dmk``
kernel at dataset load and are therefore NOT fabricated here; every record names
its schema so the loader can attach them.

Pattern provenance: the index shape (per-file symbol map, definition vs usage kinds,
file-keyed invalidation) follows vscode-anycode ``symbolIndex.ts`` (MIT) as a
PATTERN_ONLY reference; no code was copied (TypeScript/tree-sitter, different
language). See ``../PROVENANCE.jsonl``.
"""
from __future__ import annotations

import ast
import re
from collections import Counter
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

from . import local_git_adapter as lga

ADAPTER_ID = "scoped_pr_builder.repository_context_adapter"
ADAPTER_VERSION = "0.1.0"
SCHEMA_NS = "suite40.repository_context_engine"

JA_FAMILY = {".ja", ".jad", ".jasec", ".jaa", ".jaops", ".jasp", ".jaui", ".jate", ".dmk", ".deepml"}
PROFILE_BY_EXT = {
    ".ja": "ja.core", ".jad": "ja.data", ".jasec": "ja.security", ".jaa": "ja.agent", ".jaops": "ja.operations",
    ".jasp": "ja.service", ".jaui": "ja.interface", ".jate": "ja.training", ".dmk": "deepml.kernel",
    ".deepml": "deepml", ".py": "python", ".ebnf": "ebnf", ".md": "markdown", ".json": "json",
}

# Deterministic JA21-family declaration rules: (symbol_kind, regex with <name> group)
JA_DECLS = [
    ("module", re.compile(r"^\s*module\s+(?P<name>[A-Za-z0-9_.]+)\s*$", re.M)),
    ("role_module", re.compile(r"^\s*module\s+(?P<name>[A-Za-z0-9_]+)\s*\{", re.M)),
    ("schema", re.compile(r"^\s*schema\s+(?P<name>[A-Za-z0-9_]+)\s*\{", re.M)),
    ("record", re.compile(r"^\s*record\s+(?P<name>[A-Za-z0-9_]+)\s*\{", re.M)),
    ("function", re.compile(r"^\s*function\s+(?P<name>[A-Za-z0-9_]+)\s*\(", re.M)),
    ("fn", re.compile(r"^\s*fn\s+(?P<name>[A-Za-z0-9_]+)\s*\(", re.M)),
    ("kernel", re.compile(r"^\s*kernel\s+(?P<name>[A-Za-z0-9_]+)\s*\(", re.M)),
    ("service", re.compile(r"^\s*service\s+(?P<name>[A-Za-z0-9_]+)\s*\{", re.M)),
    ("message", re.compile(r"^\s*message\s+(?P<name>[A-Za-z0-9_]+)\s*\{", re.M)),
    ("endpoint", re.compile(r"^\s*endpoint\s+(?P<name>[A-Za-z0-9_]+)\s*\(", re.M)),
    ("protocol", re.compile(r"^\s*protocol\s+(?P<name>[A-Za-z0-9_]+)\s*\{", re.M)),
    ("agent", re.compile(r"^\s*agent\s+(?P<name>[A-Za-z0-9_]+)\s*\{", re.M)),
    ("tool", re.compile(r"^\s*tool\s+(?P<name>[A-Za-z0-9_]+)\s*\(", re.M)),
    ("plan", re.compile(r"^\s*plan\s+(?P<name>[A-Za-z0-9_]+)\s*\{", re.M)),
    ("policy", re.compile(r"^\s*policy\s+(?P<name>[A-Za-z0-9_]+)\s*\{", re.M)),
    ("role", re.compile(r"^\s*role\s+(?P<name>[A-Za-z0-9_]+)\s*\{", re.M)),
    ("principal", re.compile(r"^\s*principal\s+(?P<name>[A-Za-z0-9_]+)\s*$", re.M)),
    ("resource", re.compile(r"^\s*resource\s+(?P<name>[A-Za-z0-9_]+)\s+classification", re.M)),
    ("dataset", re.compile(r"^\s*dataset\s+(?P<name>[A-Za-z0-9_]+)\s*$", re.M)),
    ("query", re.compile(r"^\s*query\s+(?P<name>[A-Za-z0-9_]+)\s*\{", re.M)),
    ("graph", re.compile(r"^\s*graph\s+(?P<name>[A-Za-z0-9_]+)\b", re.M)),
    ("coupling", re.compile(r"^\s*coupling\s+(?P<name>[A-Za-z0-9_]+)\s*\{", re.M)),
    ("subsuite", re.compile(r"^\s*subsuite\s+(?P<name>[A-Za-z0-9_.]+)\s+[A-Za-z0-9_]+\s*\{", re.M)),
    ("job", re.compile(r"^\s*job\s+(?P<name>[A-Za-z0-9_]+)\s*\{", re.M)),
    ("view", re.compile(r"^\s*view\s+(?P<name>[A-Za-z0-9_]+)\s*\{", re.M)),
]
JA_USE_RE = re.compile(r"^\s*use\s+(?P<name>[A-Za-z0-9_]+)\s*$", re.M)
JA_DMK_RE = re.compile(r'from\s+dmk\("(?P<name>[^"]+)"\)')
JA_SUITE_RE = re.compile(r"\bSuite_(?P<num>\d{2})_(?P<label>[A-Za-z0-9_]+)")
SUITE_PREFIX_RE = re.compile(r"^(\d{2})(?:[._]\d+)?[._]")


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _receipt(payload: dict[str, Any]) -> str:
    return lga.sha256_digest(lga.canonical_json(payload))


def _actor_fields(judgment: str, validation: str, status: str, explanation: str | None = None) -> dict[str, Any]:
    return {
        "sophia_judgment": judgment,
        "charlotte_validation": validation,
        "landon_status": status,
        "professor_explanation": explanation,
    }


@dataclass(frozen=True)
class ContextBundle:
    """All Suite 40 records for one bound repository, plus the binding that produced them."""

    adapter_id: str
    adapter_version: str
    binding: dict[str, Any]
    context: dict[str, Any]
    worktree: dict[str, Any]
    freshness: dict[str, Any]
    symbols: list[dict[str, Any]] = field(default_factory=list)
    dependencies: list[dict[str, Any]] = field(default_factory=list)

    def to_json(self) -> str:
        return lga.canonical_json(asdict(self))

    def bundle_hash(self) -> str:
        return _receipt(asdict(self))


# --------------------------------------------------------------------------- #
# Extraction                                                                    #
# --------------------------------------------------------------------------- #
def _line_of(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def extract_ja_symbols(rel: str, text: str) -> list[tuple[str, str, int, int]]:
    """Return (kind, qualified_name, start_line, end_line_estimate) for JA21-family text."""
    module = None
    m = JA_DECLS[0][1].search(text)
    if m:
        module = m.group("name")
    out = []
    for kind, rx in JA_DECLS:
        for hit in rx.finditer(text):
            name = hit.group("name")
            qualified = name if kind in ("module", "subsuite") else (f"{module}.{name}" if module else f"{rel}::{name}")
            line = _line_of(text, hit.start())
            out.append((kind, qualified, line, line))
    return sorted(set(out), key=lambda t: (t[2], t[0], t[1]))


def extract_py_symbols(rel: str, text: str) -> list[tuple[str, str, int, int]]:
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return [("parse_error", f"{rel}::<syntax-error>", 0, 0)]
    out = []
    mod = rel[:-3].replace("/", ".")
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            out.append(("function", f"{mod}.{node.name}", node.lineno, getattr(node, "end_lineno", node.lineno)))
        elif isinstance(node, ast.ClassDef):
            out.append(("class", f"{mod}.{node.name}", node.lineno, getattr(node, "end_lineno", node.lineno)))
    return sorted(set(out), key=lambda t: (t[2], t[0], t[1]))


def extract_ja_dependencies(rel: str, text: str) -> list[tuple[str, str, str]]:
    """Return (kind, target, constraint) edges for JA21-family text."""
    edges = []
    for m in JA_USE_RE.finditer(text):
        edges.append(("use_library", m.group("name"), "library"))
    for m in JA_DMK_RE.finditer(text):
        parent = PurePosixPath(rel).parent
        edges.append(("data_source", (parent / m.group("name")).as_posix(), "dmk"))
    for m in JA_SUITE_RE.finditer(text):
        edges.append(("suite_reference", f"Suite_{m.group('num')}_{m.group('label')}", f"suite:{m.group('num')}"))
    return sorted(set(edges))


def extract_py_dependencies(rel: str, text: str) -> list[tuple[str, str, str]]:
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    edges = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                edges.add(("python_import", alias.name, "import"))
        elif isinstance(node, ast.ImportFrom):
            edges.add(("python_import", ("." * node.level) + (node.module or ""), "import_from"))
    return sorted(edges)


# --------------------------------------------------------------------------- #
# Binding + record production                                                   #
# --------------------------------------------------------------------------- #
def _suite_numbers(paths: list[str]) -> set[str]:
    nums = set()
    for p in paths:
        parts = PurePosixPath(p).parts
        if len(parts) >= 2:
            m = SUITE_PREFIX_RE.match(parts[-1])
            if m:
                nums.add(m.group(1))
    return nums


def build_context(repo: Path, revision: str = "HEAD", *, max_files: int = 20000) -> ContextBundle:
    """Bind ``repo`` at ``revision`` and produce the full Suite 40 record set (fail closed)."""
    binding = lga.bind_repository(repo, revision)
    root = Path(binding.root_path)
    listed = lga.git_bytes(root, "ls-tree", "-r", "--name-only", "-z", binding.base_revision).decode("utf-8").split("\0")
    files = sorted(p for p in listed if p)
    if len(files) > max_files:
        raise lga.AdapterError("context.too_large", f"{len(files)} files exceeds max_files={max_files}")
    indexed_at = _now()
    suite_nums = _suite_numbers(files)
    ext_counter: Counter[str] = Counter(PurePosixPath(f).suffix for f in files)

    symbols: list[dict[str, Any]] = []
    deps: list[dict[str, Any]] = []
    file_set = set(files)
    for rel in files:
        ext = PurePosixPath(rel).suffix
        if ext not in JA_FAMILY and ext != ".py":
            continue
        blob = lga.read_blob(root, binding.base_revision, PurePosixPath(rel))
        text = blob.decode("utf-8", errors="replace")
        source_hash = lga.sha256_digest(blob)
        profile = PROFILE_BY_EXT.get(ext, ext.lstrip("."))
        syms = extract_py_symbols(rel, text) if ext == ".py" else extract_ja_symbols(rel, text)
        for kind, qname, l0, l1 in syms:
            core = {
                "record_schema": f"{SCHEMA_NS}.symbols/RepositorySymbolRecord",
                "repository_id": binding.repository_id,
                "worktree_id": binding.worktree_id,
                "file_path": rel,
                "language_profile": profile,
                "symbol_kind": kind,
                "qualified_name": qname,
                "signature_hash": lga.sha256_digest(f"{kind}:{qname}"),
                "definition_span": f"L{l0}-L{l1}",
                "visibility": "public" if not qname.split(".")[-1].startswith("_") else "private",
                "source_hash": source_hash,
            }
            core["symbol_id"] = lga.sha256_digest(lga.canonical_json({"f": rel, "k": kind, "n": qname, "s": source_hash}))
            core.update(_actor_fields("declared_symbol_in_pinned_source", "validated:lexical_rule_or_ast", "indexed"))
            core["podium_receipt"] = _receipt(core)
            core["indexed_at"] = indexed_at
            symbols.append(core)
        edges = extract_py_dependencies(rel, text) if ext == ".py" else extract_ja_dependencies(rel, text)
        for kind, target, constraint in edges:
            if kind == "data_source":
                status = "resolved" if target in file_set else "unresolved"
            elif kind == "suite_reference":
                status = "resolved" if constraint.split(":")[1] in suite_nums else "unresolved"
            else:
                status = "external"
            core = {
                "record_schema": f"{SCHEMA_NS}.dependencies/RepositoryDependencyRecord",
                "repository_id": binding.repository_id,
                "worktree_id": binding.worktree_id,
                "source_node": rel,
                "target_node": target,
                "dependency_kind": kind,
                "constraint_digest": lga.sha256_digest(constraint),
                "resolution_status": status,
                "cycle_status": "pending",
                "source_hash": source_hash,
            }
            core["dependency_id"] = lga.sha256_digest(lga.canonical_json({"s": rel, "t": target, "k": kind}))
            deps.append(core)

    # cycle detection over intra-repository edges (data_source only: the only file->file edge kind here)
    graph: dict[str, set[str]] = {}
    for d in deps:
        if d["dependency_kind"] == "data_source" and d["resolution_status"] == "resolved":
            graph.setdefault(d["source_node"], set()).add(d["target_node"])
    on_cycle = _nodes_on_cycles(graph)
    for d in deps:
        if d["dependency_kind"] == "data_source":
            d["cycle_status"] = "cycle" if d["source_node"] in on_cycle and d["target_node"] in on_cycle else "acyclic"
        else:
            d["cycle_status"] = "not_applicable"
        d["dependency_hash"] = _receipt({k: d[k] for k in ("source_node", "target_node", "dependency_kind", "constraint_digest", "resolution_status", "cycle_status")})
        d.update(_actor_fields("declared_dependency_in_pinned_source", "validated:target_resolution_and_cycle_check", "indexed"))
        d["podium_receipt"] = _receipt(d)
        d["indexed_at"] = indexed_at
    deps.sort(key=lambda d: (d["source_node"], d["dependency_kind"], d["target_node"]))
    symbols.sort(key=lambda s: (s["file_path"], s["definition_span"], s["symbol_kind"], s["qualified_name"]))

    dominant = max(((PROFILE_BY_EXT.get(e, e.lstrip(".")), c) for e, c in ext_counter.items()), key=lambda t: (t[1], t[0]))[0]
    context = {
        "record_schema": f"{SCHEMA_NS}.context/RepositoryContextRecord",
        "repository_id": binding.repository_id,
        "worktree_id": binding.worktree_id,
        "root_path": binding.root_path,
        "context_kind": "repository_snapshot",
        "language_profile": dominant,
        "file_count": len(files),
        "source_snapshot_hash": binding.source_snapshot_hash,
    }
    context["context_hash"] = _receipt({**context, "symbols": [s["symbol_id"] for s in symbols], "deps": [d["dependency_id"] for d in deps]})
    context["context_id"] = lga.sha256_digest(lga.canonical_json({"r": binding.repository_id, "rev": binding.base_revision}))
    context.update(_actor_fields("interpreted_selected_repository_scope", "validated:root_revision_snapshot", "indexed"))
    context["podium_receipt"] = _receipt(context)
    context["indexed_at"] = indexed_at

    worktree = {
        "record_schema": f"{SCHEMA_NS}.worktrees/RepositoryWorktreeRecord",
        "repository_id": binding.repository_id,
        "worktree_id": binding.worktree_id,
        "root_path": binding.root_path,
        "branch_or_snapshot": binding.branch_or_snapshot,
        "base_revision": binding.base_revision,
        "current_revision": binding.current_revision,
        "dirty_file_count": binding.dirty_file_count,
        "conflict_count": _conflict_count(root),
        "isolation_status": binding.isolation_status,
        "worktree_hash": binding.worktree_hash,
    }
    worktree.update(_actor_fields("interpreted_worktree_identity", "validated:canonical_root_and_revision", "bound"))
    worktree["podium_receipt"] = _receipt(worktree)
    worktree["indexed_at"] = indexed_at

    stale_reason = None
    if binding.current_revision != binding.base_revision:
        stale_reason = "observed_head_differs_from_indexed_revision"
    elif binding.dirty_file_count:
        stale_reason = "uncommitted_changes_present"
    freshness = {
        "record_schema": f"{SCHEMA_NS}.freshness/RepositoryFreshnessRecord",
        "repository_id": binding.repository_id,
        "worktree_id": binding.worktree_id,
        "observed_revision": binding.current_revision,
        "indexed_revision": binding.base_revision,
        "source_snapshot_hash": binding.source_snapshot_hash,
        "indexed_snapshot_hash": binding.source_snapshot_hash,
        "dirty_file_count": binding.dirty_file_count,
        "stale_reason": stale_reason,
        "freshness_status": "fresh" if stale_reason is None else "stale",
    }
    freshness["check_hash"] = _receipt(freshness)
    freshness["freshness_id"] = lga.sha256_digest(lga.canonical_json({"r": binding.repository_id, "rev": binding.base_revision, "at": indexed_at}))
    freshness.update(_actor_fields("interpreted_freshness_requirement", "validated:head_vs_indexed_and_dirty_count", "checked"))
    freshness["podium_receipt"] = _receipt(freshness)
    freshness["checked_at"] = indexed_at

    return ContextBundle(
        adapter_id=ADAPTER_ID,
        adapter_version=ADAPTER_VERSION,
        binding=asdict(binding),
        context=context,
        worktree=worktree,
        freshness=freshness,
        symbols=symbols,
        dependencies=deps,
    )


def _conflict_count(root: Path) -> int:
    status = lga.git(root, "status", "--porcelain")
    return sum(1 for line in status.splitlines() if line[:2] in {"UU", "AA", "DD", "AU", "UA", "DU", "UD"})


def _nodes_on_cycles(graph: dict[str, set[str]]) -> set[str]:
    """Nodes that belong to any cycle (iterative Tarjan SCC; SCC size>1 or self-loop)."""
    index = 0
    stack: list[str] = []
    on_stack: set[str] = set()
    idx: dict[str, int] = {}
    low: dict[str, int] = {}
    result: set[str] = set()
    nodes = set(graph) | {t for ts in graph.values() for t in ts}
    for start in sorted(nodes):
        if start in idx:
            continue
        work = [(start, iter(sorted(graph.get(start, ()))))]
        idx[start] = low[start] = index
        index += 1
        stack.append(start)
        on_stack.add(start)
        while work:
            node, it = work[-1]
            advanced = False
            for nxt in it:
                if nxt not in idx:
                    idx[nxt] = low[nxt] = index
                    index += 1
                    stack.append(nxt)
                    on_stack.add(nxt)
                    work.append((nxt, iter(sorted(graph.get(nxt, ())))))
                    advanced = True
                    break
                elif nxt in on_stack:
                    low[node] = min(low[node], idx[nxt])
            if advanced:
                continue
            work.pop()
            if work:
                parent = work[-1][0]
                low[parent] = min(low[parent], low[node])
            if low[node] == idx[node]:
                comp = []
                while True:
                    w = stack.pop()
                    on_stack.discard(w)
                    comp.append(w)
                    if w == node:
                        break
                if len(comp) > 1 or node in graph.get(node, ()):
                    result.update(comp)
    return result


__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "ContextBundle", "build_context", "extract_ja_symbols", "extract_ja_dependencies", "extract_py_symbols", "extract_py_dependencies"]
