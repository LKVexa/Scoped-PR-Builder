"""Production readiness: eight release-gate assertions over the tool's own chained evidence, and one GO decision.

This is the aggregator the whole programme has been building evidence for. It adds no new checking of its own — the
security release gate, the offline qualification gate, the invariant checklist and the environment promotion gate all
already exist. What it adds is the thing none of them can do alone: state, for each paper-level production
requirement, exactly which receipts satisfy it, collect those receipts BY IMMUTABLE ID AND HASH, and refuse the GO
decision when any of them is absent, stale, conflicting, waived without authority, or indeterminate.

The reason receipts are selected by id and binding hash rather than by status text is that status text is the part an
optimistic component would edit. A receipt says `qualification:TEST-ADV-01@<matrix-hash prefix>`; if the matrix
changes, that id no longer matches and the evidence reads as stale — automatically, without anyone remembering to
invalidate it.

Build provenance (PROD-01..08 — BUILD_NEW). Yard retrieval ran before this module was drafted: ledger recall on
release gate readiness, then yard_query for release gate, readiness aggregator, go no-go, residual risk, evidence
aggregation, acceptance criteria, waiver approval, incident runbook and remediation list. Inspected and rejected:
`Frigatebird` (AGPL-3.0/GPL-3.0 — refused at the license gate before inspection could matter, and it is UAV soaring
firmware), `ai-agent-eval-scenario-library` (MIT — markdown evaluation scenarios and quality signals for agents, with
no gate, no receipt collection and nothing executable), `tim-data-investigate-platform` (a data investigation
platform). Six of the nine queries matched nothing at all. Nothing was selected; this composes the overlay's own
gates, evidence ledger and chain primitive, stdlib only.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from . import contracts as C
from . import local_git_adapter as lga
from . import security as _SEC
from .archive_adapter import _chain_append, verify_chain_file

READINESS_VERSION = "scoped_pr_builder.production_readiness/0.1.0"
READINESS_PATH = Path(__file__).resolve().parent.parent / "release" / "READINESS.json"
OVERLAY_ROOT = Path(__file__).resolve().parent.parent
REPO_ROOT = OVERLAY_ROOT.parent
ADAPTER_ID = "scoped_pr_builder.release_gate"
ADAPTER_VERSION = "0.1.0"
NS = "overlay.scoped_pr_builder.release"

ASSERTION_IDS = ("PROD-01", "PROD-02", "PROD-03", "PROD-04", "PROD-05", "PROD-06", "PROD-07", "PROD-08")
ASSERTION_REQUIRED = ("assertion_id", "statement", "evidence", "authoritative_suites", "introduced_by")
#: Every status an assertion's evidence can be in. Only `satisfied` permits GO; the other five are the failure modes
#: the task names, and each carries its own remediation. There is deliberately no "warning" or "acceptable" status —
#: a gate with a shrug in its vocabulary is not a gate.
STATUSES = ("satisfied", "absent", "stale", "conflicting", "waived_without_authority", "indeterminate")
BLOCKING_STATUSES = tuple(s for s in STATUSES if s != "satisfied")
DECISIONS = ("GO", "NO_GO")

#: What receipts bind to. A receipt is current only while the thing it was issued over is unchanged — which is what
#: makes staleness a property of the data rather than of anyone's memory.
#:
#: The three shapes here are not an inconsistency to be tidied away; each is the right binding for its evidence:
#:   * most registries bind to their whole `computed_hash`;
#:   * `threats` binds to the threat registry's `core_hash` — deliberately narrower, so adding a policy line does not
#:     invalidate adversarial evidence about the threats themselves;
#:   * `environments` binds per environment, to that profile's own hash, so changing staging does not invalidate the
#:     sandbox's smoke receipt.
#: A selector therefore names a binding, and the binding decides which fragments are acceptable.
BINDINGS = ("contracts", "threats", "matrix", "invariants", "environments", "guardrails", "components",
            "workflow", "intake", "checks", "boundaries", "stores", "review", "model", "wiring", "readiness",
            # Phase 16: documentation freshness receipts bind to the documentation registry, so a document that
            # stops describing the implementation stops the release rather than merely being out of date.
            "docs")

#: Waiver-shaped input is refused by name, wherever it appears — as a key, as a value, or as an approval channel.
#: The component under evaluation does not get to excuse itself, and neither does a caller passing `force=True`.
WAIVER_RE = re.compile(r"(?:^|[._-])(?:skip|waive|waiver|bypass|disable|ignore|force|override|suppress)(?:[._-]|$)"
                       r"|(?:gate|check|guardrail)s?\s*=\s*(?:off|false|0|none)", re.I)


class ReleaseRefusal(lga.AdapterError):
    """Raised when the release gate cannot honestly issue a GO."""


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def load_readiness(path: Path = READINESS_PATH, *, registry: Mapping[str, Any] | None = None,
                   repo_root: Path = REPO_ROOT) -> dict[str, Any]:
    """Load and validate the release-gate assertions.

    Each assertion must name a known PROD id, state what it asserts, list at least one evidence selector, and bind to
    suite files that exist. An assertion with no evidence selectors is refused outright: an assertion nothing can
    satisfy would sit permanently green or permanently red, and either way it would not be a gate.
    """
    if not Path(path).is_file():
        raise ReleaseRefusal("release.registry_missing", f"no readiness registry at {path}")
    m = json.loads(Path(path).read_text(encoding="utf-8"))
    if m.get("readiness_version") != READINESS_VERSION:
        raise ReleaseRefusal("release.registry_invalid", "readiness_version mismatch")
    for aid, a in (m.get("assertions") or {}).items():
        missing = [k for k in ASSERTION_REQUIRED if k not in a]
        if missing or a["assertion_id"] != aid or aid not in ASSERTION_IDS:
            raise ReleaseRefusal("release.registry_invalid", f"{aid}: missing {missing} / unknown assertion id")
        if not str(a["statement"]).strip():
            raise ReleaseRefusal("release.registry_invalid", f"{aid}: an assertion needs a statement")
        if not isinstance(a["evidence"], list) or not a["evidence"]:
            raise ReleaseRefusal("release.evidence_undeclared",
                                 f"{aid}: at least one evidence selector is mandatory; an assertion nothing can "
                                 f"satisfy is not a gate")
        for sel in a["evidence"]:
            _validate_selector(aid, sel)
        for f in a["authoritative_suites"]:
            if not (Path(repo_root) / f).is_file():
                raise ReleaseRefusal("release.suite_unbound", f"{aid}: authoritative suite file does not exist: {f}")
    body = {k: v for k, v in m.items() if k != "readiness_hash"}
    m["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return m


#: An evidence selector names WHICH receipts satisfy an assertion, by immutable identity:
#:   kind          — the evidence kind (the ledger's own `kind` field)
#:   id_prefix     — the stable prefix of the receipt's scenario_id, before the "@<hash>" binding
#:   binds_to      — which registry hash the receipt's id must carry, or null when the kind is not hash-bound
#:   min_receipts  — how many current PASS receipts are required (a count, so "one green row" cannot stand for a suite)
#:   requires_all  — when set, every id in the list must be present and current
SELECTOR_REQUIRED = ("kind", "id_prefix", "binds_to", "min_receipts")


def _validate_selector(aid: str, sel: Any) -> None:
    if not isinstance(sel, Mapping) or any(k not in sel for k in SELECTOR_REQUIRED):
        raise ReleaseRefusal("release.selector_invalid", f"{aid}: an evidence selector needs {SELECTOR_REQUIRED}")
    if sel["binds_to"] is not None and sel["binds_to"] not in BINDINGS:
        raise ReleaseRefusal("release.selector_invalid", f"{aid}: unknown binding registry {sel['binds_to']!r}")
    if not isinstance(sel["min_receipts"], int) or sel["min_receipts"] < 1:
        raise ReleaseRefusal("release.selector_invalid", f"{aid}: min_receipts must be a positive integer")
    if not str(sel["kind"]).strip() or not str(sel["id_prefix"]).strip():
        raise ReleaseRefusal("release.selector_invalid", f"{aid}: kind and id_prefix are mandatory")


def assertion(assertion_id: str, readiness: Mapping[str, Any] | None = None) -> dict[str, Any]:
    m = readiness or load_readiness()
    a = (m.get("assertions") or {}).get(assertion_id)
    if a is None:
        raise ReleaseRefusal("release.assertion_unknown", f"no such assertion {assertion_id!r}")
    return dict(a)


def binding_fragments(*, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """For every binding, the set of hash fragments a current receipt may carry, read from the tool itself.

    A binding that fails to resolve is reported with `fragments: None` rather than omitted: an assertion resting on it
    then reads as indeterminate, which blocks — the safe direction — instead of silently matching nothing.
    """
    from . import architecture as A
    from . import components as K
    from . import environment as E
    from . import guardrails as G
    from . import intake as IN
    from . import invariants as I
    from . import model_orchestration as MO
    from . import qualification as Q
    from . import review_surface as RS
    from . import store as ST
    from . import verification_checks as VC
    from . import wiring as WI
    from . import workflow as W
    def frag(h: Any) -> str | None:
        return h[7:39] if isinstance(h, str) and h.startswith("sha256:") else None

    def whole(fn, field: str = "computed_hash"):
        return lambda: ({frag(fn().get(field))}, f"{field} of the registry")

    def per_environment():
        m = E.load_environments()
        return ({frag(E.profile_hash(eid, m)) for eid in m["environments"]},
                "each environment's own profile hash — changing one profile does not invalidate another's receipt")

    reg = registry or C.load_registry()
    sources = {
        "contracts": whole(lambda: reg), "threats": whole(_SEC.load_threats, "core_hash"),
        "matrix": whole(Q.load_matrix), "invariants": whole(I.load_invariants),
        "environments": per_environment, "guardrails": whole(G.load_rules), "components": whole(K.load_components),
        "workflow": whole(W.load_workflow), "intake": whole(IN.load_sources), "checks": whole(VC.load_checks),
        "boundaries": whole(A.load_boundaries), "stores": whole(ST.load_stores), "review": whole(RS.load_review),
        "model": whole(MO.load_model_contract), "wiring": whole(WI.load_wiring), "readiness": whole(load_readiness),
        "docs": whole(_load_docs_registry),
    }
    out: dict[str, Any] = {}
    for name, fn in sources.items():
        try:
            fragments, how = fn()
            out[name] = {"fragments": sorted(f for f in fragments if f) or None, "binding": how}
        except Exception as exc:
            out[name] = {"fragments": None, "binding": f"could not be read: {type(exc).__name__}"}
    return out


# --------------------------------------------------------------------------- #
# T02 — collect receipts by immutable id and binding hash, never by status text
# --------------------------------------------------------------------------- #
def gate_ledger_path() -> Path:
    """The tool's own archived evidence ledger — never a sandbox copy, never a caller-supplied path by default."""
    return OVERLAY_ROOT / "evidence" / "TEST_LEDGER.jsonl"


def ledger_rows(path: Path | None = None) -> list[dict[str, Any]]:
    """Every receipt in the chained evidence ledger, with the chain verified first.

    A ledger whose chain does not verify yields no receipts at all — not "the rows we could still read". Partial
    evidence from a tampered ledger is worse than none, because it looks like evidence.
    """
    p = Path(path) if path is not None else gate_ledger_path()
    if not p.is_file():
        return []
    try:
        verify_chain_file(p)
    except lga.AdapterError as exc:
        raise ReleaseRefusal("release.ledger_broken",
                             f"{p.name}: the evidence chain does not verify ({exc}); no receipt from it can be trusted") from exc
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


def _split_id(scenario_id: str) -> tuple[str, str | None]:
    """`prefix@<hash-fragment>` → (prefix, fragment). An id with no `@` is simply unbound."""
    if "@" in scenario_id:
        head, _, tail = scenario_id.rpartition("@")
        return head, tail
    return scenario_id, None


def collect(selector: Mapping[str, Any], rows: Sequence[Mapping[str, Any]],
            bindings: Mapping[str, Any]) -> dict[str, Any]:
    """Every receipt matching one selector, classified by identity — never by reading a status string.

    A receipt is *current* when its id carries the fragment of the hash of the registry the selector binds to. A
    receipt whose prefix matches but whose fragment does not is *stale*: it was issued over a registry that has since
    changed, and nothing had to remember to invalidate it.
    """
    kind, prefix = str(selector["kind"]), str(selector["id_prefix"])
    binds_to = selector["binds_to"]
    b = bindings.get(binds_to) or {} if binds_to else {}
    acceptable = set(b.get("fragments") or ())

    matched = [r for r in rows if r.get("kind") == kind and str(r.get("scenario_id", "")).startswith(prefix)]
    current, stale = [], []
    for r in matched:
        _, frag = _split_id(str(r.get("scenario_id", "")))
        if binds_to is None:
            current.append(r)
        elif not acceptable:
            stale.append(r)          # the binding could not be read; nothing can honestly be called current
        elif frag in acceptable:
            current.append(r)
        else:
            stale.append(r)
    verdicts = sorted({str(r.get("verdict")) for r in current})
    passing = [r for r in current if str(r.get("verdict")) in ACCEPTING]
    neutral = [r for r in current if str(r.get("verdict")) in NEUTRAL]
    return {"kind": kind, "id_prefix": prefix, "binds_to": binds_to,
            "bound_to": b.get("binding"), "acceptable_fragments": sorted(acceptable)[:8],
            "matched": len(matched), "current": len(current), "stale": len(stale),
            "passing": len(passing), "neutral": len(neutral),
            "verdicts": verdicts, "min_receipts": int(selector["min_receipts"]),
            "requires_all": list(selector.get("requires_all") or []),
            "ids": sorted({str(r.get("scenario_id")) for r in current}),
            "passing_ids": sorted({str(r.get("scenario_id")) for r in passing}),
            "stale_ids": sorted({str(r.get("scenario_id")) for r in stale})[:8]}


#: The evidence ledger's verdict vocabulary, split by what each verdict means for a gate.
#: PASS is evidence for. FAIL, INDETERMINATE and BLOCKED are evidence against. NOT_APPLICABLE and SKIPPED are
#: neither: the case did not apply, which is a legitimate outcome that must not be read as a disagreement with PASS —
#: nor counted as evidence for, which is why `min_receipts` counts only PASS.
ACCEPTING = ("PASS",)
NEUTRAL = ("NOT_APPLICABLE", "SKIPPED")


def classify(found: Mapping[str, Any]) -> tuple[str, str]:
    """One selector's evidence → (status, why). The order of these tests is the order of severity.

    `conflicting` is deliberately checked before `absent`: a selector holding both a PASS and a FAIL for the same
    thing is a worse signal than one holding nothing, and reporting it as "not enough receipts" would hide that.
    """
    verdicts, current = set(found["verdicts"]), found["current"]
    against = sorted(verdicts - set(ACCEPTING) - set(NEUTRAL))
    passing = found["passing"]
    if against:
        return "conflicting", (f"current receipts include {against}"
                               + (f" alongside {passing} PASS" if passing else ""))
    if current and not passing:
        return "conflicting", f"no current receipt asserts anything: every one is {sorted(verdicts)}"
    if found["binds_to"] and not found["acceptable_fragments"]:
        return "indeterminate", f"the {found['binds_to']} binding could not be read, so no receipt can be called current"
    if passing == 0 and found["stale"]:
        return "stale", (f"{found['stale']} receipt(s) match but were issued over an earlier "
                         f"{found['binds_to']} registry: {found['stale_ids'][:3]}")
    if passing == 0:
        return "absent", f"no receipt of kind {found['kind']!r} with id prefix {found['id_prefix']!r}"
    if passing < found["min_receipts"]:
        return "indeterminate", (f"{passing} current PASS receipt(s), {found['min_receipts']} required"
                                 + (f" ({found['neutral']} not-applicable)" if found["neutral"] else ""))
    missing = [i for i in found["requires_all"]
               if not any(str(x).startswith(i) for x in found["passing_ids"])]
    if missing:
        return "absent", f"required receipt id(s) not present: {missing}"
    tail = (f"; {found['neutral']} not-applicable" if found["neutral"] else "") + \
           (f"; {found['stale']} superseded receipt(s) also present" if found["stale"] else "")
    return "satisfied", f"{passing} current PASS receipt(s){tail}"


# --------------------------------------------------------------------------- #
# T03 — absent, stale, conflicting, waived-without-authority or indeterminate evidence blocks GO, with a remediation
# list that says what to do about each
# --------------------------------------------------------------------------- #
#: What to do about each failure mode. A gate that blocks without saying what would unblock it is an obstacle, not a
#: control, and the person reading a NO_GO at 2am is the reason this table exists.
REMEDIATION = {
    "absent": "run the suite that issues this receipt, then re-run the gate",
    "stale": "the registry this evidence binds to has changed since the receipt was issued; re-run the suite so the "
             "receipts are re-issued against the current registry",
    "conflicting": "current receipts disagree; investigate the failing one — do not re-run until you know why it failed",
    "waived_without_authority": "a waiver was requested through an input rather than a human approval; remove it and "
                                "either fix the evidence or record a human decision that names what is being accepted",
    "indeterminate": "the evidence is incomplete or a registry could not be read; resolve that before judging the assertion",
}


def _waivers(inputs: Mapping[str, Any] | None) -> list[str]:
    """Waiver-shaped inputs, by name. Checked over keys AND values, at any nesting depth, because a waiver hidden one
    level down in a config blob is still a waiver."""
    found: list[str] = []

    def walk(obj: Any, path: str) -> None:
        if isinstance(obj, Mapping):
            for k, v in obj.items():
                p = f"{path}.{k}" if path else str(k)
                if WAIVER_RE.search(str(k)):
                    found.append(p)
                walk(v, p)
        elif isinstance(obj, (list, tuple)):
            for i, v in enumerate(obj):
                walk(v, f"{path}[{i}]")
        elif isinstance(obj, str) and WAIVER_RE.search(obj):
            found.append(f"{path}={obj[:40]}")
        elif obj is True and WAIVER_RE.search(path):
            found.append(path)

    walk(inputs or {}, "")
    return sorted(set(found))


def evaluate_assertion(assertion_id: str, rows: Sequence[Mapping[str, Any]], bindings: Mapping[str, Any],
                       *, readiness: Mapping[str, Any] | None = None,
                       waivers: Sequence[str] = ()) -> dict[str, Any]:
    """One assertion, judged over every selector it declares.

    The assertion's status is the worst status among its selectors: an assertion is satisfied only when ALL of its
    evidence is. There is no averaging and no "mostly".
    """
    a = assertion(assertion_id, readiness)
    selectors = []
    for sel in a["evidence"]:
        found = collect(sel, rows, bindings)
        status, why = classify(found)
        selectors.append({**found, "status": status, "why": why,
                          "remediation": REMEDIATION.get(status) if status != "satisfied" else None})
    if waivers:
        selectors.append({"kind": "waiver", "id_prefix": "-", "binds_to": None, "status": "waived_without_authority",
                          "why": f"waiver-shaped input(s) presented to the gate: {waivers[:4]}",
                          "remediation": REMEDIATION["waived_without_authority"],
                          "bound_to": None, "acceptable_fragments": [], "matched": 0, "current": 0, "stale": 0,
                          "passing": 0, "neutral": 0, "verdicts": [], "min_receipts": 0, "requires_all": [],
                          "ids": [], "passing_ids": [], "stale_ids": []})
    order = {s: i for i, s in enumerate(("conflicting", "waived_without_authority", "absent", "stale",
                                         "indeterminate", "satisfied"))}
    worst = min((s["status"] for s in selectors), key=lambda s: order[s]) if selectors else "absent"
    return {"assertion_id": assertion_id, "statement": a["statement"], "status": worst,
            "selectors": selectors, "blocking": worst in BLOCKING_STATUSES,
            "remediation": [s["remediation"] for s in selectors if s.get("remediation")],
            "authoritative_suites": list(a["authoritative_suites"])}


def gate(*, ledger: Path | None = None, readiness: Mapping[str, Any] | None = None,
         registry: Mapping[str, Any] | None = None, inputs: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """The production readiness gate: GO only when every declared assertion is satisfied on current evidence.

    `inputs` is whatever the caller wants the gate to consider. It cannot make the gate more permissive — the only
    thing the gate does with it is look for waiver-shaped names and block on them. There is no argument that turns an
    assertion off, and none that turns a NO_GO into a GO.
    """
    m = readiness or load_readiness(registry=registry)
    bindings = binding_fragments(registry=registry)
    rows = ledger_rows(ledger)
    waivers = _waivers(inputs)
    per = {aid: evaluate_assertion(aid, rows, bindings, readiness=m, waivers=waivers)
           for aid in sorted(m.get("assertions") or {})}
    blocking = sorted(aid for aid, v in per.items() if v["blocking"])
    remediation = []
    for aid in blocking:
        for s in per[aid]["selectors"]:
            if s.get("remediation"):
                remediation.append({"assertion_id": aid, "status": s["status"], "evidence": f"{s['kind']}:{s['id_prefix']}",
                                    "why": s["why"], "do": s["remediation"]})
    body = {"record_schema": f"{NS}/GateDecision", "readiness_version": READINESS_VERSION,
            "decision": "GO" if not blocking else "NO_GO", "readiness_hash": m["computed_hash"],
            "bindings": {k: v["binding"] for k, v in bindings.items()}, "receipts_considered": len(rows),
            "per_assertion": {aid: {"status": v["status"], "statement": v["statement"]} for aid, v in per.items()},
            "blocking": blocking, "waivers_refused": waivers, "remediation": remediation,
            "authority": "evidence_only — this decision states what the tool's own chained evidence shows; it "
                         "authorises nothing and replaces no human approval",
            "evaluated_at": _now(), "writer": f"{ADAPTER_ID}/{ADAPTER_VERSION}"}
    body["decision_hash"] = lga.sha256_digest(lga.canonical_json(
        {k: v for k, v in body.items() if k not in ("evaluated_at", "decision_hash")}))
    body["detail"] = per
    return body


def require_go(*, stage: str = "release", **kw: Any) -> dict[str, Any]:
    """No release over a NO_GO. The refusal names the blocking assertions and carries the remediation list."""
    d = gate(**kw)
    if d["decision"] != "GO":
        raise ReleaseRefusal("release.gate_blocked",
                             f"{stage}: production readiness NO_GO — blocking {d['blocking']}; "
                             f"{len(d['remediation'])} remediation item(s)")
    return d


def remediation_list(decision: Mapping[str, Any]) -> list[dict[str, Any]]:
    """The flat, ordered list of what must happen before this gate can pass — conflicts first, then absences."""
    order = {"conflicting": 0, "waived_without_authority": 1, "absent": 2, "stale": 3, "indeterminate": 4}
    return sorted(decision.get("remediation") or [], key=lambda r: (order.get(r["status"], 9), r["assertion_id"]))


# --------------------------------------------------------------------------- #
# T04 — record the decision, the versions that evaluated it, the approvals, the residual risks, the limitations and
# the rollback readiness, in the release evidence ledger
# --------------------------------------------------------------------------- #
RELEASE_LEDGER = "release/RELEASE_LEDGER.jsonl"
RECORD_REQUIRED = ("decision", "evaluator_versions", "approvals", "residual_risks", "limitations",
                   "rollback_readiness")


def release_ledger_path(root: Path | None = None) -> Path:
    return (Path(root) if root is not None else OVERLAY_ROOT) / RELEASE_LEDGER


def evaluator_versions(*, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Which code and which declarations produced this decision.

    Recorded so a later reader can tell whether a decision is still about the same tool. Every adapter that
    contributes a gate is named with its own version, and every binding with the fragment its receipts must carry.
    """
    from . import environment as E
    from . import invariants as I
    from . import qualification as Q
    import platform
    import sys as _sys
    b = binding_fragments(registry=registry)
    return {"release_gate": f"{ADAPTER_ID}/{ADAPTER_VERSION}",
            "qualification": f"{Q.ADAPTER_ID}/{Q.ADAPTER_VERSION}",
            "invariants": getattr(I, "INVARIANTS_VERSION", None),
            "environments": getattr(E, "ENVIRONMENTS_VERSION", None),
            "security": f"{_SEC.ADAPTER_ID}/{_SEC.ADAPTER_VERSION}",
            "python": ".".join(str(v) for v in _sys.version_info[:3]), "platform": platform.system().lower(),
            "bindings": {k: (v["fragments"] or None) for k, v in b.items()}}


def rollback_readiness(*, ledger: Path | None = None) -> dict[str, Any]:
    """Whether rollback has actually been exercised, read from the receipts rather than from a runbook.

    A documented rollback procedure that nothing has run is not readiness. What counts here is evidence that a real
    run applied a change in isolation and restored the source tree identity afterwards.
    """
    rows = ledger_rows(ledger)
    workflow = [r for r in rows if r.get("kind") == "workflow_integration" and r.get("verdict") == "PASS"]
    envs = [r for r in rows if r.get("kind") == "environment_smoke" and r.get("verdict") == "PASS"]
    boundary = [r for r in rows if r.get("kind") == "boundary_e2e" and r.get("verdict") == "PASS"]
    exercised = bool(workflow) and bool(envs)
    return {"exercised": exercised,
            "evidence": {"workflow_integration": len(workflow), "environment_smoke": len(envs),
                         "boundary_e2e": len(boundary)},
            "procedure": "archive_adapter.prove_rollback re-checks the source tree identity and the absence of any "
                         "linked worktree after an isolated apply; environment shutdown refuses to hide a leftover",
            "statement": ("rollback is exercised by every applying run, not merely documented" if exercised else
                          "no receipt shows rollback being exercised; readiness cannot be claimed")}


def residual_risks(decision: Mapping[str, Any], *, readiness: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    """What remains true even on a GO — read from the declarations, not written by hand at release time.

    A deferred invariant, an assertion resting on superseded receipts that were nonetheless sufficient, and any
    not-applicable evidence all surface here. A GO with an empty residual-risk list would be a claim that nothing is
    left to know, which is never true.
    """
    from . import invariants as I
    out: list[dict[str, Any]] = []
    try:
        m = I.load_invariants()
        for iid, e in sorted((m.get("invariants") or {}).items()):
            enf = e.get("enforcement") or {}
            if enf.get("deferred_to_host"):
                out.append({"kind": "host_requirement", "id": iid, "statement": e["statement"],
                            "detail": enf.get("deferral_reason"),
                            "accepted_as": "the host must provide this; the tool does not and does not claim to"})
    except lga.AdapterError:
        out.append({"kind": "unreadable", "id": "invariants",
                    "statement": "the invariant registry could not be read at decision time",
                    "detail": None, "accepted_as": "unknown — this alone should block"})
    for aid, v in (decision.get("detail") or {}).items():
        for s in v["selectors"]:
            if s["status"] == "satisfied" and s.get("stale"):
                out.append({"kind": "superseded_evidence", "id": f"{aid}/{s['kind']}",
                            "statement": f"{s['stale']} receipt(s) from an earlier {s['binds_to']} binding remain in the ledger",
                            "detail": s["why"], "accepted_as": "current evidence was sufficient without them"})
            if s.get("neutral"):
                out.append({"kind": "not_applicable_evidence", "id": f"{aid}/{s['kind']}",
                            "statement": f"{s['neutral']} receipt(s) record a case that did not apply",
                            "detail": s["why"], "accepted_as": "counted as neither for nor against"})
    return out


def record_decision(decision: Mapping[str, Any], *, approvals: Sequence[Mapping[str, Any]] = (),
                    limitations: Sequence[str] = (), root: Path | None = None,
                    ledger: Path | None = None, registry: Mapping[str, Any] | None = None,
                    readiness: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Chain one release decision into the release evidence ledger, with everything a later reader needs.

    Approvals are recorded, never manufactured: each must carry a human identity and a non-model channel, and this
    function refuses rather than inventing one. A GO is a release authorization and therefore requires at least one
    verified human-channel approval. Historical GO rows with empty approvals remain readable as legacy pilot evidence
    but can no longer be minted by this function.
    """
    if decision.get("decision") == "GO" and not approvals:
        raise ReleaseRefusal("release.human_approval_required", "GO requires at least one human readiness approval; current legacy GO rows are pilot-sha256sums-only")
    for a in approvals:
        _SEC.require_human_channel(str(a.get("channel", "")), identity=str(a.get("identity", "")))
        if not str(a.get("identity", "")).strip() or not str(a.get("rationale", "")).strip():
            raise ReleaseRefusal("release.approval_incomplete",
                                 "a recorded approval needs an identity and a rationale")
    body = {"record_schema": f"{NS}/ReleaseRecord", "readiness_version": READINESS_VERSION,
            "decision": decision["decision"], "release_scope": "pilot-sha256sums-only" if decision["decision"] == "GO" else "not-released", "decision_hash": decision["decision_hash"],
            "readiness_hash": decision["readiness_hash"], "blocking": list(decision["blocking"]),
            "per_assertion": dict(decision["per_assertion"]),
            "evaluator_versions": evaluator_versions(registry=registry),
            "approvals": [{"identity": a["identity"], "channel": a["channel"],
                           "rationale": str(a["rationale"])[:500], "at": a.get("at") or _now()} for a in approvals],
            "residual_risks": residual_risks(decision, readiness=readiness),
            # the record cites what is actually published. Before the limitations are published there is nothing to
            # cite, and an empty list is the honest record — the gate separately blocks on PROD-08 being absent.
            "limitations": list(limitations) or (published_limitations(root=root)
                                                 if "published_limitations" in globals() else []),
            "rollback_readiness": rollback_readiness(ledger=ledger),
            "remediation": list(decision.get("remediation") or []),
            "recorded_at": _now(), "writer": f"{ADAPTER_ID}/{ADAPTER_VERSION}"}
    missing = [k for k in RECORD_REQUIRED if body.get(k) is None]
    if missing:
        raise ReleaseRefusal("release.record_incomplete", f"the release record lacks {missing}")
    return _chain_append(release_ledger_path(root), body)


def release_records(root: Path | None = None) -> list[dict[str, Any]]:
    p = release_ledger_path(root)
    if not p.is_file():
        return []
    verify_chain_file(p)
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


# --------------------------------------------------------------------------- #
# T05 — published limitations, and the fixtures proving the gate cannot be bypassed by model output, worker status or
# UI state
# --------------------------------------------------------------------------- #
LIMITATIONS_PATH = "release/LIMITATIONS.md"
EVIDENCE_KIND = "limitations_published"
#: Every source of a limitation this tool must publish. A limitation that exists in a registry but not in the
#: document is what `verify_limitations` catches — the document cannot quietly fall behind the tool.
LIMITATION_SOURCES = ("invariants.deferred_to_host", "environments.non_goals", "release.non_goals")

#: What this tool does NOT do. Published, not implied. These are non-goals rather than gaps: each is a deliberate
#: boundary, and pretending otherwise at release time is exactly the failure this phase exists to prevent.
NON_GOALS = (
    "It does not decide whether a change is a good idea. It produces a bounded, inert candidate and a review surface; "
    "the judgement, and the accountability for it, stay with the human reviewer.",
    "It does not run in production against live traffic. Every effect happens in an isolated worktree under a run "
    "directory outside the repository, and the source tree is proven unchanged afterwards.",
    "It does not reach the network. `network: none` is declared in every environment profile and enforced by the "
    "qualification harness refusing a run that attempts a connection; it is not a kernel-level egress block.",
    "It does not provide confidentiality at rest or transport encryption (XSEC-04). It provides integrity at rest by "
    "hash-chaining every ledger; the host supplies disk encryption and TLS.",
    "It does not sandbox at the container, namespace or VM level. Isolation here is process-level and path-level.",
    "It does not compile or semantically validate JA suite files. Cross-reference checking passes 66/66; "
    "compile-level validation of the overlay's JA surfaces remains INDETERMINATE.",
    "It does not replace a security review by people. It provides the threat registry, the adversarial evidence and "
    "the refusal codes a reviewer needs, and records what was and was not examined.",
    "It does not measure monetary cost. The bound provider is a deterministic in-process advisor with no metered "
    "spend; a host binding a metered provider supplies cost per call.",
)


def gate_limitations_id(readiness: Mapping[str, Any] | None = None) -> str:
    """The receipt id the published limitations record under, bound to the readiness registry it was published
    against — so declaring a new assertion without republishing makes the receipt stale."""
    m = readiness or load_readiness()
    return f"limitations:published@{m['computed_hash'][7:39]}"


def declared_limitations(*, registry: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    """Every limitation the tool's own registries declare, gathered from the declarations rather than from memory."""
    from . import environment as E
    from . import invariants as I
    out: list[dict[str, Any]] = []
    try:
        m = I.load_invariants(registry=registry)
        for iid, e in sorted((m.get("invariants") or {}).items()):
            enf = e.get("enforcement") or {}
            if enf.get("deferred_to_host"):
                out.append({"source": "invariants.deferred_to_host", "id": iid,
                            "statement": e["statement"], "detail": enf.get("deferral_reason")})
    except lga.AdapterError:
        pass
    try:
        em = E.load_environments()
        for eid in E.ranked(em):
            e = E.environment(eid, em)
            if e["network"]["mode"] == "none":
                continue
    except lga.AdapterError:
        pass
    for i, g in enumerate(NON_GOALS):
        out.append({"source": "release.non_goals", "id": f"NON-GOAL-{i + 1:02d}", "statement": g, "detail": None})
    return out


def render_limitations(*, registry: Mapping[str, Any] | None = None,
                       readiness: Mapping[str, Any] | None = None) -> str:
    """The published limitations document, generated from the declarations so it cannot drift from them."""
    m = readiness or load_readiness(registry=registry)
    items = declared_limitations(registry=registry)
    lines = ["# Known limitations and non-goals", "",
             "Generated from the tool's own declarations — the invariant registry, the environment profiles and the",
             "declared non-goals. It is published against the readiness registry, so declaring a new release-gate",
             "assertion without republishing this document makes the published-limitations receipt stale and blocks",
             "the gate.", "",
             f"Readiness registry: `{m['computed_hash']}`", ""]
    host = [i for i in items if i["source"] == "invariants.deferred_to_host"]
    if host:
        lines += ["## Host requirements", "",
                  "Properties this tool does not implement and does not claim. A host deploying it must provide them.", ""]
        for i in host:
            lines += [f"- **{i['id']} — {i['statement']}**", f"  {i['detail']}", ""]
    lines += ["## Non-goals", "",
              "Deliberate boundaries, not gaps. Each is a thing the tool does not do, stated so that nobody has to",
              "infer it from silence.", ""]
    for i in [x for x in items if x["source"] == "release.non_goals"]:
        lines += [f"- **{i['id']}** — {i['statement']}", ""]
    return "\n".join(lines).rstrip() + "\n"


def publish_limitations(*, root: Path | None = None, registry: Mapping[str, Any] | None = None,
                        readiness: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Render the limitations document and write it, then verify it against the declarations.

    Publishing is a product step, not a test step: the document is generated from the registries so it cannot drift
    from them, and `verify_limitations` immediately re-reads it and refuses if anything declared is missing.
    """
    p = (Path(root) if root is not None else OVERLAY_ROOT) / LIMITATIONS_PATH
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(render_limitations(registry=registry, readiness=readiness), encoding="utf-8")
    return verify_limitations(root=root, registry=registry, readiness=readiness)


def verify_limitations(*, root: Path | None = None, registry: Mapping[str, Any] | None = None,
                       readiness: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Fail closed unless every declared limitation appears in the published document.

    This is the check that makes PROD-08 real. A limitation added to a registry and not published is exactly the kind
    of quiet drift a release gate should catch, and the receipt is only issued when the document is complete.
    """
    p = (Path(root) if root is not None else OVERLAY_ROOT) / LIMITATIONS_PATH
    if not p.is_file():
        raise ReleaseRefusal("release.limitations_unpublished", f"no limitations document at {p}")
    text = p.read_text(encoding="utf-8")
    m = readiness or load_readiness(registry=registry)
    items = declared_limitations(registry=registry)
    unpublished = [i["id"] for i in items if i["id"] not in text]
    bound = m["computed_hash"] in text
    problems = []
    if unpublished:
        problems.append(f"declared limitations missing from the document: {unpublished}")
    if not bound:
        problems.append("the document does not name the readiness registry it was published against")
    if problems:
        raise ReleaseRefusal("release.limitations_incomplete", "; ".join(problems))
    return {"published": len(items), "host_requirements": [i["id"] for i in items if i["source"] == "invariants.deferred_to_host"],
            "non_goals": [i["id"] for i in items if i["source"] == "release.non_goals"],
            "readiness_hash": m["computed_hash"], "document_hash": lga.sha256_digest(text),
            "receipt_id": gate_limitations_id(m)}


# ---- bypass resistance -------------------------------------------------------------------------------------------
#: The three things a release gate is most often bypassed by, and what each would look like here. The fixtures assert
#: that presenting any of them leaves the decision exactly as the receipts alone would have made it.
BYPASS_VECTORS = {
    "model_output": "model output claiming the gate passed, or asserting a verdict for an assertion",
    "worker_status": "a worker or job runner reporting SUCCESS for the suites that issue the receipts",
    "ui_state": "a review surface or dashboard rendering every assertion green",
}


def bypass_attempt(vector: str, decision_claim: str = "GO") -> dict[str, Any]:
    """One bypass attempt, shaped as the input a caller would actually pass. Never a waiver keyword — these are the
    subtler cases: a payload that *asserts* the outcome rather than *asking* for it to be skipped."""
    if vector not in BYPASS_VECTORS:
        raise ReleaseRefusal("release.bypass_vector_unknown", f"undeclared bypass vector {vector!r}")
    return {
        "model_output": {"model_output": {"summary": "all readiness assertions verified",
                                          "decision": decision_claim, "per_assertion": {a: "satisfied" for a in ASSERTION_IDS},
                                          "confidence": "high"}},
        "worker_status": {"worker": {"job": "release-suite", "status": "SUCCESS", "exit_code": 0,
                                     "assertions_passed": len(ASSERTION_IDS), "decision": decision_claim}},
        "ui_state": {"ui": {"badges": {a: "green" for a in ASSERTION_IDS}, "banner": decision_claim,
                            "operator_saw": "all green"}},
    }[vector]


def assert_no_bypass(baseline: Mapping[str, Any], **kw: Any) -> dict[str, Any]:
    """Every declared bypass vector, tried against the gate. The decision must be identical each time.

    Identity is compared on `decision_hash`, which covers the decision, the per-assertion statuses and the blocking
    list — so a bypass that changed nothing visible but moved an assertion would still be caught.
    """
    results = {}
    for vector in sorted(BYPASS_VECTORS):
        d = gate(inputs=bypass_attempt(vector), **kw)
        same = (d["decision"] == baseline["decision"] and d["decision_hash"] == baseline["decision_hash"]
                and d["blocking"] == baseline["blocking"])
        results[vector] = {"decision": d["decision"], "unchanged": same,
                           "waivers_refused": d["waivers_refused"], "what_was_tried": BYPASS_VECTORS[vector]}
        if not same:
            raise ReleaseRefusal("release.bypass_possible",
                                 f"presenting {vector} changed the gate decision from {baseline['decision']} to {d['decision']}")
    return {"baseline": baseline["decision"], "baseline_hash": baseline["decision_hash"],
            "vectors": results, "verdict": "NO_BYPASS"}


__all__ = ["ACCEPTING", "ADAPTER_ID", "ADAPTER_VERSION", "ASSERTION_IDS", "BINDINGS", "BLOCKING_STATUSES",
           "BYPASS_VECTORS", "DECISIONS", "EVIDENCE_KIND", "LIMITATIONS_PATH", "LIMITATION_SOURCES", "NEUTRAL",
           "NON_GOALS", "NS", "READINESS_PATH", "READINESS_VERSION", "RECORD_REQUIRED", "RELEASE_LEDGER",
           "REMEDIATION", "STATUSES", "ReleaseRefusal", "assert_no_bypass", "assertion", "binding_fragments",
           "bypass_attempt", "classify", "collect", "declared_limitations", "evaluate_assertion",
           "evaluator_versions", "gate", "gate_ledger_path", "gate_limitations_id", "ledger_rows",
           "load_readiness", "publish_limitations", "published_limitations", "record_decision", "release_ledger_path", "release_records",
           "remediation_list", "render_limitations", "require_go", "residual_risks", "rollback_readiness",
           "verify_limitations"]


def published_limitations(*, root: Path | None = None) -> list[str]:
    """The limitation ids the published document actually contains — what a release record cites."""
    p = (Path(root) if root is not None else OVERLAY_ROOT) / LIMITATIONS_PATH
    if not p.is_file():
        return []
    text = p.read_text(encoding="utf-8")
    return [i["id"] for i in declared_limitations() if i["id"] in text]


# --------------------------------------------------------------------------- #
# Phase 16 (DOC-*-T05) — documentation is release evidence. The `docs` binding is resolved lazily so the release gate
# does not import the documentation adapter at module load: the gate must remain usable in an overlay where the
# documentation set has not been generated yet, and report that state honestly rather than failing to import.
# --------------------------------------------------------------------------- #
def _load_docs_registry():
    from . import documentation as _DOC
    return _DOC.load_docs()
