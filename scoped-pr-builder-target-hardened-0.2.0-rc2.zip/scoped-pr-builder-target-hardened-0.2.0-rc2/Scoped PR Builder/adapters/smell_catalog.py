CATALOG={
 'trailing_whitespace':'trim_trailing_whitespace',
 'missing_final_newline':'ensure_final_newline',
 'python_unused_import':'py_unused_imports',
 'checksum_drift':'normalize_sha256sums',
}
def recipe_for(smell:str)->str|None: return CATALOG.get(smell)
