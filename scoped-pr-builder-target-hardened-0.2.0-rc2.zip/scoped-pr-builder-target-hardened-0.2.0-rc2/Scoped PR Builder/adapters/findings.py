"""Deterministic finding normalization and path proposal."""
from __future__ import annotations
from pathlib import Path
from . import local_git_adapter as lga
def todo_findings(root:Path, allowed_suffixes=('.py','.js','.ts','.go','.rs','.md')):
    out=[]
    for p in sorted(root.rglob('*')):
        if not p.is_file() or p.suffix not in allowed_suffixes or '.git' in p.parts: continue
        try: lines=p.read_text(encoding='utf-8',errors='replace').splitlines()
        except OSError: continue
        for n,line in enumerate(lines,1):
            if 'TODO' in line or 'FIXME' in line:
                rel=p.relative_to(root).as_posix(); out.append({'type':'todo','path':rel,'line':n,'evidence_hash':lga.sha256_digest(line)})
    return out
def propose_allowed_paths(findings,max_paths=32): return sorted({f['path'] for f in findings})[:max_paths]
