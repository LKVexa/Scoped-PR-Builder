"""Loopback-only interactive review server.

Static ``review.html`` remains display-only. This optional local server sends
reviewer commands through ``review_surface`` and never writes patches directly.
It constrains host headers, request size, nonce growth, and response caching so
loopback operation is not treated as a reason to skip basic HTTP hardening.
"""
from __future__ import annotations

import json
import secrets
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs

from . import approval_adapter as aa
from . import local_git_adapter as lga
from . import review_surface as rs

MAX_FORM_BYTES = 64 * 1024
MAX_NONCES = 4096
_LOOPBACK_NAMES = {"127.0.0.1", "::1", "localhost"}


def _host_header_loopback(value: str) -> bool:
    raw = str(value or "").strip().lower()
    if not raw:
        return False
    if raw.startswith("["):
        end = raw.find("]")
        if end < 0:
            return False
        host = raw[1:end]
        rest = raw[end + 1 :]
        if rest and not (rest.startswith(":") and rest[1:].isdigit()):
            return False
    elif raw.count(":") == 1:
        host, port = raw.rsplit(":", 1)
        if port and not port.isdigit():
            return False
    else:
        host = raw
    return host in _LOOPBACK_NAMES


def _load(run_dir: Path):
    def j(rel):
        return json.loads((run_dir / rel).read_text(encoding="utf-8"))

    arts = {
        "binding": j("suite40/binding.json"),
        "scope_contract": j("intent/scope_contract.json"),
        "candidate": j("candidate/candidate.json"),
        "verification_report": j("verification/report.json"),
        "review_card": j("review/review_card.json"),
    }
    path = run_dir / "suite51/evidence.json"
    if path.is_file():
        arts["evidence_bundle"] = {"evidence": j("suite51/evidence.json")}
    run_id = lga.sha256_digest(str(run_dir))
    surface = rs.bind_view(rs.build_surface(arts, run_id=run_id, run_dir=run_dir), arts, run_id=run_id)
    return arts, surface


def serve(run_dir: Path, *, key_path: Path | None = None, host: str = "127.0.0.1", port: int = 0):
    if host not in _LOOPBACK_NAMES:
        raise lga.AdapterError("review.server_non_loopback", "interactive review server must bind loopback only")
    if isinstance(port, bool) or not isinstance(port, int) or not 0 <= port <= 65535:
        raise lga.AdapterError("review.server_port_invalid", "review server port must be in 0..65535")
    run_dir = Path(run_dir).resolve()
    token = secrets.token_urlsafe(32)
    seen: set[str] = set()
    arts, surface = _load(run_dir)
    key = aa.load_or_create_key(key_path, create=True) if key_path else None
    base_html = rs.render_surface_html(surface).replace("form-action 'none'", "form-action 'self'")
    base_html = base_html.replace(
        "<form method='post' action='#command'",
        f"<form method='post' action='/command'><input type='hidden' name='csrf' value='{token}'",
    )

    class H(BaseHTTPRequestHandler):
        def _host_ok(self):
            return _host_header_loopback(self.headers.get("Host", ""))

        def _headers(self, content_type: str, length: int):
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(length))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")

        def do_GET(self):
            if not self._host_ok():
                self.send_error(403)
                return
            if self.path not in ("/", "/review"):
                self.send_error(404)
                return
            body = base_html.encode()
            self.send_response(200)
            self._headers("text/html; charset=utf-8", len(body))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            if self.path != "/command" or not self._host_ok():
                self.send_error(403)
                return
            if self.headers.get_content_type() != "application/x-www-form-urlencoded":
                self.send_error(415)
                return
            try:
                length = int(self.headers.get("Content-Length", ""))
            except ValueError:
                self.send_error(400)
                return
            if length <= 0 or length > MAX_FORM_BYTES:
                self.send_error(413)
                return
            try:
                decoded = self.rfile.read(length).decode("utf-8", errors="strict")
            except UnicodeDecodeError:
                self.send_error(400)
                return
            form = {k: values[-1] for k, values in parse_qs(decoded, keep_blank_values=True).items()}
            if not secrets.compare_digest(form.pop("csrf", ""), token):
                self.send_error(403)
                return
            nonce = form.get("nonce") or secrets.token_urlsafe(12)
            if nonce in seen:
                self.send_error(409)
                return
            if len(seen) >= MAX_NONCES:
                self.send_error(429)
                return
            seen.add(nonce)
            action = form.pop("action", "")
            identity = form.pop("identity", "")
            rationale = form.pop("rationale", "")
            fields = {
                k: ([item.strip() for item in value.split(",") if item.strip()] if k == "allowed_paths" else value)
                for k, value in form.items()
                if k != "nonce"
            }
            try:
                command = rs.issue_command(
                    action,
                    identity=identity,
                    channel="local_review_server",
                    surface=surface,
                    rationale=rationale,
                    fields=fields,
                    nonce=nonce,
                )
                result = rs.execute_command(run_dir, command, artifacts=arts, surface=surface, key=key)
                body = json.dumps(result, indent=2, sort_keys=True).encode()
                self.send_response(200)
            except Exception as exc:
                body = json.dumps({"status": "BLOCKED", "message": str(exc)}).encode()
                self.send_response(400)
            self._headers("application/json", len(body))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer((host, port), H)
    server.daemon_threads = True
    return server, token
