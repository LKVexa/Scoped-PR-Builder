"""Scoped PR Builder — security and content defense (Phase 09 / SEC-01..08).

``security/THREATS.json`` declares one explicit threat per mandatory security condition — prompt injection from
repository/docs/tickets/logs, tool-argument injection, secrets in model context, cross-project leakage, unauthorized
writes, unclassified sensitive output, fabricated approval tokens, model-modified audit records — each with its
trust-boundary rule, deny conditions (stable codes), the audit event it emits, the suite authoritative for the control and
the effect boundary where it is enforced again. Every denial is written as a chained, append-only row on the security
trail (``<run_dir>/security/denials.jsonl``; the process-wide default trail otherwise) *before* the refusal propagates, so an
adversarial attempt always leaves an immutable, reviewable record and never an effect.

Build provenance: BUILD_NEW (stdlib) for the registry, trail and enforcement; secrets/PII masking REUSES the MIT
``amplifier-bundle-redaction`` core (``adapters/vendor_redaction.py``; see THIRD-PARTY-NOTICES.md and PROVENANCE.jsonl).
"""
from __future__ import annotations

import json
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Sequence

from . import contracts as C
from . import local_git_adapter as lga
from .archive_adapter import _chain_append, verify_chain_file

THREATS_VERSION = "scoped_pr_builder.threats/0.1.0"
THREATS_PATH = Path(__file__).resolve().parent.parent / "security" / "THREATS.json"
OVERLAY_ROOT = Path(__file__).resolve().parent.parent
REPO_ROOT = OVERLAY_ROOT.parent
ADAPTER_ID = "scoped_pr_builder.security"
ADAPTER_VERSION = "0.1.0"
NS = "overlay.scoped_pr_builder.security"
THREAT_REQUIRED = ("threat_id", "version", "title", "threat", "trust_boundary", "deny_when", "audit_event", "authoritative_suites", "introduced_by")
UNTRUSTED_SOURCES = ("repository_content", "documentation", "tickets", "logs", "tool_output", "model_output", "network")
MODEL_CHANNELS = ("model", "llm", "agent", "assistant", "planner", "tool", "repository", "doc", "ticket", "log")
_TRAIL: Path | None = None


class SecurityDenial(lga.AdapterError):
    """A threat control refused: ``code`` is the declared deny code; ``record`` is the chained denial row."""

    def __init__(self, code: str, message: str, *, threat_id: str, record: Mapping[str, Any] | None = None) -> None:
        super().__init__(code, message)
        self.threat_id = threat_id
        self.record = dict(record or {})


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_threats(path: Path = THREATS_PATH, *, registry: Mapping[str, Any] | None = None, repo_root: Path = REPO_ROOT) -> dict[str, Any]:
    """Load and validate the threat registry: every threat names its trust boundary, deny codes, audit event and existing
    authoritative suites; the deny codes are namespaced per threat so a denial can never be mistaken for another control's."""
    if not Path(path).is_file():
        raise SecurityDenial("security.registry_missing", f"threat registry not found: {path}", threat_id="SEC-00")
    th = json.loads(Path(path).read_text(encoding="utf-8"))
    if th.get("threats_version") != THREATS_VERSION:
        raise SecurityDenial("security.registry_invalid", "unsupported threats_version", threat_id="SEC-00")
    for tid, t in (th.get("threats") or {}).items():
        missing = [k for k in THREAT_REQUIRED if k not in t]
        if missing or t["threat_id"] != tid or not C.SEMVER_RE.match(t["version"]):
            raise SecurityDenial("security.registry_invalid", f"{tid}: missing {missing} / id or version invalid", threat_id=tid)
        tb = t["trust_boundary"]
        if not tb.get("rule") or not tb.get("untrusted"):
            raise SecurityDenial("security.registry_invalid", f"{tid}: trust_boundary needs a rule and the untrusted sources", threat_id=tid)
        prefix = f"security.{tid.lower().replace('-', '')}."
        if not t["deny_when"] or any(not d.get("code", "").startswith(prefix) or not d.get("condition") for d in t["deny_when"]):
            raise SecurityDenial("security.registry_invalid", f"{tid}: every deny_when needs a condition and a code under {prefix}", threat_id=tid)
        if not str(t["audit_event"]).startswith("security."):
            raise SecurityDenial("security.registry_invalid", f"{tid}: audit_event must be a security.* event kind", threat_id=tid)
        for f in t["authoritative_suites"]:
            if not (Path(repo_root) / f).is_file():
                raise SecurityDenial("security.suite_unbound", f"{tid}: authoritative suite file does not exist: {f}", threat_id=tid)
    body = {k: v for k, v in th.items() if k != "threats_hash"}
    th["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    th["core_hash"] = lga.sha256_digest(lga.canonical_json({tid: {k: t[k] for k in ("version", "threat", "trust_boundary", "deny_when", "audit_event")} for tid, t in th["threats"].items()}))
    return th


def deny_codes(threats: Mapping[str, Any], threat_id: str) -> list[str]:
    return [d["code"] for d in threats["threats"][threat_id]["deny_when"]]


# ---- the trail ----------------------------------------------------------------------------------------------------
def default_trail() -> Path:
    env = os.environ.get("SPB_SECURITY_TRAIL")
    return Path(env) if env else Path(tempfile.gettempdir()) / "scoped-pr-builder-security-trail"


def use_trail(run_dir: Path | None) -> None:
    """Bind the process to a run directory's security trail (set by the workflow runtime and the effect boundaries)."""
    global _TRAIL
    _TRAIL = Path(run_dir).resolve() / "security" if run_dir is not None else None


def trail_dir(run_dir: Path | None = None) -> Path:
    if run_dir is not None:
        return Path(run_dir).resolve() / "security"
    return _TRAIL if _TRAIL is not None else default_trail()


def _minimize(value: Any, depth: int = 0) -> Any:
    """Evidence on the trail is hashes, identifiers and short strings — never content (SEC-08: audit rows carry no payloads)."""
    if isinstance(value, Mapping):
        return {str(k): _minimize(v, depth + 1) for k, v in list(value.items())[:40]}
    if isinstance(value, (list, tuple)):
        return [_minimize(v, depth + 1) for v in list(value)[:40]]
    if isinstance(value, (bytes, bytearray)):
        return {"bytes": len(value), "sha256": lga.sha256_digest(bytes(value))}
    if isinstance(value, str):
        return value if len(value) <= 160 else {"len": len(value), "sha256": lga.sha256_digest(value)}
    return value


def audit(threat_id: str, event: str, payload: Mapping[str, Any], *, run_dir: Path | None = None, threats: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Append one chained audit event for a threat control (denials and notable allow-side facts alike)."""
    th = threats or load_threats()
    kind = th["threats"][threat_id]["audit_event"] if threat_id in th["threats"] else "security.audit"
    row = {"record_schema": f"{NS}/AuditEvent", "threat_id": threat_id, "event": event, "kind": kind, "payload": minimize_for_audit(payload), "at": _now(), "writer": f"adapters/security/{ADAPTER_VERSION}"}  # SEC-08-T03
    return _chain_append(trail_dir(run_dir) / "events.jsonl", row)


def deny(threat_id: str, code: str, reason: str, *, actor: Mapping[str, Any] | str | None = None, subject: Mapping[str, Any] | None = None, evidence: Mapping[str, Any] | None = None,
         run_dir: Path | None = None, threats: Mapping[str, Any] | None = None) -> None:
    """Fail closed: write the chained denial row (and its audit event) first, then raise. The code must be one the threat
    declares; an undeclared code is itself refused (a control cannot invent denials it never documented)."""
    th = threats or load_threats()
    t = th["threats"].get(threat_id)
    if t is None or code not in [d["code"] for d in t["deny_when"]]:
        raise SecurityDenial("security.registry_invalid", f"{threat_id}: undeclared deny code {code!r}", threat_id=threat_id)
    row = {"record_schema": f"{NS}/DenialRecord", "threat_id": threat_id, "threat_version": t["version"], "code": code, "reason": reason[:400], "actor": actor_ref(actor) if actor is not None else None,  # SEC-05-T03
           "subject": _minimize(subject or {}), "evidence": _minimize(evidence or {}), "effect": "none — refused before any state change", "at": _now(), "writer": f"adapters/security/{ADAPTER_VERSION}"}
    rec = _chain_append(trail_dir(run_dir) / "denials.jsonl", row)
    audit(threat_id, "denied", {"code": code, "denial_hash": rec["entry_hash"], "reason": reason[:160]}, run_dir=run_dir, threats=th)
    raise SecurityDenial(code, f"{threat_id} {t['title']}: {reason}", threat_id=threat_id, record=rec)


def denials(run_dir: Path | None = None) -> list[dict[str, Any]]:
    """Verified denial rows of a trail (chain checked on every read; a broken chain refuses)."""
    p = trail_dir(run_dir) / "denials.jsonl"
    verify_chain_file(p)
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()] if p.is_file() else []


def events(run_dir: Path | None = None) -> list[dict[str, Any]]:
    p = trail_dir(run_dir) / "events.jsonl"
    verify_chain_file(p)
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()] if p.is_file() else []


def verify_trail(run_dir: Path | None = None) -> dict[str, int]:
    base = trail_dir(run_dir)
    return {"denials": verify_chain_file(base / "denials.jsonl"), "events": verify_chain_file(base / "events.jsonl")}


__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "MODEL_CHANNELS", "THREATS_PATH", "THREATS_VERSION", "UNTRUSTED_SOURCES", "SecurityDenial", "audit", "default_trail", "denials", "deny", "deny_codes", "events", "load_threats", "trail_dir", "use_trail", "verify_trail"]


# --------------------------------------------------------------------------- #
# T02 — enforcement: each control is applied at its authoritative suite's boundary AND again at the effect boundary;
# model output, repository text and tool output are data — never authorization, never validation
# --------------------------------------------------------------------------- #
def record_denial(threat_id: str, code: str, reason: str, *, actor: Any = None, subject: Mapping[str, Any] | None = None, evidence: Mapping[str, Any] | None = None, run_dir: Path | None = None, threats: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Write the chained denial row + audit event without raising — for boundaries whose stable refusal code must keep
    propagating (e.g. ``path.escape``); the trail still names the declared security code."""
    try:
        deny(threat_id, code, reason, actor=actor, subject=subject, evidence=evidence, run_dir=run_dir, threats=threats)
    except SecurityDenial as exc:
        return exc.record
    raise AssertionError("deny() must raise")  # pragma: no cover


# ---- SEC-01 prompt injection from repository/docs/tickets/logs ----------------------------------------------------
INJECTION_PATTERNS: tuple[tuple[str, "re.Pattern[str]"], ...] = (
    ("override_instructions", re.compile(r"\b(?:ignore|disregard|forget)\b.{0,40}\b(?:previous|prior|above|earlier|all)\b.{0,20}\b(?:instructions?|rules?|prompts?|policy)", re.I | re.S)),
    ("role_hijack", re.compile(r"\byou are now\b|\bact as (?:the |an? )?(?:system|admin|operator|reviewer|approver)\b|<\s*/?\s*(?:system|assistant|instruction|tool)\s*>", re.I)),
    ("approval_directive", re.compile(r"\b(?:auto[- ]?)?approv(?:e|ed|al)\b.{0,40}\b(?:this|the)\b.{0,20}\b(?:patch|change|candidate|pr|pull request)\b|\bmark(?:ed)? as approved\b|\bhuman[_ ]approval\b.{0,20}\b(?:granted|given|received)\b", re.I | re.S)),
    ("verification_bypass", re.compile(r"\bskip(?:ping)?\b.{0,20}\b(?:the )?(?:verification|tests?|review|checks?|sandbox)\b|\bdo not run\b.{0,20}\btests?\b|\bno need to (?:verify|test|review)\b", re.I | re.S)),
    ("token_material", re.compile(r"\b(?:receipt_hash|approval[_ ]token|signature)\s*[:=]\s*(?:hmac-sha256:)?[0-9a-f]{16,}", re.I)),
    ("scope_widening", re.compile(r"\b(?:also|additionally)\b.{0,30}\b(?:edit|modify|delete|rewrite)\b.{0,30}\b(?:all|every|any)\b.{0,20}\bfiles?\b", re.I | re.S)),
    ("exfiltration", re.compile(r"\b(?:send|post|upload|exfiltrate|curl|wget)\b.{0,40}\b(?:secrets?|keys?|tokens?|credentials?|\.env)\b", re.I | re.S)),
)


def scan_untrusted(text: str) -> list[dict[str, Any]]:
    """Directive-shaped content in untrusted text (documentation, tickets, logs, code comments, tool output). Findings
    are names + offsets only — never the payload text — so the scan itself cannot smuggle instructions onward."""
    findings = []
    for name, rx in INJECTION_PATTERNS:
        for m in rx.finditer(text or ""):
            findings.append({"pattern": name, "offset": m.start(), "length": m.end() - m.start()})
            if len(findings) >= 50:
                return findings
    return findings


def trust_block(source: str, text: str = "", *, scanned: bool = True) -> dict[str, Any]:
    if source not in UNTRUSTED_SOURCES:
        raise SecurityDenial("security.registry_invalid", f"unknown untrusted source kind {source!r}", threat_id="SEC-01")
    findings = scan_untrusted(text) if scanned else []
    return {"origin": "untrusted", "source": source, "classification": "data — never instruction, authorization or validation", "scanned": scanned, "directive_findings": [f["pattern"] for f in findings], "finding_count": len(findings)}


def mark_untrusted(record: dict[str, Any], text: str, source: str) -> dict[str, Any]:
    """Attach the trust block to a record derived from untrusted content (SEC-01 at Suite 52.2 / 51.x retrieval)."""
    record["trust"] = trust_block(source, text)
    return record


def enforce_sec01_effect(receipt: Mapping[str, Any], card: Mapping[str, Any], *, plan: Mapping[str, Any] | None = None, run_dir: Path | None = None) -> dict[str, Any]:
    """Effect boundary for SEC-01: authorization comes only from a human receipt on a human channel and executed checks;
    directive-shaped content that reached the review surface is visible but powerless; an advisory plan stays advisory."""
    channel = str(receipt.get("approver_channel", "")).strip().lower()
    if channel in MODEL_CHANNELS or any(channel.startswith(c + ":") for c in MODEL_CHANNELS):
        deny("SEC-01", "security.sec01.untrusted_channel_authorization", f"approval channel {channel!r} is an untrusted content/model channel; content cannot authorize", actor={"channel": channel}, subject={"receipt_hash": receipt.get("receipt_hash")}, run_dir=run_dir)
    if plan is not None and plan.get("authority") not in (None, "advisory_only"):
        deny("SEC-01", "security.sec01.plan_claims_authority", f"plan authority {plan.get('authority')!r} is not advisory_only", subject={"plan_hash": plan.get("plan_hash")}, run_dir=run_dir)
    unmarked = [i.get("path") for i in (card.get("evidence_summary") or {}).get("items", []) if i.get("trust") is not None and i["trust"].get("origin") != "untrusted"]
    if unmarked:
        deny("SEC-01", "security.sec01.evidence_not_marked_untrusted", f"evidence items presented as trusted: {unmarked[:5]}", subject={"card_hash": card.get("card_hash")}, run_dir=run_dir)
    directives = sum(int((i.get("trust") or {}).get("finding_count", 0)) for i in (card.get("evidence_summary") or {}).get("items", []))
    return {"channel": channel, "directive_findings_in_evidence": directives, "authorization_source": "human receipt + executed check receipts only"}


# ---- SEC-02 tool-call argument validation (command / path / scope injection) --------------------------------------
_BAD_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def validate_paths(paths: Sequence[str | PurePosixPath], *, allowed: Sequence[PurePosixPath] | None = None, forbidden: Sequence[PurePosixPath] = (), label: str = "paths", run_dir: Path | None = None) -> tuple[PurePosixPath, ...]:
    """Repository-relative, canonical, traversal-free paths only (Suite 50.6 confinement / 28.4 path gate); when an allowed
    set is given every path must also lie inside it and outside the forbidden set. Violations are recorded on the trail
    with the declared SEC-02 code and re-raised with the adapter's stable code."""
    for p in paths:
        s = str(p)
        if _BAD_CHARS.search(s) or "\n" in s or s.startswith("~") or s.startswith("-"):
            record_denial("SEC-02", "security.sec02.path_injection", f"{label}: control characters, home reference or option-shaped path: {s[:60]!r}", subject={"path": s[:120]}, run_dir=run_dir)
            raise lga.AdapterError("path.escape", f"path must be canonical and repository-relative without traversal: {s!r}")
    try:
        roots = lga.validated_roots(paths, label, allow_empty=True)
        if allowed is not None:
            lga.require_within_scope(list(roots), list(allowed), list(forbidden))
    except lga.AdapterError as exc:
        record_denial("SEC-02", "security.sec02.path_escape" if exc.code == "path.escape" else "security.sec02.scope_injection", str(exc), subject={label: [str(p)[:120] for p in list(paths)[:20]]}, run_dir=run_dir)
        raise
    return roots


def validate_argv(argv: Sequence[Any], *, sandbox: Path | None = None, run_dir: Path | None = None) -> list[str]:
    """Tool invocations are argv vectors, never shell strings: every element is a plain string without control bytes; an
    element that names an absolute path must stay inside the sandbox, the overlay or the interpreter's own tree."""
    if not isinstance(argv, (list, tuple)) or not argv or any(not isinstance(a, str) for a in argv):
        deny("SEC-02", "security.sec02.command_injection", "tool command must be a non-empty argv list of strings (no shell strings)", subject={"argv": [str(a)[:80] for a in list(argv)[:10]]} if isinstance(argv, (list, tuple)) else {"argv": str(argv)[:120]}, run_dir=run_dir)
    for a in argv:
        if _BAD_CHARS.search(a) or "\n" in a:
            deny("SEC-02", "security.sec02.command_injection", f"control bytes in tool argument {a[:60]!r}", subject={"arg": a[:120]}, run_dir=run_dir)
    import sys as _sys
    roots = [Path(_sys.executable).resolve().parent.parent, OVERLAY_ROOT.resolve(), Path(tempfile.gettempdir()).resolve()]
    if sandbox is not None:
        roots.append(Path(sandbox).resolve())
    for a in argv[1:]:
        if (a.startswith("/") or re.match(r"^[A-Za-z]:[\\/]", a)) and not any(lga.path_within(Path(a), r) for r in roots):
            deny("SEC-02", "security.sec02.path_injection", f"tool argument names a path outside the sandbox/overlay: {a[:80]!r}", subject={"arg": a[:120], "sandbox": str(sandbox) if sandbox else None}, run_dir=run_dir)
    return list(argv)


# ---- SEC-03 secrets never copied into model context ------------------------------------------------------------------
def _redaction():
    from . import vendor_redaction as R
    return R


_DIGEST_SHAPED = re.compile(r"(?:sha256:|git-tree:|blob:)?[0-9a-f]{32,64}|\[REDACTED:[A-Z]+\]")


def _mask_assignment_keep_digests(match: "re.Match[str]") -> str:
    """The donor's NAME=value masker, with one exclusion this overlay needs: values that are content digests
    (sha256:…, git tree/blob ids, plain 32–64 hex) are identifiers, never credentials — ``dedup_key: sha256:…`` stays."""
    R = _redaction()
    value = match.group("redact")
    whole = match.group(0)
    if value is None or _DIGEST_SHAPED.fullmatch(value) or not R._is_credential_shaped(value):
        return whole
    base = match.start(); start, end = match.span("redact")
    return whole[: start - base] + "[REDACTED:SECRET]" + whole[end - base:]


def mask(text: str, rules: Sequence[str] = ("secrets", "pii-basic")) -> str:
    """The vetted masker's token, assignment and PII rules over one string (digest-shaped values preserved)."""
    R = _redaction()
    out = text or ""
    if "secrets" in rules:
        for pat in R.SECRET_PATTERNS:
            out = pat.sub("[REDACTED:SECRET]", out)
        for pat in R.SECRET_ASSIGNMENT_PATTERNS:
            out = pat.sub(_mask_assignment_keep_digests, out)
    if "pii-basic" in rules:
        for pat in R.PII_PATTERNS:
            out = pat.sub("[REDACTED:PII]", out)
    return out


def scan_secrets(text: str) -> int:
    """Number of secret-shaped spans in ``text`` (token patterns + credential assignments; the text itself is never returned)."""
    return mask(text, ("secrets",)).count("[REDACTED:SECRET]") - (text or "").count("[REDACTED:SECRET]")


def protect_secrets(text: str, purpose: str) -> str:
    """Anything bound for a model context, a log, a UI or an export passes through the masker first (Suite 53.5 / 66.21)."""
    if purpose not in ("model_context", "log", "ui", "export", "storage"):
        raise SecurityDenial("security.registry_invalid", f"unknown protection purpose {purpose!r}", threat_id="SEC-03")
    return mask(text)


def enforce_sec03_effect(patch: bytes, *, run_dir: Path | None = None, subject: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Effect boundary for SEC-03: a candidate that would introduce secret material into the repository (and therefore
    into every later review/export/model context) is refused before any worktree exists."""
    added = "\n".join(l[1:] for l in patch.decode("utf-8", errors="replace").splitlines() if l.startswith("+") and not l.startswith("+++"))
    n = scan_secrets(added)
    if n:
        deny("SEC-03", "security.sec03.secret_in_candidate", f"candidate adds {n} secret-shaped value(s); secrets are never copied forward", subject=dict(subject or {}, patch_sha256=lga.sha256_digest(patch)), run_dir=run_dir)
    return {"secret_spans_in_added_lines": 0}


# ---- SEC-04 cross-project / tenant leakage --------------------------------------------------------------------------
def assert_tenant(binding: Any, *artifacts: tuple[str, Mapping[str, Any]], run_dir: Path | None = None) -> dict[str, Any]:
    """Every artifact that names a repository must name THIS repository (and revision when it carries one); an artifact
    from another project is refused with a trail — nothing from another tenant is ever read as evidence or applied."""
    for name, art in artifacts:
        if art is None:
            continue
        rid = art.get("repository_id")
        if rid is not None and rid != binding.repository_id:
            deny("SEC-04", "security.sec04.foreign_repository", f"{name} belongs to repository {rid[:23]}…, not {binding.repository_id[:23]}…", subject={"artifact": name, "repository_id": rid, "bound": binding.repository_id}, run_dir=run_dir)
        rev = art.get("base_revision")
        if rev is not None and rev != binding.base_revision:
            deny("SEC-04", "security.sec04.foreign_revision", f"{name} is bound to revision {rev[:12]}, not {binding.base_revision[:12]}", subject={"artifact": name, "base_revision": rev, "bound": binding.base_revision}, run_dir=run_dir)
        snap = art.get("source_snapshot_hash")
        if snap is not None and snap != binding.source_snapshot_hash:
            deny("SEC-04", "security.sec04.foreign_repository", f"{name} carries another source snapshot", subject={"artifact": name}, run_dir=run_dir)
    return {"repository_id": binding.repository_id, "artifacts_checked": [n for n, a in artifacts if a is not None]}


# ---- SEC-05 unauthorized writes ----------------------------------------------------------------------------------
PRIVILEGED_WRITES = ("patch.apply_isolated", "rollback.execute", "store.write", "ledger.append")


def guard_write(effect: str, actor: Mapping[str, Any] | str | None, *, authorized_by: Mapping[str, Any] | None, decision: Mapping[str, Any] | None = None, run_dir: Path | None = None) -> dict[str, Any]:
    """A write is allowed only when its policy decision is an explicit allow and, for repository effects, a verified human
    receipt authorizes it; a model/untrusted actor is refused outright. Every refusal leaves a trail row."""
    actor_s = actor if isinstance(actor, str) else (actor or {}).get("identity") or (actor or {}).get("channel") or "unknown"
    channel = (actor if isinstance(actor, Mapping) else {}).get("channel", "")
    if str(actor_s).lower() in MODEL_CHANNELS or str(channel).lower() in MODEL_CHANNELS:
        deny("SEC-05", "security.sec05.model_actor", f"{effect}: actor {actor_s!r} is a model/untrusted principal; writes are never authorized to it", actor=actor, subject={"effect": effect}, run_dir=run_dir)
    if decision is not None and decision.get("decision") != "allow":
        deny("SEC-05", "security.sec05.write_denied", f"{effect}: policy decision is {decision.get('decision')!r} ({decision.get('reason', '')})", actor=actor, subject={"effect": effect, "decision_hash": decision.get("decision_hash")}, run_dir=run_dir)
    if effect in ("patch.apply_isolated", "rollback.execute") and not (authorized_by and authorized_by.get("receipt_hash") and authorized_by.get("signature") and authorized_by.get("decision") == "APPROVE"):
        deny("SEC-05", "security.sec05.unauthorized_write", f"{effect}: no verified human APPROVE receipt authorizes this write", actor=actor, subject={"effect": effect}, run_dir=run_dir)
    return {"effect": effect, "actor": actor_s, "authorized_by": (authorized_by or {}).get("receipt_hash")}


# ---- SEC-06 sensitive generated output classified before display/export ------------------------------------------
CLASSIFICATIONS = ("public", "internal", "confidential", "restricted")


def classify_output(text: str) -> dict[str, Any]:
    """Classification of generated output before it is displayed or exported: secret-shaped content → restricted, PII →
    confidential, otherwise internal (never public by default). The masked rendering travels with the classification."""
    secrets = scan_secrets(text)
    pii = mask(text, ("pii-basic",)).count("[REDACTED:PII]") - (text or "").count("[REDACTED:PII]")
    cls = "restricted" if secrets else ("confidential" if pii else "internal")
    return {"classification": cls, "findings": {"secrets": secrets, "pii": pii}, "masked": mask(text), "policy": "display/export only the masked rendering; restricted output is never exported unmasked"}


def enforce_sec06_export(name: str, text: str, *, run_dir: Path | None = None) -> str:
    """Effect boundary for SEC-06 (display/export): an artifact classified restricted that still contains unmasked secret
    material is refused; otherwise the masked rendering is what leaves."""
    c = classify_output(text)
    if c["classification"] == "restricted" and scan_secrets(c["masked"]):
        deny("SEC-06", "security.sec06.unclassified_export", f"{name}: restricted content cannot be exported unmasked", subject={"artifact": name}, run_dir=run_dir)
    return c["masked"]


# ---- SEC-07 human approval tokens cannot be fabricated by model output ------------------------------------------------
def require_human_channel(channel: str, *, identity: str | None = None, run_dir: Path | None = None) -> str:
    """A decision may only be recorded through a human channel: model/agent/content channels are refused by name."""
    ch = str(channel or "").strip().lower()
    if not ch or ch in MODEL_CHANNELS or any(ch.startswith(c + ":") for c in MODEL_CHANNELS):
        deny("SEC-07", "security.sec07.model_channel", f"approval channel {ch!r} is not a human channel", actor={"identity": identity, "channel": ch}, run_dir=run_dir)
    return ch


def verify_human_origin(receipt: Mapping[str, Any], *, chain: Sequence[Mapping[str, Any]] | None = None, run_dir: Path | None = None) -> dict[str, Any]:
    """A receipt counts as human only when its channel is not a model/content channel, its signature has the ledger's
    HMAC shape (the key never leaves the approval adapter — model output cannot compute it), its nonce is unique in the
    chain and it was issued at or before now. The signature itself is verified by the approval adapter's chain check."""
    channel = require_human_channel(receipt.get("approver_channel", ""), identity=receipt.get("approver_identity"), run_dir=run_dir)
    sig = str(receipt.get("signature", ""))
    if not re.fullmatch(r"hmac-sha256:[0-9a-f]{64}", sig):
        deny("SEC-07", "security.sec07.fabricated_token", "receipt signature is not a ledger HMAC; a token that was not signed by the approval key is fabricated", subject={"receipt_hash": receipt.get("receipt_hash")}, run_dir=run_dir)
    if chain is not None:
        same = [r for r in chain if r.get("nonce") == receipt.get("nonce")]
        if len(same) > 1 or (same and same[0].get("receipt_hash") != receipt.get("receipt_hash")):
            deny("SEC-07", "security.sec07.replayed_token", "receipt nonce reused in the approval ledger", subject={"receipt_hash": receipt.get("receipt_hash")}, run_dir=run_dir)
    try:
        issued = datetime.fromisoformat(str(receipt.get("issued_at")).replace("Z", "+00:00"))
    except ValueError:
        deny("SEC-07", "security.sec07.fabricated_token", "receipt issued_at is not a timestamp", subject={"receipt_hash": receipt.get("receipt_hash")}, run_dir=run_dir)
    if issued > datetime.now(timezone.utc):
        deny("SEC-07", "security.sec07.fabricated_token", "receipt claims to be issued in the future", subject={"receipt_hash": receipt.get("receipt_hash")}, run_dir=run_dir)
    return {"channel": channel, "human": True}


# ---- SEC-08 audit records cannot be modified by the model -----------------------------------------------------------
AUDIT_LEDGERS = ("archive/audit.jsonl", "archive/run-state.jsonl", "workflow/steps.jsonl", "workflow/events.jsonl", "security/denials.jsonl", "security/events.jsonl")


def assert_audit_intact(run_dir: Path, *, stores: bool = True, include_archive: bool = True) -> dict[str, int]:
    """Every chained ledger under the run directory must still link and hash; a broken or edited chain refuses the
    effect (SEC-08 at Archive Ledger 29.5 / Cypher 11 and at every effect boundary). The archive regenerates its own
    run-state/audit chains from the inputs, so it verifies the inputs (``include_archive=False``)."""
    run_dir = Path(run_dir).resolve()
    counts: dict[str, int] = {}
    paths = [run_dir / rel for rel in AUDIT_LEDGERS if include_archive or not rel.startswith("archive/")]
    if stores and (run_dir / "stores").is_dir():
        paths += sorted((run_dir / "stores").glob("*.jsonl"))
    for p in paths:
        if not p.is_file():
            continue
        try:
            counts[p.relative_to(run_dir).as_posix()] = verify_chain_file(p)
        except lga.AdapterError as exc:
            deny("SEC-08", "security.sec08.audit_tampered", f"{p.relative_to(run_dir).as_posix()}: {exc}", subject={"ledger": p.relative_to(run_dir).as_posix()}, run_dir=run_dir)
    return counts


def guard_audit_writer(writer: str, *, run_dir: Path | None = None) -> None:
    """Only named adapters append audit/state rows; a model, UI or anonymous principal is refused with a trail row."""
    if str(writer).lower() in ("model", "ui", "anonymous", "llm", "agent", "assistant"):
        deny("SEC-08", "security.sec08.model_writer", f"writer {writer!r} may not append audit or state records", actor={"identity": writer}, run_dir=run_dir)


__all__ += ["AUDIT_LEDGERS", "CLASSIFICATIONS", "INJECTION_PATTERNS", "PRIVILEGED_WRITES", "assert_audit_intact", "assert_tenant", "classify_output", "enforce_sec01_effect", "enforce_sec03_effect", "enforce_sec06_export", "guard_audit_writer", "guard_write", "mark_untrusted", "mask", "protect_secrets", "record_denial", "require_human_channel", "scan_secrets", "scan_untrusted", "trust_block", "validate_argv", "validate_paths", "verify_human_origin"]


# --------------------------------------------------------------------------- #
# T03 — classify and sanitize untrusted data before it reaches prompts/tools; minimize/redact protected fields before
# storage, logs, UI or export
# --------------------------------------------------------------------------- #
PROTECTED_FIELDS = ("rationale", "signature", "approver_identity", "approver_channel", "nonce", "key", "token", "secret", "password", "authorization", "email", "phone")


def sanitize_directives(text: str, *, marker: str = "[UNTRUSTED-DIRECTIVE:{pattern}]") -> str:
    """Neutralize directive-shaped spans in untrusted text before it is placed on any surface a person or tool reads:
    the span is replaced by a labelled marker (never executed, never quoted verbatim)."""
    out = text or ""
    spans = sorted(((f["offset"], f["offset"] + f["length"], f["pattern"]) for f in scan_untrusted(out)), reverse=True)
    for start, end, name in spans:
        out = out[:start] + marker.format(pattern=name) + out[end:]
    return out


def sanitize_for_tool(paths: Sequence[str | PurePosixPath]) -> list[str]:
    """Canonical, repository-relative path strings for tool argv substitution (no traversal, no option-shaped values)."""
    return [p.as_posix() for p in validate_paths(paths, label="tool_paths")]


def minimize_record(obj: Any, *, protected: Sequence[str] = PROTECTED_FIELDS, keep: Sequence[str] = ()) -> Any:
    """Data minimization before storage/logs/export: protected fields are masked (identity fields kept as stable digests),
    every string is passed through the secrets/PII masker, structure and hashes are preserved."""
    def walk(v: Any, key: str | None) -> Any:
        if isinstance(v, Mapping):
            return {str(k): walk(x, str(k)) for k, x in v.items()}
        if isinstance(v, list):
            return [walk(x, key) for x in v]
        if isinstance(v, str):
            k = (key or "").lower()
            parts = set(k.split("_"))
            if k in keep or k.endswith(("_hash", "_digest", "_id", "_ref", "_version")):
                return v
            if k == "signature":
                return v[:20] + "…"
            if k == "approver_identity":
                return "sha256:" + lga.sha256_digest(v)[7:23] + "…"
            if k == "nonce":
                return v  # random, not secret-bearing; needed for replay checks
            if parts & set(protected):
                return "[MINIMIZED]"
            return mask(v)
        return v
    return walk(obj, None)


def scrub_secrets(obj: Any) -> Any:
    """Secrets masked throughout a JSON-like structure before it is stored (identities, digests and hashes untouched)."""
    if isinstance(obj, Mapping):
        return {k: scrub_secrets(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [scrub_secrets(v) for v in obj]
    if isinstance(obj, str):
        return mask(obj, ("secrets",))
    return obj


def public_view(receipt: Mapping[str, Any]) -> dict[str, Any]:
    """What a log, card history or export may show of an approval receipt: decision, hashes, timestamps, a truncated
    signature and a digest of the approver identity — never the rationale or the raw signature."""
    return {"decision": receipt.get("decision"), "receipt_hash": receipt.get("receipt_hash"), "candidate_id": receipt.get("candidate_id"), "issued_at": receipt.get("issued_at"), "expires_at": receipt.get("expires_at"),
            "approver": "sha256:" + lga.sha256_digest(str(receipt.get("approver_identity", "")))[7:23] + "…", "channel": receipt.get("approver_channel"), "signature": str(receipt.get("signature", ""))[:20] + "…", "rationale": "[MINIMIZED]"}


def tenant_tag(binding: Any) -> dict[str, Any]:
    """The tenant identity every record carries so cross-project material is recognizable at a glance."""
    return {"repository_id": binding.repository_id, "worktree_id": binding.worktree_id, "base_revision": binding.base_revision, "source_snapshot_hash": binding.source_snapshot_hash}


def actor_ref(actor: Mapping[str, Any] | str | None) -> dict[str, Any]:
    """Minimized actor reference for trails: an identity digest and the role/channel — never the raw identity."""
    if actor is None:
        return {"identity_digest": None, "role": None, "channel": None}
    if isinstance(actor, str):
        return {"identity_digest": "sha256:" + lga.sha256_digest(actor)[7:23] + "…", "role": None, "channel": None}
    ident = str(actor.get("identity") or "")
    return {"identity_digest": ("sha256:" + lga.sha256_digest(ident)[7:23] + "…") if ident else None, "role": actor.get("role"), "channel": actor.get("channel")}


def minimize_for_audit(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Audit rows carry identifiers, hashes and short labels — never payload content (SEC-08)."""
    return _minimize(minimize_record(payload))


__all__ += ["PROTECTED_FIELDS", "actor_ref", "minimize_for_audit", "minimize_record", "public_view", "sanitize_directives", "sanitize_for_tool", "scrub_secrets", "tenant_tag"]


# --------------------------------------------------------------------------- #
# T05 — the security regression gate: every threat-control test is mandatory for release and cannot be waived by the
# component under evaluation — the gate reads the tool's own archived evidence ledger (never the sandbox copy), refuses
# waiver-shaped inputs by name, and the sandbox runner re-executes the adversarial suite whenever the overlay changes
# --------------------------------------------------------------------------- #
GATE_EVIDENCE_KIND = "security_adversarial"
WAIVER_NAMES = re.compile(r"(?:^|_)(?:skip|waive|bypass|disable|ignore)(?:_|$)|security_gate\s*=\s*(?:off|false|0)", re.I)


def gate_scenario(threat_id: str, case: str, threats: Mapping[str, Any] | None = None) -> str:
    """Scenario id the adversarial fixtures record under, bound to the current threat core."""
    th = threats or load_threats()
    return f"security:{threat_id}:{case}@{th['core_hash'][7:39]}"


def gate_ledger_path() -> Path:
    env = os.environ.get("SPB_SECURITY_GATE_LEDGER")
    return Path(env) if env else OVERLAY_ROOT / "evidence" / "TEST_LEDGER.jsonl"


def _ledger_rows(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    verify_chain_file(path)
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]


def release_gate(*, ledger: Path | None = None, threats: Mapping[str, Any] | None = None, inputs: Mapping[str, Any] | None = None, run_dir: Path | None = None) -> dict[str, Any]:
    """PROCEED only when, for every declared threat, the tool's chained evidence ledger holds a PASS ``security_adversarial``
    receipt whose scenario id is bound to the current threat core (``security:<id>:<case>@<core-hash prefix>``; the core
    covers ids, versions, trust boundaries, deny codes and audit events) including the ``fail_closed`` case; a
    waiver-shaped input blocks by itself. Nothing the candidate or the sandbox contains can satisfy this gate."""
    th = threats or load_threats()
    waivers = sorted(k for k in (inputs or {}) if WAIVER_NAMES.search(str(k)) or WAIVER_NAMES.search(f"{k}={(inputs or {})[k]}"))
    rows = _ledger_rows(ledger or gate_ledger_path())
    per: dict[str, dict[str, Any]] = {}
    blocking: list[str] = []
    for tid, t in th["threats"].items():
        g = t.get("release_gate") or {}
        if not g.get("mandatory", True) or g.get("waivable", False):
            per[tid] = {"status": "misdeclared", "reason": "release_gate must be mandatory and non-waivable"}; blocking.append(tid); continue
        mine = [r for r in rows if r.get("kind") == GATE_EVIDENCE_KIND and str(r.get("scenario_id", "")).startswith(f"security:{tid}:")]
        bound = [r for r in mine if str(r.get("scenario_id", "")).endswith("@" + th["core_hash"][7:39])]
        if not mine:
            per[tid] = {"status": "missing", "reason": "no adversarial receipt for this threat on the tool's evidence ledger"}
        elif not bound:
            per[tid] = {"status": "stale", "reason": "adversarial receipts predate the current threat definitions"}
        elif any(r.get("verdict") != "PASS" for r in bound):
            per[tid] = {"status": "failed", "reason": "an adversarial receipt bound to the current definitions is not PASS"}
        elif not any(":fail_closed@" in str(r.get("scenario_id", "")) for r in bound):
            per[tid] = {"status": "incomplete", "reason": "no fail_closed receipt (refusal + no unauthorized effect + complete trail) bound to the current definitions"}
        else:
            per[tid] = {"status": "satisfied", "reason": f"{len(bound)} receipt(s) bound to core {th['core_hash'][7:19]}…", "receipts": [r.get("entry_hash") for r in bound][:8]}
        if per[tid]["status"] != "satisfied":
            blocking.append(tid)
    if waivers:
        blocking.append("WAIVER")
        per["WAIVER"] = {"status": "refused", "reason": f"waiver-shaped inputs are refused by name: {waivers}"}
    d = {"record_schema": f"{NS}/ReleaseGateDecision", "decision": "PROCEED" if not blocking else "BLOCK", "threats_core_hash": th["core_hash"], "ledger": str(ledger or gate_ledger_path()), "per_threat": per, "blocking": blocking,
         "evaluated_at": _now(), "rule": "mandatory, non-waivable; evidence read only from the tool's own chained ledger"}
    d["decision_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in d.items() if k not in ("decision_hash", "evaluated_at")}))
    audit("SEC-05", "release_gate", {"decision": d["decision"], "blocking": blocking, "decision_hash": d["decision_hash"]}, run_dir=run_dir, threats=th)
    return d


def require_release_gate(*, stage: str, ledger: Path | None = None, inputs: Mapping[str, Any] | None = None, run_dir: Path | None = None, threats: Mapping[str, Any] | None = None) -> dict[str, Any]:
    d = release_gate(ledger=ledger, threats=threats, inputs=inputs, run_dir=run_dir)
    if d["decision"] != "PROCEED":
        raise SecurityDenial("security.release_gate_blocked", f"{stage}: security regression gate BLOCK on {', '.join(d['blocking'])} — " + "; ".join(f"{t} {d['per_threat'][t]['status']} ({d['per_threat'][t]['reason']})" for t in d["blocking"]), threat_id="SEC-ALL", record=d)
    return d


__all__ += ["GATE_EVIDENCE_KIND", "WAIVER_NAMES", "gate_ledger_path", "gate_scenario", "release_gate", "require_release_gate"]
