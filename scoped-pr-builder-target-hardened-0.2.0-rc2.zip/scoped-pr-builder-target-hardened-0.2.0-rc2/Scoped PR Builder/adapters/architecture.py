"""Scoped PR Builder — architecture boundary registry and crossing checks (Phase 01 / ARCH-*-T01).

``architecture/boundaries.json`` declares every explicit boundary of the Scoped-PR Builder
architecture: its authoritative suite files (which must exist in the repository — exact
binding), trust level, allowed and denied effects, input/output contract ids (from the
contract registry), failure behavior (stable refusal codes), and the overlay surface that
composes it. Each entry carries a passing crossing and violating crossings with the
refusal code expected, executed by ``tests/test_architecture.py``.

``check_crossing`` is the executable boundary: a message may cross only if it names a
registered boundary, carries the canonical identity block (API-07), requests an allowed
effect, and declares a payload contract the boundary accepts. Everything else is refused
with a stable code — no side channel, no fallback.

Build provenance: BUILD_NEW (stdlib); patterns consulted per item are recorded in
``../PROVENANCE.jsonl`` (agents-humanoversight, amplifier-bundle-routing-matrix, LSKV — MIT,
pattern only).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

from . import contracts as C
from . import local_git_adapter as lga

BOUNDARIES_VERSION = "scoped_pr_builder.architecture_boundaries/0.1.0"
BOUNDARIES_PATH = Path(__file__).resolve().parent.parent / "architecture" / "boundaries.json"
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
TRUST_LEVELS = ("untrusted_input", "deterministic_trusted", "advisory_only", "human_authority", "append_only_ledger", "isolated_executor")
ENTRY_REQUIRED = ("boundary_id", "layer", "version", "authoritative_suites", "trust_level", "allowed_effects", "denied_effects", "input_contracts", "output_contracts", "failure_behavior", "overlay_surface", "identity_carried", "introduced_by", "examples")
IDENTITY_MIN = ("run_id", "repository_id", "worktree_id", "base_revision", "source_snapshot_hash", "scope_contract_hash", "policy_hash", "tool_version")


def load_boundaries(path: Path = BOUNDARIES_PATH, *, repo_root: Path = REPO_ROOT, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Load and self-validate the boundary registry (exact suite-file binding, contract refs, examples)."""
    if not Path(path).is_file():
        raise lga.AdapterError("boundary.registry_missing", f"boundary registry not found: {path}")
    reg = json.loads(Path(path).read_text(encoding="utf-8"))
    if reg.get("boundaries_version") != BOUNDARIES_VERSION:
        raise lga.AdapterError("boundary.registry_invalid", "unsupported boundaries_version")
    contracts = (registry or C.load_registry())["contracts"]
    entries = reg.get("boundaries")
    if not isinstance(entries, dict) or not entries:
        raise lga.AdapterError("boundary.registry_invalid", "no boundaries declared")
    for bid, e in entries.items():
        missing = [k for k in ENTRY_REQUIRED if k not in e]
        if missing or e["boundary_id"] != bid:
            raise lga.AdapterError("boundary.registry_invalid", f"{bid}: missing {missing} or id mismatch")
        if e["trust_level"] not in TRUST_LEVELS:
            raise lga.AdapterError("boundary.registry_invalid", f"{bid}: unknown trust level {e['trust_level']!r}")
        if not C.SEMVER_RE.match(e["version"]):
            raise lga.AdapterError("boundary.registry_invalid", f"{bid}: bad version")
        for suite in e["authoritative_suites"]:
            if not (Path(repo_root) / suite["file"]).is_file():
                raise lga.AdapterError("boundary.suite_unbound", f"{bid}: authoritative suite file does not exist: {suite['file']}")
        if set(e["allowed_effects"]) & set(e["denied_effects"]):
            raise lga.AdapterError("boundary.registry_invalid", f"{bid}: an effect is both allowed and denied")
        for cid in e["input_contracts"] + e["output_contracts"]:
            if cid not in contracts:
                raise lga.AdapterError("boundary.registry_invalid", f"{bid}: unknown contract {cid!r}")
        if not set(IDENTITY_MIN) <= set(e["identity_carried"]):
            raise lga.AdapterError("boundary.registry_invalid", f"{bid}: identity_carried lacks the canonical minimum")
        if "valid" not in e["examples"] or not e["examples"].get("invalid"):
            raise lga.AdapterError("boundary.registry_invalid", f"{bid}: examples need one valid and at least one invalid crossing")
        fb = e["failure_behavior"]
        if fb.get("mode") != "fail_closed" or not fb.get("codes"):
            raise lga.AdapterError("boundary.registry_invalid", f"{bid}: failure_behavior must be fail_closed with codes")
    body = {k: v for k, v in reg.items() if k != "boundaries_hash"}
    reg["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return reg


def check_crossing(message: Mapping[str, Any], *, boundaries: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Admit or refuse one boundary crossing; returns a hash-bound crossing receipt on admission."""
    reg = registry or C.load_registry()
    b = boundaries or load_boundaries(registry=reg)
    if not isinstance(message, Mapping):
        raise lga.AdapterError("boundary.malformed", "crossing message must be an object")
    entry = b["boundaries"].get(message.get("boundary_id"))
    if entry is None:
        raise lga.AdapterError("boundary.unknown", f"no such boundary {message.get('boundary_id')!r}")
    identity = message.get("identity")
    if not isinstance(identity, Mapping):
        raise lga.AdapterError("boundary.identity_missing", "crossing carries no identity block")
    try:
        C.validate(C.DEFS["identity"], identity, path="$.identity", registry=reg)
    except C.SchemaError as exc:
        raise lga.AdapterError("boundary.identity_invalid", str(exc)) from exc
    for field in entry["identity_carried"]:
        if field not in identity:
            raise lga.AdapterError("boundary.identity_missing", f"identity lacks {field!r} required by {entry['boundary_id']}")
    effect = message.get("effect")
    if effect in entry["denied_effects"]:
        raise lga.AdapterError("boundary.effect_denied", f"{entry['boundary_id']} denies effect {effect!r}")
    if effect not in entry["allowed_effects"]:
        raise lga.AdapterError("boundary.effect_not_allowed", f"{entry['boundary_id']} does not allow effect {effect!r}")
    direction = message.get("direction")
    if direction not in ("inbound", "outbound"):
        raise lga.AdapterError("boundary.malformed", "direction must be inbound or outbound")
    accepted = entry["input_contracts"] if direction == "inbound" else entry["output_contracts"]
    contract_id = message.get("payload_contract")
    if contract_id not in accepted:
        raise lga.AdapterError("boundary.contract_not_accepted", f"{entry['boundary_id']} does not accept {contract_id!r} {direction}")
    if "payload" in message:
        try:
            C.validate_payload(contract_id, message["payload"], registry=reg)
        except C.SchemaError as exc:
            raise lga.AdapterError("boundary.payload_invalid", str(exc)) from exc
    receipt = {
        "boundary_id": entry["boundary_id"], "boundary_version": entry["version"], "trust_level": entry["trust_level"], "direction": direction,
        "effect": effect, "payload_contract": contract_id, "identity": dict(identity),
        "payload_hash": lga.sha256_digest(lga.canonical_json(message.get("payload"))) if "payload" in message else None,
        "verdict": "ADMITTED",
    }
    receipt["crossing_hash"] = lga.sha256_digest(lga.canonical_json(receipt))
    return receipt


__all__ = ["BOUNDARIES_PATH", "BOUNDARIES_VERSION", "TRUST_LEVELS", "check_crossing", "load_boundaries"]
