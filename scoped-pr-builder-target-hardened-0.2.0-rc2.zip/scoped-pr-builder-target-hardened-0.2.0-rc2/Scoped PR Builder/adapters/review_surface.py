"""Scoped PR Builder — human review and approval surface (Phase 11 / HUMAN-01..07).

``review/REVIEW.json`` declares one reviewer behavior per requirement (what the reviewer can see or do, the typed action,
its explicit side-effect semantics and the authoritative suites — Diff Patch and Review 50.5 for evidence/approval
semantics, 44.4 approvals, 49.14 review history, 66.08 authorization/dispatch). ``adapters/review_surface`` composes the
existing review card (review_renderer), the approval adapter (signed, chained, hash-bound receipts), evidence retrieval
(Suite 51 records) and the workflow artifacts into one reviewer surface: original evidence can be inspected byte-exact at
the pinned revision, the surface states exactly what was and was not analyzed, scope can be narrowed for a rerun, a
rejection has no side effects, additional evidence can be required, every approval carries identity / timestamp /
approved scope, and accountability is always the human's. Everything shown is bound to immutable run/candidate hashes
(T02); every reviewer action is a typed command with identity, authority, scope, timestamp, nonce/idempotency key and
explicit side effects (T03); non-applying actions can never apply and any changed bound input invalidates a prior
approval (T04); UI/accessibility and end-to-end tests prove the actions and the audit trail (T05).

Build provenance: BUILD_NEW (stdlib). Yard candidates inspected and rejected: amplifier-module-hooks-approval (MIT —
async amplifier-core hook; audit rows carry no identity/hash binding), a11y-llm-eval / axe-pipelines-samples (axe via
node), universal-artifact-sdk (research-artifact graph), Consent-Package (JS consent audit).
"""
from __future__ import annotations

import json
import re
import secrets
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Sequence

from . import contracts as C
from . import local_git_adapter as lga
from . import security as _SEC
from .archive_adapter import _chain_append, verify_chain_file

REVIEW_VERSION = "scoped_pr_builder.review/0.1.0"
REVIEW_PATH = Path(__file__).resolve().parent.parent / "review" / "REVIEW.json"
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
ADAPTER_ID = "scoped_pr_builder.review_surface"
ADAPTER_VERSION = "0.1.0"
NS = "overlay.scoped_pr_builder.review"
SURFACE_VERSION = "scoped_pr_builder.review_surface/0.1.0"
BEHAVIOR_REQUIRED = ("behavior_id", "title", "section", "reviewer_action", "side_effects", "authoritative_suites", "introduced_by")
ACTIONS = ("inspect_evidence", "request_evidence", "narrow_scope", "reject", "cancel", "approve")
ACCOUNTABILITY_STATEMENT = "Final accountability for this change rests with the human reviewer who issues the decision; it never rests with the AI, which proposed, verified nothing, decided nothing and holds no authority."


class ReviewRefusal(lga.AdapterError):
    """Raised by the review surface (stale/tampered view, invalid command, widened scope, side effect observed)."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _canon(value: Any) -> Any:
    if hasattr(value, "to_json"):
        return json.loads(value.to_json())
    if isinstance(value, (bytes, bytearray)):
        return {"bytes_sha256": lga.sha256_digest(bytes(value)), "size": len(value)}
    return value


def load_review(path: Path = REVIEW_PATH, *, registry: Mapping[str, Any] | None = None, repo_root: Path = REPO_ROOT) -> dict[str, Any]:
    """Load and validate the review registry: every behavior names its section, its typed reviewer action (one of the closed
    action vocabulary), explicit side-effect semantics and existing authoritative suites."""
    if not Path(path).is_file():
        raise ReviewRefusal("review.registry_missing", f"review registry not found: {path}")
    r = json.loads(Path(path).read_text(encoding="utf-8"))
    if r.get("review_version") != REVIEW_VERSION:
        raise ReviewRefusal("review.registry_invalid", "unsupported review_version")
    for bid, b in (r.get("behaviors") or {}).items():
        missing = [k for k in BEHAVIOR_REQUIRED if k not in b]
        if missing or b["behavior_id"] != bid or not re.match(r"^HUMAN-\d{2}$", bid):
            raise ReviewRefusal("review.registry_invalid", f"{bid}: missing {missing} / id")
        if b["reviewer_action"] not in ACTIONS:
            raise ReviewRefusal("review.registry_invalid", f"{bid}: reviewer_action {b['reviewer_action']!r} is not in the closed action vocabulary")
        se = b["side_effects"]
        if not isinstance(se, Mapping) or "applies_patch" not in se or se["applies_patch"] is not False or not isinstance(se.get("effects"), list):
            raise ReviewRefusal("review.registry_invalid", f"{bid}: side_effects must declare applies_patch=false and an explicit effects list")
        for extra_action, extra in (b.get("additional_actions") or {}).items():
            if extra_action not in ACTIONS or not isinstance(extra, Mapping) or extra.get("applies_patch") is not False or not isinstance(extra.get("effects"), list):
                raise ReviewRefusal("review.registry_invalid", f"{bid}: additional action {extra_action!r} must be in the closed vocabulary and declare applies_patch=false with explicit effects")
        for f in b["authoritative_suites"]:
            if not (Path(repo_root) / f).is_file():
                raise ReviewRefusal("review.suite_unbound", f"{bid}: authoritative suite file does not exist: {f}")
    body = {k: v for k, v in r.items() if k != "review_hash"}
    r["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return r


def behavior_for(action: str, review: Mapping[str, Any]) -> dict[str, Any]:
    """The declared behavior exposing an action — its own reviewer_action, or one of its declared additional actions (each
    with its own explicit side effects; e.g. cancel under the reject-without-side-effects behavior)."""
    for b in review["behaviors"].values():
        if b["reviewer_action"] == action:
            return dict(b)
        extra = (b.get("additional_actions") or {}).get(action)
        if extra is not None:
            return dict(b, reviewer_action=action, side_effects=dict(extra))
    raise ReviewRefusal("review.action_undeclared", f"no declared behavior exposes the action {action!r}")


def _side_effects(action: str, review: Mapping[str, Any]) -> dict[str, Any]:
    try:
        return dict(behavior_for(action, review)["side_effects"])
    except ReviewRefusal:
        return {"applies_patch": False, "effects": [f"{action}: behavior not yet declared — the action is unavailable"], "declared": False}


# ---- HUMAN-01: the reviewer inspects the original evidence ----------------------------------------------------------
def inspect_evidence(root: Path, revision: str, item: Mapping[str, Any]) -> dict[str, Any]:
    """The original evidence, byte-exact at the pinned revision, verified against the record's content hash (Suite 51.1
    exact locator); a blob that no longer hashes to the record is refused — the reviewer never sees substituted evidence."""
    path = PurePosixPath(item["path"] if "path" in item else item["canonical_path"])
    try:
        blob = lga.read_blob(Path(root), revision, path)
    except lga.AdapterError as exc:
        raise ReviewRefusal("review.evidence_missing", f"{path} is not present at {revision[:12]}: {exc}") from exc
    digest = lga.sha256_digest(blob)
    if digest != item["content_hash"]:
        raise ReviewRefusal("review.evidence_mismatch", f"{path}@{revision[:12]} hashes to {digest[:23]}, the record says {item['content_hash'][:23]}")
    br = item.get("byte_range")
    if isinstance(br, str) and re.match(r"^\d+-\d+$", br):  # Suite 51.1 records carry "start-end"
        start, end = (int(x) for x in br.split("-"))
    elif isinstance(br, Mapping):
        start, end = int(br.get("start", 0) or 0), int(br.get("end", len(blob)) or len(blob))
    else:
        start, end = 0, len(blob)
    start, end = max(0, min(start, len(blob))), max(0, min(end, len(blob)))
    text = blob.decode("utf-8", errors="replace")
    return {"record_schema": f"{NS}/OriginalEvidence", "evidence_id": item.get("evidence_id"), "path": str(path), "revision": revision, "locator": item.get("locator") or item.get("exact_locator"), "content_hash": digest, "verified": True,
            "size": len(blob), "byte_range": {"start": start, "end": end}, "excerpt": _SEC.protect_secrets(blob[start:end].decode("utf-8", errors="replace")[:4000], "ui"), "text": _SEC.protect_secrets(text[:20000], "ui"), "authority": "display_only"}


def _evidence_items(card: Mapping[str, Any], bundle: Mapping[str, Any] | None) -> list[dict[str, Any]]:
    by_path = {e["canonical_path"]: e for e in (bundle or {}).get("evidence", [])}
    items = []
    for i in card["evidence_summary"]["items"]:
        e = by_path.get(i["path"], {})
        items.append({"evidence_id": e.get("evidence_id"), "path": i["path"], "kind": i["kind"], "locator": i["locator"], "content_hash": i["content_hash"], "byte_range": e.get("byte_range"), "score": i.get("score"), "trust": (i.get("trust") or {}).get("origin", "untrusted"),
                      "inspect": {"how": "review_surface.inspect_evidence(root, base_revision, item)", "verifies": "sha256 of the blob at the pinned revision == content_hash", "authority": "display_only"}})
    return items


# ---- HUMAN-02: exactly what was and was not analyzed ---------------------------------------------------------------
def analysis_coverage(card: Mapping[str, Any], bundle: Mapping[str, Any] | None, report: Mapping[str, Any], intake: Mapping[str, Mapping[str, Any]] | None, contract: Mapping[str, Any], model_call: Mapping[str, Any] | None, check_results: Sequence[Mapping[str, Any]] | None) -> dict[str, Any]:
    """Two explicit lists — analyzed and NOT analyzed — over intake sources, evidence, checks and model calls; nothing is
    inferred over what was excluded, blocked or never retrieved."""
    jobs = {j["check"]: j for j in report.get("jobs", [])}
    executed = sorted(c for c, j in jobs.items() if j["verdict"] in ("PASS", "FAIL"))
    not_executed = sorted(c for c, j in jobs.items() if j["verdict"] not in ("PASS", "FAIL"))
    typed = {r["check_id"]: r["result"] for r in (check_results or [])}
    ev = (bundle or {}).get("evidence", [])
    targets = [e for e in ev if e["evidence_kind"] == "target_source"]; examples = [e for e in ev if e["evidence_kind"] == "analogous_example"]
    admitted, non_admitted, excluded = [], [], []
    for sid, rec in sorted((intake or {}).items()):
        (admitted if rec.get("state") == "ADMITTED" else non_admitted).append({"source_id": sid, "state": rec.get("state"), "items": (rec.get("counts") or {}).get("items", 0), "excluded": (rec.get("counts") or {}).get("excluded", 0)})
        excluded += [{"source_id": sid, **({"path": x.get("path"), "reason": x.get("reason")} if isinstance(x, Mapping) else {"item": str(x)})} for x in (rec.get("excluded") or [])[:50]]
    corpus = int((bundle or {}).get("corpus_size") or 0)
    analyzed = {"intake_sources_admitted": admitted, "evidence_targets": [e["canonical_path"] for e in targets], "evidence_examples": [e["canonical_path"] for e in examples], "checks_executed": executed,
                "typed_results": {k: v for k, v in typed.items() if v in ("pass", "fail")}, "model_calls": [{"provider": model_call.get("provider"), "route": (model_call.get("route") or {}).get("route"), "call_id": model_call.get("call_id")}] if model_call else []}
    not_analyzed = {"intake_sources_not_admitted": non_admitted, "intake_items_excluded": excluded, "checks_not_executed": not_executed, "typed_results_not_pass_fail": {k: v for k, v in typed.items() if v not in ("pass", "fail")},
                    "corpus_files_not_retrieved": max(corpus - len(ev), 0), "forbidden_paths": list(contract.get("forbidden_paths", [])), "evidence_gaps": list(card["evidence_summary"].get("gaps", [])),
                    "model_reasoning": "advisory plan only — no model verified, approved or applied anything" if model_call else "no model call recorded"}
    statement = (f"Analyzed: {len(admitted)} admitted intake source(s), {len(targets)} target(s) and {len(examples)} analogous example(s) out of {corpus} corpus file(s), {len(executed)} executed check(s). "
                 f"NOT analyzed: {len(non_admitted)} non-admitted source(s), {len(excluded)} excluded item(s), {len(not_executed)} unexecuted check(s), {max(corpus - len(ev), 0)} file(s) never retrieved.")
    return {"analyzed": analyzed, "not_analyzed": not_analyzed, "statement": statement, "authority": "display_only"}


# ---- HUMAN-03: narrow scope and rerun ----------------------------------------------------------------------------------
def narrow_scope(contract: Mapping[str, Any], *, allowed_paths: Sequence[str], max_changed_files: int | None = None, max_diff_lines: int | None = None, title: str | None = None, description: str | None = None) -> dict[str, Any]:
    """A narrowed intent for a rerun: allowed paths must lie within the current allowed roots (never widened), limits may only
    shrink; the result is a NEW intent (→ new scope contract → new run) — no candidate or approval carries over."""
    current = [PurePosixPath(p) for p in contract["allowed_paths"]]
    new = [str(lga.relative_path(str(p))) for p in allowed_paths]
    if not new:
        raise ReviewRefusal("review.scope_empty", "a narrowed scope needs at least one allowed path")
    widened = [p for p in new if not lga.within(PurePosixPath(p), current)]
    if widened:
        raise ReviewRefusal("review.scope_widening", f"narrowing cannot add paths outside the current scope: {widened[:5]}")
    files = int(max_changed_files if max_changed_files is not None else contract["max_changed_files"]); lines = int(max_diff_lines if max_diff_lines is not None else contract["max_diff_lines"])
    if files > int(contract["max_changed_files"]) or lines > int(contract["max_diff_lines"]) or files < 1 or lines < 1:
        raise ReviewRefusal("review.scope_widening", "limits may only shrink (and must stay positive)")
    intent = {"kind": contract["intent_kind"], "title": (title or contract["title"]).strip(), "description": (description or contract["description"]).strip(), "allowed_paths": sorted(set(new)), "forbidden_paths": list(contract.get("forbidden_paths", [])),
              "max_changed_files": files, "max_diff_lines": lines, "requested_by": contract["requested_by"]}
    return {"record_schema": f"{NS}/RerunIntent", "narrowed_from": contract["scope_contract_hash"], "intent": intent, "semantics": "new intent → new scope contract hash → new run; the previous candidate, verification and approval do not carry over", "intent_hash": lga.sha256_digest(lga.canonical_json(intent))}


# ---- HUMAN-06: the approval record ---------------------------------------------------------------------------------------
def approval_record(receipt: Mapping[str, Any], contract: Mapping[str, Any], candidate: Mapping[str, Any]) -> dict[str, Any]:
    """Identity, channel, timestamp and the exact approved scope of one decision (derived from the signed receipt; never edited)."""
    return {"record_schema": f"{NS}/ApprovalRecord", "decision": receipt["decision"], "identity": receipt["approver_identity"], "channel": receipt["approver_channel"], "issued_at": receipt["issued_at"], "expires_at": receipt.get("expires_at"),
            "approved_scope": {"scope_contract_hash": receipt["scope_contract_hash"], "allowed_paths": list(contract["allowed_paths"]), "forbidden_paths": list(contract.get("forbidden_paths", [])), "candidate_paths": list(candidate["canonical_paths"]), "patch_hash": receipt["patch_hash"], "base_revision": receipt["base_revision"],
                               "limits": {"max_changed_files": contract["max_changed_files"], "max_diff_lines": contract["max_diff_lines"]}},
            "receipt_hash": receipt["receipt_hash"], "rationale": receipt.get("rationale", "")}


# ---- HUMAN-07: accountability -----------------------------------------------------------------------------------------
def accountability(receipts: Sequence[Mapping[str, Any]], model_call: Mapping[str, Any] | None) -> dict[str, Any]:
    latest = receipts[-1] if receipts else None
    return {"accountable_party": "human reviewer", "decided_by": f"{latest['approver_identity']} via {latest['approver_channel']} ({latest['decision']})" if latest else "no decision yet — pending a human reviewer",
            "ai_role": "advisory only", "ai_may": ["propose an advisory plan over labeled evidence"], "ai_cannot": ["decide", "approve", "verify", "apply", "hold accountability"],
            "model": {"provider": (model_call or {}).get("provider")} if model_call else None, "statement": ACCOUNTABILITY_STATEMENT}


# ---- the surface -------------------------------------------------------------------------------------------------------
def build_surface(artifacts: Mapping[str, Any], *, run_id: str | None = None, run_dir: Path | None = None, review: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """The reviewer surface for one run: seven sections, one per declared behavior, over the run's own artifacts (binding,
    scope contract, evidence bundle, intake records, plan, candidate, patch, verification report, review card, check results,
    model call, approval chain). Display-only; nothing here records or implies a decision."""
    rv = review or load_review(registry=registry)
    binding = _canon(artifacts["binding"]); contract = artifacts["scope_contract"]; card = artifacts["review_card"]; cand = artifacts["candidate"]; report = artifacts["verification_report"]; patch = artifacts["patch"]
    bundle = artifacts.get("evidence_bundle"); intake = artifacts.get("intake_records"); results = artifacts.get("check_results"); plan = artifacts.get("refactoring_plan") or {}
    model_call = artifacts.get("model_call")
    if model_call is None and run_dir is not None and (Path(run_dir) / "model" / "call.json").is_file():
        model_call = json.loads((Path(run_dir) / "model" / "call.json").read_text(encoding="utf-8"))
    receipts = list(artifacts.get("approval_chain") or [])
    if not receipts and run_dir is not None:
        from . import approval_adapter as _aa
        receipts = [r for r in _aa.load_chain(Path(run_dir)) if r.get("candidate_id") == cand["candidate_id"]]
    if card["identity"]["candidate_id"] != cand["candidate_id"] or card["identity"]["patch_hash"] != cand["patch_hash"] or report["candidate_id"] != cand["candidate_id"] or lga.sha256_digest(bytes(patch)) != cand["patch_hash"]:
        raise ReviewRefusal("review.artifact_mismatch", "card, report and patch must describe the same candidate")
    if contract["scope_contract_hash"] != cand["scope_contract_hash"] or binding["base_revision"] != cand["base_revision"]:
        raise ReviewRefusal("review.artifact_mismatch", "candidate is bound to another scope contract or revision")
    sections = {
        "HUMAN-01": {"section": "evidence_inspection", "revision": binding["base_revision"], "repository_root": binding["root_path"], "items": _evidence_items(card, bundle), "original_evidence_available": True, "note": "every item is inspectable byte-exact at the pinned revision; a blob that no longer hashes to its record is refused"},
        "HUMAN-02": {"section": "analysis_coverage", **analysis_coverage(card, bundle, report, intake, contract, model_call, results)},
        "HUMAN-03": {"section": "scope_controls", "current": {"scope_contract_hash": contract["scope_contract_hash"], "allowed_paths": list(contract["allowed_paths"]), "forbidden_paths": list(contract.get("forbidden_paths", [])), "max_changed_files": contract["max_changed_files"], "max_diff_lines": contract["max_diff_lines"]},
                     "narrowing_rule": "allowed paths must lie within the current allowed roots; limits may only shrink; widening is refused", "rerun_semantics": "a narrowed scope is a new intent → new scope contract → new run; no candidate, verification or approval carries over", "action": "narrow_scope"},
        "HUMAN-04": {"section": "rejection_controls", "action": "reject", "side_effects": _side_effects("reject", rv), "guarantees": ["no isolated application", "source worktree untouched", "no archive", "any earlier APPROVE for this candidate is superseded"]},
        "HUMAN-05": {"section": "evidence_request_controls", "action": "request_evidence", "fields": ["paths", "kinds", "question"], "side_effects": _side_effects("request_evidence", rv), "guarantees": ["run cannot reach APPROVED until a human decides again over evidence that includes the request", "no repository effect"]},
        "HUMAN-06": {"section": "approval_record", "decisions": [approval_record(r, contract, cand) for r in receipts], "pending": not any(r["decision"] == "APPROVE" for r in receipts), "records": ["identity", "channel", "timestamp (issued_at / expires_at)", "approved scope (scope contract hash, allowed/forbidden paths, candidate paths, patch hash, base revision, limits)"]},
        "HUMAN-07": {"section": "accountability", **accountability(receipts, model_call)},
    }
    for bid, s in sections.items():
        b = rv["behaviors"].get(bid)
        s["behavior_id"] = bid; s["title"] = b["title"] if b else None; s["declared"] = b is not None; s["authority"] = "display_only"
    surface = {"record_schema": f"{NS}/ReviewSurface", "surface_version": SURFACE_VERSION, "renderer": f"{ADAPTER_ID}/{ADAPTER_VERSION}", "authority": "display_only", "run_id": run_id,
               "identity": {"candidate_id": cand["candidate_id"], "patch_hash": cand["patch_hash"], "base_revision": binding["base_revision"], "scope_contract_hash": contract["scope_contract_hash"], "report_hash": report["report_hash"], "card_hash": card["card_hash"], "repository_id": binding["repository_id"], "source_snapshot_hash": binding["source_snapshot_hash"], "plan_hash": plan.get("plan_hash")},
               "review_hash": rv["computed_hash"], "sections": sections, "verification_verdict": report["verdict"], "blocking_risk": card["risk_summary"]["blocking_risk"], "available_actions": [b["reviewer_action"] for b in rv["behaviors"].values()], "rendered_at": _now()}
    return surface


def _e(value: Any) -> str:
    import html as _h
    return _h.escape(str(value), quote=True)


def _rows(rows: Sequence[tuple[str, Any]]) -> str:
    return "<table><tbody>" + "".join(f"<tr><th scope='row'>{_e(k)}</th><td>{_e(v)}</td></tr>" for k, v in rows) + "</tbody></table>"


def render_surface_html(surface: Mapping[str, Any]) -> str:
    """Deterministic, script-free, landmarked HTML for the reviewer surface: one labelled region per section, tables with
    header cells, every action a labelled form (identity, rationale, submit) — nothing on the page can record a decision."""
    s = surface["sections"]; ident = surface["identity"]
    ev = "".join(f"<tr><td>{_e(i['kind'])}</td><td>{_e(i['path'])}</td><td class='mono'>{_e(i['locator'])}</td><td class='mono'>{_e((i['content_hash'] or '')[7:23])}</td><td>{_e(i['trust'])}</td></tr>" for i in s["HUMAN-01"]["items"])
    cov = s["HUMAN-02"]
    decisions = "".join(f"<tr><td>{_e(d['decision'])}</td><td>{_e(d['identity'])}</td><td>{_e(d['channel'])}</td><td>{_e(d['issued_at'])}</td><td class='mono'>{_e(d['approved_scope']['scope_contract_hash'][7:23])} · {_e(', '.join(d['approved_scope']['candidate_paths']))}</td></tr>" for d in s["HUMAN-06"]["decisions"]) or "<tr><td colspan='5'>no decision yet — pending a human reviewer</td></tr>"

    def form(action: str, label: str, extra: str = "") -> str:
        a = _e(action)
        return (f"<form method='post' action='#command' aria-labelledby='h-{a}'><h3 id='h-{a}'>{_e(label)}</h3><input type='hidden' name='action' value='{a}'>"
                f"<p><label for='{a}-identity'>Reviewer identity</label> <input id='{a}-identity' name='identity' type='text' required></p>"
                f"<p><label for='{a}-rationale'>Rationale</label> <textarea id='{a}-rationale' name='rationale' rows='2'></textarea></p>{extra}"
                f"<p><button type='submit'>{_e(label)}</button></p></form>")
    return _SEC.enforce_sec06_export("review_surface.html", f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Scoped PR Builder — Reviewer surface {_e(ident['candidate_id'][7:19])}</title>
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; form-action 'none'">
<style>
body{{font:14px/1.5 system-ui,sans-serif;margin:0;padding:24px;color:#1b1b1b;background:#fff}} h1{{font-size:22px}} h2{{font-size:17px;margin-top:28px;border-bottom:1px solid #ccc;padding-bottom:4px}}
table{{border-collapse:collapse;width:100%;margin:8px 0}} th,td{{text-align:left;vertical-align:top;padding:4px 8px;border-bottom:1px solid #ddd}} th{{color:#333;font-weight:600}}
.mono{{font-family:ui-monospace,monospace;font-size:12px}} form{{border:1px solid #999;padding:12px;margin:8px 0;background:#f7f7f7}} label{{font-weight:600}}
button{{font:inherit;padding:6px 12px;border:2px solid #1b1b1b;background:#fff;color:#1b1b1b}} button:focus,input:focus,textarea:focus,a:focus{{outline:3px solid #005a9c;outline-offset:2px}}
.banner{{padding:12px 16px;border:2px solid #1b1b1b;font-weight:600}} .skip{{position:absolute;left:-999px}} .skip:focus{{left:8px;top:8px}}
</style></head><body>
<a class="skip" href="#main">Skip to main content</a>
<header role="banner"><h1>Scoped PR Builder — Human review</h1>
<p class="banner" role="status">Verification {_e(surface['verification_verdict'])} · blocking risk: {_e(surface['blocking_risk'])} · authority: {_e(surface['authority'])}</p></header>
<nav aria-label="Review sections"><ul>{''.join(f"<li><a href='#sec-{_e(b)}'>{_e(b)} — {_e(sec['title'] or sec['section'])}</a></li>" for b, sec in s.items())}</ul></nav>
<main id="main">
<section id="sec-identity" aria-labelledby="h-identity"><h2 id="h-identity">Identity (hash-bound)</h2>{_rows(list(ident.items()))}</section>
<section id="sec-HUMAN-01" aria-labelledby="h-HUMAN-01"><h2 id="h-HUMAN-01">HUMAN-01 — {_e(s['HUMAN-01']['title'])}</h2>
<p>Original evidence at revision <span class="mono">{_e(s['HUMAN-01']['revision'][:12])}</span>; each item is inspectable byte-exact and verified against its content hash.</p>
<table><caption>Evidence items</caption><thead><tr><th scope="col">kind</th><th scope="col">path</th><th scope="col">locator</th><th scope="col">content hash</th><th scope="col">trust</th></tr></thead><tbody>{ev}</tbody></table>
{form('inspect_evidence', 'Inspect original evidence', "<p><label for='inspect_evidence-path'>Evidence path</label> <input id='inspect_evidence-path' name='path' type='text' required></p>")}</section>
<section id="sec-HUMAN-02" aria-labelledby="h-HUMAN-02"><h2 id="h-HUMAN-02">HUMAN-02 — {_e(s['HUMAN-02']['title'])}</h2><p>{_e(cov['statement'])}</p>
<h3>Analyzed</h3>{_rows([(k, v if not isinstance(v, (list, dict)) else json.dumps(v, sort_keys=True)[:600]) for k, v in cov['analyzed'].items()])}
<h3>Not analyzed</h3>{_rows([(k, v if not isinstance(v, (list, dict)) else json.dumps(v, sort_keys=True)[:600]) for k, v in cov['not_analyzed'].items()])}</section>
<section id="sec-HUMAN-03" aria-labelledby="h-HUMAN-03"><h2 id="h-HUMAN-03">HUMAN-03 — {_e(s['HUMAN-03']['title'])}</h2>{_rows(list(s['HUMAN-03']['current'].items()))}<p>{_e(s['HUMAN-03']['narrowing_rule'])} {_e(s['HUMAN-03']['rerun_semantics'])}</p>
{form('narrow_scope', 'Narrow scope and rerun', "<p><label for='narrow_scope-paths'>Allowed paths (subset)</label> <input id='narrow_scope-paths' name='allowed_paths' type='text' required></p>")}</section>
<section id="sec-HUMAN-04" aria-labelledby="h-HUMAN-04"><h2 id="h-HUMAN-04">HUMAN-04 — {_e(s['HUMAN-04']['title'])}</h2><p>Side effects: {_e('; '.join(s['HUMAN-04']['side_effects']['effects']))}. Guarantees: {_e('; '.join(s['HUMAN-04']['guarantees']))}.</p>{form('reject', 'Reject (no side effects)')}</section>
<section id="sec-HUMAN-05" aria-labelledby="h-HUMAN-05"><h2 id="h-HUMAN-05">HUMAN-05 — {_e(s['HUMAN-05']['title'])}</h2><p>Side effects: {_e('; '.join(s['HUMAN-05']['side_effects']['effects']))}.</p>
{form('request_evidence', 'Require additional evidence', "<p><label for='request_evidence-question'>What evidence is required</label> <textarea id='request_evidence-question' name='question' rows='2' required></textarea></p>")}</section>
<section id="sec-HUMAN-06" aria-labelledby="h-HUMAN-06"><h2 id="h-HUMAN-06">HUMAN-06 — {_e(s['HUMAN-06']['title'])}</h2>
<table><caption>Decisions recorded (identity, channel, timestamp, approved scope)</caption><thead><tr><th scope="col">decision</th><th scope="col">identity</th><th scope="col">channel</th><th scope="col">issued at</th><th scope="col">approved scope</th></tr></thead><tbody>{decisions}</tbody></table>
{form('approve', 'Approve (records a hash-bound receipt; application happens only at WF-11 after fresh revalidation)')}</section>
<section id="sec-HUMAN-07" aria-labelledby="h-HUMAN-07"><h2 id="h-HUMAN-07">HUMAN-07 — {_e(s['HUMAN-07']['title'])}</h2>{_rows([('accountable party', s['HUMAN-07']['accountable_party']), ('decided by', s['HUMAN-07']['decided_by']), ('AI role', s['HUMAN-07']['ai_role']), ('AI cannot', ', '.join(s['HUMAN-07']['ai_cannot']))])}<p><strong>{_e(s['HUMAN-07']['statement'])}</strong></p></section>
</main>
<footer role="contentinfo"><p class="mono">surface {_e(surface.get('view_hash') or 'unbound')} · rendered {_e(surface['rendered_at'])} · {_e(surface['renderer'])} · authority: {_e(surface['authority'])}</p></footer>
</body></html>
""")


__all__ = ["ACCOUNTABILITY_STATEMENT", "ACTIONS", "ADAPTER_ID", "ADAPTER_VERSION", "REVIEW_PATH", "REVIEW_VERSION", "SURFACE_VERSION", "ReviewRefusal", "accountability", "analysis_coverage", "approval_record", "behavior_for", "build_surface", "inspect_evidence", "load_review", "narrow_scope", "render_surface_html"]



# --------------------------------------------------------------------------- #
# T02 — everything displayed (diff, findings, evidence links, uncertainty state, verification results, rollback plan,
# requested actions) is bound to immutable run/candidate hashes; a view whose binding no longer matches the artifacts is
# stale and refused; a view whose section hashes do not recompute was tampered with
# --------------------------------------------------------------------------- #
BOUND_FIELDS_VIEW = ("run_id", "candidate_id", "patch_hash", "base_revision", "scope_contract_hash", "report_hash", "card_hash", "evidence_set_hash", "source_snapshot_hash")


def evidence_set_hash(artifacts: Mapping[str, Any]) -> str:
    """Identity of the exact evidence set the reviewer is shown (sorted evidence ids + content hashes)."""
    ev = (artifacts.get("evidence_bundle") or {}).get("evidence") or []
    ids = sorted(f"{e['evidence_id']}:{e['content_hash']}" for e in ev) if ev else sorted(f"{i['path']}:{i['content_hash']}" for i in artifacts["review_card"]["evidence_summary"]["items"])
    return lga.sha256_digest(lga.canonical_json(ids))


def view_binding(artifacts: Mapping[str, Any], *, run_id: str | None = None) -> dict[str, Any]:
    """The immutable identities every displayed item is bound to (run, candidate, patch, revision, scope, report, card,
    evidence set, snapshot)."""
    b = _canon(artifacts["binding"]); cand = artifacts["candidate"]; card = artifacts["review_card"]; report = artifacts["verification_report"]
    return {"run_id": run_id, "candidate_id": cand["candidate_id"], "patch_hash": cand["patch_hash"], "base_revision": b["base_revision"], "scope_contract_hash": cand["scope_contract_hash"], "report_hash": report["report_hash"], "card_hash": card["card_hash"],
            "evidence_set_hash": evidence_set_hash(artifacts), "source_snapshot_hash": b["source_snapshot_hash"]}


def _displayed_items(surface: Mapping[str, Any], artifacts: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    """The seven kinds of displayed things the task names, each reduced to the identity it must be bound to."""
    card = artifacts["review_card"]; cand = artifacts["candidate"]; report = artifacts["verification_report"]; plan = artifacts.get("refactoring_plan") or {}
    s = surface["sections"]
    return {"diff": {"patch_hash": cand["patch_hash"], "source_diff_hash": cand.get("source_diff_hash"), "text_hash": lga.sha256_digest(card["unified_diff"]["text"])},
            "findings": {"guardrails_hash": (card.get("guardrails") or {}).get("fragment_hash"), "intake_hash": (card.get("intake") or {}).get("fragment_hash"), "preconditions": card["preconditions"]},
            "evidence_links": {"evidence_set_hash": evidence_set_hash(artifacts), "items": [{"path": i["path"], "content_hash": i["content_hash"], "locator": i["locator"]} for i in s["HUMAN-01"]["items"]]},
            "uncertainty_state": {"uncertainty": card["risk_summary"]["uncertainty"], "blocking_risk": card["risk_summary"]["blocking_risk"], "coverage_statement": s["HUMAN-02"]["statement"]},
            "verification_results": {"report_hash": report["report_hash"], "verdict": report["verdict"], "checks": {c: j["verdict"] for c, j in card["verification"]["checks"].items()}},
            "rollback_plan": {"checkpoint_revision": card["rollback_summary"]["checkpoint_revision"], "method": card["rollback_summary"]["method"], "plan_hash": plan.get("plan_hash")},
            "requested_actions": {"available": list(surface["available_actions"]), "controls": {bid: {"action": sec.get("action"), "side_effects": sec.get("side_effects")} for bid, sec in s.items() if sec.get("action")}}}


def bind_view(surface: Mapping[str, Any], artifacts: Mapping[str, Any], *, run_id: str | None = None) -> dict[str, Any]:
    """Seal the surface: every section and every displayed item carries ``bound_to`` (the immutable identities) and a hash;
    the whole view gets a ``view_hash`` the reviewer's commands and the audit trail refer to."""
    bound = view_binding(artifacts, run_id=run_id if run_id is not None else surface.get("run_id"))
    out = json.loads(lga.canonical_json({k: v for k, v in surface.items() if k not in ("view_hash", "bound_to", "displayed", "section_hashes", "rendered_at")}))
    for bid, sec in out["sections"].items():
        sec["bound_to"] = dict(bound)
        sec["section_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in sec.items() if k != "section_hash"}))
    displayed = _displayed_items(out, artifacts)
    out["displayed"] = {k: {"content": v, "bound_to": dict(bound), "item_hash": lga.sha256_digest(lga.canonical_json({"kind": k, "content": v, "bound_to": bound}))} for k, v in displayed.items()}
    out["bound_to"] = bound
    out["section_hashes"] = {bid: sec["section_hash"] for bid, sec in out["sections"].items()}
    out["view_hash"] = lga.sha256_digest(lga.canonical_json({"identity": out["identity"], "bound_to": bound, "sections": out["section_hashes"], "displayed": {k: v["item_hash"] for k, v in out["displayed"].items()}, "review_hash": out["review_hash"]}))
    out["rendered_at"] = surface.get("rendered_at") or _now()
    return out


def verify_view(surface: Mapping[str, Any], artifacts: Mapping[str, Any], *, run_id: str | None = None) -> dict[str, Any]:
    """Fail closed unless the bound view still describes exactly these artifacts (stale → review.view_stale) and every
    section/item hash recomputes (tampered → review.view_tampered)."""
    if not surface.get("view_hash") or not surface.get("bound_to"):
        raise ReviewRefusal("review.view_unbound", "the surface was never bound; nothing shown can be acted upon")
    current = view_binding(artifacts, run_id=run_id if run_id is not None else surface.get("run_id"))
    stale = [k for k in BOUND_FIELDS_VIEW if surface["bound_to"].get(k) != current.get(k)]
    if stale:
        raise ReviewRefusal("review.view_stale", f"the view is bound to other artifacts: {stale}")
    for bid, sec in surface["sections"].items():
        if sec.get("bound_to") != surface["bound_to"] or lga.sha256_digest(lga.canonical_json({k: v for k, v in sec.items() if k != "section_hash"})) != sec.get("section_hash"):
            raise ReviewRefusal("review.view_tampered", f"section {bid} does not recompute to its hash")
    for k, v in surface["displayed"].items():
        if lga.sha256_digest(lga.canonical_json({"kind": k, "content": v["content"], "bound_to": v["bound_to"]})) != v["item_hash"] or v["bound_to"] != surface["bound_to"]:
            raise ReviewRefusal("review.view_tampered", f"displayed item {k} does not recompute to its hash")
    expected = lga.sha256_digest(lga.canonical_json({"identity": surface["identity"], "bound_to": surface["bound_to"], "sections": {bid: sec["section_hash"] for bid, sec in surface["sections"].items()}, "displayed": {k: v["item_hash"] for k, v in surface["displayed"].items()}, "review_hash": surface["review_hash"]}))
    if expected != surface["view_hash"]:
        raise ReviewRefusal("review.view_tampered", "view_hash does not recompute")
    return {"view_hash": surface["view_hash"], "bound_to": dict(surface["bound_to"]), "sections": len(surface["sections"]), "displayed": sorted(surface["displayed"])}


__all__ += ["BOUND_FIELDS_VIEW", "bind_view", "evidence_set_hash", "verify_view", "view_binding"]



# --------------------------------------------------------------------------- #
# T03 — every allowed reviewer action is a typed command: identity, authority, scope (the bound view), timestamp, nonce and
# idempotency key, and explicit side-effect semantics declared by the registry; executed once, replayed never
# --------------------------------------------------------------------------- #
COMMAND_VERSION = "0.1.0"
COMMAND_FIELDS = {"inspect_evidence": ("path",), "request_evidence": ("question",), "narrow_scope": ("allowed_paths",), "reject": (), "cancel": (), "approve": ()}
RATIONALE_REQUIRED = ("request_evidence", "narrow_scope", "reject", "approve")
RECEIPT_DECISION = {"request_evidence": "REQUEST_CHANGES", "narrow_scope": "REQUEST_CHANGES", "reject": "REJECT", "approve": "APPROVE"}


def _identity_ref(identity: str, channel: str) -> dict[str, Any]:
    return {"identity_digest": lga.sha256_digest(identity.strip()), "channel": channel.strip()}


def issue_command(action: str, *, identity: str, channel: str, surface: Mapping[str, Any], rationale: str = "", fields: Mapping[str, Any] | None = None, nonce: str | None = None, review: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None, now: str | None = None) -> dict[str, Any]:
    """A contract-valid reviewer command over a bound view. The authority is the human's (never the tool's, never a model's);
    the scope is the exact bound identities of what the reviewer was shown; the side effects are the registry's, verbatim."""
    rv = review or load_review(registry=registry)
    if action not in ACTIONS:
        raise ReviewRefusal("review.action_invalid", f"unknown reviewer action {action!r}")
    b = behavior_for(action, rv)
    if not surface.get("view_hash") or not surface.get("bound_to"):
        raise ReviewRefusal("review.view_unbound", "a command needs a bound view — nothing unbound can be acted upon")
    _SEC.require_human_channel(channel, identity=identity)  # SEC-07: a model/content channel cannot issue a reviewer command
    if not identity.strip() or len(identity.strip()) < 3:
        raise ReviewRefusal("review.identity_missing", "reviewer identity is required")
    f = dict(fields or {})
    missing = [k for k in COMMAND_FIELDS[action] if k not in f or f[k] in (None, "", [])]
    if missing:
        raise ReviewRefusal("review.command_fields_missing", f"{action} requires {missing}")
    if action in RATIONALE_REQUIRED and not rationale.strip():
        raise ReviewRefusal("review.rationale_required", f"{action} requires a rationale")
    if action == "approve" and (surface.get("verification_verdict") != "PASS" or surface.get("blocking_risk")):
        raise ReviewRefusal("review.approve_blocked", "the surface shows a blocking risk or a non-PASS verification; approval is not offered")
    bound = surface["bound_to"]
    n = nonce or secrets.token_hex(16)
    if not re.match(r"^[0-9a-f]{32}$", n):
        raise ReviewRefusal("review.nonce_invalid", "nonce must be 32 hex characters")
    body = {"record_schema": f"{NS}/ReviewerCommand", "command_version": COMMAND_VERSION, "action": action, "identity": identity.strip(), "channel": channel.strip(),
            "authority": {"role": "human_reviewer", "declared_by": "human", "basis": f"{b['behavior_id']} {b['title']} — {b['authoritative_suites'][0]}"},
            "scope": {"run_id": bound.get("run_id"), "candidate_id": bound["candidate_id"], "patch_hash": bound["patch_hash"], "base_revision": bound["base_revision"], "scope_contract_hash": bound["scope_contract_hash"], "card_hash": bound["card_hash"], "report_hash": bound["report_hash"], "evidence_set_hash": bound["evidence_set_hash"], "view_hash": surface["view_hash"]},
            "issued_at": now or _now(), "nonce": n, "side_effects": {"applies_patch": False, "effects": list(b["side_effects"]["effects"]), "records": list(b["side_effects"].get("records", []))}, "fields": f, "rationale": rationale.strip()}
    body["idempotency_key"] = lga.sha256_digest(lga.canonical_json({"action": action, "identity": body["identity"], "channel": body["channel"], "scope": body["scope"], "fields": f, "nonce": n}))
    body["command_hash"] = lga.sha256_digest(lga.canonical_json(body))
    C.validate_payload("reviewer_command", body, registry=registry)
    return body


def commands_path(run_dir: Path) -> Path:
    return Path(run_dir).resolve() / "review" / "commands.jsonl"


def audit_path(run_dir: Path) -> Path:
    return Path(run_dir).resolve() / "review" / "audit.jsonl"


def _ledger_rows(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    verify_chain_file(path)
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]


def commands(run_dir: Path) -> list[dict[str, Any]]:
    return _ledger_rows(commands_path(run_dir))


def audit_trail(run_dir: Path) -> list[dict[str, Any]]:
    return _ledger_rows(audit_path(run_dir))


def _receipt(run_dir: Path, key: bytes | None, decision: str, cmd: Mapping[str, Any], artifacts: Mapping[str, Any], rationale: str):
    from . import approval_adapter as _aa
    if not isinstance(key, (bytes, bytearray)):
        raise ReviewRefusal("review.key_required", f"{cmd['action']} records a {decision} receipt and needs the approval ledger key")
    r = _aa.issue_receipt(Path(run_dir), bytes(key), decision=decision, approver_identity=cmd["identity"], approver_channel=cmd["channel"], rationale=rationale, candidate=artifacts["candidate"], card=artifacts["review_card"], report=artifacts["verification_report"])
    return json.loads(r.to_json())


def _dispatch(run_dir: Path, cmd: Mapping[str, Any], artifacts: Mapping[str, Any], surface: Mapping[str, Any], key: bytes | None) -> dict[str, Any]:
    action, f = cmd["action"], cmd["fields"]
    binding = _canon(artifacts["binding"]); contract = artifacts["scope_contract"]
    if action == "inspect_evidence":
        items = [i for i in surface["sections"]["HUMAN-01"]["items"] if i["path"] == f["path"]]
        if not items:
            raise ReviewRefusal("review.evidence_unknown", f"{f['path']} is not among the evidence shown")
        ev = inspect_evidence(Path(binding["root_path"]), binding["base_revision"], items[0])
        return {"evidence": ev, "receipt_hash": None}
    if action == "request_evidence":
        rec = _receipt(run_dir, key, "REQUEST_CHANGES", cmd, artifacts, f"request_evidence: {f['question']} — {cmd['rationale']}")
        row = _chain_append(Path(run_dir).resolve() / "review" / "evidence_requests.jsonl", {"record_schema": f"{NS}/EvidenceRequest", "command_hash": cmd["command_hash"], "candidate_id": cmd["scope"]["candidate_id"], "question": str(f["question"])[:1000], "paths": list(f.get("paths") or []), "kinds": list(f.get("kinds") or []), "receipt_hash": rec["receipt_hash"], "requested_at": _now()})
        return {"receipt_hash": rec["receipt_hash"], "request_hash": row["entry_hash"], "decision": "REQUEST_CHANGES"}
    if action == "narrow_scope":
        rerun = narrow_scope(contract, allowed_paths=list(f["allowed_paths"]), max_changed_files=f.get("max_changed_files"), max_diff_lines=f.get("max_diff_lines"), title=f.get("title"), description=f.get("description"))
        rec = _receipt(run_dir, key, "REQUEST_CHANGES", cmd, artifacts, f"narrow_scope → {rerun['intent_hash'][:23]} — {cmd['rationale']}") if key is not None else None
        row = _chain_append(Path(run_dir).resolve() / "review" / "rerun_requests.jsonl", {"record_schema": f"{NS}/RerunRequest", "command_hash": cmd["command_hash"], "narrowed_from": rerun["narrowed_from"], "intent_hash": rerun["intent_hash"], "intent": rerun["intent"], "receipt_hash": rec["receipt_hash"] if rec else None, "requested_at": _now()})
        return {"rerun": rerun, "receipt_hash": rec["receipt_hash"] if rec else None, "request_hash": row["entry_hash"], "decision": "REQUEST_CHANGES" if rec else None}
    if action == "reject":
        rec = _receipt(run_dir, key, "REJECT", cmd, artifacts, cmd["rationale"])
        return {"receipt_hash": rec["receipt_hash"], "decision": "REJECT"}
    if action == "cancel":
        return {"receipt_hash": None, "cancellation": {"kind": "abort", "code": "workflow.cancelled", "cause": f"reviewer cancelled: {cmd['rationale'] or 'no rationale given'}", "command_hash": cmd["command_hash"]}}
    if action == "approve":
        rec = _receipt(run_dir, key, "APPROVE", cmd, artifacts, cmd["rationale"])
        record = approval_record(rec, contract, artifacts["candidate"])
        p = Path(run_dir).resolve() / "review" / "approval_record.json"; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(lga.canonical_json(record) + "\n", encoding="utf-8")
        return {"receipt": rec, "receipt_hash": rec["receipt_hash"], "decision": "APPROVE", "approval_record": record}
    raise ReviewRefusal("review.action_invalid", f"unknown reviewer action {action!r}")  # pragma: no cover


def execute_command(run_dir: Path, cmd: Mapping[str, Any], *, artifacts: Mapping[str, Any], surface: Mapping[str, Any], key: bytes | None = None, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Execute one typed command exactly once: the command must validate, its scope must be the bound view of exactly these
    artifacts, a repeated idempotency key replays the recorded result (no second effect) and a conflicting one is refused;
    the audit trail records what was shown (view + section + item hashes) and what was decided (command + receipt)."""
    C.validate_payload("reviewer_command", cmd, registry=registry)
    run_dir = Path(run_dir).resolve()
    verify_view(surface, artifacts)
    sc = cmd["scope"]
    if sc["view_hash"] != surface["view_hash"] or any(sc[k] != surface["bound_to"][k] for k in ("candidate_id", "patch_hash", "base_revision", "scope_contract_hash", "card_hash", "report_hash", "evidence_set_hash")):
        raise ReviewRefusal("review.command_unbound", "the command's scope is not the bound view of these artifacts")
    b = behavior_for(cmd["action"], load_review(registry=registry))
    if cmd["side_effects"] != {"applies_patch": False, "effects": list(b["side_effects"]["effects"]), "records": list(b["side_effects"].get("records", []))}:
        raise ReviewRefusal("review.side_effects_mismatch", "the command's declared side effects are not the registry's")
    for row in commands(run_dir):
        if row["idempotency_key"] == cmd["idempotency_key"]:
            if row["command_hash"] != cmd["command_hash"]:
                raise ReviewRefusal("review.idempotency_conflict", "a different command already used this idempotency key")
            return dict(row["result"], replayed=True, command_hash=cmd["command_hash"], audit_hash=row["audit_hash"], outcome="replayed")
    result = _dispatch(run_dir, cmd, artifacts, surface, key)
    audit = _chain_append(audit_path(run_dir), {"record_schema": f"{NS}/ReviewAuditEntry", "shown": {"view_hash": surface["view_hash"], "section_hashes": dict(surface["section_hashes"]), "displayed": {k: v["item_hash"] for k, v in surface["displayed"].items()}, "bound_to": dict(surface["bound_to"])},
                                                 "decided": {"action": cmd["action"], "command_hash": cmd["command_hash"], "identity": _identity_ref(cmd["identity"], cmd["channel"]), "issued_at": cmd["issued_at"], "receipt_hash": result.get("receipt_hash"), "decision": result.get("decision"), "rationale_hash": lga.sha256_digest(cmd["rationale"])},
                                                 "side_effects": {"declared": cmd["side_effects"], "applies_patch": False}, "at": _now(), "writer": f"adapters/review_surface/{ADAPTER_VERSION}"})
    summary = {k: v for k, v in result.items() if k not in ("evidence", "receipt", "approval_record")}
    _chain_append(commands_path(run_dir), {"record_schema": f"{NS}/CommandRecord", "command_hash": cmd["command_hash"], "idempotency_key": cmd["idempotency_key"], "action": cmd["action"], "identity": _identity_ref(cmd["identity"], cmd["channel"]), "scope": dict(sc), "issued_at": cmd["issued_at"], "result": summary, "audit_hash": audit["entry_hash"], "executed_at": _now()})
    return dict(result, outcome="executed", replayed=False, command_hash=cmd["command_hash"], audit_hash=audit["entry_hash"])


def verify_command_for_receipt(run_dir: Path, cmd: Mapping[str, Any], receipt: Mapping[str, Any], *, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """WF-10 linkage: the receipt a human presents must be the one the executed typed command produced — same candidate
    scope, same identity/channel, recorded on the command ledger with that receipt hash; the decision then carries the
    command hash (what was shown → what was decided → what was recorded)."""
    C.validate_payload("reviewer_command", cmd, registry=registry)
    run_dir = Path(run_dir).resolve()
    if cmd["scope"]["candidate_id"] != receipt.get("candidate_id") or cmd["scope"]["patch_hash"] != receipt.get("patch_hash") or cmd["scope"]["card_hash"] != receipt.get("card_hash"):
        raise ReviewRefusal("review.command_receipt_mismatch", "the command's scope is not the receipt's candidate")
    if cmd["identity"] != receipt.get("approver_identity") or cmd["channel"] != receipt.get("approver_channel"):
        raise ReviewRefusal("review.command_receipt_mismatch", "the command's identity/channel is not the receipt's")
    rows = [r for r in commands(run_dir) if r["command_hash"] == cmd["command_hash"]]
    if not rows or rows[0]["result"].get("receipt_hash") != receipt.get("receipt_hash"):
        raise ReviewRefusal("review.command_not_executed", "no executed command on the ledger produced this receipt")
    return {"command_hash": cmd["command_hash"], "action": cmd["action"], "view_hash": cmd["scope"]["view_hash"], "audit_hash": rows[0]["audit_hash"]}


__all__ += ["COMMAND_FIELDS", "COMMAND_VERSION", "RATIONALE_REQUIRED", "RECEIPT_DECISION", "audit_path", "audit_trail", "commands", "commands_path", "execute_command", "issue_command", "verify_command_for_receipt"]



# --------------------------------------------------------------------------- #
# T04 — reject / cancel / request-more-evidence / narrow-scope can never apply a patch or reuse a stale approval: the
# executor has no application path at all, every non-applying command is bracketed by an effect proof, and any changed
# bound input (or any later non-approving command) invalidates a prior approval at WF-10 and at the effect boundary
# --------------------------------------------------------------------------- #
NON_APPLYING = ("inspect_evidence", "request_evidence", "narrow_scope", "reject", "cancel")
INVALIDATING = ("request_evidence", "narrow_scope", "reject", "cancel")
APPROVAL_BOUND_INPUTS = ("candidate_id", "patch_hash", "base_revision", "scope_contract_hash", "card_hash", "report_hash", "evidence_set_hash", "source_snapshot_hash")


def effect_proof(artifacts: Mapping[str, Any], run_dir: Path) -> dict[str, Any]:
    """What a side effect would change: the pinned tree, the worktree status, the isolated-application directories and the
    approval ledger length. Taken before and after every non-applying command; any difference is a refusal."""
    b = _canon(artifacts["binding"]); root = Path(b["root_path"]); run_dir = Path(run_dir).resolve()
    try:
        tree = lga.tree_identity(root, b["base_revision"]); head = lga.git(root, "rev-parse", "HEAD"); status = lga.git(root, "status", "--porcelain", "--untracked-files=all")
    except lga.AdapterError as exc:  # pragma: no cover
        raise ReviewRefusal("review.effect_proof_unavailable", str(exc)) from exc
    from . import approval_adapter as _aa
    return {"tree_identity": tree, "head": head, "status_hash": lga.sha256_digest(status), "applied_dir": (run_dir / "applied").exists(), "applied_worktrees": sorted(p.name for p in (run_dir / "applied-worktrees").glob("*")) if (run_dir / "applied-worktrees").exists() else [],
            "archive_dir": (run_dir / "archive").exists(), "approval_chain_len": len(_aa.load_chain(run_dir))}


def assert_no_effect(before: Mapping[str, Any], after: Mapping[str, Any], *, allow_receipt: bool) -> dict[str, Any]:
    """The only permitted difference after a non-applying command is one more approval-ledger row (its own receipt)."""
    changed = [k for k in ("tree_identity", "head", "status_hash", "applied_dir", "applied_worktrees", "archive_dir") if before[k] != after[k]]
    if changed:
        raise ReviewRefusal("review.side_effect", f"a non-applying reviewer command changed {changed}; refused")
    rows = after["approval_chain_len"] - before["approval_chain_len"]
    if rows > (1 if allow_receipt else 0) or rows < 0:
        raise ReviewRefusal("review.side_effect", f"a non-applying reviewer command appended {rows} approval rows; refused")
    return {"no_side_effect": True, "receipt_rows": rows, "applied_patch": False}


def invalidations_path(run_dir: Path) -> Path:
    return Path(run_dir).resolve() / "review" / "invalidations.jsonl"


def invalidate_prior_approvals(run_dir: Path, cmd: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Every APPROVE for this candidate that precedes a reject / cancel / request-more-evidence / narrow-scope command is
    invalidated by a chained row (the ledger itself is append-only; the invalidation is a later fact, never an edit)."""
    from . import approval_adapter as _aa
    run_dir = Path(run_dir).resolve()
    rows = []
    for r in _aa.load_chain(run_dir):
        if r.get("candidate_id") == cmd["scope"]["candidate_id"] and r.get("decision") == "APPROVE":
            rows.append(_chain_append(invalidations_path(run_dir), {"record_schema": f"{NS}/ApprovalInvalidation", "receipt_hash": r["receipt_hash"], "candidate_id": r["candidate_id"], "invalidated_by": {"action": cmd["action"], "command_hash": cmd["command_hash"]}, "reason": f"a later {cmd['action']} command by a human reviewer", "at": _now()}))
    return rows


def invalidated_receipts(run_dir: Path) -> set[str]:
    p = invalidations_path(run_dir)
    return {json.loads(l)["receipt_hash"] for l in p.read_text(encoding="utf-8").splitlines() if l.strip()} if p.is_file() else set()


def approval_binding(artifacts: Mapping[str, Any]) -> dict[str, Any]:
    """The bound inputs an approval stands on — the same identities the view is bound to."""
    v = view_binding(artifacts)
    return {k: v[k] for k in APPROVAL_BOUND_INPUTS}


def assert_approval_current(run_dir: Path, receipt: Mapping[str, Any], artifacts: Mapping[str, Any]) -> dict[str, Any]:
    """Fail closed when a receipt would be reused over changed inputs: every bound input must still be the one the receipt
    was issued over (candidate, patch, revision, scope, card, report, evidence set, snapshot), and no later human command may
    have invalidated it. Runs before the ledger check at WF-10 and at the effect boundary."""
    run_dir = Path(run_dir).resolve()
    if receipt.get("receipt_hash") in invalidated_receipts(run_dir):
        raise lga.AdapterError("approval.invalidated", "a later reviewer command (reject / cancel / request evidence / narrow scope) invalidated this approval")
    current = approval_binding(artifacts)
    stale = [k for k in ("candidate_id", "patch_hash", "base_revision", "scope_contract_hash", "card_hash") if receipt.get(k) != current[k]] + (["report_hash"] if receipt.get("verification_report_hash") != current["report_hash"] else [])
    if stale:
        raise lga.AdapterError("approval.stale_inputs", f"bound inputs changed since the approval was issued: {stale}; a new human decision is required")
    rec = (run_dir / "review" / "approval_record.json")
    if rec.is_file():
        ar = json.loads(rec.read_text(encoding="utf-8"))
        if ar.get("receipt_hash") == receipt.get("receipt_hash") and ar["approved_scope"]["scope_contract_hash"] != current["scope_contract_hash"]:
            raise lga.AdapterError("approval.stale_inputs", "the approved scope is not the current scope contract")
    return {"current": True, "bound_inputs": current, "invalidated": False}


def _execute_guarded(run_dir: Path, cmd: Mapping[str, Any], *, artifacts: Mapping[str, Any], surface: Mapping[str, Any], key: bytes | None = None, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """T04 wrapper around the T03 executor: non-applying commands are bracketed by the effect proof and invalidate earlier
    approvals; the executor itself never applies anything (there is no application path in this module)."""
    run_dir = Path(run_dir).resolve()
    if cmd["action"] in NON_APPLYING:
        before = effect_proof(artifacts, run_dir)
        result = _execute_command_t03(run_dir, cmd, artifacts=artifacts, surface=surface, key=key, registry=registry)
        after = effect_proof(artifacts, run_dir)
        proof = assert_no_effect(before, after, allow_receipt=cmd["action"] in RECEIPT_DECISION)
        if cmd["action"] in INVALIDATING and not result.get("replayed"):
            proof["invalidated_approvals"] = [r["receipt_hash"] for r in invalidate_prior_approvals(run_dir, cmd)]
        result["effect_proof"] = proof
        return result
    result = _execute_command_t03(run_dir, cmd, artifacts=artifacts, surface=surface, key=key, registry=registry)
    result["effect_proof"] = {"applied_patch": False, "note": "approve records a receipt only; application happens at WF-11 after fresh revalidation, never here"}
    return result


_execute_command_t03 = execute_command
execute_command = _execute_guarded

__all__ += ["APPROVAL_BOUND_INPUTS", "INVALIDATING", "NON_APPLYING", "approval_binding", "assert_approval_current", "assert_no_effect", "effect_proof", "invalidate_prior_approvals", "invalidated_receipts", "invalidations_path"]



# --------------------------------------------------------------------------- #
# T05 — UI/accessibility checks over the rendered reviewer surface (stdlib html.parser; WCAG-shaped structural rules) and
# the audit-trail proof that what was shown and what was decided are exactly what the trail captured
# --------------------------------------------------------------------------- #
from html.parser import HTMLParser as _HTMLParser

A11Y_RULES = {"html-has-lang": "the document declares its language", "document-title": "the document has a non-empty title", "page-has-heading-one": "exactly one h1", "heading-order": "heading levels never skip downward",
              "landmarks": "banner, navigation, main and contentinfo landmarks are present and main is unique", "skip-link": "a skip link targets the main landmark", "label": "every form control has an associated label", "button-name": "every button has a visible name",
              "link-name": "every link has text", "image-alt": "every image has alt text", "table-structure": "every data table has header cells (th) and a caption or a preceding heading", "th-scope": "every th declares its scope",
              "no-positive-tabindex": "no positive tabindex", "duplicate-id": "ids are unique", "aria-refs": "every aria-labelledby / for reference resolves", "no-script": "no script and no event handler attributes", "region-labels": "every section is labelled",
              "status-region": "the verification banner is a live status region", "focus-visible": "a visible focus style is declared"}


class _A11yParser(_HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tags: list[tuple[str, dict[str, str], int]] = []  # (tag, attrs, depth)
        self.text_by_index: dict[int, str] = {}
        self.stack: list[tuple[str, int]] = []
        self.title = ""; self.in_title = False; self.scripts = 0; self.handlers = 0; self.styles: list[str] = []; self.in_style = False
        self._open_index: dict[int, int] = {}  # stack position → tag index

    def handle_starttag(self, tag, attrs):
        a = {k: (v or "") for k, v in attrs}
        idx = len(self.tags); self.tags.append((tag, a, len(self.stack)))
        if tag == "script":
            self.scripts += 1
        self.handlers += sum(1 for k in a if k.startswith("on"))
        if tag == "title":
            self.in_title = True
        if tag == "style":
            self.in_style = True
        self.stack.append((tag, idx))
        self.text_by_index[idx] = ""

    def handle_endtag(self, tag):
        if tag == "title":
            self.in_title = False
        if tag == "style":
            self.in_style = False
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                del self.stack[i:]
                break

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs); self.handle_endtag(tag)

    def handle_data(self, data):
        if self.in_title:
            self.title += data
        if self.in_style:
            self.styles.append(data)
        for _, idx in self.stack:
            self.text_by_index[idx] = self.text_by_index.get(idx, "") + data


def check_accessibility(html: str) -> dict[str, Any]:
    """Structural accessibility audit of a rendered page (no browser, no network): returns the rule results and the
    violations; a page with any violation is not accessible enough to be the reviewer's surface."""
    p = _A11yParser(); p.feed(html)
    tags = p.tags
    ids = [a["id"] for t, a, _ in tags if "id" in a]
    dup = sorted({i for i in ids if ids.count(i) > 1})
    heads = [(int(t[1]), i) for i, (t, a, _) in enumerate(tags) if re.match(r"^h[1-6]$", t)]
    order_ok, last = True, 0
    for lvl, _ in heads:
        if last and lvl > last + 1:
            order_ok = False
        last = lvl
    roles = {a.get("role") for _, a, _ in tags}
    tagnames = [t for t, _, _ in tags]
    labels_for = {a["for"] for t, a, _ in tags if t == "label" and "for" in a}
    controls = [(t, a) for t, a, _ in tags if t in ("input", "textarea", "select") and a.get("type") != "hidden"]
    unlabeled = [a.get("name") or t for t, a in controls if not (a.get("id") in labels_for or a.get("aria-label") or a.get("aria-labelledby"))]
    buttons = [(i, a) for i, (t, a, _) in enumerate(tags) if t == "button"]
    unnamed_buttons = [i for i, a in buttons if not (p.text_by_index.get(i, "").strip() or a.get("aria-label"))]
    links = [(i, a) for i, (t, a, _) in enumerate(tags) if t == "a"]
    unnamed_links = [a.get("href") for i, a in links if not (p.text_by_index.get(i, "").strip() or a.get("aria-label"))]
    imgs = [a for t, a, _ in tags if t == "img"]
    tables = [i for i, (t, _, _) in enumerate(tags) if t == "table"]
    table_ok = True
    for ti in tables:
        depth = tags[ti][2]; inner = []
        for j in range(ti + 1, len(tags)):
            if tags[j][2] <= depth:
                break
            inner.append(tags[j])
        has_th = any(t == "th" for t, _, _ in inner); has_caption = any(t == "caption" for t, _, _ in inner)
        prev_heading = any(re.match(r"^h[1-6]$", t) for t, _, _ in tags[max(0, ti - 6):ti])
        if not has_th or not (has_caption or prev_heading):
            table_ok = False
    ths = [a for t, a, _ in tags if t == "th"]
    sections = [a for t, a, _ in tags if t == "section"]
    aria_refs = [a["aria-labelledby"] for _, a, _ in tags if "aria-labelledby" in a] + list(labels_for)
    unresolved = sorted({r for r in aria_refs if r not in ids})
    html_lang = any(t == "html" and a.get("lang") for t, a, _ in tags)
    skip = any(t == "a" and a.get("href") == "#main" for t, a, _ in tags) and "main" in ids
    results = {"html-has-lang": html_lang, "document-title": bool(p.title.strip()), "page-has-heading-one": tagnames.count("h1") == 1, "heading-order": order_ok,
               "landmarks": "banner" in roles and "contentinfo" in roles and tagnames.count("main") == 1 and "nav" in tagnames, "skip-link": skip, "label": not unlabeled, "button-name": not unnamed_buttons, "link-name": not unnamed_links,
               "image-alt": all(a.get("alt") is not None for a in imgs), "table-structure": table_ok, "th-scope": all(a.get("scope") in ("col", "row") for a in ths), "no-positive-tabindex": not any(a.get("tabindex", "0").lstrip("-").isdigit() and int(a.get("tabindex", "0")) > 0 for _, a, _ in tags),
               "duplicate-id": not dup, "aria-refs": not unresolved, "no-script": p.scripts == 0 and p.handlers == 0, "region-labels": all(a.get("aria-labelledby") or a.get("aria-label") for a in sections), "status-region": "status" in roles,
               "focus-visible": any(":focus" in s and "outline" in s for s in p.styles)}
    violations = [{"rule": r, "description": A11Y_RULES[r], "detail": {"label": unlabeled, "button-name": unnamed_buttons, "link-name": unnamed_links, "duplicate-id": dup, "aria-refs": unresolved}.get(r)} for r, ok in results.items() if not ok]
    return {"record_schema": f"{NS}/AccessibilityAudit", "rules": len(A11Y_RULES), "passed": sum(1 for ok in results.values() if ok), "results": results, "violations": violations, "accessible": not violations, "page_hash": lga.sha256_digest(html)}


def verify_audit_against_view(run_dir: Path, surface: Mapping[str, Any], cmd: Mapping[str, Any], *, result: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """The audit trail must capture exactly what was shown (the bound view's hash, its section and item hashes) and what
    was decided (the command hash, the human's identity reference, the receipt) — nothing more, nothing less."""
    rows = [r for r in audit_trail(run_dir) if r["decided"]["command_hash"] == cmd["command_hash"]]
    if len(rows) != 1:
        raise ReviewRefusal("review.audit_missing", f"{len(rows)} audit rows for the command; exactly one expected")
    row = rows[0]
    shown_ok = row["shown"]["view_hash"] == surface["view_hash"] and row["shown"]["section_hashes"] == surface["section_hashes"] and row["shown"]["displayed"] == {k: v["item_hash"] for k, v in surface["displayed"].items()} and row["shown"]["bound_to"] == surface["bound_to"]
    decided_ok = row["decided"]["action"] == cmd["action"] and row["decided"]["identity"] == _identity_ref(cmd["identity"], cmd["channel"]) and row["decided"]["issued_at"] == cmd["issued_at"] and (result is None or row["decided"]["receipt_hash"] == result.get("receipt_hash"))
    if not shown_ok or not decided_ok:
        raise ReviewRefusal("review.audit_mismatch", f"the audit trail does not capture exactly what was shown ({shown_ok}) and decided ({decided_ok})")
    if row["side_effects"]["applies_patch"] is not False or cmd["rationale"] in json.dumps(row) and cmd["rationale"]:
        raise ReviewRefusal("review.audit_mismatch", "the audit row must state applies_patch=false and carry the rationale only as a hash")
    return {"audit_hash": row["entry_hash"], "shown": row["shown"]["view_hash"], "decided": row["decided"]["command_hash"], "receipt_hash": row["decided"]["receipt_hash"]}


__all__ += ["A11Y_RULES", "check_accessibility", "verify_audit_against_view"]
