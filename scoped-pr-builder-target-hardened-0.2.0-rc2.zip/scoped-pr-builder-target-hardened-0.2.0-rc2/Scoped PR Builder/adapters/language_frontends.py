"""Explicit structural language frontend capability records."""
from __future__ import annotations
import ast
from pathlib import Path
from typing import Any
def analyze(path:Path)->dict[str,Any]:
    suffix=path.suffix.lower(); text=path.read_text(encoding='utf-8',errors='replace')
    if suffix=='.py':
        try: tree=ast.parse(text)
        except SyntaxError as e: return {'language':'python','status':'FAIL','diagnostic':str(e)}
        return {'language':'python','status':'PASS','symbols':[getattr(n,'name','') for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))]}
    if suffix in {'.ts','.tsx','.js','.jsx','.go','.rs'}:
        try:
            import tree_sitter  # noqa:F401
            return {'language':suffix.lstrip('.'),'status':'INDETERMINATE','diagnostic':'tree-sitter installed but grammar binding is not configured'}
        except Exception:
            return {'language':suffix.lstrip('.'),'status':'INDETERMINATE','diagnostic':'optional tree-sitter frontend unavailable'}
    if suffix in {'.ja','.jad','.jasec','.jaa','.jaops','.jasp','.jaui','.jate','.dmk','.deepml'}:
        return {'language':'ja-family','status':'INDETERMINATE','diagnostic':'structural regex only; no JA compiler configured'}
    return {'language':'unknown','status':'INDETERMINATE','diagnostic':'unsupported frontend'}
