"""Optional Ed25519 helper using a vetted dependency; primitives are not implemented here."""
from __future__ import annotations
from . import local_git_adapter as lga
def sign(private_key_bytes:bytes,payload:bytes)->bytes:
    try: from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    except Exception as e: raise lga.AdapterError('crypto.unavailable','install the `crypto` optional extra for Ed25519') from e
    return Ed25519PrivateKey.from_private_bytes(private_key_bytes).sign(payload)
def verify(public_key_bytes:bytes,payload:bytes,signature:bytes)->bool:
    try: from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except Exception as e: raise lga.AdapterError('crypto.unavailable','install the `crypto` optional extra for Ed25519') from e
    try: Ed25519PublicKey.from_public_bytes(public_key_bytes).verify(signature,payload); return True
    except Exception: return False
