"""Single executable source for global Scoped PR Builder hard caps.

CAP-01 and GRD-01 must agree. Environments/intents may only narrow these values.
The registry shape is validated fail-closed; malformed, boolean, zero, or negative
limits never silently become effective policy.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

from . import local_git_adapter as lga

RULES_PATH = Path(__file__).resolve().parent.parent / "guardrails" / "RULES.json"
_KEYS = ("max_changed_files", "max_diff_lines")
_REGISTRY_KEYS = {
    "max_changed_files": "hard_max_changed_files",
    "max_diff_lines": "hard_max_diff_lines",
}


def _positive_int(value: Any, *, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise lga.AdapterError("caps.value_invalid", f"{label} must be a positive integer")
    return value


def hard_caps(path: Path = RULES_PATH) -> dict[str, int]:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise lga.AdapterError("caps.registry_unreadable", f"cannot read hard-cap registry: {exc}") from exc
    rules = data.get("rules") if isinstance(data, dict) and isinstance(data.get("rules"), dict) else data
    if not isinstance(rules, dict):
        raise lga.AdapterError("caps.registry_invalid", "hard-cap registry must contain a rules object")

    values: list[dict[str, int]] = []
    for rid in ("CAP-01", "GRD-01"):
        rule = rules.get(rid)
        if not isinstance(rule, dict):
            raise lga.AdapterError("caps.rule_missing", f"{rid} is missing")
        params = rule.get("parameters")
        if not isinstance(params, dict):
            raise lga.AdapterError("caps.rule_invalid", f"{rid}.parameters is missing")
        parsed = {
            key: _positive_int(params.get(registry_key), label=f"{rid}.parameters.{registry_key}")
            for key, registry_key in _REGISTRY_KEYS.items()
        }
        values.append(parsed)

    if values[0] != values[1]:
        raise lga.AdapterError("caps.rule_conflict", f"CAP-01 {values[0]} != GRD-01 {values[1]}")
    return dict(values[0])


def effective_caps(*, environment: Mapping[str, Any] | None = None, requested: Mapping[str, Any] | None = None) -> dict[str, int]:
    """Return the hard caps narrowed by environment/request policy.

    Any supplied cap is validated before it can participate. Missing values are
    ignored; present values must be positive integers. Widening is impossible
    because each layer is combined with ``min``.
    """
    caps = hard_caps()
    for source_name, src in (("environment", environment or {}), ("requested", requested or {})):
        for key in _KEYS:
            if key not in src or src[key] is None:
                continue
            value = _positive_int(src[key], label=f"{source_name}.{key}")
            caps[key] = min(caps[key], value)
    return caps
