"""Deployment environments: an explicit profile per environment, and the rule that an environment can only ever
narrow authority — never broaden it.

The failure this module exists to prevent is the ordinary one: a tool behaves correctly in the sandbox where it was
written, then is handed a "staging" or "production" configuration whose defaults quietly grant it more than the policy
ever did. Here the effective authority of a run is the *intersection* of the policy's grants with the environment's
allowed effects, and a profile that names an effect the policy does not grant is refused at load — not warned about.

Build provenance (ENV-01..06 — BUILD_NEW). Yard retrieval ran before this module was drafted: ledger recall on
deployment profile and environment promotion, then yard_query for deployment profile, environment configuration,
health readiness, smoke tests, promotion criteria, resource quotas, sandbox isolation, checkpoint rollback and
toolchain pinning. Inspected and rejected: `terraform-azurerm-environment-configuration` (MIT — Terraform for Azure
private-link and endpoint suffixes; infrastructure-as-code for a cloud tenant, not a declared authority profile for
this tool), `CloudConfigurationManager` (MIT — a serverless PowerShell DSC alternative), `Windows-Sandbox` (MIT — a
Windows OS feature, not process isolation this tool controls), `azuredatastudio-smoke-test-repo` (MIT — SQL notebooks
used as fixtures by another product's smoke tests), `VirtualHealthcareBlueprint` / `TailwindTraders-Backend` / `ARI`
(PowerShell and C# deployment scripts for cloud estates). Three queries matched nothing at all (health readiness,
promotion criteria, checkpoint rollback, toolchain pinning). Nothing was selected; this is stdlib-only and composes
the overlay's own policy adapter, store, archive chain and approval ledger.
"""

from __future__ import annotations

import json
import os
import platform
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from . import contracts as C
from . import controls as CT
from . import local_git_adapter as lga
from . import security as _SEC
from .archive_adapter import _chain_append, verify_chain_file

ENVIRONMENTS_VERSION = "scoped_pr_builder.environments/0.1.0"
ENVIRONMENTS_PATH = Path(__file__).resolve().parent.parent / "environments" / "ENVIRONMENTS.json"
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
ADAPTER_ID = "scoped_pr_builder.environment"
ADAPTER_VERSION = "0.1.0"
NS = "overlay.scoped_pr_builder.environment"

#: The six declared environments, in increasing order of authority. The order is what "promotion" means, and it is
#: declared here rather than inferred from a name, so a profile cannot promote itself by being renamed.
ENVIRONMENT_IDS = ("developer_sandbox", "ci_validation", "staging", "production_read_only",
                   "privileged_execution", "isolated_test_tenant")
PROFILE_REQUIRED = ("environment_id", "title", "rank", "bindings", "permissions", "network", "secrets",
                    "quotas", "storage", "logging", "model_profile", "allowed_effects", "authoritative_suites",
                    "introduced_by")
#: Every effect this tool can ever exercise. A profile naming anything outside this set is a typo or an escalation,
#: and either way it is refused.
KNOWN_EFFECTS = ("repository.bind", "repository.read", "worktree.isolate", "diff.generate_inert",
                 "verification.run_isolated", "review.render", "ledger.append", "store.write",
                 "patch.apply_isolated", "rollback.execute")
PRIVILEGED_EFFECTS = ("patch.apply_isolated", "rollback.execute")
NETWORK_MODES = ("none", "loopback_only")
SECRETS_MODES = ("none", "run_local_key")
POSTURES = ("read_only", "draft_only", "apply_isolated")


class EnvironmentRefusal(lga.AdapterError):
    """Raised when a profile is malformed, would broaden authority, or does not match the world it claims."""


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def load_environments(path: Path = ENVIRONMENTS_PATH, *, registry: Mapping[str, Any] | None = None,
                      repo_root: Path = REPO_ROOT) -> dict[str, Any]:
    """Load and validate every declared profile.

    A profile must name a known environment, declare all nine dimensions the task lists, bind to suite files that
    exist, and stay inside the effect vocabulary. Two structural rules are enforced here, not left to review:

    * `network` is `none` or `loopback_only` — this tool never declares outbound network in any environment;
    * an environment whose `posture` is not `apply_isolated` may not list a privileged effect at all, so a
      "read-only" profile cannot carry `patch.apply_isolated` in a corner of its allow-list.
    """
    if not Path(path).is_file():
        raise EnvironmentRefusal("environment.registry_missing", f"no environment registry at {path}")
    m = json.loads(Path(path).read_text(encoding="utf-8"))
    if m.get("environments_version") != ENVIRONMENTS_VERSION:
        raise EnvironmentRefusal("environment.registry_invalid", "environments_version mismatch")
    ranks: dict[int, str] = {}
    for eid, e in (m.get("environments") or {}).items():
        missing = [k for k in PROFILE_REQUIRED if k not in e]
        if missing or e["environment_id"] != eid or eid not in ENVIRONMENT_IDS:
            raise EnvironmentRefusal("environment.registry_invalid", f"{eid}: missing {missing} / unknown environment id")
        if not isinstance(e["rank"], int) or e["rank"] in ranks:
            raise EnvironmentRefusal("environment.registry_invalid", f"{eid}: rank must be a unique integer (clashes with {ranks.get(e['rank'])})")
        ranks[e["rank"]] = eid
        if e["network"].get("mode") not in NETWORK_MODES:
            raise EnvironmentRefusal("environment.registry_invalid", f"{eid}: network mode must be one of {NETWORK_MODES}; this tool declares no outbound network in any environment")
        if e["secrets"].get("mode") not in SECRETS_MODES:
            raise EnvironmentRefusal("environment.registry_invalid", f"{eid}: secrets mode must be one of {SECRETS_MODES}")
        posture = e["permissions"].get("posture")
        if posture not in POSTURES:
            raise EnvironmentRefusal("environment.registry_invalid", f"{eid}: posture must be one of {POSTURES}")
        unknown = sorted(set(e["allowed_effects"]) - set(KNOWN_EFFECTS))
        if unknown:
            raise EnvironmentRefusal("environment.effect_unknown", f"{eid}: allowed_effects names effects this tool cannot exercise: {unknown}")
        privileged = sorted(set(e["allowed_effects"]) & set(PRIVILEGED_EFFECTS))
        if privileged and posture != "apply_isolated":
            raise EnvironmentRefusal("environment.authority_broadened", f"{eid}: posture {posture!r} may not allow privileged effects {privileged}")
        for f in e["authoritative_suites"]:
            if not (Path(repo_root) / f).is_file():
                raise EnvironmentRefusal("environment.suite_unbound", f"{eid}: authoritative suite file does not exist: {f}")
    body = {k: v for k, v in m.items() if k != "environments_hash"}
    m["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return m


def environment(environment_id: str, environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    m = environments or load_environments()
    e = (m.get("environments") or {}).get(environment_id)
    if e is None:
        raise EnvironmentRefusal("environment.unknown", f"no such environment {environment_id!r}")
    return dict(e)


def ranked(environments: Mapping[str, Any] | None = None) -> list[str]:
    """The declared environments in authority order — the order promotion follows."""
    m = environments or load_environments()
    return [eid for _, eid in sorted((e["rank"], eid) for eid, e in (m.get("environments") or {}).items())]


def profile_hash(environment_id: str, environments: Mapping[str, Any] | None = None) -> str:
    e = environment(environment_id, environments)
    return lga.sha256_digest(lga.canonical_json(e))


# --------------------------------------------------------------------------- #
# T02 — the profile is what the run actually gets: authority is the INTERSECTION of the policy's grants with the
# environment's allowed effects, and a profile that would broaden anything is refused rather than merged
# --------------------------------------------------------------------------- #
def effective_rule_set(rule_set: Mapping[str, Any], environment_id: str,
                       environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Narrow a policy rule set to one environment. This is the only supported way to bring an environment's
    permissions into a run, and it can only ever remove.

    * every role's grants are intersected with the environment's `allowed_effects`;
    * the environment's `require_human_approval` additions are unioned in (an environment may demand *more* review);
    * `deny_by_default` patterns are unioned in (an environment may deny more);
    The result is a rule set that still validates against the closed `policy_layer` contract — the environment
    identity travels beside it in `narrowing_record`, never inside it, because adding a field to a closed schema
    would make every narrowed rule set invalid at the first step that validates one.

    An environment that names an effect no role is granted is not an error — it simply narrows to nothing there. An
    environment that tried to *add* a grant cannot: there is no code path that writes into `grants`.
    """
    e = environment(environment_id, environments)
    allowed = set(e["allowed_effects"])
    out = json.loads(lga.canonical_json(rule_set))
    out["grants"] = {role: sorted(set(effects) & allowed) for role, effects in (rule_set.get("grants") or {}).items()}
    out["require_human_approval"] = sorted(set(rule_set.get("require_human_approval") or [])
                                           | set(e["permissions"].get("require_human_approval") or []))
    out["deny_by_default"] = sorted(set(rule_set.get("deny_by_default") or [])
                                    | set(e["permissions"].get("deny_by_default") or []))
    out["policy_hash"] = lga.sha256_digest(lga.canonical_json(
        {k: v for k, v in out.items() if k not in ("policy_hash",)}))
    assert_no_broadening(rule_set, out)
    return out


def narrowing_record(rule_set: Mapping[str, Any], environment_id: str,
                     environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """The narrowed rule set together with the environment identity that shaped it, so an audit row can be traced
    back to the profile without putting extra fields inside a contract-validated rule set."""
    narrowed = effective_rule_set(rule_set, environment_id, environments)
    return {"record_schema": f"{NS}/Narrowing", "environment_id": environment_id,
            "environment_profile_hash": profile_hash(environment_id, environments),
            "policy_hash": narrowed["policy_hash"], "rule_set": narrowed,
            "effects_removed": sorted(set(_all_effects(rule_set)) - set(_all_effects(narrowed))),
            "at": _now()}


def assert_no_broadening(before: Mapping[str, Any], after: Mapping[str, Any]) -> dict[str, Any]:
    """Fail closed if narrowing added authority anywhere: a new grant, a new role, a dropped human-approval
    requirement or a dropped deny pattern. Called on every narrowing, so the property is checked, not assumed."""
    added_roles = sorted(set(after.get("grants") or {}) - set(before.get("grants") or {}))
    if added_roles:
        raise EnvironmentRefusal("environment.authority_broadened", f"narrowing introduced roles {added_roles}")
    for role, effects in (after.get("grants") or {}).items():
        extra = sorted(set(effects) - set((before.get("grants") or {}).get(role, [])))
        if extra:
            raise EnvironmentRefusal("environment.authority_broadened", f"narrowing granted {role} new effects {extra}")
    dropped = sorted(set(before.get("require_human_approval") or []) - set(after.get("require_human_approval") or []))
    if dropped:
        raise EnvironmentRefusal("environment.authority_broadened", f"narrowing dropped human approval for {dropped}")
    dropped_deny = sorted(set(before.get("deny_by_default") or []) - set(after.get("deny_by_default") or []))
    if dropped_deny:
        raise EnvironmentRefusal("environment.authority_broadened", f"narrowing dropped deny patterns {dropped_deny}")
    return {"verdict": "NARROWED_ONLY", "roles": sorted(after.get("grants") or {}),
            "effects_removed": sorted(set(_all_effects(before)) - set(_all_effects(after)))}


def _all_effects(rs: Mapping[str, Any]) -> list[str]:
    out: set[str] = set()
    for effects in (rs.get("grants") or {}).values():
        out.update(effects)
    return sorted(out)


def decide(rule_set: Mapping[str, Any], effect: str, principal_role: str, environment_id: str, *,
           context: Mapping[str, Any] | None = None, environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """One policy decision taken inside one environment. The decision carries the environment and the profile hash,
    so an audit row can never be read as if it had been taken somewhere with more authority."""
    rec = narrowing_record(rule_set, environment_id, environments)
    d = CT.policy_decide(rec["rule_set"], effect, principal_role, context)
    d["environment_id"] = environment_id
    d["environment_profile_hash"] = rec["environment_profile_hash"]
    if d["decision"] == "allow" and effect not in set(environment(environment_id, environments)["allowed_effects"]):
        raise EnvironmentRefusal("environment.authority_broadened",
                                 f"{effect} was allowed in {environment_id} but is not in its profile — refusing rather than proceeding")
    return d


QUOTA_KEYS = ("max_changed_files", "max_diff_lines")


def cap_intent(intent: Mapping[str, Any], environment_id: str,
               environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Clamp an intent's change thresholds to the environment's declared quotas.

    This is what makes a quota real rather than documentation. Clamping only ever lowers: an intent asking for less
    than the environment allows keeps its own smaller number. An environment whose quota is zero produces an intent
    that cannot authorise any change at all, which is how `production_read_only` is read-only in practice — analysis
    runs to completion and candidate generation is refused, rather than the environment being unable to start.
    """
    e = environment(environment_id, environments)
    out = dict(intent)
    clamped = {}
    for k in QUOTA_KEYS:
        limit = e["quotas"].get(k)
        if limit is None:
            continue
        current = out.get(k)
        if isinstance(current, int) and current > limit:
            clamped[k] = {"requested": current, "allowed": limit}
            out[k] = limit
        elif current is None:
            out[k] = limit
    out["_environment"] = {"environment_id": environment_id, "clamped": clamped,
                           "quotas": {k: e["quotas"].get(k) for k in QUOTA_KEYS}}
    return out


def quota_of(environment_id: str, environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    e = environment(environment_id, environments)
    q = dict(e["quotas"])
    q["permits_change"] = bool(q.get("max_changed_files")) and bool(q.get("max_diff_lines"))
    return q


def posture_of(environment_id: str, environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """The read/write posture this environment declares, with what it implies, so a smoke test can assert it."""
    e = environment(environment_id, environments)
    posture = e["permissions"]["posture"]
    return {"environment_id": environment_id, "posture": posture,
            "may_write_repository": posture == "apply_isolated",
            "may_generate_patch": posture in ("draft_only", "apply_isolated"),
            "privileged_effects": sorted(set(e["allowed_effects"]) & set(PRIVILEGED_EFFECTS)),
            "requires_human_approval": sorted(e["permissions"].get("require_human_approval") or [])}


# --------------------------------------------------------------------------- #
# T03 — pinned toolchain, health and readiness, clean startup/shutdown, isolation, checkpoint/rollback and a
# deterministic evidence export: what has to be true before a run is allowed to start in this environment
# --------------------------------------------------------------------------- #
PIN_KEYS = ("python", "platform", "overlay_version", "contracts_hash", "policy_hash", "invariants_hash",
            "environments_hash")
HEALTH_CHECKS = ("interpreter_pinned", "overlay_present", "registries_load", "run_dir_outside_repository",
                 "network_declared_none", "secrets_policy_honoured", "quotas_declared", "storage_writable",
                 "logging_chained")


def pins(environments: Mapping[str, Any] | None = None, *, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """The versions a run in any environment must record, read from the tool itself — never from configuration that
    an environment could set to whatever it likes."""
    m = environments or load_environments()
    reg = registry or C.load_registry()
    from . import invariants as _I
    out = {"python": ".".join(str(v) for v in sys.version_info[:3]),
           "platform": platform.system().lower(),
           "overlay_version": ENVIRONMENTS_VERSION.split("/")[-1],
           "contracts_hash": reg["computed_hash"],
           "environments_hash": m["computed_hash"]}
    try:
        out["invariants_hash"] = _I.load_invariants(registry=reg)["computed_hash"]
    except lga.AdapterError:
        out["invariants_hash"] = None
    return out


def health(environment_id: str, run_dir: Path, *, repo_root: Path = REPO_ROOT,
           environments: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Readiness for this environment: every check reports what it observed, and a failing check is named.

    `ready` is only true when every check passes. This is deliberately not a liveness probe — it answers "may a
    governed run start here", which is a question about authority and isolation, not about uptime.
    """
    m = environments or load_environments()
    e = environment(environment_id, m)
    run_dir = Path(run_dir).resolve()
    repo_root = Path(repo_root).resolve()
    checks: dict[str, Any] = {}

    def check(name: str, ok: bool, observed: Any) -> None:
        checks[name] = {"ok": bool(ok), "observed": observed}

    p = pins(m, registry=registry)
    check("interpreter_pinned", bool(p["python"]), p["python"])
    check("overlay_present", (repo_root / "Scoped PR Builder" / "adapters").is_dir(), str(repo_root))
    ok_reg = True
    try:
        C.load_registry()
        load_environments()
    except lga.AdapterError:
        ok_reg = False
    check("registries_load", ok_reg, "contracts + environments")
    inside = lga.path_within(run_dir, repo_root)
    check("run_dir_outside_repository", not inside, str(run_dir))
    check("network_declared_none", e["network"]["mode"] in NETWORK_MODES, e["network"]["mode"])
    # The secrets policy is about what this tool holds, not about what happens to be set in the operator's shell.
    # Refusing to start on any machine with GITHUB_TOKEN exported would be theatre; what is checkable — and what
    # actually matters — is that the run directory carries no key material the profile does not declare.
    keys = _key_material(run_dir)
    if e["secrets"]["mode"] == "none":
        secrets_ok, secrets_detail = not keys, {"mode": "none", "key_material_found": keys}
    else:
        stray = [k for k in keys if not k.endswith("approvals/key")]
        secrets_ok, secrets_detail = not stray, {"mode": e["secrets"]["mode"], "expected": "approvals/key", "stray": stray}
    check("secrets_policy_honoured", e["secrets"]["mode"] in SECRETS_MODES and secrets_ok, secrets_detail)
    check("quotas_declared", all(k in e["quotas"] for k in ("max_run_seconds", "max_changed_files", "max_diff_lines")), sorted(e["quotas"]))
    # A readiness check must not create the very directory it has just judged to be in the wrong place. When the run
    # directory resolves inside the repository the check reports "not attempted" rather than making it writable and
    # leaving a stray directory in the source tree — the environment is already not ready, and probing further would
    # only add a side effect to a check that is supposed to have none.
    writable, why = False, str(run_dir)
    if inside:
        why = f"{run_dir} is inside the repository; writability was not probed and no directory was created"
    else:
        try:
            run_dir.mkdir(parents=True, exist_ok=True)
            probe = run_dir / ".health_probe"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink()
            writable = True
        except OSError as exc:
            why = f"{run_dir}: {exc.__class__.__name__}"
    check("storage_writable", writable, why)
    check("logging_chained", e["logging"].get("chained") is True, e["logging"].get("chained"))
    failing = sorted(k for k, v in checks.items() if not v["ok"])
    return {"environment_id": environment_id, "checks": checks, "failing": failing, "ready": not failing,
            "pins": p, "environment_profile_hash": profile_hash(environment_id, m),
            # advisory, never blocking: names only, so an operator can see what the ambient environment carries.
            # The values are never read here, and the boundaries that could carry them out are guarded by SEC-03/05/06.
            "ambient_secret_names": _env_secret_names(),
            "checked_at": _now()}


_SECRET_ENV = re.compile(r"(?:^|_)(?:TOKEN|SECRET|PASSWORD|APIKEY|API_KEY|CREDENTIAL)s?(?:_|$)", re.I)


def _env_secret_names() -> list[str]:
    """Names only — never values. Reported so an operator can see what the ambient process environment carries; the
    values are never read, logged or returned, and this list never blocks a run."""
    return sorted(k for k in os.environ if _SECRET_ENV.search(k))


_KEY_NAMES = re.compile(r"(?:^|[._-])(?:key|pem|p12|pfx|keystore|credentials?)$", re.I)


def _key_material(run_dir: Path) -> list[str]:
    """Paths under the run directory that look like key material — the only secrets this tool is responsible for."""
    run_dir = Path(run_dir)
    if not run_dir.is_dir():
        return []
    return sorted(p.relative_to(run_dir).as_posix() for p in run_dir.rglob("*")
                  if p.is_file() and _KEY_NAMES.search(p.name))


def require_ready(environment_id: str, run_dir: Path, **kw: Any) -> dict[str, Any]:
    """No run starts in an environment that is not ready. The refusal names the failing checks."""
    h = health(environment_id, run_dir, **kw)
    if not h["ready"]:
        raise EnvironmentRefusal("environment.not_ready", f"{environment_id}: failing readiness checks {h['failing']}")
    return h


def startup(environment_id: str, run_dir: Path, *, environments: Mapping[str, Any] | None = None,
            registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Open a run in this environment: readiness proven, the security trail bound to the run directory, a chained
    lifecycle row written. Returns the handle `shutdown` needs."""
    m = environments or load_environments()
    run_dir = Path(run_dir).resolve()
    h = require_ready(environment_id, run_dir, environments=m, registry=registry)
    _SEC.use_trail(run_dir)
    row = _chain_append(lifecycle_path(run_dir),
                        {"record_schema": f"{NS}/Lifecycle", "phase": "startup", "environment_id": environment_id,
                         "environment_profile_hash": h["environment_profile_hash"], "pins": h["pins"],
                         "readiness": {k: v["ok"] for k, v in h["checks"].items()}, "at": _now()})
    return {"environment_id": environment_id, "run_dir": str(run_dir), "started_at": row["at"],
            "entry_hash": row["entry_hash"], "pins": h["pins"],
            "environment_profile_hash": h["environment_profile_hash"]}


def shutdown(handle: Mapping[str, Any], *, outcome: str = "COMPLETED",
             environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Close the run cleanly: prove nothing was left behind that the profile forbids, then chain the closing row.

    A shutdown that finds leftovers does not tidy them away silently — it records them and refuses, because a
    leftover worktree or a run directory inside the repository is exactly the state a later run must not inherit.
    """
    run_dir = Path(handle["run_dir"]).resolve()
    e = environment(handle["environment_id"], environments)
    leftovers: list[str] = []
    for pattern in e["storage"].get("must_be_empty_at_shutdown", []):
        for p in sorted(run_dir.glob(pattern)):
            if p.is_dir() and any(p.iterdir()):
                leftovers.append(p.relative_to(run_dir).as_posix())
            elif p.is_file() and p.stat().st_size:
                leftovers.append(p.relative_to(run_dir).as_posix())
    chains = {}
    for rel in ("workflow/steps.jsonl", "workflow/events.jsonl", f"{NS.split('.')[-1]}/lifecycle.jsonl"):
        p = run_dir / rel
        if p.is_file():
            chains[rel] = verify_chain_file(p)
    row = _chain_append(lifecycle_path(run_dir),
                        {"record_schema": f"{NS}/Lifecycle", "phase": "shutdown", "environment_id": handle["environment_id"],
                         "environment_profile_hash": handle["environment_profile_hash"], "outcome": outcome,
                         "leftovers": leftovers, "chains_verified": chains, "at": _now()})
    if leftovers:
        raise EnvironmentRefusal("environment.unclean_shutdown",
                                 f"{handle['environment_id']}: {leftovers[:6]} must be empty at shutdown; recorded, not removed")
    return {"outcome": outcome, "leftovers": [], "chains_verified": chains, "entry_hash": row["entry_hash"],
            "closed_at": row["at"]}


def lifecycle_path(run_dir: Path) -> Path:
    return Path(run_dir).resolve() / "environment" / "lifecycle.jsonl"


def lifecycle(run_dir: Path) -> list[dict[str, Any]]:
    p = lifecycle_path(run_dir)
    if not p.is_file():
        return []
    verify_chain_file(p)
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


def export_evidence(run_dir: Path, out_dir: Path, *, environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """A deterministic evidence export for this run: every chained ledger and declared artifact, listed with its
    content hash, under a manifest whose own hash is a function of the content alone — the same run exports to the
    same manifest hash every time, on any machine."""
    run_dir = Path(run_dir).resolve()
    out_dir = Path(out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    files = []
    for p in sorted(run_dir.rglob("*")):
        if not p.is_file() or p.name == ".health_probe":
            continue
        rel = p.relative_to(run_dir).as_posix()
        files.append({"path": rel, "bytes": p.stat().st_size,
                      "sha256": lga.sha256_digest(p.read_bytes())})
    life = lifecycle(run_dir)
    body = {"record_schema": f"{NS}/EvidenceExport", "environments_version": ENVIRONMENTS_VERSION,
            "environment_id": life[0]["environment_id"] if life else None,
            "environment_profile_hash": life[0]["environment_profile_hash"] if life else None,
            "pins": life[0]["pins"] if life else None, "files": files, "file_count": len(files)}
    body["manifest_hash"] = lga.sha256_digest(lga.canonical_json(body))
    path = out_dir / "EVIDENCE_MANIFEST.json"
    path.write_text(lga.canonical_json(body) + "\n", encoding="utf-8")
    return dict(body, path=str(path))


# --------------------------------------------------------------------------- #
# T04 — smoke tests per environment: launch, repository binding, authorization, read/write posture, model/tool
# availability, logging and cleanup. Each check asserts what the PROFILE declares, so a profile that lies fails here.
# --------------------------------------------------------------------------- #
SMOKE_CHECKS = ("launch", "repository_binding", "authorization", "read_write_posture",
                "model_tool_availability", "logging", "cleanup")
SMOKE_VERDICTS = ("PASS", "FAIL")
#: The binding's own vocabulary (local_git_adapter.bind_repository): the checkout the run was pointed at, or a
#: linked worktree created under the run directory. Both are legitimate; anything else is not a binding this tool made.
ISOLATION_STATES = ("source_worktree", "linked_worktree")


def smoke_plan(environment_id: str, environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """What this environment's smoke run must demonstrate, read from its own profile."""
    e = environment(environment_id, environments)
    declared = e.get("smoke")
    if not isinstance(declared, Mapping):
        # never default: a plan invented here would carry an expectation nobody declared, and a run would then be
        # judged against it. An environment with no declared smoke plan simply cannot be smoke-tested yet.
        raise EnvironmentRefusal("environment.smoke_undeclared",
                                 f"{environment_id} declares no smoke plan; there is nothing to judge a run against")
    checks = list(declared.get("checks") or ())
    missing = [c for c in SMOKE_CHECKS if c not in checks]
    if missing:
        raise EnvironmentRefusal("environment.smoke_incomplete", f"{environment_id}: smoke plan lacks {missing}")
    if "expected_posture" not in declared:
        raise EnvironmentRefusal("environment.smoke_incomplete", f"{environment_id}: smoke plan declares no expected posture")
    return {"environment_id": environment_id, "checks": checks,
            "expected_posture": declared["expected_posture"],
            "expected_privileged": list(declared.get("expected_privileged") or []),
            "allowed_effects": list(e["allowed_effects"]), "quotas": dict(e["quotas"])}


def smoke_result(environment_id: str, observed: Mapping[str, Any], *,
                 environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Judge one smoke run against the plan. Every check is compared to what the profile declares; an unobserved
    check is a FAIL, never a skip, because "we did not look" is not evidence that an environment is sound."""
    plan = smoke_plan(environment_id, environments)
    e = environment(environment_id, environments)
    results: dict[str, Any] = {}
    problems: list[str] = []

    def judge(name: str, ok: bool, detail: Any) -> None:
        results[name] = {"ok": bool(ok), "observed": detail}
        if not ok:
            problems.append(f"{name}: {detail}")

    if not set(plan["checks"]) <= set(observed):
        for c in sorted(set(plan["checks"]) - set(observed)):
            judge(c, False, "not observed")

    if "launch" in observed:
        o = observed["launch"]
        judge("launch", bool(o.get("ready")) and o.get("environment_id") == environment_id
              and o.get("environment_profile_hash") == profile_hash(environment_id, environments), o)
    if "repository_binding" in observed:
        o = observed["repository_binding"]
        judge("repository_binding",
              str(o.get("repository_id", "")).startswith("sha256:")
              and bool(re.fullmatch(r"[0-9a-f]{40}", str(o.get("base_revision", ""))))
              and o.get("isolation_status") in ISOLATION_STATES, o)
    if "authorization" in observed:
        o = observed["authorization"]
        granted = set(o.get("granted") or [])
        extra = sorted(granted - set(plan["allowed_effects"]))
        judge("authorization", not extra and o.get("environment_id") == environment_id,
              {"granted": sorted(granted), "outside_profile": extra})
    if "read_write_posture" in observed:
        o = observed["read_write_posture"]
        want = posture_of(environment_id, environments)
        judge("read_write_posture",
              o.get("posture") == plan["expected_posture"]
              and bool(o.get("source_tree_unchanged"))
              and bool(o.get("may_write_repository")) == want["may_write_repository"]
              and sorted(o.get("privileged_effects") or []) == sorted(plan["expected_privileged"]), o)
    if "model_tool_availability" in observed:
        o = observed["model_tool_availability"]
        approved = set(e["model_profile"]["providers"])
        judge("model_tool_availability",
              set(o.get("providers") or []) <= approved and o.get("network") == "none" and bool(o.get("pinned")), o)
    if "logging" in observed:
        o = observed["logging"]
        declared_ledgers = set(e["logging"]["ledgers"])
        verified = {k: v for k, v in (o.get("chains_verified") or {}).items()}
        judge("logging", bool(verified) and set(verified) <= declared_ledgers
              and all(isinstance(v, int) and v >= 0 for v in verified.values()), o)
    if "cleanup" in observed:
        o = observed["cleanup"]
        judge("cleanup", o.get("leftovers") == [] and bool(o.get("closed_at")), o)

    verdict = "PASS" if not problems else "FAIL"
    sat = _satisfied_criteria(environment_id, results, observed, environments)
    body = {"record_schema": f"{NS}/SmokeResult", "environment_id": environment_id,
            "environment_profile_hash": profile_hash(environment_id, environments),
            "checks": results, "verdict": verdict, "problems": problems,
            "satisfied": sat["satisfied"] if verdict == "PASS" else [],
            "unmet": sat["unmet"], "criteria_declared": sat["declared"],
            "ran_at": _now()}
    body["smoke_hash"] = lga.sha256_digest(lga.canonical_json(
        {k: v for k, v in body.items() if k not in ("ran_at", "smoke_hash")}))
    return body


def _satisfied(environment_id: str, results: Mapping[str, Any],
               environments: Mapping[str, Any] | None = None) -> list[str]:
    """The promotion criteria this smoke run demonstrates.

    A smoke run demonstrates *facts* — the posture held, the tree was unchanged, the chains verified — and a fact
    satisfies any criterion it speaks to, wherever that criterion is declared. So this is evaluated over every
    criterion in the registry, not only the source environment's: the gate checks the destination's entry criteria
    against this same list, and scoping it to the source would make that check vacuous.

    A criterion is listed only when every check that would demonstrate it actually passed, and a criterion no check
    speaks to is never listed — the gate then refuses, which is the safe direction.
    """
    m = environments or load_environments()
    out = []
    for e in (m.get("environments") or {}).values():
        promo = e.get("promotion") or {}
        for crit in list(promo.get("entry_criteria") or []) + list(promo.get("exit_criteria") or []):
            needed = _criterion_checks(crit)
            if needed and all(results.get(c, {}).get("ok") for c in needed):
                out.append(crit)
    return sorted(set(out))


#: How each declared criterion is demonstrated. Keyed by the EXACT criterion string, because keyword matching credits
#: criteria a run never demonstrated — "a full run reaches the review surface without producing a candidate" and "a
#: candidate patch is produced and left inert" are opposites, and any map that matches both on the word "candidate"
#: manufactures evidence. Each entry names the smoke checks that must pass AND, where the criterion is about
#: something a smoke run cannot see by itself, the field in `observed` that must carry the demonstration.
#: A criterion absent from this table is NEVER satisfied; the promotion gate then refuses, which is the safe direction.
CRITERION_EVIDENCE: dict[str, dict[str, Any]] = {
    # --- demonstrated by the smoke checks themselves ---
    "repository binds at a pinned revision": {"checks": ("repository_binding",)},
    "run directory outside the repository": {"checks": ("launch",)},
    "no outbound network declared": {"checks": ("launch", "model_tool_availability")},
    "the audit trail verifies as a chain": {"checks": ("logging",)},
    "the audit trail shows the authority for each privileged effect": {"checks": ("logging", "authorization"),
                                                                       "requires": "privileged_authority"},
    "analysis completes against a real repository with the source tree unchanged": {
        "checks": ("launch", "repository_binding", "read_write_posture", "logging"), "posture": "read_only"},
    "candidate generation is refused by policy, not merely skipped": {
        "checks": ("read_write_posture", "authorization"), "posture": "read_only",
        "requires": "candidate_generation_denied"},
    "a full run completes with the source tree unchanged": {"checks": ("launch", "read_write_posture", "logging")},
    "a candidate patch is produced and left inert": {"checks": ("read_write_posture",), "posture": "draft_only"},
    "the source tree is provably unchanged": {"checks": ("read_write_posture",)},
    "an isolated apply and rollback complete with the source tree unchanged": {"checks": ("read_write_posture", "cleanup"),
                                                                               "posture": "apply_isolated"},
    "rollback is proven on a real candidate": {"checks": ("read_write_posture", "cleanup"), "posture": "apply_isolated"},
    "the review surface renders and binds for a human decision": {"checks": ("read_write_posture", "logging"),
                                                                  "requires": "review_surface_bound"},
    "every privileged effect exercised carries a verified human approval receipt": {"checks": ("authorization",),
                                                                                    "requires": "privileged_authority"},
    # --- demonstrated only by evidence the smoke caller must present explicitly ---
    "the full overlay suite passes": {"checks": (), "requires": "overlay_suite_passed"},
    "every mandatory qualification scenario passes": {"checks": (), "requires": "qualification_all_passed"},
    "every platform invariant is satisfied or deferred with a reason": {"checks": (), "requires": "invariants_clean"},
    "evidence export is deterministic": {"checks": ("cleanup",), "requires": "evidence_export_deterministic"},
    "the evidence manifest reproduces byte-for-byte": {"checks": ("cleanup",), "requires": "evidence_export_deterministic"},
    "fixtures are synthetic and carry no real repository identity": {"checks": (), "requires": "synthetic_fixtures"},
    "retention and deletion are declared for everything the run writes": {"checks": ("cleanup",), "requires": "retention_declared"},
    "privacy and security validation runs to completion against synthetic data only": {"checks": (), "requires": "privacy_validation_passed"},
    "nothing from this tenant is readable from any other environment": {"checks": (), "requires": "tenant_isolated"},
}


def _satisfied_criteria(environment_id: str, results: Mapping[str, Any], observed: Mapping[str, Any],
                        environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Which declared criteria this smoke run actually demonstrates, and why each of the others does not.

    Three conditions must hold for a criterion to be listed: every smoke check it names passed; the environment's
    posture matches, where the criterion is posture-specific (an apply-and-rollback run does not demonstrate a
    read-only criterion, and vice versa); and any explicitly required evidence was presented and is true.
    """
    m = environments or load_environments()
    posture = environment(environment_id, m)["permissions"]["posture"]
    declared: set[str] = set()
    for e in (m.get("environments") or {}).values():
        promo = e.get("promotion") or {}
        declared |= set(promo.get("entry_criteria") or []) | set(promo.get("exit_criteria") or [])
    satisfied, unmet = [], {}
    for crit in sorted(declared):
        spec = CRITERION_EVIDENCE.get(crit)
        if spec is None:
            unmet[crit] = "no declared way to demonstrate this criterion"
            continue
        failed = [c for c in spec["checks"] if not results.get(c, {}).get("ok")]
        if failed:
            unmet[crit] = f"smoke checks did not pass: {failed}"
            continue
        want_posture = spec.get("posture")
        if want_posture and want_posture != posture:
            unmet[crit] = f"criterion applies to a {want_posture} environment; this run was {posture}"
            continue
        need = spec.get("requires")
        if need and observed.get("evidence", {}).get(need) is not True:
            unmet[crit] = f"required evidence {need!r} was not presented"
            continue
        satisfied.append(crit)
    return {"satisfied": satisfied, "unmet": unmet, "declared": len(declared)}


def require_smoke(environment_id: str, result: Mapping[str, Any]) -> dict[str, Any]:
    """No environment is used, and no promotion out of it is considered, on a failing smoke result."""
    if result.get("environment_id") != environment_id:
        raise EnvironmentRefusal("environment.smoke_mismatch",
                                 f"the smoke result is for {result.get('environment_id')!r}, not {environment_id!r}")
    if result.get("verdict") != "PASS":
        raise EnvironmentRefusal("environment.smoke_failed",
                                 f"{environment_id}: smoke {result.get('verdict')} — {result.get('problems', [])[:4]}")
    return {"environment_id": environment_id, "verdict": "PASS", "smoke_hash": result["smoke_hash"]}


# --------------------------------------------------------------------------- #
# T05 — promotion into and out of an environment, and the signed compatibility receipt that must exist before any
# broader authority is granted
# --------------------------------------------------------------------------- #
COMPATIBILITY_VERSION = "scoped_pr_builder.compatibility_receipt/0.1.0"
EVIDENCE_KIND = "environment_smoke"
PROMOTION_REQUIRED = ("entry_criteria", "exit_criteria", "profile_assertions", "promotes_to", "requires_receipt")
#: How each profile assertion is decided, against the destination profile itself. An assertion whose wording matches
#: nothing here is reported unverifiable and refuses the promotion — the safe direction.
_ASSERTIONS = {
    "posture is draft_only": lambda e: e["permissions"]["posture"] == "draft_only",
    "posture is read_only": lambda e: e["permissions"]["posture"] == "read_only",
    "posture is apply_isolated": lambda e: e["permissions"]["posture"] == "apply_isolated",
    "no privileged effect is allowed": lambda e: not (set(e["allowed_effects"]) & set(PRIVILEGED_EFFECTS)),
    "every privileged effect requires human approval": lambda e: set(PRIVILEGED_EFFECTS) & set(e["allowed_effects"]) <= set(e["permissions"].get("require_human_approval") or []),
    "network mode is none": lambda e: e["network"]["mode"] == "none",
    "logging is chained": lambda e: e["logging"].get("chained") is True,
    "max_changed_files is zero": lambda e: e["quotas"].get("max_changed_files") == 0,
}


def verify_profile_assertions(environment_id: str, environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Check what an environment's profile claims about itself, against the profile. These are static properties —
    a run cannot demonstrate them and must not be asked to."""
    e = environment(environment_id, environments)
    promo = e.get("promotion") or {}
    results, failing, unverifiable = {}, [], []
    for a in promo.get("profile_assertions") or []:
        fn = _ASSERTIONS.get(a)
        if fn is None:
            unverifiable.append(a); results[a] = None; continue
        results[a] = bool(fn(e))
        if not results[a]:
            failing.append(a)
    return {"environment_id": environment_id, "assertions": results, "failing": failing,
            "unverifiable": unverifiable, "ok": not failing and not unverifiable}


def promotion_of(entry: Mapping[str, Any]) -> dict[str, Any]:
    p = entry.get("promotion")
    if not isinstance(p, Mapping) or any(k not in p for k in PROMOTION_REQUIRED):
        raise EnvironmentRefusal("environment.promotion_missing",
                                 f"{entry['environment_id']}: promotion criteria into and out of the environment are mandatory")
    if not p["entry_criteria"] or not p["exit_criteria"]:
        raise EnvironmentRefusal("environment.promotion_missing", f"{entry['environment_id']}: criteria must be non-empty")
    return dict(p)


def compatibility_receipt(from_env: str, to_env: str, *, smoke: Mapping[str, Any], entry_smoke: Mapping[str, Any],
                          readiness: Mapping[str, Any], approver_identity: str, approver_channel: str, rationale: str,
                          environments: Mapping[str, Any] | None = None, run_dir: Path | None = None) -> dict[str, Any]:
    """The receipt that must exist before authority widens.

    It is bound to exactly what was demonstrated — the two profile hashes, the pins, the smoke result and the
    readiness result — so it cannot be reused across a profile change. The approver must be a human channel
    (SEC-07 refuses a model channel by name); this function never mints one, it only refuses or records.

    Two smoke results are required, not one. `smoke` is a run in the SOURCE environment and demonstrates its exit
    criteria; `entry_smoke` is a run in the DESTINATION environment and demonstrates its entry criteria. They cannot
    be the same run: a staging apply-and-rollback cannot demonstrate "no write of any kind is attempted against the
    repository", because that is a property of the read-only posture it was not running under. Asking one run to
    stand for both is how a promotion gate ends up approving a posture nobody exercised.

    Note also that rank is pipeline position, not authority: `production_read_only` follows `staging` and holds
    strictly *fewer* effects. So the receipt is required for every declared promotion, and `authority_delta` states
    separately what actually widens, narrows or stays the same. A promotion that gains a privileged effect must name
    it in the rationale — the reviewer is approving that specific widening, not a stage name.
    """
    m = environments or load_environments()
    src, dst = environment(from_env, m), environment(to_env, m)
    if dst["rank"] <= src["rank"]:
        raise EnvironmentRefusal("environment.promotion_denied",
                                 f"{to_env} does not rank after {from_env}; promotion follows the declared pipeline order")
    promo = promotion_of(src)
    if to_env not in promo["promotes_to"]:
        raise EnvironmentRefusal("environment.promotion_denied", f"{from_env} does not declare a promotion path to {to_env}")
    channel = _SEC.require_human_channel(approver_channel, identity=approver_identity, run_dir=run_dir)
    if not rationale.strip():
        raise EnvironmentRefusal("environment.promotion_denied", "a promotion decision requires a rationale")
    unmet = [c for c in promo["exit_criteria"] if c not in (smoke.get("satisfied") or [])]
    if unmet:
        raise EnvironmentRefusal("environment.promotion_denied", f"{from_env} exit criteria not demonstrated: {unmet}")
    if entry_smoke.get("environment_id") != to_env:
        raise EnvironmentRefusal("environment.promotion_denied",
                                 f"the entry smoke result is for {entry_smoke.get('environment_id')!r}, not the destination {to_env!r}")
    if entry_smoke.get("verdict") != "PASS":
        raise EnvironmentRefusal("environment.promotion_denied", f"{to_env} entry smoke verdict is {entry_smoke.get('verdict')!r}")
    unmet_in = [c for c in promotion_of(dst)["entry_criteria"] if c not in (entry_smoke.get("satisfied") or [])]
    if unmet_in:
        raise EnvironmentRefusal("environment.promotion_denied",
                                 f"{to_env} entry criteria not demonstrated by a run in {to_env}: {unmet_in}")
    pa = verify_profile_assertions(to_env, m)
    if not pa["ok"]:
        raise EnvironmentRefusal("environment.promotion_denied",
                                 f"{to_env} profile does not hold what it asserts: failing {pa['failing']}, unverifiable {pa['unverifiable']}")
    if not readiness.get("ready"):
        raise EnvironmentRefusal("environment.promotion_denied", f"{to_env} is not ready: {readiness.get('failing')}")
    if smoke.get("verdict") != "PASS":
        raise EnvironmentRefusal("environment.promotion_denied", f"{from_env} smoke verdict is {smoke.get('verdict')!r}")
    delta = authority_delta(from_env, to_env, m)
    unnamed = [x for x in delta["privileged_gained"] if x not in rationale]
    if unnamed:
        raise EnvironmentRefusal("environment.promotion_denied",
                                 f"{from_env} -> {to_env} gains privileged effects {unnamed}; the approval rationale must name each one")
    body = {"record_schema": f"{NS}/CompatibilityReceipt", "receipt_version": COMPATIBILITY_VERSION,
            "from_environment": from_env, "to_environment": to_env,
            "from_profile_hash": profile_hash(from_env, m), "to_profile_hash": profile_hash(to_env, m),
            "environments_hash": m["computed_hash"], "pins": dict(readiness.get("pins") or {}),
            "smoke_hash": smoke.get("smoke_hash"), "entry_smoke_hash": entry_smoke.get("smoke_hash"),
            "readiness_hash": lga.sha256_digest(lga.canonical_json(readiness.get("checks") or {})),
            "authority_delta": delta, "profile_assertions": pa["assertions"],
            "approver_identity": approver_identity.strip(), "approver_channel": channel,
            "rationale": rationale.strip()[:1000], "issued_at": _now(),
            "authority": "evidence_only — this receipt records that a human approved widening authority; it grants nothing by itself"}
    body["receipt_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return body


def authority_delta(from_env: str, to_env: str, environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Exactly what widens between two environments — the list a reviewer is actually approving."""
    m = environments or load_environments()
    a, b = environment(from_env, m), environment(to_env, m)
    gained = sorted(set(b["allowed_effects"]) - set(a["allowed_effects"]))
    lost = sorted(set(a["allowed_effects"]) - set(b["allowed_effects"]))
    return {"effects_gained": gained, "effects_lost": lost,
            "direction": "widens" if gained else ("narrows" if lost else "unchanged"),
            "privileged_gained": sorted(set(gained) & set(PRIVILEGED_EFFECTS)),
            "posture": {"from": a["permissions"]["posture"], "to": b["permissions"]["posture"]},
            "quotas": {"from": dict(a["quotas"]), "to": dict(b["quotas"])},
            "network": {"from": a["network"]["mode"], "to": b["network"]["mode"]}}


def verify_compatibility_receipt(receipt: Mapping[str, Any], *, smoke: Mapping[str, Any] | None = None,
                                 entry_smoke: Mapping[str, Any] | None = None,
                                 environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Fail closed unless the receipt still describes the world it was issued over: both profiles, the registry hash
    and (when given) the smoke result must still hash the same, and it must recompute to its own receipt hash."""
    m = environments or load_environments()
    body = {k: v for k, v in receipt.items() if k != "receipt_hash"}
    if lga.sha256_digest(lga.canonical_json(body)) != receipt.get("receipt_hash"):
        raise EnvironmentRefusal("environment.receipt_tampered", "the compatibility receipt does not hash to its contents")
    stale = []
    if receipt.get("environments_hash") != m["computed_hash"]:
        stale.append("environments registry changed")
    if receipt.get("from_profile_hash") != profile_hash(receipt["from_environment"], m):
        stale.append(f"{receipt['from_environment']} profile changed")
    if receipt.get("to_profile_hash") != profile_hash(receipt["to_environment"], m):
        stale.append(f"{receipt['to_environment']} profile changed")
    if smoke is not None and receipt.get("smoke_hash") != smoke.get("smoke_hash"):
        stale.append("the source smoke result is not the one the receipt was issued over")
    if entry_smoke is not None and receipt.get("entry_smoke_hash") != entry_smoke.get("smoke_hash"):
        stale.append("the destination smoke result is not the one the receipt was issued over")
    if stale:
        raise EnvironmentRefusal("environment.receipt_stale", f"compatibility receipt no longer applies: {stale}")
    return {"verdict": "VALID", "from": receipt["from_environment"], "to": receipt["to_environment"],
            "approved_by": receipt["approver_identity"], "receipt_hash": receipt["receipt_hash"]}


def require_promotion(from_env: str, to_env: str, receipt: Mapping[str, Any] | None, *,
                      smoke: Mapping[str, Any] | None = None, entry_smoke: Mapping[str, Any] | None = None,
                      environments: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """No widening of authority without a current, human-signed compatibility receipt. There is no bypass argument
    and no default-allow branch: a missing receipt is a refusal."""
    if receipt is None:
        raise EnvironmentRefusal("environment.promotion_denied",
                                 f"{from_env} -> {to_env} widens authority and no compatibility receipt was presented")
    v = verify_compatibility_receipt(receipt, smoke=smoke, entry_smoke=entry_smoke, environments=environments)
    if (v["from"], v["to"]) != (from_env, to_env):
        raise EnvironmentRefusal("environment.promotion_denied",
                                 f"the receipt authorises {v['from']} -> {v['to']}, not {from_env} -> {to_env}")
    return v


def promotion_table(environments: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    """Every promotion path both of whose ends declare promotion, with what it changes.

    A path whose destination declares no promotion block yet is not listed — its entry criteria are unknown, and a
    row that stated no entry criteria would read as a path with nothing to demonstrate. `incomplete_paths` names them.
    """
    m = environments or load_environments()
    rows = []
    for eid in ranked(m):
        e = environment(eid, m)
        if "promotion" not in e:
            continue
        p = promotion_of(e)
        for dst in p["promotes_to"]:
            if "promotion" not in environment(dst, m):
                continue
            rows.append({"from": eid, "to": dst, "requires_receipt": bool(p["requires_receipt"]),
                         "entry_criteria": list(promotion_of(environment(dst, m))["entry_criteria"]),
                         "exit_criteria": list(p["exit_criteria"]), "widens": authority_delta(eid, dst, m)})
    return rows


def incomplete_paths(environments: Mapping[str, Any] | None = None) -> list[dict[str, str]]:
    """Declared promotion targets that do not themselves declare promotion criteria — a path nothing can traverse."""
    m = environments or load_environments()
    out = []
    for eid in ranked(m):
        e = environment(eid, m)
        if "promotion" not in e:
            continue
        for dst in promotion_of(e)["promotes_to"]:
            if "promotion" not in environment(dst, m):
                out.append({"from": eid, "to": dst, "why": f"{dst} declares no promotion criteria"})
    return out


__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "COMPATIBILITY_VERSION", "ENVIRONMENTS_PATH", "ENVIRONMENTS_VERSION",
           "ENVIRONMENT_IDS", "EVIDENCE_KIND", "HEALTH_CHECKS", "KNOWN_EFFECTS", "NETWORK_MODES", "NS", "POSTURES",
           "PRIVILEGED_EFFECTS", "PROFILE_REQUIRED", "SECRETS_MODES", "EnvironmentRefusal", "assert_no_broadening",
           "authority_delta", "cap_intent", "quota_of", "QUOTA_KEYS", "compatibility_receipt", "decide", "effective_rule_set", "environment",
           "export_evidence", "health", "lifecycle", "lifecycle_path", "load_environments", "narrowing_record",
           "pins", "posture_of",
           "profile_hash", "incomplete_paths", "promotion_of", "promotion_table", "ranked", "require_promotion", "require_ready",
           "shutdown", "startup", "verify_compatibility_receipt", "verify_profile_assertions"]
