"""Scoped PR Builder — hash-bound human approval and isolated application (SLICE-08).

Two responsibilities, deliberately separated:

1. **Approval receipts** — a human decision is recorded as an ``ApprovalReceipt`` that is
   bound to the exact ``candidate_id``, ``patch_hash``, ``base_revision``,
   ``scope_contract_hash``, review ``card_hash`` and verification ``report_hash``.
   Receipts carry a nonce and an expiry, are HMAC-signed with a key that lives
   OUTSIDE the run directory, and are appended to a hash-chained ledger whose root is
   the candidate id. A receipt that is unsigned, re-signed with another key, edited,
   expired, replayed for another candidate, or absent from the chain is rejected.
   Model output cannot produce a receipt: issuance requires the signing key and an
   explicit ``approver_identity``/``approver_channel`` supplied by the human path.

2. **Isolated application** — ``apply_isolated`` revalidates freshness (HEAD and
   pinned tree), the contract, candidate, verification report (must be PASS and
   describe this candidate), review card and receipt, then applies the patch in a NEW
   detached worktree outside the repository root. The source worktree is never
   modified; the post-apply tree identity is recorded for archival/rollback proof.

Authority: Suite 50.5 (hash-bound, scoped, expiring, replay-resistant approval),
Suite 13 (Chair authorization), Release Plane 43.8 (patch application) remain
authoritative; this adapter executes their rules locally.

Build provenance: BUILD_NEW (stdlib hmac/hashlib/secrets); no yard donor
(see ``../PROVENANCE.jsonl``).
"""
from __future__ import annotations

import hmac
import os
import re
import json
import os
import secrets
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

from . import local_git_adapter as lga
from . import security as _SEC

ADAPTER_ID = "scoped_pr_builder.approval_adapter"
ADAPTER_VERSION = "0.1.0"
RECEIPT_VERSION = "scoped_pr_builder.approval_receipt/0.1.0"
DECISIONS = ("APPROVE", "REJECT", "REQUEST_CHANGES")
DEFAULT_TTL_MINUTES = 240
BOUND_FIELDS = ("candidate_id", "patch_hash", "base_revision", "scope_contract_hash", "card_hash", "verification_report_hash")


def _now() -> datetime:
    return datetime.now(timezone.utc).replace(microsecond=0)


def _iso(dt: datetime) -> str:
    return dt.isoformat()


# --------------------------------------------------------------------------- #
# Signing key (outside the run directory)                                       #
# --------------------------------------------------------------------------- #
def load_or_create_key(key_path: Path, *, create: bool) -> bytes:
    key_path = Path(key_path)
    if key_path.exists():
        data = key_path.read_bytes().strip()
        if len(data) < 32:
            raise lga.AdapterError("approval.key_invalid", "approval signing key is too short")
        return data
    if not create:
        raise lga.AdapterError("approval.key_missing", f"approval signing key not found: {key_path}")
    key_path.parent.mkdir(parents=True, exist_ok=True)
    data = secrets.token_hex(32).encode("ascii")
    fd = os.open(key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(data + b"\n")
    return data


def _sign(key: bytes, receipt_hash: str) -> str:
    return "hmac-sha256:" + hmac.new(key, receipt_hash.encode("ascii"), "sha256").hexdigest()


# --------------------------------------------------------------------------- #
# Receipts and the hash-chained ledger                                          #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class ApprovalReceipt:
    receipt_version: str
    decision: str
    approver_identity: str
    approver_channel: str
    rationale: str
    candidate_id: str
    patch_hash: str
    base_revision: str
    scope_contract_hash: str
    card_hash: str
    verification_report_hash: str
    issued_at: str
    expires_at: str
    nonce: str
    prev_hash: str
    receipt_hash: str
    signature: str

    def to_json(self) -> str:
        return lga.canonical_json(asdict(self))


def _chain_path(run_dir: Path) -> Path:
    return run_dir / "approvals" / "ledger.jsonl"


def load_chain(run_dir: Path) -> list[dict[str, Any]]:
    path = _chain_path(run_dir)
    if not path.is_file():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def verify_chain(run_dir: Path, candidate_id: str, key: bytes) -> list[dict[str, Any]]:
    """Fail closed unless every ledger entry links, hashes, and verifies under ``key``."""
    chain = load_chain(run_dir)
    prev = candidate_id
    for i, rec in enumerate(chain):
        if rec.get("prev_hash") != prev:
            raise lga.AdapterError("approval.chain_broken", f"ledger entry {i} does not link to the previous entry")
        body = {k: v for k, v in rec.items() if k not in ("receipt_hash", "signature")}
        if lga.sha256_digest(lga.canonical_json(body)) != rec.get("receipt_hash"):
            raise lga.AdapterError("approval.receipt_tampered", f"ledger entry {i} content does not match its hash")
        if not hmac.compare_digest(_sign(key, rec["receipt_hash"]), str(rec.get("signature", ""))):
            raise lga.AdapterError("approval.signature_invalid", f"ledger entry {i} signature does not verify")
        prev = rec["receipt_hash"]
    return chain


def issue_receipt(
    run_dir: Path,
    key: bytes,
    *,
    decision: str,
    approver_identity: str,
    approver_channel: str,
    rationale: str,
    candidate: Mapping[str, Any],
    card: Mapping[str, Any],
    report: Mapping[str, Any],
    ttl_minutes: int = DEFAULT_TTL_MINUTES,
) -> ApprovalReceipt:
    """Record a human decision as a signed, chained, hash-bound receipt."""
    if decision not in DECISIONS:
        raise lga.AdapterError("approval.decision_invalid", f"decision must be one of {DECISIONS}")
    if not approver_identity.strip() or not approver_channel.strip():
        raise lga.AdapterError("approval.approver_missing", "approver_identity and approver_channel are required")
    _SEC.require_human_channel(approver_channel, identity=approver_identity, run_dir=run_dir)  # SEC-07-T02: model/content channels cannot record a decision
    if card["identity"]["candidate_id"] != candidate["candidate_id"] or report["candidate_id"] != candidate["candidate_id"]:
        raise lga.AdapterError("approval.artifact_mismatch", "review card / verification report do not describe this candidate")
    if ttl_minutes <= 0 or ttl_minutes > 24 * 60:
        raise lga.AdapterError("approval.ttl_invalid", "ttl_minutes must be within (0, 1440]")
    chain = verify_chain(run_dir, candidate["candidate_id"], key)
    prev = chain[-1]["receipt_hash"] if chain else candidate["candidate_id"]
    now = _now()
    body = {
        "receipt_version": RECEIPT_VERSION,
        "decision": decision,
        "approver_identity": approver_identity.strip(),
        "approver_channel": approver_channel.strip(),
        "rationale": rationale.strip(),
        "candidate_id": candidate["candidate_id"],
        "patch_hash": candidate["patch_hash"],
        "base_revision": candidate["base_revision"],
        "scope_contract_hash": candidate["scope_contract_hash"],
        "card_hash": card["card_hash"],
        "verification_report_hash": report["report_hash"],
        "issued_at": _iso(now),
        "expires_at": _iso(now + timedelta(minutes=ttl_minutes)),
        "nonce": secrets.token_hex(16),
        "prev_hash": prev,
    }
    receipt_hash = lga.sha256_digest(lga.canonical_json(body))
    receipt = ApprovalReceipt(**body, receipt_hash=receipt_hash, signature=_sign(key, receipt_hash))
    path = _chain_path(run_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(receipt.to_json() + "\n")
    return receipt


def verify_receipt(
    run_dir: Path,
    key: bytes,
    receipt: Mapping[str, Any],
    *,
    candidate: Mapping[str, Any],
    card: Mapping[str, Any],
    report: Mapping[str, Any],
    now: datetime | None = None,
) -> None:
    """Fail closed unless ``receipt`` is a valid, unexpired APPROVE bound to exactly these artifacts."""
    chain = verify_chain(run_dir, candidate["candidate_id"], key)
    _SEC.verify_human_origin(receipt, chain=chain, run_dir=run_dir)  # SEC-07-T02: channel, HMAC shape, nonce uniqueness, issue time
    position = next((i for i, rec in enumerate(chain) if rec.get("receipt_hash") == receipt.get("receipt_hash") and rec == receipt), None)
    if position is None:
        raise lga.AdapterError("approval.not_in_ledger", "receipt is not present in the signed approval ledger")
    expected = {
        "candidate_id": candidate["candidate_id"], "patch_hash": candidate["patch_hash"], "base_revision": candidate["base_revision"],
        "scope_contract_hash": candidate["scope_contract_hash"], "card_hash": card["card_hash"], "verification_report_hash": report["report_hash"],
    }
    for field in BOUND_FIELDS:
        if receipt.get(field) != expected[field]:
            raise lga.AdapterError("approval.binding_mismatch", f"receipt {field} does not match the artifact under review")
    if receipt.get("decision") != "APPROVE":
        raise lga.AdapterError("approval.not_approved", f"decision is {receipt.get('decision')!r}; application is not authorized")
    current = now or _now()
    if datetime.fromisoformat(receipt["expires_at"]) <= current:
        raise lga.AdapterError("approval.expired", "approval receipt has expired")
    # A later (in ledger order) REJECT / REQUEST_CHANGES for the same candidate supersedes an earlier APPROVE.
    later = []
    for r in chain[position + 1:]:
        try:
            issued = datetime.fromisoformat(str(r["issued_at"]).replace("Z", "+00:00"))
        except (KeyError, ValueError) as exc:
            raise lga.AdapterError("approval.receipt_tampered", "a later ledger entry has an invalid issued_at timestamp") from exc
        if issued <= current and r["decision"] != "APPROVE":
            later.append(r)
    if later:
        raise lga.AdapterError("approval.superseded", "a later non-approve decision supersedes this receipt")


# --------------------------------------------------------------------------- #
# Isolated application                                                          #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class AppliedRecord:
    adapter_id: str
    adapter_version: str
    candidate_id: str
    patch_hash: str
    base_revision: str
    scope_contract_hash: str
    receipt_hash: str
    applied_worktree: str
    changed_paths: tuple[str, ...]
    post_apply_tree: str
    source_tree_unchanged: bool
    branch_name: str
    commit_hash: str
    applied_at: str
    guardrails_hash: str = ""
    record_hash: str = ""

    def to_json(self) -> str:
        return lga.canonical_json(asdict(self))


def apply_isolated(
    binding: lga.RepositoryBinding,
    contract: Mapping[str, Any],
    candidate: Mapping[str, Any],
    patch: bytes,
    report: Mapping[str, Any],
    card: Mapping[str, Any],
    receipt: Mapping[str, Any],
    key: bytes,
    run_dir: Path,
    worktree_parent: Path,
) -> AppliedRecord:
    """Apply an APPROVED candidate in a fresh isolated worktree after full revalidation."""
    from . import intent_intake as ii
    from . import patch_generator as pg

    # --- revalidation gate (all fail closed) ---------------------------------------
    lga.revalidate_binding(binding)
    ii.verify_contract_hash(contract)
    _SEC.use_trail(run_dir)
    _SEC.assert_tenant(binding, ("scope_contract", contract), ("candidate", candidate), ("verification_report", report), ("review_card", card.get("identity") or {}), ("approval_receipt", receipt), run_dir=run_dir)  # SEC-04-T02: nothing from another tenant is applied
    _SEC.assert_audit_intact(run_dir)  # SEC-08-T02: an edited ledger blocks the effect
    pg.verify_candidate_hash(candidate, patch)
    if candidate["scope_contract_hash"] != contract["scope_contract_hash"] or candidate["base_revision"] != binding.base_revision:
        raise lga.AdapterError("apply.candidate_mismatch", "candidate is not bound to this contract/revision")
    from . import verification_runner as vr
    vr.verify_report_hash(report)  # a report whose verdict was edited after the run is refused
    if report["candidate_id"] != candidate["candidate_id"] or report["patch_hash"] != candidate["patch_hash"]:
        raise lga.AdapterError("apply.report_mismatch", "verification report does not describe this candidate")
    if report["verdict"] != "PASS":
        raise lga.AdapterError("apply.verification_not_pass", f"verification verdict is {report['verdict']}; application refused")
    # VERIFY-*-T03: the application boundary consumes typed check receipts re-derived from the hash-bound report — never assertions
    from . import verification_checks as VC
    VC.require_gate(VC.derive_results(report, binding=binding, contract=contract, candidate=candidate), VC.subject_of(binding, contract, candidate), stage="apply.isolated")
    body = {k: v for k, v in card.items() if k not in ("card_hash", "rendered_at")}
    if lga.sha256_digest(lga.canonical_json(body)) != card.get("card_hash") or card["identity"]["candidate_id"] != candidate["candidate_id"]:
        raise lga.AdapterError("apply.card_mismatch", "review card is tampered or describes another candidate")
    _SEC.verify_human_origin(receipt, run_dir=run_dir)  # SEC-07-T02: a fabricated token is refused before the ledger is consulted
    try:  # SEC-05-T02: verified receipt or a trailed refusal
        verify_receipt(run_dir, key, receipt, candidate=candidate, card=card, report=report)
    except lga.AdapterError as exc:
        if exc.code.startswith("approval."):
            _SEC.record_denial("SEC-05", "security.sec05.unauthorized_write", str(exc), actor={"identity": receipt.get("approver_identity"), "channel": receipt.get("approver_channel")}, subject={"candidate_id": candidate["candidate_id"]}, run_dir=run_dir)
        raise
    _SEC.guard_write("patch.apply_isolated", {"identity": receipt.get("approver_identity"), "channel": receipt.get("approver_channel")}, authorized_by=receipt, run_dir=run_dir)  # SEC-05-T02: the effect boundary re-check — a repository write needs a verified human APPROVE
    _SEC.enforce_sec01_effect(receipt, card, run_dir=run_dir)  # SEC-01-T02: content/model channels never authorize; evidence stays marked untrusted
    _SEC.enforce_sec03_effect(patch, run_dir=run_dir, subject={"candidate_id": candidate["candidate_id"]})  # SEC-03-T02: a candidate adding secret material never applies
    _SEC.require_release_gate(stage="apply.isolated", run_dir=run_dir)  # SEC-*-T05: the tool's own security receipts must be current; non-waivable
    from . import review_surface as _RS  # HUMAN-*-T04: a verified receipt invalidated by a later human command (or over changed bound inputs) is never reused at the effect boundary
    _RS.assert_approval_current(run_dir, receipt, {"binding": binding, "candidate": candidate, "review_card": card, "verification_report": report})
    # PAPER-GRD-03/04-T03: the effect boundary — all four paper guardrails are evaluated on facts derived from the
    # artifacts under application; any blocking state refuses before a worktree exists; decisions are persisted.
    from . import guardrails as GR
    decisions = GR.enforce("patch.apply_isolated", GR.apply_time_facts(binding, contract, candidate, patch, card, report, receipt, run_dir, key))
    guard = GR.record_decisions(run_dir, "patch.apply_isolated", candidate["candidate_id"], decisions)

    root = Path(binding.root_path)
    before_tree = lga.tree_identity(root, binding.base_revision)
    before_status = lga.git(root, "status", "--porcelain", "--untracked-files=all")
    allowed = lga.validated_roots(contract["allowed_paths"], "allowed_paths")
    forbidden = lga.validated_roots(contract.get("forbidden_paths", ()), "forbidden_paths", allow_empty=True)

    wt = lga.worktree_add(root, Path(worktree_parent) / f"apply-{candidate['candidate_id'][7:19]}", binding.base_revision)
    try:
        import subprocess
        chk = subprocess.run(["git", "apply", "--check", "-"], cwd=wt, input=patch, capture_output=True)
        if chk.returncode != 0:
            raise lga.AdapterError("apply.not_applicable", chk.stderr.decode("utf-8", errors="replace").strip())
        ap = subprocess.run(["git", "apply", "-"], cwd=wt, input=patch, capture_output=True)
        if ap.returncode != 0:
            raise lga.AdapterError("apply.failed", ap.stderr.decode("utf-8", errors="replace").strip())
        changed = list(lga.changed_paths(wt, binding.base_revision))
        _SEC.validate_paths(changed, allowed=allowed, forbidden=forbidden, label="applied_paths", run_dir=run_dir)  # SEC-02-T02: the effect boundary
        lga.require_within_scope(changed, allowed, forbidden)
        declared = {PurePosixPath(p) for p in candidate["canonical_paths"]}
        if set(changed) != declared:
            raise lga.AdapterError("apply.scope_drift", f"applied paths {sorted(map(str, changed))} differ from declared {sorted(map(str, declared))}")
        if len(changed) > contract["max_changed_files"]:
            raise lga.AdapterError("apply.too_many_files", "applied change exceeds max_changed_files")
        VC.assert_symbol_scope(wt, root, binding.base_revision, candidate, report)  # VERIFY-05-T03: applied symbol changes == verified/approved symbol change set
        # Content-addressed tree plus a real isolated branch/commit. The source worktree is never checked out or changed.
        lga.git(wt, "add", "-A")
        post_tree = lga.git(wt, "write-tree")
        raw_slug = str(contract.get("title") or contract.get("intent_id") or "change").lower()
        slug = re.sub(r"[^a-z0-9]+", "-", raw_slug).strip("-")[:48] or "change"
        iid = re.sub(r"[^a-zA-Z0-9]+", "-", str(contract.get("intent_id","intent"))).strip("-")[:24]
        branch_name = f"spb/{iid}-{slug}"
        existing = lga.git(root, "branch", "--list", branch_name).strip()
        if existing:
            raise lga.AdapterError("apply.branch_exists", f"isolated branch already exists: {branch_name}")
        lga.git(wt, "switch", "-c", branch_name)
        env = os.environ.copy(); env.setdefault("GIT_AUTHOR_NAME","Scoped PR Builder"); env.setdefault("GIT_AUTHOR_EMAIL","spb@localhost"); env.setdefault("GIT_COMMITTER_NAME","Scoped PR Builder"); env.setdefault("GIT_COMMITTER_EMAIL","spb@localhost")
        import subprocess as _sp
        msg=f"chore(spb): {contract.get('title','scoped refactor')}\n\nCandidate: {candidate['candidate_id']}\nPatch: {candidate['patch_hash']}\nScope: {contract['scope_contract_hash']}\nVerification: {report['report_hash']}"
        cp=_sp.run(["git","commit","-m",msg],cwd=wt,env=env,capture_output=True,text=True)
        if cp.returncode != 0: raise lga.AdapterError("apply.commit_failed", cp.stderr.strip())
        commit_hash=lga.git(wt,"rev-parse","HEAD")
    except Exception:
        lga.worktree_remove(root, wt)
        raise
    unchanged = lga.tree_identity(root, binding.base_revision) == before_tree and lga.git(root, "status", "--porcelain", "--untracked-files=all") == before_status
    if not unchanged:
        lga.worktree_remove(root, wt)
        raise lga.AdapterError("apply.source_modified", "source worktree changed during isolated application; rolled back")
    rec = AppliedRecord(
        adapter_id=ADAPTER_ID, adapter_version=ADAPTER_VERSION, candidate_id=candidate["candidate_id"], patch_hash=candidate["patch_hash"],
        base_revision=binding.base_revision, scope_contract_hash=contract["scope_contract_hash"], receipt_hash=receipt["receipt_hash"],
        applied_worktree=str(wt), changed_paths=tuple(p.as_posix() for p in changed), post_apply_tree=f"git-tree:{post_tree}",
        source_tree_unchanged=True, branch_name=branch_name, commit_hash=commit_hash, applied_at=_iso(_now()), guardrails_hash=guard["decisions_hash"],
    )
    body = asdict(rec); body.pop("record_hash")
    return AppliedRecord(**{**body, "record_hash": lga.sha256_digest(lga.canonical_json(body))})


__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "RECEIPT_VERSION", "DECISIONS", "ApprovalReceipt", "AppliedRecord", "apply_isolated", "issue_receipt", "load_chain", "load_or_create_key", "verify_chain", "verify_receipt"]
