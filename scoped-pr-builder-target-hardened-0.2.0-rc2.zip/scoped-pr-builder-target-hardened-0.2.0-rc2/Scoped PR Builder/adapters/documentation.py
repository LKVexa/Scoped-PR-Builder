"""Documentation that cannot drift: twelve deliverables generated from the registries they describe.

Hand-written architecture documentation is wrong within a month, and the failure is silent — nothing tells you that
the permission matrix in the wiki no longer matches the policy, or that a threat model still describes a boundary
that moved two releases ago. So none of these documents is written by hand. Each declares which registries it draws
from; the generator renders it from those registries; and a freshness check re-reads them and refuses when the
document no longer matches what it documents.

The consequence worth stating plainly: a document here is evidence about the implementation only because it was
produced from the implementation. Where something is NOT implemented, the generator says so in those words rather
than describing intended behaviour as operational fact — that distinction is the whole point of DOC-*-T03.

Build provenance (DOC-01..12 — BUILD_NEW). Yard retrieval ran before this module was drafted: ledger recall on
documentation generation, then yard_query for documentation generator, architecture diagram, trust boundary, docs
freshness, permission matrix, runbook, markdown generator, schema documentation and stale reference. Inspected and
rejected: `generator-azuredatastudio` (MIT — a Yeoman scaffolder that emits VS Code extension skeletons from
templates; it generates code from prompts, not documentation from a running system), `json-schemas` (MIT — a
published collection of Microsoft's own schemas), `hve-core-main` (MIT — a Copilot prompt library),
`ApplicationInsights-JS` (MIT — SDK reference docs), `HybridRunbookWorkerConfig` (MIT — a PowerShell Azure Automation
worker configuration script, unrelated to an incident runbook for this tool), `apm-main` (an agent dependency
manager). One query matched nothing at all. Nothing was selected; this is stdlib-only and reads the overlay's own
registries.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from . import contracts as C
from . import local_git_adapter as lga

DOCS_VERSION = "scoped_pr_builder.documentation/0.1.0"
DOCS_PATH = Path(__file__).resolve().parent.parent / "docs" / "DOCS.json"
OVERLAY_ROOT = Path(__file__).resolve().parent.parent
REPO_ROOT = OVERLAY_ROOT.parent
DOCS_DIR = "docs"
ADAPTER_ID = "scoped_pr_builder.documentation"
ADAPTER_VERSION = "0.1.0"
NS = "overlay.scoped_pr_builder.documentation"

DOC_IDS = tuple(f"DOC-{i:02d}" for i in range(1, 13))
DOC_REQUIRED = ("doc_id", "title", "filename", "generator", "sources", "knowledge_repository",
                "authoritative_suites", "introduced_by")
#: Front-matter every document carries (DOC-*-T03). None of it is optional: a document with no owner, no
#: last-validated version or no change triggers is the kind that quietly rots, and the loader refuses one.
FRONT_MATTER = ("ownership", "last_validated_version", "last_validated_at", "source_references",
                "assumptions", "known_gaps", "change_triggers")

#: Where a document may draw from. Each name resolves to a loader and a hash, so a document records exactly which
#: version of each registry it was generated against.
SOURCE_REGISTRIES = ("contracts", "threats", "matrix", "invariants", "environments", "guardrails", "components",
                     "workflow", "intake", "checks", "boundaries", "stores", "review", "model", "wiring",
                     "readiness", "policy")


class DocumentationRefusal(lga.AdapterError):
    """Raised when a document is malformed, ungenerated, or no longer matches what it documents."""


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def load_docs(path: Path = DOCS_PATH, *, registry: Mapping[str, Any] | None = None,
              repo_root: Path = REPO_ROOT) -> dict[str, Any]:
    """Load and validate the documentation registry.

    A document must name a known DOC id, a generator this adapter actually implements, at least one source registry,
    the Knowledge Repository record it registers under, and suite files that exist. A document with no sources is
    refused: it would be hand-written prose wearing a generated document's front matter, which is precisely the
    thing this module exists to prevent.
    """
    if not Path(path).is_file():
        raise DocumentationRefusal("documentation.registry_missing", f"no documentation registry at {path}")
    m = json.loads(Path(path).read_text(encoding="utf-8"))
    if m.get("docs_version") != DOCS_VERSION:
        raise DocumentationRefusal("documentation.registry_invalid", "docs_version mismatch")
    for did, d in (m.get("documents") or {}).items():
        missing = [k for k in DOC_REQUIRED if k not in d]
        if missing or d["doc_id"] != did or did not in DOC_IDS:
            raise DocumentationRefusal("documentation.registry_invalid", f"{did}: missing {missing} / unknown doc id")
        if not isinstance(d["sources"], list) or not d["sources"]:
            raise DocumentationRefusal("documentation.sources_undeclared",
                                       f"{did}: a document must declare the registries it is generated from; "
                                       f"a document with no sources is hand-written prose in generated clothing")
        unknown = sorted(set(d["sources"]) - set(SOURCE_REGISTRIES))
        if unknown:
            raise DocumentationRefusal("documentation.registry_invalid", f"{did}: unknown source registries {unknown}")
        # A document may be DECLARED before its generator is implemented — that is the difference between creating
        # the deliverable and populating it. What must never happen is generating from a generator that does not
        # exist, so `render` refuses that; here the state is only recorded.
        d["generator_implemented"] = d["generator"] in GENERATORS
        if not str(d["filename"]).endswith(".md") or "/" in str(d["filename"]):
            raise DocumentationRefusal("documentation.registry_invalid", f"{did}: filename must be a bare .md name")
        if "front_matter" in d:
            fm_missing = [k for k in FRONT_MATTER if k not in d["front_matter"]]
            if fm_missing:
                raise DocumentationRefusal("documentation.front_matter_incomplete", f"{did}: front matter lacks {fm_missing}")
        for f in d["authoritative_suites"]:
            if not (Path(repo_root) / f).is_file():
                raise DocumentationRefusal("documentation.suite_unbound", f"{did}: authoritative suite file does not exist: {f}")
    body = {k: v for k, v in m.items() if k != "docs_hash"}
    m["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return m


def document(doc_id: str, docs: Mapping[str, Any] | None = None) -> dict[str, Any]:
    m = docs or load_docs()
    d = (m.get("documents") or {}).get(doc_id)
    if d is None:
        raise DocumentationRefusal("documentation.unknown", f"no such document {doc_id!r}")
    return dict(d)


def doc_path(doc_id: str, *, root: Path | None = None, docs: Mapping[str, Any] | None = None) -> Path:
    d = document(doc_id, docs)
    return (Path(root) if root is not None else OVERLAY_ROOT) / DOCS_DIR / d["filename"]


def source_state(*, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Every source registry with its current hash and a short description of what it holds.

    A registry that cannot be read is reported with a null hash rather than omitted, so a document resting on it
    reads as indeterminate instead of silently matching nothing.
    """
    from . import architecture as A
    from . import components as K
    from . import environment as E
    from . import guardrails as G
    from . import intake as IN
    from . import invariants as I
    from . import model_orchestration as MO
    from . import qualification as Q
    from . import release_gate as RG
    from . import review_surface as RS
    from . import security as SEC
    from . import store as ST
    from . import verification_checks as VC
    from . import wiring as WI
    from . import workflow as W
    reg = registry or C.load_registry()
    loaders: dict[str, Callable[[], Any]] = {
        "contracts": lambda: reg, "threats": SEC.load_threats, "matrix": Q.load_matrix,
        "invariants": I.load_invariants, "environments": E.load_environments, "guardrails": G.load_rules,
        "components": K.load_components, "workflow": W.load_workflow, "intake": IN.load_sources,
        "checks": VC.load_checks, "boundaries": A.load_boundaries, "stores": ST.load_stores,
        "review": RS.load_review, "model": MO.load_model_contract, "wiring": WI.load_wiring,
        "readiness": RG.load_readiness, "policy": _policy_state,
    }
    out: dict[str, Any] = {}
    for name, fn in loaders.items():
        try:
            m = fn()
            out[name] = {"hash": m.get("computed_hash"), "entries": _entry_count(m)}
        except Exception as exc:
            out[name] = {"hash": None, "entries": None, "error": f"{type(exc).__name__}"}
    return out


def _entry_count(m: Mapping[str, Any]) -> int | None:
    for key in ("contracts", "threats", "scenarios", "invariants", "environments", "rules", "components", "steps",
                "sources", "checks", "boundaries", "stores", "behaviors", "providers", "ports", "assertions",
                "lines"):
        v = m.get(key)
        if isinstance(v, (dict, list)):
            return len(v)
    return None


def _policy_state() -> dict[str, Any]:
    """The policy surface is a JA file, not a JSON registry: its state is the hash of the file itself and the number
    of declared rule lines. Documenting it from the file is the only honest option — there is no registry to read."""
    p = OVERLAY_ROOT / "scoped_pr_builder_policy.jasec"
    text = p.read_text(encoding="utf-8") if p.is_file() else ""
    lines = [l.strip() for l in text.splitlines() if l.strip().startswith(("deny ", "allow ", "audit "))]
    return {"computed_hash": lga.sha256_digest(text), "lines": lines}


def knowledge_repository_rows(docs: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    """The registration rows for Knowledge Repository 41.1 — one per document, by id and record name."""
    m = docs or load_docs()
    return [{"record_schema": "suite41.knowledge_repository.documentation/DocumentRecord",
             "document_id": did, "title": d["title"], "path": f"Scoped PR Builder/{DOCS_DIR}/{d['filename']}",
             "knowledge_repository": d["knowledge_repository"], "generator": d["generator"],
             "sources": list(d["sources"]), "owner": (d.get("front_matter") or {}).get("ownership"),
             "introduced_by": d["introduced_by"]}
            for did, d in sorted((m.get("documents") or {}).items())]


# --------------------------------------------------------------------------- #
# T02 — the generators. Each renders from the registries its document declares, so names, ids, versions, permissions
# and boundaries are the implementation's, not a writer's recollection of it.
# --------------------------------------------------------------------------- #
GENERATORS: dict[str, Callable[..., list[str]]] = {}


def generator(name: str):
    def deco(fn):
        GENERATORS[name] = fn
        return fn
    return deco


def _table(headers: Sequence[str], rows: Sequence[Sequence[Any]]) -> list[str]:
    if not rows:
        return ["_No entries._", ""]
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(c).replace("|", "\\|").replace("\n", " ") for c in r) + " |")
    out.append("")
    return out


def _short(h: Any, n: int = 12) -> str:
    return h[7:7 + n] if isinstance(h, str) and h.startswith("sha256:") else str(h)


def _suites(entry: Mapping[str, Any], n: int = 2) -> str:
    """Authoritative suites, which registries record either as bare paths or as {file, role} objects."""
    out = []
    for s in (entry.get("authoritative_suites") or [])[:n]:
        out.append(s["file"] if isinstance(s, Mapping) else str(s))
    return ", ".join(f"`{x}`" for x in out) or "—"


def _seq(value: Any) -> list[Any]:
    """Registry fields are declared per registry, and the same-sounding field is sometimes a list, sometimes a flag
    and sometimes an object. A generator that assumed one shape would crash on the next registry, so every list
    rendering goes through here: a list stays a list, anything else becomes a single-item list or nothing."""
    if isinstance(value, list):
        return value
    if value is None or value is False:
        return []
    if value is True:
        return ["yes"]
    if isinstance(value, Mapping):
        return [f"{k}: {v}" for k, v in sorted(value.items())]
    return [value]


def _cells(value: Any, n: int = 3, code: bool = True) -> str:
    items = [str(x) for x in _seq(value)[:n]]
    return ", ".join(f"`{x}`" if code else x for x in items) or "—"


def _first(entry: Mapping[str, Any], *keys: str, default: str = "—") -> str:
    for k in keys:
        v = entry.get(k)
        if isinstance(v, str) and v.strip():
            return v
    return default


def _loaded(name: str, *, registry: Mapping[str, Any] | None = None) -> Any:
    """Load one source registry, or raise the refusal that says which document cannot be generated and why."""
    from . import architecture as A
    from . import components as K
    from . import environment as E
    from . import guardrails as G
    from . import intake as IN
    from . import invariants as I
    from . import model_orchestration as MO
    from . import qualification as Q
    from . import release_gate as RG
    from . import review_surface as RS
    from . import security as SEC
    from . import store as ST
    from . import verification_checks as VC
    from . import wiring as WI
    from . import workflow as W
    reg = registry or C.load_registry()
    fns = {"contracts": lambda: reg, "threats": SEC.load_threats, "matrix": Q.load_matrix,
           "invariants": I.load_invariants, "environments": E.load_environments, "guardrails": G.load_rules,
           "components": K.load_components, "workflow": W.load_workflow, "intake": IN.load_sources,
           "checks": VC.load_checks, "boundaries": A.load_boundaries, "stores": ST.load_stores,
           "review": RS.load_review, "model": MO.load_model_contract, "wiring": WI.load_wiring,
           "readiness": RG.load_readiness, "policy": _policy_state}
    if name not in fns:
        raise DocumentationRefusal("documentation.source_unknown", f"no source registry {name!r}")
    try:
        return fns[name]()
    except lga.AdapterError as exc:
        raise DocumentationRefusal("documentation.source_unreadable", f"{name}: {exc}") from exc


@generator("architecture")
def _gen_architecture(ctx: Mapping[str, Any]) -> list[str]:
    """DOC-01 — the boundaries, their trust levels and effects, and the ports and adapters that serve each."""
    b = _loaded("boundaries", registry=ctx["registry"])
    w = _loaded("wiring", registry=ctx["registry"])
    K = _loaded("components", registry=ctx["registry"])
    out = ["## Boundaries", "",
           "Every crossing in this tool goes through a declared boundary. A message naming no boundary, or one not "
           "declared here, is refused at `architecture.check_crossing` rather than routed. `denied_effects` is the "
           "column to read: those are refused at the boundary regardless of what any caller asks for.", ""]
    rows = []
    for bid, e in sorted((b.get("boundaries") or {}).items()):
        rows.append([f"`{bid}`", e.get("layer", "—"), f"`{e.get('trust_level', '—')}`",
                     _cells(e.get("allowed_effects")), _cells(e.get("denied_effects"))])
    out += _table(["boundary", "layer", "trust level", "allows", "denies"], rows)
    out += ["## Ports and the adapters that serve them", "",
            "A port is where the overlay meets something across a boundary. Each names one serving adapter, the "
            "contracts it accepts and emits, and which of its effects are guarded as privileged.", ""]
    prows = []
    for pid, p in sorted((w.get("ports") or {}).items()):
        prows.append([f"`{pid}`", f"`{p.get('boundary_id', '—')}`", f"`{p.get('adapter_id', '—')}`",
                      _cells(p.get("inbound_contracts"), 2), _cells(p.get("privileged_effects_guarded"), 2)])
    out += _table(["port", "boundary", "adapter", "inbound contracts", "privileged effects guarded"], prows)
    comps = K.get("components") or {}
    out += ["## Components", "",
            f"{len(comps)} declared components. Each declares its interface bounds — file counts, output sizes and "
            f"timeouts — which are enforced rather than advisory: a component exceeding them is refused.", ""]
    crows = []
    for cid, c in sorted(comps.items()):
        bounds = ((c.get("interface") or {}).get("bounds") or {})
        crows.append([f"`{cid}`", c.get("title", "")[:46],
                      str(bounds.get("timeout_s", "—")), str(bounds.get("max_files", "—")), _suites(c, 1)])
    out += _table(["component", "title", "timeout (s)", "max files", "authoritative suite"], crows)
    return out


@generator("data_flow")
def _gen_data_flow(ctx: Mapping[str, Any]) -> list[str]:
    """DOC-02 — where data comes from, which trust boundary it crosses, and what happens to it there."""
    th = _loaded("threats", registry=ctx["registry"])
    intake = _loaded("intake", registry=ctx["registry"])
    b = _loaded("boundaries", registry=ctx["registry"])
    out = ["## Trust boundaries", "",
           "Each row is a boundary where data changes trust level. The deny conditions are enforced in code at that "
           "boundary — they are not advice to a model.", ""]
    rows = []
    for tid, t in sorted((th.get("threats") or {}).items()):
        rows.append([f"`{tid}`", t.get("trust_boundary", "—"), str(t.get("title", ""))[:52],
                     _cells(t.get("deny_when"), 2, code=False)])
    out += _table(["threat", "trust boundary", "title", "denied when"], rows)
    out += ["## Sources and how they enter", "",
            "Nothing is analysed that was not admitted here. Each source is pinned at admission and re-checked for "
            "freshness before it is used.", ""]
    srows = []
    for sid, src in sorted((intake.get("sources") or {}).items()):
        srows.append([f"`{sid}`", _cells(src.get("permission_scope")),
                      str((src.get("freshness") or {}).get("rule", src.get("freshness")))[:52],
                      _suites(src, 1)])
    out += _table(["source", "permission scope", "freshness rule", "authoritative suite"], srows)
    out += ["## Flow", "",
            "```", "  repository (read-only, pinned revision)",
            "        │  bind + pin  ──────────────────────────────► suite40/binding.json",
            "        ▼",
            "  intake: admit, stamp, verify pin ──────────────────► intake/",
            "        ▼",
            "  deterministic analyzers (symbols, deps, graph) ────► index/",
            "        ▼   [TRUST BOUNDARY: everything below treats repository content as DATA]",
            "  retrieval (BM25 over the pinned tree, bounded) ────► plan/refactoring_plan.json:evidence_refs",
            "        ▼   [TRUST BOUNDARY: model output is untrusted and schema-validated]",
            "  model boundary (sealed sources, no minting) ───────► model/calls.jsonl",
            "        ▼",
            "  plan → candidate patch (INERT, never applied here) ► candidate/",
            "        ▼",
            "  verification in an isolated worktree ──────────────► verification/",
            "        ▼   [TRUST BOUNDARY: a human decides; the tool cannot]",
            "  review surface (bound, hash-sealed) ───────────────► review/surface.json",
            "        ▼",
            "  human approval receipt (signed, TTL, scope-bound) ─► approvals/ledger.jsonl",
            "        ▼",
            "  apply in an isolated worktree, then rollback ──────► applied/, archive/rollback.json",
            "```", "",
            f"Declared boundaries: {len(b.get('boundaries') or {})}. Every arrow above that crosses a trust boundary "
            f"is a refusal point, not a checkpoint: the default is to refuse.", ""]
    return out


@generator("source_inventory")
def _gen_source_inventory(ctx: Mapping[str, Any]) -> list[str]:
    """DOC-03 — every source and connector this tool admits, and what it refuses."""
    intake = _loaded("intake", registry=ctx["registry"])
    env = _loaded("environments", registry=ctx["registry"])
    out = ["## Admitted sources", ""]
    rows = []
    for sid, src in sorted((intake.get("sources") or {}).items()):
        ident = src.get("identity") or {}
        rows.append([f"`{sid}`", str(ident.get("bound_by", ident))[:56],
                     _cells(src.get("permission_scope")), str(src.get("size_caps") or "—")[:40]])
    out += _table(["source", "bound by", "permission scope", "size caps"], rows)
    out += ["## Connectors", "",
            "This tool has one external connector — a local git repository, opened read-only — and no others. "
            "It declares `network: none` in every environment profile, so there is no HTTP client, no API client "
            "and no message bus to inventory.", ""]
    crows = [["local git repository", "`adapters/local_git_adapter`", "read-only; worktrees under the run directory",
              "the operator supplies the path at bind time"],
             ["model provider", "`adapters/model_orchestration`",
              "in-process deterministic advisor, pinned", "declared in `model/PROVIDERS.json`; an unapproved "
              "provider is refused"]]
    out += _table(["connector", "adapter", "posture", "how it is bound"], crows)
    out += ["## Network posture by environment", ""]
    erows = [[f"`{eid}`", e["network"]["mode"], e["permissions"]["posture"],
              str(e["quotas"].get("max_changed_files"))]
             for eid, e in sorted((env.get("environments") or {}).items(), key=lambda kv: kv[1]["rank"])]
    out += _table(["environment", "network", "posture", "max changed files"], erows)
    return out


@generator("permission_matrix")
def _gen_permission_matrix(ctx: Mapping[str, Any]) -> list[str]:
    """DOC-04 — which principal may exercise which effect, in which environment, under what condition."""
    env = _loaded("environments", registry=ctx["registry"])
    pol = _loaded("policy", registry=ctx["registry"])
    from . import environment as E
    out = ["## Effects by environment", "",
           "The effective authority of a run is the policy's grants INTERSECTED with the environment's allowed "
           "effects. An environment can only narrow; there is no code path that adds a grant.", ""]
    envs = sorted((env.get("environments") or {}).items(), key=lambda kv: kv[1]["rank"])
    effects = sorted(E.KNOWN_EFFECTS)
    headers = ["effect"] + [eid.replace("_", " ") for eid, _ in envs]
    rows = []
    for eff in effects:
        row = [f"`{eff}`"]
        for eid, e in envs:
            allowed = eff in e["allowed_effects"]
            gated = eff in (e["permissions"].get("require_human_approval") or [])
            row.append("human gate" if (allowed and gated) else ("yes" if allowed else "—"))
        rows.append(row)
    out += _table(headers, rows)
    out += ["## Privileged effects", "",
            "Two effects touch a repository: `patch.apply_isolated` and `rollback.execute`. Both require a verified "
            "human APPROVE receipt at `security.guard_write`, and both are refused to any model or untrusted "
            "principal by name, in every environment.", "",
            "## Policy rules in force", "",
            f"{len(pol.get('lines') or [])} declared rule lines in `scoped_pr_builder_policy.jasec`. "
            f"Conflict resolution is `explicit_deny_wins`; an ungranted effect is denied by default.", ""]
    return out


@generator("threat_model")
def _gen_threat_model(ctx: Mapping[str, Any]) -> list[str]:
    """DOC-05 — every declared threat, where it is enforced, and the code it refuses with."""
    th = _loaded("threats", registry=ctx["registry"])
    inv = _loaded("invariants", registry=ctx["registry"])
    from . import security as SEC
    out = ["## Threats", "",
           "Each threat names the trust boundary it lives at, the conditions that deny it, and the audit event it "
           "writes. Every one is enforced at an effect boundary in code.", ""]
    rows = []
    for tid, t in sorted((th.get("threats") or {}).items()):
        codes = SEC.deny_codes(th, tid)
        rows.append([f"`{tid}`", str(t.get("title", ""))[:50], t.get("trust_boundary", "—"),
                     _cells(codes)])
    out += _table(["threat", "title", "trust boundary", "refusal codes"], rows)
    out += ["## Security invariants and where they are enforced", "",
            "The XSEC family of platform invariants, with the callable that is authoritative for each. An invariant "
            "whose enforcement point does not resolve is refused at load, so nothing here is aspirational.", ""]
    irows = []
    for iid, e in sorted((inv.get("invariants") or {}).items()):
        if not iid.startswith("XSEC"):
            continue
        enf = e.get("enforcement") or {}
        deferred = enf.get("deferred_to_host")
        irows.append([f"`{iid}`", e["statement"],
                      "**DEFERRED TO HOST**" if deferred else f"`{enf.get('authoritative_point', '—')}`"])
    out += _table(["invariant", "statement", "enforced at"], irows)
    deferred = [iid for iid, e in (inv.get("invariants") or {}).items()
                if (e.get("enforcement") or {}).get("deferred_to_host")]
    if deferred:
        out += ["### Not implemented by this tool", ""]
        for iid in sorted(deferred):
            e = inv["invariants"][iid]
            out += [f"**{iid} — {e['statement']}**", "",
                    (e.get("enforcement") or {}).get("deferral_reason", ""), "",
                    "This is a host requirement. It is recorded as `deferred`, never as satisfied, and it appears as "
                    "a residual risk on every release record.", ""]
    return out


@generator("model_inventory")
def _gen_model_inventory(ctx: Mapping[str, Any]) -> list[str]:
    """DOC-06 — the model providers and the tools, with what each is allowed to do."""
    mo = _loaded("model", registry=ctx["registry"])
    K = _loaded("components", registry=ctx["registry"])
    from . import model_orchestration as MO
    out = ["## Model providers", ""]
    rows = []
    for pid, p in sorted((mo.get("providers") or {}).items()):
        rows.append([f"`{pid}`", p.get("kind", "—"), str(p.get("model", "—")), str(p.get("version", "—")),
                     "yes" if p.get("pinned") else "**no**", str(p.get("network", "none")),
                     f"`{p.get('output_contract', '—')}`"])
    out += _table(["provider", "kind", "model", "version", "pinned", "network", "output contract"], rows)
    out += ["", "## What model output may never do", "",
            "These are refused structurally: the fields are rejected by the output contract before anything reads "
            "them, and the refusal is by name rather than by heuristic.", ""]
    out += _table(["cannot", "meaning"],
                  [[f"`{c}`", {"mint_permissions": "grant itself or anything else an effect",
                               "mint_approvals": "produce or assert a human approval",
                               "assert_verification": "claim a verification verdict",
                               "expand_scope": "widen the accepted scope contract"}.get(c, "")]
                   for c in MO.CANNOT])
    out += ["## Tools", "",
            "Tool invocations are argv vectors, never shell strings. An element carrying control bytes, or an "
            "absolute path outside the sandbox and overlay, is refused at `security.validate_argv`.", ""]
    trows = []
    for cid, c in sorted((K.get("components") or {}).items()):
        iface = c.get("interface") or {}
        bounds = iface.get("bounds") or {}
        if not bounds:
            continue
        trows.append([f"`{cid}`", str(c.get("title", ""))[:44], str(bounds.get("timeout_s", "—")),
                      str(bounds.get("max_output_bytes", "—"))])
    out += _table(["component", "title", "timeout (s)", "max output bytes"], trows[:14])
    return out


@generator("provenance_schema")
def _gen_provenance_schema(ctx: Mapping[str, Any]) -> list[str]:
    """DOC-07 — the contracts that carry provenance, and the chain that binds them."""
    reg = _loaded("contracts", registry=ctx["registry"])
    out = ["## Provenance contracts", "",
           "Each is a registered schema, validated at the boundary that produces it. The `examples.invalid` payloads "
           "in the registry are executable: every one is asserted to be refused.", ""]
    rows = []
    for cid, c in sorted((reg.get("contracts") or {}).items()):
        if not any(k in cid for k in ("provenance", "evidence", "artifact", "audit", "immutable", "freshness",
                                      "intake_record", "store_record", "run_state")):
            continue
        rows.append([f"`{cid}`", c.get("version", "—"), c.get("title", "")[:64]])
    out += _table(["contract", "version", "title"], rows)
    out += ["## The chain", "",
            "Every ledger this tool writes is a hash chain: each row carries `prev_hash`, and its own `entry_hash` "
            "is the digest of the row including that link. An edited row breaks the chain, and the effect that "
            "reads it refuses.", "",
            "```",
            "  row[0].prev_hash = 'genesis'",
            "  row[n].prev_hash = row[n-1].entry_hash",
            "  row[n].entry_hash = sha256(canonical_json(row[n] without entry_hash))",
            "```", "",
            "The approval ledger is the one exception in shape, deliberately: its first row links to the candidate "
            "id rather than to `genesis`, so a receipt chain from another candidate cannot be spliced onto the "
            "front of it.", "",
            "## What grounds a finding", "",
            "A material AI finding is an operation in `plan/refactoring_plan.json`. It is grounded when every "
            "evidence id it cites resolves in that plan's own `evidence_refs` and the operation's recorded source "
            "hash still matches the evidence captured for that path, at the revision the run pinned. "
            "`observability.grounding` classifies each operation as grounded, stale, unresolvable or unsupported.", ""]
    return out


@generator("run_state_schema")
def _gen_run_state_schema(ctx: Mapping[str, Any]) -> list[str]:
    """DOC-08 — the run states, the transitions between them, and the evidence each transition requires."""
    from . import controls as CT
    w = _loaded("workflow", registry=ctx["registry"])
    out = ["## Run states", "",
           f"{len(CT.STATES)} states, of which {len(CT.TERMINAL_STATES)} are terminal. A run in a terminal state "
           f"admits no further transition — the refusal is `state.terminal`.", "",
           "```", "  " + " → ".join(["INTAKE", "BOUND", "INTENT_ACCEPTED", "PLANNED", "PATCH_INERT", "VERIFIED",
                                     "REVIEW_PENDING", "APPROVED", "APPLIED_ISOLATED", "ARCHIVED"]),
           "",
           "  terminal: " + ", ".join(sorted(CT.TERMINAL_STATES)),
           "```", "",
           "## Declared transitions and their required evidence", "",
           "A transition is admitted only when it is declared AND the evidence it names is present as a sha256 "
           "digest. This is why a run cannot skip forward: the evidence for the step it skipped does not exist.", ""]
    rows = []
    for (a, b), ev in sorted(CT.TRANSITION_EVIDENCE.items()):
        rows.append([f"`{a}`", f"`{b}`", _cells(ev, 4)])
    out += _table(["from", "to", "required evidence"], rows)
    out += ["## Workflow steps", "", f"{len(w.get('steps') or {})} declared steps.", ""]
    srows = []
    for sid, st in sorted((w.get("steps") or {}).items(), key=lambda kv: kv[1].get("order", 0)):
        frm = st.get("run_state_from")
        frm = ", ".join(frm) if isinstance(frm, list) else str(frm or "—")
        srows.append([f"`{sid}`", str(st.get("title", ""))[:48], f"`{frm}` → `{st.get('run_state_to', '—')}`",
                      _cells(st.get("transition_evidence"), 2)])
    out += _table(["step", "title", "state change", "transition evidence"], srows)
    return out


@generator("approval_policy")
def _gen_approval_policy(ctx: Mapping[str, Any]) -> list[str]:
    """DOC-09 — where a human decides, what they are shown, and what their decision is bound to."""
    rv = _loaded("review", registry=ctx["registry"])
    env = _loaded("environments", registry=ctx["registry"])
    from . import approval_adapter as AA
    out = ["## Where a human decides", "",
           "The run cannot leave `REVIEW_PENDING` without a signed human approval receipt. The state machine "
           "declares no other edge, so this is structural rather than procedural.", "",
           "## Reviewer actions", ""]
    rows = []
    for bid, b in sorted((rv.get("behaviors") or {}).items()):
        safety = b.get("safety") or {}
        non_applying = safety.get("non_applying")
        rows.append([f"`{bid}`", f"`{b.get('reviewer_action', '—')}`",
                     "no" if non_applying else ("**yes**" if non_applying is False else "—"),
                     str(safety.get("rule", ""))[:64] or "—"])
    out += _table(["requirement", "reviewer action", "applies patch", "safety rule"], rows)
    out += ["## What an approval is bound to", "",
            "A receipt is valid only over exactly the artifacts it was issued for. If any of them changes, the "
            "receipt is stale and a new human decision is required — `approval.stale_inputs`.", ""]
    out += _table(["bound field", "what it pins"],
                  [[f"`{f}`", {"candidate_id": "the candidate being approved",
                               "patch_hash": "the exact diff shown",
                               "base_revision": "the repository revision it applies to",
                               "scope_contract_hash": "the accepted scope",
                               "card_hash": "the review card the human saw",
                               "verification_report_hash": "the verification result they saw"}.get(f, "")]
                   for f in AA.BOUND_FIELDS])
    out += ["## What cannot approve", "",
            "- A model, agent, assistant, planner, tool, repository, document, ticket or log channel — refused by "
            "name at `security.require_human_channel` (`security.sec07.model_channel`).",
            "- A receipt whose signature was not produced by the run's own approval key "
            "(`security.sec07.fabricated_token`).",
            "- A receipt past its declared TTL (`approval.expired`).",
            "- A receipt a later human command invalidated — reject, cancel, request-evidence or narrow-scope "
            "(`approval.invalidated`).",
            "", "## Accountability", "",
            "The accountable party is the human reviewer, named on the surface and in the audit record. The AI is "
            "declared advisory only, with an explicit cannot-list, and accountability never rests with it.", "",
            "## Which environments require a human gate", ""]
    erows = [[f"`{eid}`", e["permissions"]["posture"],
              ", ".join(e["permissions"].get("require_human_approval") or []) or "—"]
             for eid, e in sorted((env.get("environments") or {}).items(), key=lambda kv: kv[1]["rank"])]
    out += _table(["environment", "posture", "requires human approval for"], erows)
    return out


@generator("evaluation_plan")
def _gen_evaluation_plan(ctx: Mapping[str, Any]) -> list[str]:
    """DOC-10 — the offline corpus, what each scenario asserts, and how quality is measured."""
    mx = _loaded("matrix", registry=ctx["registry"])
    from . import qualification as Q
    out = ["## The corpus", "",
           "The evaluation corpus is built from this repository itself — named fixtures, not downloaded data. There "
           "is no network in any environment, so an offline corpus is the only kind this tool has.", ""]
    out += _table(["fixture", "what it is"],
                  [[f"`{f}`", {"suite_corpus": "the repository's own suites, bound read-only at a pinned revision",
                               "injection_corpus": "planted directive-shaped content, treated as data",
                               "lonely_target": "a target with no analogous examples — the abstention case",
                               "failing_tests": "a candidate whose verification fails",
                               "second_repository": "a foreign repository, for cross-tenant refusal",
                               "oversized_intent": "an intent past the hard caps"}.get(f, "")]
                   for f in Q.FIXTURE_NAMES])
    out += ["## Scenarios", ""]
    rows = []
    for sid, sc in sorted((mx.get("scenarios") or {}).items()):
        rows.append([f"`{sid}`", sc.get("kind", "—"), "**yes**" if sc.get("mandatory") else "no",
                     f"`{sc.get('fixture', '—')}`", str(sc.get("title", ""))[:50]])
    out += _table(["scenario", "kind", "mandatory", "fixture", "title"], rows)
    out += ["## How quality is measured", "",
            "Ground truth here is the matrix's own declared expectations — the exact state, effects, changed paths, "
            "evidence closure and approval outcome each scenario must produce. Confusion is defined against the "
            "guardrail firing:", "",
            "- **false negative** — a scenario whose declared outcome is a refusal that did not refuse;",
            "- **false positive** — a scenario whose declared outcome is not a refusal that refused anyway;",
            "- scenarios with no declared expectation are counted `ungrounded` and excluded from every rate, rather "
            "than assumed correct.", "",
            "Grounding is measured mechanically rather than judged: every planned operation is classified against "
            "the evidence set it cites and the revision the run pinned. Review burden is measured alongside "
            "completion — items presented, decisions demanded, round trips — and never replaced by it.", "",
            "## The gate", "",
            "For every mandatory scenario the tool's own chained evidence ledger must hold a current PASS receipt "
            "bound to the matrix hash. Missing, stale, failed or indeterminate blocks release. Waiver-shaped inputs "
            "are refused by name: the component under evaluation cannot excuse itself from the matrix.", ""]
    return out


@generator("incident_runbook")
def _gen_incident_runbook(ctx: Mapping[str, Any]) -> list[str]:
    """DOC-11 — what to do when something goes wrong, written against the refusals that actually exist."""
    env = _loaded("environments", registry=ctx["registry"])
    from . import workflow as W
    out = ["## Rollback", "",
           "Rollback is not a procedure someone follows from memory; it is a code path every applying run "
           "exercises. `archive_adapter.prove_rollback` re-checks the source tree identity and the absence of any "
           "linked worktree after an isolated apply, and records the proof.", "",
           "**To roll back a run that applied a candidate:**", "",
           "1. The run has already done it. WF-12 rolls back by default and the run reaches `ROLLED_BACK`; "
           "`archive/rollback.json` carries the before/after tree identities and the verdict.",
           "2. To confirm: the `before.source_tree_identity` and `after.source_tree_identity` must be equal, "
           "`after.status_clean` true, and `after.worktree_present` false.",
           "3. If they are not equal, the source tree changed and this is an incident — go to *Unclean state* below.",
           "", "## Failure kinds and where they route", "",
           "Every failure is one of a declared set, and each routes fail-closed. A failure that is not one of these "
           "does not route forward — the run stays where it is and does not advance.", ""]
    rows = [[f"`{k}`", f"`{W.DEFAULT_ROUTES.get(k, '—')}`"] for k in W.FAILURE_KINDS]
    out += _table(["failure kind", "routes to"], rows)
    out += ["## Incidents", "", "### A ledger chain does not verify", "",
            "Symptom: `archive.chain_broken` or `archive.chain_tampered`, or a release gate reporting "
            "`release.ledger_broken`.", "",
            "This means a row was edited or removed. **The correct response is not to regenerate the ledger.** "
            "The run's evidence is no longer trustworthy: quarantine the run directory, and treat every conclusion "
            "drawn from it as unproven. A gate that reads a broken chain yields no receipts at all, deliberately — "
            "partial evidence from a tampered ledger is worse than none.", "",
            "### Unclean state after an apply", "",
            "Symptom: `environment.unclean_shutdown`, or a rollback proof whose tree identities differ.", "",
            "The shutdown records the leftovers and refuses rather than tidying them away, so the evidence of what "
            "happened is intact. Inspect `environment/lifecycle.jsonl` for the shutdown row, then the leftover paths "
            "it names. Nothing is cleaned automatically because a later run must not inherit that state silently.", "",
            "### An approval no longer applies", "",
            "Symptom: `approval.stale_inputs` or `approval.invalidated` at WF-10 or at the effect boundary.", "",
            "This is working as intended: a bound input changed, or a human command invalidated the approval. "
            "A new human decision is required. There is no override.", "",
            "### The release gate says NO_GO", "",
            "The decision carries a remediation list saying what would unblock each assertion. `stale` means "
            "re-run the suite that issues those receipts; `conflicting` means investigate the failing one and do "
            "**not** re-run until you know why it failed.", "",
            "## Quotas by environment", "",
            "A run that exceeds these is refused at generation rather than truncated.", ""]
    erows = [[f"`{eid}`", str(e["quotas"].get("max_run_seconds")), str(e["quotas"].get("max_changed_files")),
              str(e["quotas"].get("max_diff_lines"))]
             for eid, e in sorted((env.get("environments") or {}).items(), key=lambda kv: kv[1]["rank"])]
    out += _table(["environment", "max run seconds", "max changed files", "max diff lines"], erows)
    return out


@generator("limitations")
def _gen_limitations(ctx: Mapping[str, Any]) -> list[str]:
    """DOC-12 — the published limitations and non-goals, drawn from the same declarations the release gate reads."""
    from . import release_gate as RG
    items = RG.declared_limitations(registry=ctx["registry"])
    host = [i for i in items if i["source"] == "invariants.deferred_to_host"]
    out = ["## Host requirements", "",
           "Properties this tool does not implement and does not claim. A host deploying it must provide them.", ""]
    for i in host:
        out += [f"### {i['id']} — {i['statement']}", "", i["detail"] or "", ""]
    if not host:
        out += ["_None declared._", ""]
    out += ["## Non-goals", "",
            "Deliberate boundaries, not gaps. Each is stated so nobody has to infer it from silence.", ""]
    for i in [x for x in items if x["source"] == "release.non_goals"]:
        out += [f"- **{i['id']}** — {i['statement']}", ""]
    out += ["## Where this is enforced", "",
            "`release_gate.verify_limitations` refuses when a declared limitation is missing from the published "
            "document, and the published-limitations receipt binds to the readiness registry — so declaring a new "
            "release-gate assertion without republishing makes the receipt stale and blocks the gate.", ""]
    return out


# --------------------------------------------------------------------------- #
# Generation (T02). The document body comes from the generator; the source versions it was produced from are
# recorded in the document itself, because that is what makes freshness checkable later. The T03 wave replaces
# `render` with one that adds the full front matter over this same body.
# --------------------------------------------------------------------------- #
def source_digest(entry: Mapping[str, Any], sources: Mapping[str, Any]) -> str:
    """One hash over exactly the source registries this document draws from — what freshness compares."""
    return lga.sha256_digest(lga.canonical_json(
        {s: sources.get(s, {}).get("hash") for s in sorted(entry["sources"])}))


def render_body(doc_id: str, *, docs: Mapping[str, Any] | None = None,
                registry: Mapping[str, Any] | None = None) -> list[str]:
    """The generated body, from the registries this document declares. Refuses rather than generating a document
    with a section silently missing because a registry could not be read."""
    m = docs or load_docs(registry=registry)
    d = document(doc_id, m)
    if d["generator"] not in GENERATORS:
        raise DocumentationRefusal("documentation.generator_unknown",
                                   f"{doc_id}: no generator named {d['generator']!r} — the document is declared but "
                                   f"cannot be populated")
    sources = source_state(registry=registry)
    unreadable = [s for s in d["sources"] if sources.get(s, {}).get("hash") is None]
    if unreadable:
        raise DocumentationRefusal("documentation.source_unreadable",
                                   f"{doc_id}: cannot be generated — source registries unreadable: {unreadable}")
    return GENERATORS[d["generator"]]({"registry": registry, "docs": m, "entry": d, "sources": sources})


def source_reference_block(entry: Mapping[str, Any], sources: Mapping[str, Any]) -> list[str]:
    """What this document was generated against, embedded in the document. Freshness reads exactly this."""
    refs = [f"`{s}` @ `{_short(sources.get(s, {}).get('hash'), 16)}`" for s in entry["sources"]]
    return [f"# {entry['doc_id']} — {entry['title']}", "",
            "> **Generated from the registries it describes.** Editing it by hand does not change what it says for "
            "long: the next generation overwrites it, and the freshness check refuses a document that no longer "
            "matches its sources.", "",
            f"- **Last validated against:** {', '.join(refs)}",
            f"- **Authoritative suites:** " + ", ".join(f"`{s}`" for s in entry["authoritative_suites"]), ""]


def render(doc_id: str, *, docs: Mapping[str, Any] | None = None,
           registry: Mapping[str, Any] | None = None) -> str:
    """Generate one document. Replaced by the T03 wave with a version carrying the full front matter."""
    m = docs or load_docs(registry=registry)
    d = document(doc_id, m)
    sources = source_state(registry=registry)
    body = render_body(doc_id, docs=m, registry=registry)
    lines = source_reference_block(d, sources) + body + [
        "---", "",
        f"_Generated by `{ADAPTER_ID}` (`{d['generator']}`). "
        f"Documentation registry `{_short(m['computed_hash'], 16)}`._", ""]
    return "\n".join(lines).rstrip() + "\n"


_VOLATILE_RE = re.compile(r"^(?:generated_at:|- \*\*Last validated at:\*\*).*$", re.M)


def _strip_volatile(text: str) -> str:
    """Drop the timestamps, which differ on every generation and mean nothing for drift."""
    return _VOLATILE_RE.sub("", text)


def publish(doc_id: str, *, root: Path | None = None, docs: Mapping[str, Any] | None = None,
            registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Generate the document and write it, recording what it was generated against."""
    m = docs or load_docs(registry=registry)
    d = document(doc_id, m)
    text = render(doc_id, docs=m, registry=registry)
    p = doc_path(doc_id, root=root, docs=m)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")
    sources = source_state(registry=registry)
    return {"doc_id": doc_id, "path": str(p), "bytes": len(text.encode("utf-8")),
            "document_hash": lga.sha256_digest(text), "source_digest": source_digest(d, sources),
            "sources": {s: sources[s]["hash"] for s in d["sources"]}, "generated_at": _now()}


def publish_all(*, root: Path | None = None, docs: Mapping[str, Any] | None = None,
                registry: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    """Publish every document whose generator is implemented. One declared but not yet implemented is not silently
    skipped — `check_freshness` reports it `absent`, which blocks."""
    m = docs or load_docs(registry=registry)
    return [publish(did, root=root, docs=m, registry=registry) for did in sorted(m.get("documents") or {})
            if m["documents"][did]["generator"] in GENERATORS]


# --------------------------------------------------------------------------- #
# T03 — front matter: ownership, last-validated version and date, source references, assumptions, known gaps and
# change triggers. And the rule that gives the rest of it meaning: unimplemented behaviour is never written as
# operational fact.
# --------------------------------------------------------------------------- #
#: Phrases that assert something is operational. The check below refuses them in a KNOWN GAP, where they are
#: self-contradictory: a gap saying "X is fully enforced" is not a gap, it is unimplemented behaviour being written
#: as operational fact, which is exactly what DOC-*-T03 forbids.
#:
#: Assumptions are deliberately NOT linted. An assumption states what the document takes as given, and those givens
#: are frequently implemented facts backed by evidence ("every threat is enforced at an effect boundary"). Linting
#: them would force true statements to be weakened to satisfy a regex, which is the opposite of the honesty this
#: check exists to protect.
_OPERATIONAL_CLAIM = re.compile(
    r"\b(?:is (?:fully |now )?(?:implemented|enforced|operational|complete|guaranteed)"
    r"|are (?:fully |now )?(?:implemented|enforced|operational|complete|guaranteed)"
    r"|works? as (?:designed|specified)|handles all|covers all|prevents all)\b", re.I)


def front_matter_block(entry: Mapping[str, Any], sources: Mapping[str, Any]) -> list[str]:
    """The front matter, rendered from the document's declaration plus the live source hashes.

    `last_validated_version` is not a date someone typed: it is the hash of every registry the document was
    generated from, so "validated" means "regenerated from exactly this state".
    """
    fm = entry.get("front_matter") or {}
    refs = [f"`{s}` @ `{_short(sources.get(s, {}).get('hash'), 16)}`" for s in entry["sources"]]
    out = ["---", f"document: {entry['doc_id']} — {entry['title']}",
           f"owner: {fm.get('ownership', 'unassigned')}",
           f"generated_by: {ADAPTER_ID}/{ADAPTER_VERSION} (generator `{entry['generator']}`)",
           f"generated_at: {_now()}",
           f"knowledge_repository: {entry['knowledge_repository']}",
           "---", "",
           f"# {entry['doc_id']} — {entry['title']}", "",
           "> **This document is generated from the registries it describes.** It is not edited by hand: any change "
           "made here is overwritten on the next generation, and the freshness check refuses a document that no "
           "longer matches its sources. To change what it says, change the implementation.", "",
           "## Provenance of this document", "",
           f"- **Owner:** {fm.get('ownership', 'unassigned')}",
           f"- **Last validated against:** {', '.join(refs)}",
           f"- **Last validated at:** {fm.get('last_validated_at', _now())}",
           f"- **Authoritative suites:** " + ", ".join(f"`{s}`" for s in entry["authoritative_suites"]), ""]
    if fm.get("assumptions"):
        out += ["### Assumptions", "",
                "What this document takes as given. If one of these stops being true, the document is wrong even "
                "though its hashes still match.", ""]
        out += [f"- {a}" for a in fm["assumptions"]] + [""]
    if fm.get("known_gaps"):
        out += ["### Known gaps", "",
                "What this document does **not** cover, stated here rather than left to be discovered.", ""]
        out += [f"- {g}" for g in fm["known_gaps"]] + [""]
    if fm.get("change_triggers"):
        out += ["### Change triggers", "",
                "Changing any of these makes this document stale. The freshness check detects it; these are stated "
                "so a reader knows what to watch without running it.", ""]
        out += [f"- {t}" for t in fm["change_triggers"]] + [""]
    return out


def check_honesty(entry: Mapping[str, Any]) -> list[str]:
    """Refuse a known gap or assumption phrased as an operational claim (DOC-*-T03).

    A gap that says "X is fully enforced" is not a gap; it is the unimplemented behaviour being documented as
    operational fact, which is the exact failure this tier names. Assumptions are exempt by design — see the note on
    `_OPERATIONAL_CLAIM`.
    """
    fm = entry.get("front_matter") or {}
    problems = []
    for line in fm.get("known_gaps", []):
        m = _OPERATIONAL_CLAIM.search(str(line))
        if m:
            problems.append(f"{entry['doc_id']}: a known gap states an operational claim ({m.group(0)!r}), which "
                            f"contradicts it being a gap: {line[:90]}")
    return problems


def render(doc_id: str, *, docs: Mapping[str, Any] | None = None,
           registry: Mapping[str, Any] | None = None) -> str:
    """Generate one document WITH its full front matter (T03), over the body the generator produces.

    This replaces the T02 renderer: the body is unchanged, and everything a reader needs to judge the document —
    who owns it, what it was validated against, what it assumes, what it does not cover and what makes it stale —
    is placed in front of it.
    """
    m = docs or load_docs(registry=registry)
    d = document(doc_id, m)
    problems = check_honesty(d)
    if problems:
        raise DocumentationRefusal("documentation.unimplemented_as_fact", "; ".join(problems))
    sources = source_state(registry=registry)
    body = render_body(doc_id, docs=m, registry=registry)
    lines = front_matter_block(d, sources) + body + [
        "---", "",
        f"_Generated from {len(d['sources'])} registry/registries by `{ADAPTER_ID}` "
        f"(`{d['generator']}`). Documentation registry `{_short(m['computed_hash'], 16)}`._", ""]
    return "\n".join(lines).rstrip() + "\n"


# --------------------------------------------------------------------------- #
# T04 — the freshness check: detect stale schema, policy, state, connector, model/tool and workflow references after
# the implementation changes
# --------------------------------------------------------------------------- #
FRESHNESS = ("absent", "stale", "drifted", "unreadable", "fresh")
BLOCKING_FRESHNESS = tuple(f for f in FRESHNESS if f != "fresh")
EVIDENCE_KIND = "documentation_freshness"

#: What a stale reference looks like per source. The document embeds each source's hash fragment in its front
#: matter, so drift is detected by comparing what the document says it was generated against with what the
#: registries currently are — not by a heuristic over prose.
STALENESS_REASONS = {
    "contracts": "a schema was added, changed or retired",
    "threats": "the threat model changed",
    "matrix": "the evaluation corpus changed",
    "invariants": "a platform invariant or its enforcement point changed",
    "environments": "a deployment profile changed",
    "guardrails": "a guardrail rule changed",
    "components": "a component or its capabilities changed",
    "workflow": "a workflow step or transition changed",
    "intake": "an admitted source changed",
    "checks": "a verification check changed",
    "boundaries": "an architectural boundary changed",
    "stores": "a store or its retention changed",
    "review": "a reviewer behavior changed",
    "model": "a model provider or its pins changed",
    "wiring": "a port or its adapter changed",
    "readiness": "a release-gate assertion changed",
    "policy": "a policy rule changed",
}


def check_freshness(doc_id: str, *, root: Path | None = None, docs: Mapping[str, Any] | None = None,
                    registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Is this document still the one its sources would generate?

    Three distinct answers, because they need three distinct responses:
      * `absent`   — the document was never generated;
      * `stale`    — a source registry moved since it was generated (regenerate);
      * `drifted`  — the file on disk is not what the generator produces from the CURRENT sources, even though the
                     sources match what it records — i.e. somebody edited it by hand;
      * `unreadable` — a source registry cannot be read, so freshness cannot be judged at all.
    """
    m = docs or load_docs(registry=registry)
    d = document(doc_id, m)
    p = doc_path(doc_id, root=root, docs=m)
    sources = source_state(registry=registry)
    unreadable = [s for s in d["sources"] if sources.get(s, {}).get("hash") is None]
    if unreadable:
        return {"doc_id": doc_id, "status": "unreadable", "path": str(p),
                "why": f"source registries could not be read: {unreadable}",
                "stale_sources": [], "remediation": "resolve the unreadable registry before judging this document"}
    if not p.is_file():
        return {"doc_id": doc_id, "status": "absent", "path": str(p),
                "why": "the document has never been generated", "stale_sources": [],
                "remediation": f"generate it with documentation.publish({doc_id!r})"}
    text = p.read_text(encoding="utf-8")
    recorded = _recorded_fragments(text)
    stale = []
    for s in d["sources"]:
        want = _short(sources[s]["hash"], 16)
        if recorded.get(s) and recorded[s] != want:
            stale.append({"source": s, "document_has": recorded[s], "current": want,
                          "meaning": STALENESS_REASONS.get(s, "this source changed")})
    if stale:
        return {"doc_id": doc_id, "status": "stale", "path": str(p),
                "why": f"{len(stale)} source registry/registries changed since this was generated: "
                       f"{[x['source'] for x in stale]}",
                "stale_sources": stale,
                "remediation": f"regenerate with documentation.publish({doc_id!r})"}
    missing_refs = [s for s in d["sources"] if s not in recorded]
    if missing_refs:
        return {"doc_id": doc_id, "status": "drifted", "path": str(p),
                "why": f"the document records no version for {missing_refs}; it is not what the generator produces",
                "stale_sources": [], "remediation": f"regenerate with documentation.publish({doc_id!r})"}
    fresh_text = render(doc_id, docs=m, registry=registry)
    if _strip_volatile(text) != _strip_volatile(fresh_text):
        return {"doc_id": doc_id, "status": "drifted", "path": str(p),
                "why": "the file on disk differs from what the generator produces from the current sources — it was "
                       "edited by hand, or the generator changed",
                "stale_sources": [], "remediation": f"regenerate with documentation.publish({doc_id!r}); hand edits "
                                                    f"to a generated document do not survive"}
    return {"doc_id": doc_id, "status": "fresh", "path": str(p),
            "why": f"regenerating from the current sources reproduces this document byte for byte",
            "stale_sources": [], "remediation": None,
            "document_hash": lga.sha256_digest(text), "source_digest": source_digest(d, sources)}


_REF_RE = re.compile(r"`([a-z_]+)` @ `([0-9a-f]{4,64})`")


def _recorded_fragments(text: str) -> dict[str, str]:
    """The source versions the document itself records, read from its front matter."""
    return {m.group(1): m.group(2) for m in _REF_RE.finditer(text)}


def check_all(*, root: Path | None = None, docs: Mapping[str, Any] | None = None,
              registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Every declared document's freshness, with the ones needing attention first."""
    m = docs or load_docs(registry=registry)
    results = {did: check_freshness(did, root=root, docs=m, registry=registry)
               for did in sorted(m.get("documents") or {})}
    blocking = sorted(d for d, r in results.items() if r["status"] in BLOCKING_FRESHNESS)
    return {"record_schema": f"{NS}/FreshnessReport", "docs_version": DOCS_VERSION,
            "docs_hash": m["computed_hash"], "documents": len(results),
            "per_document": {d: r["status"] for d, r in results.items()},
            "blocking": blocking, "fresh": sorted(d for d, r in results.items() if r["status"] == "fresh"),
            "remediation": [{"doc_id": d, "status": results[d]["status"], "why": results[d]["why"],
                             "do": results[d]["remediation"]} for d in blocking],
            "detail": results, "checked_at": _now()}


def require_fresh(*, stage: str = "release", **kw: Any) -> dict[str, Any]:
    """No release over documentation that no longer describes the implementation."""
    r = check_all(**kw)
    if r["blocking"]:
        raise DocumentationRefusal("documentation.stale",
                                   f"{stage}: {len(r['blocking'])} document(s) do not match the implementation: "
                                   f"{[(d, r['per_document'][d]) for d in r['blocking'][:6]]}")
    return r


def gate_document_id(doc_id: str, docs: Mapping[str, Any] | None = None) -> str:
    """The receipt id a document's freshness records under, bound to the documentation registry."""
    m = docs or load_docs()
    return f"documentation:{doc_id}@{m['computed_hash'][7:39]}"


__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "BLOCKING_FRESHNESS", "DOCS_DIR", "DOCS_PATH", "DOCS_VERSION",
           "DOC_IDS", "DOC_REQUIRED", "EVIDENCE_KIND", "FRESHNESS", "FRONT_MATTER", "GENERATORS", "NS",
           "SOURCE_REGISTRIES", "STALENESS_REASONS", "DocumentationRefusal", "check_all", "check_freshness",
           "check_honesty", "doc_path", "document", "front_matter_block", "gate_document_id", "generator",
           "load_docs", "publish", "publish_all", "render", "require_fresh",
           "source_digest", "source_state"]
