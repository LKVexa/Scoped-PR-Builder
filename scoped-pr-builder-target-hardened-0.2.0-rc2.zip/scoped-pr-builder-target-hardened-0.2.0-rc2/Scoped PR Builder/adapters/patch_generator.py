"""Scoped PR Builder — Suite 50 inert bounded diff/patch generation (SLICE-05).

Produces ONE inert candidate patch for a planned refactor, bounded by the scope
contract, from the pinned revision only. The patch is an artifact: nothing here
touches the repository working tree, and the generator proves it by comparing the
tree identity before and after generation.

Authority: Suite 50.1 (bounded diff production), 50.2 (bounded patch construction)
and 50.6 (repository confinement) remain authoritative; their record shapes are
mirrored here (``BoundedDiffPlan`` / ``BoundedPatchPlan``). The refactor content is
computed by a *registered deterministic recipe*; there is no model and no fallback:
an unregistered recipe is refused (``BLOCKED``), never improvised.

Build provenance: BUILD_NEW on the Python standard library (``difflib.unified_diff``)
and the overlay's local-Git adapter; the yard held no reusable patch generator
(see ``../PROVENANCE.jsonl``).
"""
from __future__ import annotations

import difflib
import hashlib
import ast
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Mapping

from . import local_git_adapter as lga
from . import security as _SEC

ADAPTER_ID = "scoped_pr_builder.patch_generator"
ADAPTER_VERSION = "0.1.0"
CANDIDATE_VERSION = "scoped_pr_builder.candidate_patch/0.1.0"

# A recipe maps (binding, target path, current bytes, sibling tree listing) -> proposed bytes.
Recipe = Callable[[lga.RepositoryBinding, PurePosixPath, bytes, list[PurePosixPath]], bytes]
RECIPES: dict[str, Recipe] = {}


def recipe(name: str) -> Callable[[Recipe], Recipe]:
    def register(fn: Recipe) -> Recipe:
        RECIPES[name] = fn
        return fn
    return register


@recipe("regenerate_sha256sums_manifest")
def _regenerate_sha256sums(binding: lga.RepositoryBinding, target: PurePosixPath, current: bytes, tree: list[PurePosixPath]) -> bytes:
    """Rewrite ``<dir>/SHA256SUMS.txt`` from the pinned tree: one ``<sha256>  <name>`` line per sibling file."""
    if target.name != "SHA256SUMS.txt":
        raise lga.AdapterError("recipe.target_mismatch", f"recipe regenerate_sha256sums_manifest requires a SHA256SUMS.txt target, got {target}")
    root = Path(binding.root_path)
    siblings = sorted(p for p in tree if p.parent == target.parent and p != target)
    lines = []
    for p in siblings:
        blob = lga.read_blob(root, binding.base_revision, p)
        lines.append(f"{hashlib.sha256(blob).hexdigest()}  {p.name}\n")
    return "".join(lines).encode("utf-8")


@recipe("normalize_sha256sums")
def _normalize_sha256sums(binding: lga.RepositoryBinding, target: PurePosixPath, current: bytes, tree: list[PurePosixPath]) -> bytes:
    return _regenerate_sha256sums(binding, target, current, tree)


@recipe("trim_trailing_whitespace")
def _trim_trailing_whitespace(binding: lga.RepositoryBinding, target: PurePosixPath, current: bytes, tree: list[PurePosixPath]) -> bytes:
    if b"\x00" in current:
        raise lga.AdapterError("recipe.binary_refused", f"binary/NUL content refused: {target}")
    text=current.decode("utf-8")
    return "".join(line.rstrip(" \t\r\n") + ("\n" if line.endswith(("\n","\r")) else "") for line in text.splitlines(keepends=True)).encode("utf-8")


@recipe("ensure_final_newline")
def _ensure_final_newline(binding: lga.RepositoryBinding, target: PurePosixPath, current: bytes, tree: list[PurePosixPath]) -> bytes:
    if b"\x00" in current:
        raise lga.AdapterError("recipe.binary_refused", f"binary/NUL content refused: {target}")
    current.decode("utf-8")
    return current if not current or current.endswith(b"\n") else current + b"\n"


def _import_name(node: ast.AST) -> list[str]:
    if isinstance(node, ast.Import): return [a.asname or a.name.split('.')[0] for a in node.names]
    if isinstance(node, ast.ImportFrom): return [a.asname or a.name for a in node.names if a.name != '*']
    return []

@recipe("py_unused_imports")
def _py_unused_imports(binding: lga.RepositoryBinding, target: PurePosixPath, current: bytes, tree: list[PurePosixPath]) -> bytes:
    """Remove only imports explicitly marked safe for removal.

    A bare AST "unused" result cannot prove that importing a module has no
    side effects, and ``from __future__`` directives are semantic even though
    they do not appear as loaded names. The recipe therefore fails safe by
    leaving unmarked imports untouched. A reviewer/tool may opt a single-line
    import in with ``# spb: safe-remove-unused-import``.
    """
    if target.suffix != '.py':
        raise lga.AdapterError('recipe.target_mismatch', f'py_unused_imports requires .py: {target}')
    text = current.decode('utf-8')
    mod = ast.parse(text)
    used = {n.id for n in ast.walk(mod) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}
    lines = text.splitlines(keepends=True)
    remove: list[int] = []
    marker = '# spb: safe-remove-unused-import'
    for node in mod.body:
        if not isinstance(node, (ast.Import, ast.ImportFrom)) or any(name in used for name in _import_name(node)):
            continue
        if isinstance(node, ast.ImportFrom) and (node.module == '__future__' or node.level):
            continue
        end = getattr(node, 'end_lineno', node.lineno)
        src = ''.join(lines[node.lineno - 1:end])
        if end != node.lineno or '*' in src or '# noqa' in src or '# type:' in src or marker not in src:
            continue
        remove.append(node.lineno - 1)
    return ''.join(line for i, line in enumerate(lines) if i not in set(remove)).encode('utf-8')


@dataclass(frozen=True)
class CandidatePatch:
    candidate_version: str
    adapter_id: str
    adapter_version: str
    candidate_id: str
    intent_id: str
    scope_contract_hash: str
    plan_id: str
    plan_hash: str
    repository_id: str
    worktree_id: str
    base_revision: str
    source_snapshot_hash: str
    recipe: str
    canonical_paths: tuple[str, ...]
    files_changed: int
    lines_added: int
    lines_deleted: int
    hunks: int
    patch_bytes: int
    patch_hash: str
    source_diff_hash: str
    limit_profile: dict[str, int]
    bounded_diff_plan: dict[str, Any]
    bounded_patch_plan: dict[str, Any]
    approval_state: str
    inert: bool
    created_at: str

    def to_json(self) -> str:
        return lga.canonical_json(asdict(self))


def _count(diff_lines: list[str]) -> tuple[int, int, int]:
    added = deleted = hunks = 0
    for line in diff_lines:
        if line.startswith("@@"):
            hunks += 1
        elif line.startswith("+") and not line.startswith("+++"):
            added += 1
        elif line.startswith("-") and not line.startswith("---"):
            deleted += 1
    return added, deleted, hunks


def generate_candidate(
    binding: lga.RepositoryBinding,
    contract: Mapping[str, Any],
    plan: Mapping[str, Any],
    recipe_name: str,
) -> tuple[CandidatePatch, bytes]:
    """Generate an inert unified-diff candidate for every planned operation, bounded by the contract."""
    if plan.get("scope_contract_hash") != contract["scope_contract_hash"]:
        raise lga.AdapterError("patch.plan_mismatch", "plan does not belong to this scope contract")
    if plan.get("status") != "PLANNED":
        raise lga.AdapterError("patch.plan_not_planned", f"plan status is {plan.get('status')!r}; refusing to generate")
    if contract.get("base_revision") != binding.base_revision or contract.get("repository_id") != binding.repository_id:
        raise lga.AdapterError("patch.binding_mismatch", "scope contract is not bound to this repository/revision")
    fn = RECIPES.get(recipe_name)
    if fn is None:
        raise lga.AdapterError("recipe.unregistered", f"no deterministic recipe named {recipe_name!r}; refusing to improvise")

    root = Path(binding.root_path)
    before_tree = lga.tree_identity(root, binding.base_revision)
    before_status = lga.git(root, "status", "--porcelain", "--untracked-files=all")
    allowed = lga.validated_roots(contract["allowed_paths"], "allowed_paths")
    forbidden = lga.validated_roots(contract.get("forbidden_paths", ()), "forbidden_paths", allow_empty=True)
    listed = lga.git_bytes(root, "ls-tree", "-r", "--name-only", "-z", binding.base_revision).decode("utf-8").split("\0")
    tree = [PurePosixPath(p) for p in listed if p]

    targets = [PurePosixPath(op["path"]) for op in plan["operations"]]
    _SEC.validate_paths(targets, allowed=allowed, forbidden=forbidden, label="plan_targets")  # SEC-02-T02: Suite 50.6 confinement with a trail
    lga.require_within_scope(targets, allowed, forbidden)
    if len(targets) > contract["max_changed_files"]:
        raise lga.AdapterError("patch.too_many_files", f"{len(targets)} files exceed max_changed_files={contract['max_changed_files']}")

    diff_parts: list[str] = []
    changed: list[str] = []
    for target, op in zip(targets, plan["operations"]):
        current = lga.read_blob(root, binding.base_revision, target)
        if lga.sha256_digest(current) != op["source_content_hash"]:
            raise lga.AdapterError("patch.source_drift", f"{target} content no longer matches the planned source hash")
        proposed = fn(binding, target, current, tree)
        if proposed == current:
            continue
        a = current.decode("utf-8", errors="surrogateescape").splitlines(keepends=True)
        b = proposed.decode("utf-8", errors="surrogateescape").splitlines(keepends=True)
        lines = list(difflib.unified_diff(a, b, fromfile=f"a/{target.as_posix()}", tofile=f"b/{target.as_posix()}", n=3))
        # git-style header so `git apply` can consume it
        diff_parts.append(f"diff --git a/{target.as_posix()} b/{target.as_posix()}\n")
        diff_parts.extend(line if line.endswith("\n") else line + "\n\\ No newline at end of file\n" for line in lines)
        changed.append(target.as_posix())
    if not changed:
        raise lga.AdapterError("patch.empty", "recipe produced no change for any planned target")

    patch_text = "".join(diff_parts)
    patch_bytes = patch_text.encode("utf-8", errors="surrogateescape")
    added, deleted, hunks = _count(patch_text.splitlines())
    if added + deleted > contract["max_diff_lines"]:
        raise lga.AdapterError("patch.too_large", f"{added + deleted} changed lines exceed max_diff_lines={contract['max_diff_lines']}")

    # Inertness proof: the repository is untouched by generation.
    if lga.tree_identity(root, binding.base_revision) != before_tree or lga.git(root, "status", "--porcelain", "--untracked-files=all") != before_status:
        raise lga.AdapterError("patch.not_inert", "repository state changed during patch generation")

    patch_hash = lga.sha256_digest(patch_bytes)
    source_diff_hash = lga.sha256_digest("".join(p for p in diff_parts if not p.startswith("diff --git")))
    limit_profile = {"max_changed_files": contract["max_changed_files"], "max_diff_lines": contract["max_diff_lines"], "files_changed": len(changed), "lines_changed": added + deleted, "hunks": hunks}
    diff_plan = {
        "record_schema": "suite50.diff_patch_review.bounded_diff_production/BoundedDiffPlan",
        "repository_root": binding.root_path,
        "baseline_hash": binding.source_snapshot_hash,
        "target_hash": patch_hash,
        "path_scope": lga.canonical_json(list(contract["allowed_paths"])),
        "limit_profile": lga.canonical_json(limit_profile),
        "approval_state": "required_before_application",
        "sophia": "interpret_change_intent", "charlotte": "validate_scope_hashes_and_limits", "landon": "produce_read_only_unified_diff",
        "professor": "explain_changed_behavior", "podium": "publish_diff_receipt",
    }
    patch_plan = {
        "record_schema": "suite50.diff_patch_review.bounded_patch_construction/BoundedPatchPlan",
        "repository_root": binding.root_path,
        "source_diff_hash": source_diff_hash,
        "patch_hash": patch_hash,
        "canonical_paths": lga.canonical_json(changed),
        "limit_profile": lga.canonical_json(limit_profile),
        "approval_state": "required_before_application",
        "sophia": "model_patch_intent", "charlotte": "validate_patch_structure_and_scope", "landon": "construct_inert_patch_artifact",
        "professor": "explain_patch_contents", "podium": "publish_patch_receipt",
    }
    candidate_id = lga.sha256_digest(lga.canonical_json({"patch": patch_hash, "rev": binding.base_revision, "scope": contract["scope_contract_hash"], "plan": plan["plan_hash"]}))
    cand = CandidatePatch(
        candidate_version=CANDIDATE_VERSION, adapter_id=ADAPTER_ID, adapter_version=ADAPTER_VERSION,
        candidate_id=candidate_id, intent_id=contract["intent_id"], scope_contract_hash=contract["scope_contract_hash"],
        plan_id=plan["plan_id"], plan_hash=plan["plan_hash"], repository_id=binding.repository_id, worktree_id=binding.worktree_id,
        base_revision=binding.base_revision, source_snapshot_hash=binding.source_snapshot_hash, recipe=recipe_name,
        canonical_paths=tuple(changed), files_changed=len(changed), lines_added=added, lines_deleted=deleted, hunks=hunks,
        patch_bytes=len(patch_bytes), patch_hash=patch_hash, source_diff_hash=source_diff_hash, limit_profile=limit_profile,
        bounded_diff_plan=diff_plan, bounded_patch_plan=patch_plan, approval_state="required_before_application", inert=True,
        created_at=datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
    )
    # PAPER-CAP-03-T03: effect boundary — the candidate must be one inert atomic operation within the configured threshold.
    from . import guardrails as GR
    GR.enforce("diff.generate_inert", {"CAP-03": GR.facts_atomic_bounded_diff(asdict(cand))}, rule_ids=["CAP-03"])
    return cand, patch_bytes


def verify_candidate_hash(candidate: Mapping[str, Any], patch_bytes: bytes) -> None:
    """Fail closed if the stored candidate does not match the patch bytes it claims to describe."""
    if lga.sha256_digest(patch_bytes) != candidate.get("patch_hash"):
        raise lga.AdapterError("candidate.patch_hash_mismatch", "patch bytes do not match candidate.patch_hash")
    expected = lga.sha256_digest(lga.canonical_json({"patch": candidate["patch_hash"], "rev": candidate["base_revision"], "scope": candidate["scope_contract_hash"], "plan": candidate["plan_hash"]}))
    if expected != candidate.get("candidate_id"):
        raise lga.AdapterError("candidate.id_mismatch", "candidate_id does not match its bound patch/revision/scope/plan")


__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "CANDIDATE_VERSION", "RECIPES", "CandidatePatch", "generate_candidate", "recipe", "verify_candidate_hash"]
