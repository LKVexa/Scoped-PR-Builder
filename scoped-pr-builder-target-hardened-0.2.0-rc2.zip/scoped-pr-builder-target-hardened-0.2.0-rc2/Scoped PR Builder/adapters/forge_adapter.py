"""Deny-by-default forge boundary for connected Scoped PR Builder profiles.

The adapter has no ambient network authority. A caller must inject a provider
client and exact, expiring repository/action grants. Push and PR creation are
separate authorities so a PR-create grant cannot silently authorize a branch
write.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from fnmatch import fnmatchcase
from typing import Any, Protocol, Sequence

from . import local_git_adapter as lga

WRITE_ACTIONS = {"forge.push", "pr.create", "review.request", "pr.ready"}
_SUCCESS = {"success", "passed", "neutral", "skipped"}
_FAILURE = {"failure", "failed", "cancelled", "canceled", "error", "timed_out", "action_required"}


@dataclass(frozen=True)
class ForgeGrant:
    provider: str
    repository: str
    action: str
    subject: str
    expires_at: str


class ForgeClient(Protocol):
    def push(self, repository: str, branch: str, commit: str) -> dict[str, Any]: ...
    def create_draft_pr(self, repository: str, base: str, head: str, title: str, body: str) -> dict[str, Any]: ...
    def request_reviewers(self, repository: str, pr_number: int, reviewers: list[str]) -> dict[str, Any]: ...
    def checks(self, repository: str, ref: str) -> list[dict[str, Any]]: ...
    def fetch_issue(self, repository: str, number: int) -> dict[str, Any]: ...
    def fetch_pr(self, repository: str, number: int) -> dict[str, Any]: ...


def _expiry(value: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError) as exc:
        raise lga.AdapterError("forge.grant_invalid", "forge grant expiry is malformed") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise lga.AdapterError("forge.grant_invalid", "forge grant expiry must include a timezone")
    return parsed.astimezone(timezone.utc)


def require_grant(
    grant: ForgeGrant | None,
    *,
    provider: str,
    repository: str,
    action: str,
    now: datetime | None = None,
) -> ForgeGrant:
    if grant is None or grant.provider != provider or grant.repository != repository or grant.action != action:
        raise lga.AdapterError("forge.authorization_required", f"{action} requires an exact forge grant for {provider}:{repository}")
    if not str(grant.subject).strip():
        raise lga.AdapterError("forge.grant_invalid", "forge grant subject is required")
    current = now or datetime.now(timezone.utc)
    if current.tzinfo is None or current.utcoffset() is None:
        raise lga.AdapterError("forge.grant_invalid", "authorization comparison time must include a timezone")
    if _expiry(grant.expires_at) <= current.astimezone(timezone.utc):
        raise lga.AdapterError("forge.grant_expired", "forge grant has expired")
    return grant


def create_draft_pr(
    client: ForgeClient,
    grant: ForgeGrant,
    *,
    push_grant: ForgeGrant | None,
    provider: str,
    repository: str,
    base: str,
    branch: str,
    commit: str,
    title: str,
    body: str,
) -> dict[str, Any]:
    """Push exactly one approved commit and create a draft PR.

    ``grant`` authorizes PR creation only; ``push_grant`` independently
    authorizes the branch write. Both must be exact and current.
    """
    require_grant(push_grant, provider=provider, repository=repository, action="forge.push")
    require_grant(grant, provider=provider, repository=repository, action="pr.create")
    if not branch.strip() or not commit.strip():
        raise lga.AdapterError("forge.request_invalid", "branch and commit are required")
    pushed = client.push(repository, branch, commit)
    if pushed.get("commit") != commit:
        raise lga.AdapterError("forge.push_mismatch", "forge push response does not prove the approved commit was pushed")
    result = client.create_draft_pr(repository, base, branch, title, body)
    if not result.get("draft", False):
        raise lga.AdapterError("forge.non_draft_refused", "forge returned a non-draft PR")
    return {**result, "head_commit": commit, "branch": branch, "provider": provider, "repository": repository}


def parse_codeowners(text: str) -> list[tuple[str, list[str]]]:
    rules = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) >= 2 and all(o.startswith("@") for o in parts[1:]):
            rules.append((parts[0], parts[1:]))
    return rules


def owners_for_path(path: str, rules: Sequence[tuple[str, Sequence[str]]]) -> list[str]:
    # CODEOWNERS is last-match-wins. This remains deliberately conservative for common glob forms.
    owners: list[str] = []
    p = path.lstrip("/")
    for pattern, candidate in rules:
        pat = pattern.lstrip("/")
        matched = fnmatchcase(p, pat) or (pat.endswith("/") and p.startswith(pat)) or fnmatchcase(p, f"*/{pat}")
        if matched:
            owners = list(candidate)
    return owners


def reviewers_for_paths(paths: Sequence[str], codeowners_text: str) -> dict[str, Any]:
    rules = parse_codeowners(codeowners_text)
    by_path = {p: owners_for_path(p, rules) for p in paths}
    missing = sorted(p for p, owners in by_path.items() if not owners)
    reviewers = sorted({owner for owners in by_path.values() for owner in owners})
    return {"by_path": by_path, "reviewers": reviewers, "missing_paths": missing}


def request_codeowners(
    client: ForgeClient,
    grant: ForgeGrant,
    *,
    provider: str,
    repository: str,
    pr_number: int,
    paths: Sequence[str],
    codeowners_text: str,
) -> dict[str, Any]:
    require_grant(grant, provider=provider, repository=repository, action="review.request")
    result = reviewers_for_paths(paths, codeowners_text)
    if result["missing_paths"]:
        raise lga.AdapterError("forge.codeowners_missing", f"required owner unresolved for {result['missing_paths']}")
    response = client.request_reviewers(repository, pr_number, result["reviewers"])
    return {**result, "result": response}


def _outcome(check: dict[str, Any]) -> str:
    conclusion = str(check.get("conclusion") or "").strip().lower()
    status = str(check.get("status") or "").strip().lower()
    if conclusion in _FAILURE or status in _FAILURE:
        return "failure"
    if conclusion in _SUCCESS:
        return "success"
    if status in _SUCCESS:
        return "success"
    return "pending"


def required_checks_state(checks: Sequence[dict[str, Any]], required: Sequence[str], *, head_sha: str) -> dict[str, Any]:
    """Evaluate exact-head required checks, failing closed on ambiguous duplicates."""
    grouped: dict[str, list[dict[str, Any]]] = {}
    for check in checks:
        if check.get("head_sha") != head_sha or not check.get("name"):
            continue
        grouped.setdefault(str(check["name"]), []).append(check)
    missing = [name for name in required if name not in grouped]
    duplicates = [name for name in required if len(grouped.get(name, [])) > 1]
    failed = [name for name in required if name in grouped and any(_outcome(c) == "failure" for c in grouped[name])]
    pending = [
        name
        for name in required
        if name in grouped and name not in failed and any(_outcome(c) == "pending" for c in grouped[name])
    ]
    return {
        "head_sha": head_sha,
        "missing": missing,
        "failed": failed,
        "pending": pending,
        "duplicates": duplicates,
        "ready": not (missing or failed or pending or duplicates),
    }


def fetch_pinned(client: ForgeClient, *, kind: str, repository: str, number: int) -> dict[str, Any]:
    if kind not in ("issue", "pr"):
        raise lga.AdapterError("forge.intake_kind_invalid", kind)
    if isinstance(number, bool) or not isinstance(number, int) or number <= 0:
        raise lga.AdapterError("forge.intake_number_invalid", "issue/PR number must be a positive integer")
    raw = client.fetch_issue(repository, number) if kind == "issue" else client.fetch_pr(repository, number)
    body = {"kind": kind, "repository": repository, "number": number, "item": raw}
    return {**body, "content_hash": lga.sha256_digest(lga.canonical_json(body))}
