"""Scoped PR Builder — persistence stores (Phase 07 / STORE-01..07).

``store/STORES.json`` declares one storage record kind per persisted concern — workflow/run state, versioned artifact
metadata and source pointers, evidence/provenance records, human approval/rejection history, model/tool version
metadata, retention/deletion/privacy controls, and the append-only audit trail for privileged actions — with a stable
identity rule, schema version, ownership (who may write), classification, retention and provenance fields, and a
lifecycle (CREATED → SEALED → RETAINED | EXPIRED | TOMBSTONED).

Every record is an envelope (contract ``store_record``) written only through ``Store.put`` into a hash-chained,
append-only ledger under ``<run_dir>/stores/<store_id>.jsonl`` (Filing Cabinet 12 ledgers / Archive Ledger 29.5
provenance / Cypher 11 audit shapes). Nothing else writes state: the model and the UI have no write path.

Build provenance: BUILD_NEW (stdlib), composing archive_adapter's chain primitive and the contract registry.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from . import contracts as C
from . import local_git_adapter as lga
from . import security as _SEC
from .archive_adapter import _chain_append, verify_chain_file

STORES_VERSION = "scoped_pr_builder.stores/0.1.0"
STORES_PATH = Path(__file__).resolve().parent.parent / "store" / "STORES.json"
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
RECORD_SCHEMA = "overlay.scoped_pr_builder.store/StoreRecord"
LIFECYCLE = ("CREATED", "SEALED", "RETAINED", "EXPIRED", "TOMBSTONED")
CLASSIFICATIONS = ("public", "internal", "confidential", "restricted")
STORE_REQUIRED = ("store_id", "version", "title", "record_kind", "identity", "schema_version", "ownership", "classification", "retention", "provenance_fields", "lifecycle", "authoritative_suites", "introduced_by")
FORBIDDEN_WRITERS = ("model", "ui", "anonymous")


class StoreRefusal(lga.AdapterError):
    """Raised by the store boundary (unknown store, forbidden writer, identity/version/retention violations)."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_stores(path: Path = STORES_PATH, *, registry: Mapping[str, Any] | None = None, repo_root: Path = REPO_ROOT) -> dict[str, Any]:
    if not Path(path).is_file():
        raise StoreRefusal("store.registry_missing", f"store registry not found: {path}")
    reg = registry or C.load_registry()
    st = json.loads(Path(path).read_text(encoding="utf-8"))
    if st.get("stores_version") != STORES_VERSION:
        raise StoreRefusal("store.registry_invalid", "unsupported stores_version")
    for sid, s in (st.get("stores") or {}).items():
        missing = [k for k in STORE_REQUIRED if k not in s]
        if missing or s["store_id"] != sid or not C.SEMVER_RE.match(s["version"]) or not C.SEMVER_RE.match(s["schema_version"]):
            raise StoreRefusal("store.registry_invalid", f"{sid}: missing {missing} / id or versions invalid")
        if not s["identity"].get("key_fields"):
            raise StoreRefusal("store.registry_invalid", f"{sid}: identity.key_fields required")
        w = s["ownership"].get("writers") or []
        if not w or any(x in FORBIDDEN_WRITERS for x in w):
            raise StoreRefusal("store.registry_invalid", f"{sid}: writers must be named adapters/components — never model, ui or anonymous")
        if s["classification"] not in CLASSIFICATIONS:
            raise StoreRefusal("store.registry_invalid", f"{sid}: unknown classification")
        r = s["retention"]
        if r.get("mode") not in ("append_only", "append_only_tombstone") or ("ttl_days" in r and r["ttl_days"] is not None and int(r["ttl_days"]) <= 0):
            raise StoreRefusal("store.registry_invalid", f"{sid}: retention mode/ttl invalid")
        if set(s["lifecycle"]["states"]) != set(LIFECYCLE):
            raise StoreRefusal("store.registry_invalid", f"{sid}: lifecycle must declare every state")
        for f in s["authoritative_suites"]:
            if not (Path(repo_root) / f).is_file():
                raise StoreRefusal("store.suite_unbound", f"{sid}: authoritative suite file does not exist: {f}")
    body = {k: v for k, v in st.items() if k != "stores_hash"}
    st["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return st


def record_id(store: Mapping[str, Any], payload: Mapping[str, Any]) -> str:
    """Stable identity: sha256 over the store id, schema version and the declared key fields of the payload."""
    keys = {}
    for k in store["identity"]["key_fields"]:
        if k not in payload or payload[k] in (None, ""):
            raise StoreRefusal("store.identity_incomplete", f"{store['store_id']}: key field {k!r} missing from the payload; identity is never inferred")
        keys[k] = payload[k]
    return lga.sha256_digest(lga.canonical_json({"store": store["store_id"], "schema": store["schema_version"], "keys": keys}))


class Store:
    """The only write path to persisted state: chained, append-only ledgers per store under one run directory."""

    def __init__(self, run_dir: Path, *, stores: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> None:
        self.run_dir = Path(run_dir).resolve()
        self.registry = registry or C.load_registry()
        self.stores = stores or load_stores(registry=self.registry)
        self.base = self.run_dir / "stores"

    def store(self, store_id: str) -> dict[str, Any]:
        s = self.stores["stores"].get(store_id)
        if s is None:
            raise StoreRefusal("store.unknown", f"no such store {store_id!r}")
        return s

    def path(self, store_id: str) -> Path:
        self.store(store_id)
        return self.base / f"{store_id}.jsonl"

    # ---- write ------------------------------------------------------------------------------------------------
    def put(self, store_id: str, payload: Mapping[str, Any], *, writer: str, provenance: Mapping[str, Any], classification: str | None = None, retention: Mapping[str, Any] | None = None) -> dict[str, Any]:
        """Append one sealed record. The writer must be a declared owner; identity comes from the declared key fields;
        provenance fields are mandatory; classification may only be raised, never lowered below the store's own."""
        s = self.store(store_id)
        if writer in FORBIDDEN_WRITERS or writer not in s["ownership"]["writers"]:
            if writer not in FORBIDDEN_WRITERS:
                _SEC.record_denial("SEC-05", "security.sec05.write_denied", f"{store_id}: undeclared writer {writer!r}", actor={"identity": writer}, subject={"store_id": store_id}, run_dir=self.run_dir)  # SEC-05-T02
            if writer in FORBIDDEN_WRITERS:
                _SEC.record_denial("SEC-08", "security.sec08.model_writer", f"{store_id}: {writer!r} may not append records", actor={"identity": writer}, subject={"store_id": store_id}, run_dir=self.run_dir)  # SEC-08-T02
            raise StoreRefusal("store.writer_forbidden", f"{store_id}: {writer!r} may not write this store (writers: {s['ownership']['writers']})")
        missing = [f for f in s["provenance_fields"] if f not in provenance or provenance[f] in (None, "")]
        if missing:
            raise StoreRefusal("store.provenance_incomplete", f"{store_id}: provenance lacks {missing}")
        cls = classification or s["classification"]
        if CLASSIFICATIONS.index(cls) < CLASSIFICATIONS.index(s["classification"]):
            raise StoreRefusal("store.classification_lowered", f"{store_id}: classification {cls} is below the store's {s['classification']}")
        ret = dict(s["retention"]); ret.update(retention or {})
        payload = _SEC.scrub_secrets(dict(payload))  # SEC-03-T03: secrets never persist
        rid = record_id(s, payload)
        created = _now()
        expires = (datetime.fromisoformat(created) + timedelta(days=int(ret["ttl_days"]))).isoformat(timespec="seconds") if ret.get("ttl_days") else None
        rec = {"record_schema": RECORD_SCHEMA, "store_id": store_id, "record_kind": s["record_kind"], "record_id": rid, "schema_version": s["schema_version"], "owner": s["ownership"]["owner"], "writer": writer,
               "classification": cls, "retention": {"mode": ret["mode"], "ttl_days": ret.get("ttl_days"), "expires_at": expires, "legal_hold": bool(ret.get("legal_hold", False))},
               "provenance": {k: provenance[k] for k in s["provenance_fields"]}, "payload": dict(payload), "payload_hash": lga.sha256_digest(lga.canonical_json(payload)), "lifecycle": "SEALED", "created_at": created}
        rec["record_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in rec.items() if k != "record_hash"}))
        C.validate_payload("store_record", {k: v for k, v in rec.items() if k != "payload"}, registry=self.registry)
        return self._append(store_id, rec)

    def _append(self, store_id: str, rec: Mapping[str, Any]) -> dict[str, Any]:
        return _chain_append(self.path(store_id), dict(rec))

    # ---- read ---------------------------------------------------------------------------------------------------
    def rows(self, store_id: str) -> list[dict[str, Any]]:
        p = self.path(store_id)
        if not p.is_file():
            return []
        verify_chain_file(p)
        return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]

    def get(self, store_id: str, rid: str) -> dict[str, Any] | None:
        """The current record for an identity: the latest sealed row, unless a later tombstone retired it."""
        latest = None
        for r in self.rows(store_id):
            if r.get("record_id") == rid:
                latest = r
        if latest is None or latest.get("lifecycle") == "TOMBSTONED":
            return None
        return latest

    def head(self, store_id: str) -> str:
        rows = self.rows(store_id)
        return rows[-1]["entry_hash"] if rows else "genesis"

    def verify(self, store_id: str) -> dict[str, Any]:
        p = self.path(store_id)
        n = verify_chain_file(p) if p.is_file() else 0
        return {"store_id": store_id, "rows": n, "head": self.head(store_id), "verdict": "PASS"}

    def summary(self) -> dict[str, Any]:
        return {sid: {"rows": len(self.rows(sid)) if self.path(sid).is_file() else 0, "head": self.head(sid)} for sid in self.stores["stores"]}


__all__ = ["CLASSIFICATIONS", "LIFECYCLE", "RECORD_SCHEMA", "STORES_PATH", "STORES_VERSION", "Store", "StoreRefusal", "load_stores", "record_id"]


# --------------------------------------------------------------------------- #
# T02 — persistence bound through the Filing Cabinet / Archive Ledger shapes: every store is fed only from the run
# artifacts the adapters produced (chained ledgers, manifests, receipts); the model and the UI have no write path
# --------------------------------------------------------------------------- #
_BINDERS: dict[str, Any] = {}


def register_binder(store_id: str):
    def deco(fn):
        _BINDERS[store_id] = fn
        return fn
    return deco


def _jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    verify_chain_file(path)
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]


def _json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else None


def _run_identity(run_dir: Path) -> dict[str, Any]:
    b = _json(run_dir / "suite40" / "binding.json") or {}
    steps = _jsonl(run_dir / "workflow" / "steps.jsonl")
    run_id = steps[0]["run_id"] if steps else (_json(run_dir / "archive" / "MANIFEST.json") or {}).get("run_id")
    if not run_id or not b.get("base_revision"):
        raise StoreRefusal("store.run_unbound", "the run directory carries no workflow records or binding; nothing is persisted from an unidentified run")
    return {"run_id": run_id, "repository_id": b["repository_id"], "base_revision": b["base_revision"], "source_snapshot_hash": b["source_snapshot_hash"]}


def bind_run(store: "Store", run_dir: Path, *, only: Sequence[str] | None = None) -> dict[str, Any]:
    """Persist every bound store from one run directory. Idempotent per identity: a record whose identity and payload
    hash already sit at the head of its store is not rewritten (a changed payload for the same identity is a new sealed
    version, never an overwrite)."""
    run_dir = Path(run_dir).resolve()
    ident = _run_identity(run_dir)
    out = {}
    for sid in store.stores["stores"]:
        if only and sid not in only:
            continue
        fn = _BINDERS.get(sid)
        if fn is None:
            out[sid] = {"bound": False, "written": 0}
            continue
        written = 0
        for writer, payload, prov in fn(run_dir, ident):
            s = store.store(sid)
            rid = record_id(s, payload)
            cur = store.get(sid, rid)
            if cur is not None and cur["payload_hash"] == lga.sha256_digest(lga.canonical_json(payload)):
                continue
            store.put(sid, payload, writer=writer, provenance={**ident, **prov})
            written += 1
        out[sid] = {"bound": True, "written": written, "rows": len(store.rows(sid))}
    return out


# @@ STORE-01
@register_binder("STORE-01")
def _bind_run_state(run_dir: Path, ident: Mapping[str, Any]):
    """STORE-01 persistent workflow/run state: every workflow step attempt (before/after) and every archived run-state
    transition, as produced by the workflow runtime and the archive adapter (Filing Cabinet 12 ledgers, 58.2 storage)."""
    for r in _jsonl(run_dir / "workflow" / "steps.jsonl"):
        yield "workflow", {"run_id": r["run_id"], "step_id": r["step_id"], "attempt_id": r["attempt_id"], "phase": r["phase"], "attempt_no": r["attempt_no"], "run_state_before": r.get("run_state_before"), "run_state_after": r.get("run_state_after"),
                           "outcome": r.get("outcome"), "error_code": r.get("error_code"), "route": r.get("route"), "evidence": r.get("evidence") or {}, "inputs_hash": r.get("inputs_hash"), "started_at": r.get("started_at"), "finished_at": r.get("finished_at"), "step_record_hash": r["record_hash"]}, {"produced_by": "adapters/workflow.WorkflowRun", "source_ledger": "workflow/steps.jsonl", "source_entry_hash": r["entry_hash"]}
    for r in _jsonl(run_dir / "archive" / "run-state.jsonl"):
        yield "archive_adapter", {"run_id": r["run_id"], "step_id": "archive.run_state", "attempt_id": r["entry_hash"], "phase": "transition", "attempt_no": 0, "run_state_before": None, "run_state_after": r["run_state"], "outcome": "SUCCEEDED", "error_code": None, "route": None,
                                 "evidence": {"evidence_ref": r.get("evidence_ref")}, "inputs_hash": None, "started_at": r.get("at"), "finished_at": r.get("at"), "step_record_hash": r["entry_hash"]}, {"produced_by": "adapters/archive_adapter.archive_run", "source_ledger": "archive/run-state.jsonl", "source_entry_hash": r["entry_hash"]}
# @@ STORE-02
@register_binder("STORE-02")
def _bind_artifacts(run_dir: Path, ident: Mapping[str, Any]):
    """STORE-02 versioned artifact metadata and source pointers: the content-addressed archive manifest entries
    (Archive Ledger 29.4/29.5), each pointing at its run, repository and pinned revision."""
    m = _json(run_dir / "archive" / "MANIFEST.json")
    if not m:
        return
    for e in m.get("artifacts", []):
        yield "archive_adapter", {"run_id": m["run_id"], "path": e["path"], "sha256": e["sha256"], "bytes": e.get("bytes"), "step": e.get("step"), "manifest_hash": m["manifest_hash"], "artifact_version": m.get("archive_version") or "0.1.0",
                                  "source_pointer": {"run_dir_relative": e["path"], "repository_id": ident["repository_id"], "base_revision": ident["base_revision"], "source_snapshot_hash": ident["source_snapshot_hash"]}}, {"produced_by": "adapters/archive_adapter.archive_run", "source_ledger": "archive/MANIFEST.json", "source_entry_hash": m["manifest_hash"]}
# @@ STORE-03
@register_binder("STORE-03")
def _bind_evidence(run_dir: Path, ident: Mapping[str, Any]):
    """STORE-03 evidence/provenance records: Suite 51.1 exact evidence records, Phase 04 intake records and the archive's
    provenance links — each pinned to the snapshot it came from (29.5 provenance, Cypher 11 audit provenance)."""
    for e in _json(run_dir / "suite51" / "evidence.json") or []:
        yield "evidence_retrieval", {"evidence_id": e["evidence_id"], "kind": "evidence_record", "canonical_path": e["canonical_path"], "content_hash": e["content_hash"], "retrieval_id": e["retrieval_id"], "source_snapshot_hash": e["source_snapshot_hash"], "evidence_kind": e["evidence_kind"], "match_status": e["match_status"], "exact_locator": e["exact_locator"]}, {"produced_by": "adapters/evidence_retrieval.retrieve_examples", "source_ledger": "suite51/evidence.json", "source_entry_hash": e["evidence_id"]}
    for sid, r in (_json(run_dir / "intake" / "records.json") or {}).items():
        yield "intake", {"evidence_id": r["intake_hash"], "kind": "intake_record", "canonical_path": sid, "content_hash": r["intake_hash"], "retrieval_id": r.get("pin", {}).get("pin_hash") or r["intake_hash"], "source_snapshot_hash": r["source_snapshot_hash"], "evidence_kind": f"intake:{sid}", "match_status": r["state"], "exact_locator": f"{sid}@{r['base_revision']}"}, {"produced_by": "adapters/intake.admit", "source_ledger": "intake/records.json", "source_entry_hash": r["intake_hash"]}
    p = _json(run_dir / "archive" / "provenance.json")
    if p:
        h = lga.sha256_digest(lga.canonical_json(p))
        yield "archive_adapter", {"evidence_id": h, "kind": "provenance_links", "canonical_path": "archive/provenance.json", "content_hash": h, "retrieval_id": h, "source_snapshot_hash": ident["source_snapshot_hash"], "evidence_kind": "lineage", "match_status": "archived", "exact_locator": f"archive/provenance.json@{ident['base_revision']}"}, {"produced_by": "adapters/archive_adapter.archive_run", "source_ledger": "archive/provenance.json", "source_entry_hash": h}
# @@ STORE-04
@register_binder("STORE-04")
def _bind_approvals(run_dir: Path, ident: Mapping[str, Any]):
    """STORE-04 human approval/rejection history: every signed receipt on the approvals ledger (50.5, 44.4, 49.14) —
    decision, approver, channel, binding hashes, validity window; signatures are stored, never re-issued."""
    path = run_dir / "approvals" / "ledger.jsonl"
    for n, line in enumerate(path.read_text(encoding="utf-8").splitlines() if path.is_file() else []):
        if not line.strip():
            continue
        r = json.loads(line)
        body = {k: v for k, v in r.items() if k not in ("receipt_hash", "signature")}
        if lga.sha256_digest(lga.canonical_json(body)) != r.get("receipt_hash"):  # the receipt chain is verified by the approval adapter with its key; the body hash is checked here
            raise StoreRefusal("store.source_tampered", f"approvals/ledger.jsonl entry {n}: receipt hash does not match its body")
        yield "approval_adapter", {"receipt_hash": r["receipt_hash"], "decision": r["decision"], "approver_identity": r["approver_identity"], "approver_channel": r["approver_channel"], "candidate_id": r["candidate_id"], "card_hash": r["card_hash"], "verification_report_hash": r["verification_report_hash"],
                                   "issued_at": r["issued_at"], "expires_at": r["expires_at"], "signature": r["signature"], "prev_hash": r["prev_hash"], "rationale": r.get("rationale")}, {"produced_by": "adapters/approval_adapter.issue_receipt", "source_ledger": "approvals/ledger.jsonl", "source_entry_hash": r["receipt_hash"]}
# @@ STORE-05
@register_binder("STORE-05")
def _bind_versions(run_dir: Path, ident: Mapping[str, Any]):
    """STORE-05 model/tool version metadata: adapter, registry, component, guardrail, policy, workflow and store versions
    the run executed under, plus the (advisory) model version — pinned so a replay can prove what produced what."""
    import platform
    import subprocess
    from . import components as K
    from . import guardrails as GR
    from . import workflow as WF
    b = _json(run_dir / "suite40" / "binding.json") or {}
    plan = _json(run_dir / "plan" / "refactoring_plan.json") or {}
    reg = C.load_registry()
    versions = [("local_git_adapter", b.get("adapter_version", "?"), b.get("adapter_id", "adapter")), ("contracts_registry", reg["computed_hash"][:23], "registry"), ("components_registry", K.load_components(registry=reg)["computed_hash"][:23], "registry"),
                ("guardrail_rules", GR.load_rules(registry=reg)["computed_hash"][:23] if "computed_hash" in GR.load_rules(registry=reg) else "?", "rules"), ("workflow_registry", WF.load_workflow(registry=reg)["computed_hash"][:23], "registry"),
                ("model", str(plan.get("model_version") or "none (deterministic plan; advisory model output not used)"), "model"), ("python", platform.python_version(), "tool")]
    try:
        versions.append(("git", subprocess.run(["git", "--version"], capture_output=True, text=True, check=True).stdout.strip().split()[-1], "tool"))
    except Exception:  # pragma: no cover
        versions.append(("git", "unavailable", "tool"))
    for name, ver, kind in versions:
        yield "workflow", {"run_id": ident["run_id"], "component": name, "version": ver, "kind": kind, "policy_hash": (_json(run_dir / "workflow" / "authority.json") or {}).get("policy_hash")}, {"produced_by": "adapters/store.bind_run (versions observed at bind time)", "source_ledger": "suite40/binding.json + registries", "source_entry_hash": b.get("worktree_hash") or ident["source_snapshot_hash"]}
# @@ STORE-06
@register_binder("STORE-06")
def _bind_retention(run_dir: Path, ident: Mapping[str, Any]):
    """STORE-06 retention, deletion and privacy controls: one control record per store declaring the retention class,
    classification, deletion mode and legal-hold state in force for this run (44.3 trust boundaries, 28.4/28.7, 52.7)."""
    st = load_stores()
    for sid, s in st["stores"].items():
        yield "store", {"subject_store": sid, "subject_record_id": "*", "control_kind": "retention_class", "run_id": ident["run_id"], "classification": s["classification"], "retention_mode": s["retention"]["mode"], "ttl_days": s["retention"].get("ttl_days"), "legal_hold": False,
                        "privacy": {"contains_personal_data": s.get("privacy", {}).get("contains_personal_data", False), "fields": s.get("privacy", {}).get("fields", [])}}, {"produced_by": "adapters/store.bind_run (retention controller)", "source_ledger": "store/STORES.json", "source_entry_hash": st["computed_hash"]}
# @@ STORE-07
@register_binder("STORE-07")
def _bind_audit(run_dir: Path, ident: Mapping[str, Any]):
    """STORE-07 append-only audit trail for privileged actions: the archive audit ledger (approval issuance, isolated
    apply, rollback) and the workflow decision events (Chair 13, 44.5, 55.4, 28.5) — one immutable row per action."""
    for r in _jsonl(run_dir / "archive" / "audit.jsonl"):
        yield "archive_adapter", {"run_id": r["run_id"], "effect": r["effect"], "entry_hash": r["entry_hash"], "actor": r.get("actor"), "at": r.get("at"), "decision": r.get("decision") or r.get("verdict"), "authorized_by": r.get("authorized_by"), "source": "archive/audit.jsonl"}, {"produced_by": "adapters/archive_adapter", "source_ledger": "archive/audit.jsonl", "source_entry_hash": r["entry_hash"]}
    for r in _jsonl(run_dir / "workflow" / "events.jsonl"):
        if r["kind"] == "decision.outcome":
            p = r["payload"]
            yield "workflow", {"run_id": r["run_id"], "effect": f"workflow.{p['step_id']}", "entry_hash": r["entry_hash"], "actor": "adapters/workflow", "at": r["at"], "decision": p["outcome"], "authorized_by": p.get("attempt_id"), "source": "workflow/events.jsonl"}, {"produced_by": "adapters/workflow.WorkflowRun", "source_ledger": "workflow/events.jsonl", "source_entry_hash": r["entry_hash"]}


__all__ += ["bind_run", "register_binder"]


# --------------------------------------------------------------------------- #
# T03 — storage semantics: durable single-row transactions, append-only immutability with tamper detection, optimistic
# version checks + exclusive locks, retention/deletion by tombstone under legal hold, backup checkpoints and recovery
# --------------------------------------------------------------------------- #
import shutil
import contextlib


@contextlib.contextmanager
def _locked(self: "Store", store_id: str):
    """Exclusive writer lock per store ledger (O_EXCL lock file); a second writer refuses instead of interleaving."""
    lock = self.path(store_id).with_suffix(".lock")
    lock.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        raise StoreRefusal("store.locked", f"{store_id}: another writer holds the ledger lock; refusing to interleave") from None
    try:
        os.write(fd, f"{os.getpid()} {_now()}".encode()); os.close(fd)
        yield
    finally:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(str(lock))


def _append_durable(self: "Store", store_id: str, rec: Mapping[str, Any], *, expected_head: str | None = None) -> dict[str, Any]:
    """One record = one transaction: under the lock, verify the chain head (optimistic version check), append the
    chained row, flush and fsync. A partially written tail is never accepted as a row (see recover)."""
    p = self.path(store_id)
    with _locked(self, store_id):
        head = self.head(store_id)
        if expected_head is not None and expected_head != head:
            raise StoreRefusal("store.conflict", f"{store_id}: head moved ({head[:23]} != expected {expected_head[:23]}); re-read and retry")
        entry = dict(rec, prev_hash=head)
        entry["entry_hash"] = lga.sha256_digest(lga.canonical_json(entry))
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("a", encoding="utf-8") as f:
            f.write(lga.canonical_json(entry) + "\n"); f.flush(); os.fsync(f.fileno())
        return entry


def _put_versioned(self: "Store", store_id: str, payload: Mapping[str, Any], *, writer: str, provenance: Mapping[str, Any], classification: str | None = None, retention: Mapping[str, Any] | None = None, expected_head: str | None = None) -> dict[str, Any]:
    self._pending_head = expected_head
    try:
        return _put_v1(self, store_id, payload, writer=writer, provenance=provenance, classification=classification, retention=retention)
    finally:
        self._pending_head = None


def _append_v3(self: "Store", store_id: str, rec: Mapping[str, Any]) -> dict[str, Any]:
    return _append_durable(self, store_id, rec, expected_head=getattr(self, "_pending_head", None))


def _rows_v3(self: "Store", store_id: str) -> list[dict[str, Any]]:
    """Reads verify the chain; a broken chain (tampered or partially written row) refuses — nothing is read past it."""
    p = self.path(store_id)
    if not p.is_file():
        return []
    try:
        verify_chain_file(p)
    except lga.AdapterError as exc:
        raise StoreRefusal("store.chain_broken", f"{store_id}: {exc.code}: {exc} — run recover() to quarantine the damaged tail; a mid-chain change is tampering") from exc
    except ValueError as exc:
        raise StoreRefusal("store.chain_broken", f"{store_id}: unreadable row: {exc} — run recover()") from exc
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


def recover(self: "Store", store_id: str) -> dict[str, Any]:
    """Recovery: keep the longest valid chain prefix; move any damaged tail rows to a quarantine file (never deleted,
    never reinterpreted); report what was kept and what was quarantined. A break followed by valid rows is tampering."""
    p = self.path(store_id)
    if not p.is_file():
        return {"store_id": store_id, "rows": 0, "quarantined": 0, "verdict": "EMPTY"}
    raw = [l for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]
    good, prev, bad_from = [], "genesis", None
    for i, line in enumerate(raw):
        try:
            e = json.loads(line)
            body = {k: v for k, v in e.items() if k != "entry_hash"}
            ok = e.get("prev_hash") == prev and lga.sha256_digest(lga.canonical_json(body)) == e.get("entry_hash")
        except ValueError:
            ok = False
        if not ok:
            bad_from = i
            break
        good.append(line); prev = e["entry_hash"]
    if bad_from is None:
        return {"store_id": store_id, "rows": len(good), "quarantined": 0, "verdict": "INTACT"}
    tail = raw[bad_from:]
    tampering = len(tail) > 1  # rows after the break: an interior row was altered or removed, not a torn write
    with _locked(self, store_id):
        q = p.with_suffix(".quarantine")
        with q.open("a", encoding="utf-8") as f:
            for line in tail:
                f.write(json.dumps({"quarantined_at": _now(), "reason": "tampered_or_removed_row" if tampering else "partial_write", "raw": line}) + "\n")
        tmp = p.with_suffix(".tmp")
        tmp.write_text("".join(l + "\n" for l in good), encoding="utf-8")
        os.replace(tmp, p)
    return {"store_id": store_id, "rows": len(good), "quarantined": len(tail), "verdict": "TAMPERED" if tampering else "RECOVERED", "quarantine": str(q)}


def tombstone(self: "Store", store_id: str, rid: str, *, writer: str, reason: str) -> dict[str, Any]:
    """Deletion under append-only semantics: a tombstone row retires the identity; the original row stays in the chain
    (its payload hash remains, the payload is not copied). Refused for pure append-only stores and under legal hold."""
    s = self.store(store_id)
    if s["retention"]["mode"] != "append_only_tombstone":
        raise StoreRefusal("store.immutable", f"{store_id}: records of this store are never deleted (mode {s['retention']['mode']})")
    if writer not in s["ownership"]["writers"]:
        raise StoreRefusal("store.writer_forbidden", f"{store_id}: {writer!r} may not tombstone")
    cur = self.get(store_id, rid)
    if cur is None:
        raise StoreRefusal("store.not_found", f"{store_id}: no current record {rid[:23]}")
    if cur["retention"].get("legal_hold") or self.on_hold(store_id, rid):
        raise StoreRefusal("store.legal_hold", f"{store_id}: record {rid[:23]} is under legal hold; deletion refused")
    rec = {k: v for k, v in cur.items() if k not in ("prev_hash", "entry_hash")}
    rec.update(lifecycle="TOMBSTONED", payload={}, tombstone={"reason": reason, "of_record_hash": cur["record_hash"], "payload_hash_retained": cur["payload_hash"], "at": _now()}, writer=writer, created_at=_now())
    rec["record_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in rec.items() if k != "record_hash"}))
    return self._append(store_id, rec)


def on_hold(self: "Store", store_id: str, rid: str) -> bool:
    """Legal-hold state for one identity: the latest STORE-06 legal_hold control for the record (or for the whole store) wins."""
    if not self.path("STORE-06").is_file():
        return False
    hold = False
    for r in self.rows("STORE-06"):
        p = r.get("payload") or {}
        if r.get("lifecycle") != "TOMBSTONED" and p.get("control_kind") == "legal_hold" and p.get("subject_store") == store_id and p.get("subject_record_id") in (rid, "*"):
            hold = bool(p.get("hold"))
    return hold


def set_legal_hold(self: "Store", store_id: str, rid: str, *, hold: bool, writer: str, provenance: Mapping[str, Any], reason: str) -> dict[str, Any]:
    """A privacy/retention control record: legal hold on or off for one identity (or '*' for the whole store)."""
    self.store(store_id)
    return self.put("STORE-06", {"subject_store": store_id, "subject_record_id": rid, "control_kind": "legal_hold", "run_id": provenance.get("run_id"), "hold": bool(hold), "reason": reason, "classification": self.store(store_id)["classification"],
                                 "retention_mode": self.store(store_id)["retention"]["mode"], "ttl_days": self.store(store_id)["retention"].get("ttl_days"), "legal_hold": bool(hold), "privacy": {"contains_personal_data": False, "fields": []}}, writer=writer, provenance=provenance)


def purge_expired(self: "Store", store_id: str, *, writer: str, now: str | None = None) -> dict[str, Any]:
    """Retention: tombstone every current record whose TTL elapsed, unless held; nothing is physically removed."""
    now = now or _now()
    seen, purged, held = set(), [], []
    for r in reversed(self.rows(store_id)):
        rid = r["record_id"]
        if rid in seen:
            continue
        seen.add(rid)
        exp = r.get("retention", {}).get("expires_at")
        if r.get("lifecycle") == "TOMBSTONED" or not exp or exp > now:
            continue
        try:
            self.tombstone(store_id, rid, writer=writer, reason=f"retention_expired:{exp}")
            purged.append(rid)
        except StoreRefusal as exc:
            if exc.code == "store.legal_hold":
                held.append(rid)
            else:
                raise
    return {"store_id": store_id, "purged": purged, "held": held, "at": now}


def checkpoint(self: "Store", dest: Path) -> dict[str, Any]:
    """Backup: copy every ledger with a manifest of sha256 + head per store (verifiable, restorable)."""
    dest = Path(dest).resolve()
    if lga.path_within(dest, self.base):
        raise StoreRefusal("store.checkpoint_inside", "checkpoint destination must lie outside the stores directory")
    dest.mkdir(parents=True, exist_ok=True)
    files = {}
    for sid in self.stores["stores"]:
        p = self.path(sid)
        if p.is_file():
            self.rows(sid)
            shutil.copy2(p, dest / p.name)
            files[p.name] = {"sha256": lga.sha256_digest(p.read_bytes()), "head": self.head(sid), "rows": len(self.rows(sid))}
    man = {"record_schema": "overlay.scoped_pr_builder.store/Checkpoint", "stores_hash": self.stores["computed_hash"], "files": files, "created_at": _now()}
    man["checkpoint_hash"] = lga.sha256_digest(lga.canonical_json(man))
    (dest / "CHECKPOINT.json").write_text(lga.canonical_json(man) + "\n", encoding="utf-8")
    return man


def restore(self: "Store", src: Path) -> dict[str, Any]:
    """Recovery from a checkpoint: verify the manifest against the files, then restore only onto ledgers that are
    absent or a prefix of the checkpoint (never onto a longer or diverged chain)."""
    src = Path(src).resolve()
    man = json.loads((src / "CHECKPOINT.json").read_text(encoding="utf-8"))
    body = {k: v for k, v in man.items() if k != "checkpoint_hash"}
    if lga.sha256_digest(lga.canonical_json(body)) != man["checkpoint_hash"]:
        raise StoreRefusal("store.checkpoint_invalid", "checkpoint manifest hash mismatch")
    restored = []
    for name, meta in man["files"].items():
        data = (src / name).read_bytes()
        if lga.sha256_digest(data) != meta["sha256"]:
            raise StoreRefusal("store.checkpoint_invalid", f"{name}: file does not match the checkpoint manifest")
        target = self.base / name
        if target.is_file():
            cur = target.read_bytes()
            if cur == data or cur.startswith(data):
                continue  # the live chain equals or extends the checkpoint: nothing to restore
            if not data.startswith(cur):
                raise StoreRefusal("store.restore_conflict", f"{name}: the live ledger diverged from the checkpoint; refusing to overwrite")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        restored.append(name)
    return {"restored": restored, "checkpoint_hash": man["checkpoint_hash"]}


_put_v1 = Store.put
Store.put = _put_versioned  # type: ignore[assignment]
Store._append = _append_v3  # type: ignore[assignment]
Store.rows = _rows_v3  # type: ignore[assignment]
Store.recover = recover  # type: ignore[attr-defined]
Store.tombstone = tombstone  # type: ignore[attr-defined]
Store.on_hold = on_hold  # type: ignore[attr-defined]
Store.set_legal_hold = set_legal_hold  # type: ignore[attr-defined]
Store.purge_expired = purge_expired  # type: ignore[attr-defined]
Store.checkpoint = checkpoint  # type: ignore[attr-defined]
Store.restore = restore  # type: ignore[attr-defined]


# --------------------------------------------------------------------------- #
# T04 — restart/replay: an interrupted run reconstructs the same material state from its chained ledgers alone; inputs
# whose provenance no longer matches the live repository are flagged stale and never reinterpreted as current
# --------------------------------------------------------------------------- #
def materialize(self: "Store", store_id: str) -> dict[str, dict[str, Any]]:
    """Current records of a store by identity: the latest row per record_id, tombstones applied (retired identities
    are absent). Pure function of the chain — two loads of the same ledger yield the same material state."""
    latest: dict[str, dict[str, Any]] = {}
    for r in self.rows(store_id):
        latest[r["record_id"]] = r
    return {rid: r for rid, r in latest.items() if r.get("lifecycle") != "TOMBSTONED"}


def material_hash(self: "Store", store_id: str) -> str:
    """Digest of the material state (record ids → record hashes), independent of row timestamps of retired rows."""
    m = self.materialize(store_id)
    return lga.sha256_digest(lga.canonical_json({rid: r["record_hash"] for rid, r in m.items()}))


def current(self: "Store", store_id: str, *, binding: Any = None) -> dict[str, Any]:
    """Material records partitioned by freshness against a live binding: a record whose provenance names another
    repository/revision/snapshot is *stale* — returned separately, never as current."""
    m = self.materialize(store_id)
    if binding is None:
        return {"current": m, "stale": {}, "checked_against": None}
    cur, stale = {}, {}
    for rid, r in m.items():
        p = r.get("provenance") or {}
        if p.get("repository_id") == binding.repository_id and p.get("base_revision") == binding.base_revision and p.get("source_snapshot_hash") == binding.source_snapshot_hash:
            cur[rid] = r
        else:
            stale[rid] = {"record": r, "reason": "provenance does not match the live binding (repository/revision/snapshot)"}
    return {"current": cur, "stale": stale, "checked_against": {"repository_id": binding.repository_id, "base_revision": binding.base_revision, "source_snapshot_hash": binding.source_snapshot_hash}}


def resume(run_dir: Path, *, binding: Any = None, stores: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Restart loading for an interrupted run: verify every ledger, rebuild the workflow run from its step records,
    materialize every store, and classify inputs as current or stale against the live binding. Nothing is re-derived
    from artifacts on disk — only from chained records — and stale inputs are reported, not reused."""
    from . import workflow as WF
    run_dir = Path(run_dir).resolve()
    st = Store(run_dir, stores=stores, registry=registry)
    _SEC.assert_audit_intact(run_dir)  # SEC-08-T02: an edited chain is never resumed
    ledgers = {sid: st.verify(sid) for sid in st.stores["stores"] if st.path(sid).is_file()}
    wf_state = None
    if (run_dir / "workflow" / "steps.jsonl").is_file():
        run = WF.WorkflowRun.load(run_dir, registry=st.registry)
        wf_state = {"run_id": run.run_id, "run_state": run.state, "completed": sorted(run.completed), "attempts": dict(run.attempts), "evidence": dict(run.evidence), "terminal": run.state in WF.CT.TERMINAL_STATES, "resumable": run.state not in WF.CT.TERMINAL_STATES}
    stores_state, stale_inputs = {}, []
    for sid in ledgers:
        c = st.current(sid, binding=binding)
        stores_state[sid] = {"material_hash": st.material_hash(sid), "current": len(c["current"]), "stale": len(c["stale"]), "rows": ledgers[sid]["rows"], "head": ledgers[sid]["head"]}
        stale_inputs += [{"store_id": sid, "record_id": rid, "reason": v["reason"]} for rid, v in c["stale"].items()]
    report = {"record_schema": "overlay.scoped_pr_builder.store/ResumeReport", "run_dir": str(run_dir), "ledgers": ledgers, "workflow": wf_state, "stores": stores_state, "stale_inputs": stale_inputs,
              "may_continue": bool(wf_state and wf_state["resumable"]) and not stale_inputs, "resumed_at": _now()}
    report["resume_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in report.items() if k not in ("resumed_at",)}))
    return report


def assert_fresh(report: Mapping[str, Any]) -> None:
    """Refuse to continue a resumed run over stale inputs (they are surfaced for review; never reinterpreted)."""
    if report["stale_inputs"]:
        raise StoreRefusal("store.stale_input", f"{len(report['stale_inputs'])} persisted input(s) no longer match the live repository; review before continuing")
    if not report.get("workflow"):
        raise StoreRefusal("store.no_workflow", "no workflow records to resume from")
    if not report["workflow"]["resumable"]:
        raise StoreRefusal("store.terminal", f"run is terminal ({report['workflow']['run_state']}); nothing to resume")


Store.materialize = materialize  # type: ignore[attr-defined]
Store.material_hash = material_hash  # type: ignore[attr-defined]
Store.current = current  # type: ignore[attr-defined]

__all__ += ["assert_fresh", "resume"]
