"""Scoped PR Builder — versioned contract registry and payload validation (Phase 01 / T01).

The overlay's canonical schemas, controls and API contracts live in
``contracts/REGISTRY.json``: one entry per contract, versioned (semver), each carrying
its schema, the authoritative suites it composes, the item that introduced it, a
Tables/08 ``SchemaRegistryRecord``-shaped registration row, and **examples** — a
passing payload plus violating payloads with the exact refusal code expected. The
examples are executed by ``tests/test_contracts.py``, so every registered contract is
demonstrated in a passing path and a violating/blocked path.

Validation is a small, deterministic, dependency-free subset of JSON Schema:
``type`` (object/array/string/integer/number/boolean/null and lists of those),
``required``, ``properties``, ``additionalProperties`` (default **false** — unknown
fields are rejected), ``enum``, ``const``, ``pattern``, ``minimum``/``maximum``,
``minLength``/``maxLength``, ``minItems``/``maxItems``, ``items``, ``$ref`` to another
registered contract (``#/contracts/<id>``). Anything the validator does not
understand is a registry error, never a silent pass.

Identity fields (``sha256:`` digests, 40-hex revisions) are shared definitions so every
boundary payload carries immutable identities in one canonical form (API-07).

Build provenance: BUILD_NEW (stdlib); see ``../PROVENANCE.jsonl``.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Mapping

from . import local_git_adapter as lga

REGISTRY_VERSION = "scoped_pr_builder.contract_registry/0.1.0"
REGISTRY_PATH = Path(__file__).resolve().parent.parent / "contracts" / "REGISTRY.json"
SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")
CONTRACT_ID_RE = re.compile(r"^[a-z][a-z0-9_]{2,63}$")
KINDS = ("boundary", "control", "schema", "api")
TYPES = {"object": dict, "array": list, "string": str, "integer": int, "number": (int, float), "boolean": bool, "null": type(None)}
KNOWN_KEYS = {"type", "required", "properties", "additionalProperties", "enum", "const", "pattern", "minimum", "maximum", "minLength", "maxLength", "minItems", "maxItems", "items", "$ref", "description", "title"}

# Shared canonical definitions (API-07: immutable run / artifact identities).
DEFS: dict[str, dict[str, Any]] = {
    "digest": {"type": "string", "pattern": r"^sha256:[0-9a-f]{64}$", "description": "content-addressed identity"},
    "revision": {"type": "string", "pattern": r"^[0-9a-f]{40}$", "description": "full git commit id"},
    "git_tree": {"type": "string", "pattern": r"^git-tree:[0-9a-f]{40}$"},
    "semver": {"type": "string", "pattern": r"^\d+\.\d+\.\d+$"},
    "contract_ref": {"type": "string", "pattern": r"^[a-z][a-z0-9_.]+/\d+\.\d+\.\d+$", "description": "<contract_id or namespace>/<semver>"},
    "timestamp": {"type": "string", "pattern": r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$"},
    "repo_relative_path": {"type": "string", "pattern": r"^(?!/)(?!.*(^|/)\.\.?(/|$))(?!.*\\)[^\x00]+$", "minLength": 1},
    "identity": {
        "type": "object",
        "required": ["run_id", "repository_id", "worktree_id", "base_revision", "source_snapshot_hash", "scope_contract_hash", "policy_hash", "tool_version"],
        "properties": {
            "run_id": {"$ref": "#/defs/digest"}, "repository_id": {"$ref": "#/defs/digest"}, "worktree_id": {"$ref": "#/defs/digest"},
            "base_revision": {"$ref": "#/defs/revision"}, "source_snapshot_hash": {"$ref": "#/defs/digest"}, "scope_contract_hash": {"$ref": "#/defs/digest"},
            "policy_hash": {"$ref": "#/defs/digest"}, "tool_version": {"type": "string", "minLength": 1}, "model_version": {"type": ["string", "null"]},
            "provenance_ref": {"$ref": "#/defs/digest"},
        },
    },
}


class SchemaError(lga.AdapterError):
    pass


def _type_ok(value: Any, t: Any) -> bool:
    types = t if isinstance(t, list) else [t]
    for name in types:
        py = TYPES.get(name)
        if py is None:
            raise SchemaError("registry.invalid", f"unknown type {name!r}")
        if name == "integer" and isinstance(value, bool):
            continue
        if name == "number" and isinstance(value, bool):
            continue
        if isinstance(value, py):
            return True
    return False


def validate(schema: Mapping[str, Any], value: Any, *, path: str = "$", registry: Mapping[str, Any] | None = None) -> None:
    """Fail closed with ``schema.invalid`` (payload) or ``registry.invalid`` (schema) errors."""
    unknown = set(schema) - KNOWN_KEYS
    if unknown:
        raise SchemaError("registry.invalid", f"{path}: unsupported schema keywords {sorted(unknown)}")
    if "$ref" in schema:
        ref = schema["$ref"]
        if ref.startswith("#/defs/"):
            target = DEFS.get(ref[7:])
        elif ref.startswith("#/contracts/") and registry is not None:
            entry = registry["contracts"].get(ref[12:])
            target = entry["schema"] if entry else None
        else:
            target = None
        if target is None:
            raise SchemaError("registry.invalid", f"{path}: unresolvable $ref {ref}")
        return validate(target, value, path=path, registry=registry)
    if "type" in schema and not _type_ok(value, schema["type"]):
        raise SchemaError("schema.invalid", f"{path}: expected {schema['type']}, got {type(value).__name__}")
    if "const" in schema and value != schema["const"]:
        raise SchemaError("schema.invalid", f"{path}: must equal {schema['const']!r}")
    if "enum" in schema and value not in schema["enum"]:
        raise SchemaError("schema.invalid", f"{path}: {value!r} not in {schema['enum']}")
    if isinstance(value, str):
        if "pattern" in schema and not re.search(schema["pattern"], value):
            raise SchemaError("schema.invalid", f"{path}: does not match /{schema['pattern']}/")
        if "minLength" in schema and len(value) < schema["minLength"]:
            raise SchemaError("schema.invalid", f"{path}: shorter than {schema['minLength']}")
        if "maxLength" in schema and len(value) > schema["maxLength"]:
            raise SchemaError("schema.invalid", f"{path}: longer than {schema['maxLength']}")
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]:
            raise SchemaError("schema.invalid", f"{path}: below minimum {schema['minimum']}")
        if "maximum" in schema and value > schema["maximum"]:
            raise SchemaError("schema.invalid", f"{path}: above maximum {schema['maximum']}")
    if isinstance(value, list):
        if "minItems" in schema and len(value) < schema["minItems"]:
            raise SchemaError("schema.invalid", f"{path}: fewer than {schema['minItems']} items")
        if "maxItems" in schema and len(value) > schema["maxItems"]:
            raise SchemaError("schema.invalid", f"{path}: more than {schema['maxItems']} items")
        if "items" in schema:
            for i, item in enumerate(value):
                validate(schema["items"], item, path=f"{path}[{i}]", registry=registry)
    if isinstance(value, dict):
        props = schema.get("properties", {})
        for key in schema.get("required", []):
            if key not in value:
                raise SchemaError("schema.invalid", f"{path}: missing required field {key!r}")
        if not schema.get("additionalProperties", False):
            extra = sorted(set(value) - set(props))
            if extra:
                raise SchemaError("schema.invalid", f"{path}: unknown fields rejected {extra}")
        for key, sub in props.items():
            if key in value:
                validate(sub, value[key], path=f"{path}.{key}", registry=registry)


# --------------------------------------------------------------------------- #
# Registry                                                                       #
# --------------------------------------------------------------------------- #
ENTRY_REQUIRED = ("contract_id", "kind", "version", "title", "owning_suites", "introduced_by", "schema", "examples", "registration")


def load_registry(path: Path = REGISTRY_PATH) -> dict[str, Any]:
    """Load and self-validate the registry; fail closed on any structural defect."""
    if not Path(path).is_file():
        raise SchemaError("registry.missing", f"contract registry not found: {path}")
    reg = json.loads(Path(path).read_text(encoding="utf-8"))
    if reg.get("registry_version") != REGISTRY_VERSION:
        raise SchemaError("registry.invalid", f"unsupported registry_version {reg.get('registry_version')!r}")
    contracts = reg.get("contracts")
    if not isinstance(contracts, dict) or not contracts:
        raise SchemaError("registry.invalid", "registry has no contracts")
    for cid, e in contracts.items():
        missing = [k for k in ENTRY_REQUIRED if k not in e]
        if missing or e.get("contract_id") != cid:
            raise SchemaError("registry.invalid", f"contract {cid}: missing {missing} or id mismatch")
        if not CONTRACT_ID_RE.match(cid) or e["kind"] not in KINDS or not SEMVER_RE.match(e["version"]):
            raise SchemaError("registry.invalid", f"contract {cid}: bad id/kind/version")
        if not isinstance(e["owning_suites"], list) or not e["owning_suites"]:
            raise SchemaError("registry.invalid", f"contract {cid}: owning_suites required")
        reg_row = e["registration"]
        if reg_row.get("schema_name") != cid or reg_row.get("schema_version") != e["version"] or reg_row.get("record_schema") != "tables.schemas/SchemaRegistryRecord":
            raise SchemaError("registry.invalid", f"contract {cid}: registration row does not match")
        ex = e["examples"]
        if "valid" not in ex or not isinstance(ex.get("invalid"), list) or not ex["invalid"]:
            raise SchemaError("registry.invalid", f"contract {cid}: examples need one valid and at least one invalid payload")
    # every schema must be executable against its own valid example
    for cid, e in contracts.items():
        validate(e["schema"], e["examples"]["valid"], registry=reg)
    body = {k: v for k, v in reg.items() if k != "registry_hash"}
    reg["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return reg


def validate_payload(contract_id: str, payload: Any, *, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Validate ``payload`` against a registered contract; return a validation receipt."""
    reg = registry or load_registry()
    entry = reg["contracts"].get(contract_id)
    if entry is None:
        raise SchemaError("contract.unknown", f"no registered contract {contract_id!r}")
    validate(entry["schema"], payload, registry=reg)
    return {"contract_id": contract_id, "contract_version": entry["version"], "payload_hash": lga.sha256_digest(lga.canonical_json(payload)), "verdict": "VALID"}


def registration_rows(registry: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    """Tables/08 SchemaRegistryRecord-shaped rows for every registered contract (admission-ready)."""
    reg = registry or load_registry()
    return [dict(e["registration"], registered_by=e["introduced_by"]) for e in reg["contracts"].values()]


__all__ = ["DEFS", "REGISTRY_PATH", "REGISTRY_VERSION", "SchemaError", "load_registry", "registration_rows", "validate", "validate_payload"]
