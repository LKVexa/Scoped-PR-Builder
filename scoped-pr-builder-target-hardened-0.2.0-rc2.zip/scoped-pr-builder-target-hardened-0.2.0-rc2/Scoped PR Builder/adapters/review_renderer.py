"""Scoped PR Builder — human review surface rendering (SLICE-07).

Composes the run's evidence, plan, candidate diff, uncertainty, verification report and
rollback plan into ONE review bundle for the human reviewer:

  * ``review_card.json`` — Action Cards (Suite 49) shaped sections: risk, evidence,
    parameters, impact, rollback, hashes, capability contract, preconditions,
    expected effects, unified diff, review history;
  * ``review.html`` — a self-contained, script-free, deterministic rendering of that
    card for Suite 26 (Full Stack UI) / Core Studio surfaces.

Trust model: every string that originates from the repository, the donor material, the
patch, or tool output is *untrusted data*. It is HTML-escaped without exception and
never interpreted as markup or instructions. The renderer holds no authority: the
approval controls it shows are declarations of what a reviewer must supply
(hash-bound receipt, SLICE-08); the page cannot approve anything.

Build provenance: BUILD_NEW (stdlib ``html.escape`` only). The yard offered no
dependency-free Python review/diff renderer (see ``../PROVENANCE.jsonl``).
"""
from __future__ import annotations

import html
from datetime import datetime, timezone
from typing import Any, Mapping, Sequence

from . import guardrails as GR
from . import local_git_adapter as lga
from . import security as _SEC

ADAPTER_ID = "scoped_pr_builder.review_renderer"
ADAPTER_VERSION = "0.1.0"
CARD_VERSION = "scoped_pr_builder.review_card/0.1.0"


def _e(value: Any) -> str:
    return html.escape("" if value is None else str(value), quote=True)


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def build_review_card(
    binding: Mapping[str, Any],
    contract: Mapping[str, Any],
    evidence: Sequence[Mapping[str, Any]],
    authority: Mapping[str, Any],
    plan: Mapping[str, Any],
    candidate: Mapping[str, Any],
    patch: bytes,
    report: Mapping[str, Any],
    *,
    context: Any = None,
    intake: Mapping[str, Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """Assemble the Action-Cards-shaped review card; fails closed on identity mismatches."""
    ids = {contract["base_revision"], plan["base_revision"], candidate["base_revision"], report["base_revision"], binding["base_revision"]}
    if len(ids) != 1:
        raise lga.AdapterError("review.revision_mismatch", f"artifacts disagree on base_revision: {sorted(ids)}")
    scopes = {contract["scope_contract_hash"], plan["scope_contract_hash"], candidate["scope_contract_hash"], report["scope_contract_hash"]}
    if len(scopes) != 1:
        raise lga.AdapterError("review.scope_mismatch", "artifacts disagree on scope_contract_hash")
    if report["candidate_id"] != candidate["candidate_id"] or report["patch_hash"] != candidate["patch_hash"]:
        raise lga.AdapterError("review.candidate_mismatch", "verification report does not describe this candidate")
    if lga.sha256_digest(patch) != candidate["patch_hash"]:
        raise lga.AdapterError("review.patch_mismatch", "patch bytes do not match candidate.patch_hash")
    from . import verification_runner as vr
    vr.verify_report_hash(report)  # the surface must not render a verdict that was edited after verification

    checks = {j["check"]: j for j in report.get("jobs", [])}
    failed = sorted(c for c, j in checks.items() if j["verdict"] == "FAIL")
    indeterminate = sorted(c for c, j in checks.items() if j["verdict"] == "INDETERMINATE")
    examples = [e for e in evidence if e["evidence_kind"] == "analogous_example"]
    targets = [e for e in evidence if e["evidence_kind"] == "target_source"]
    blocking = report["verdict"] != "PASS" or plan["status"] != "PLANNED" or not report.get("source_tree_unchanged", False)

    card = {
        "card_version": CARD_VERSION,
        "renderer": f"{ADAPTER_ID}/{ADAPTER_VERSION}",
        "authority": "display_only",
        "identity": {
            "intent_id": contract["intent_id"],
            "scope_contract_hash": contract["scope_contract_hash"],
            "plan_id": plan["plan_id"],
            "candidate_id": candidate["candidate_id"],
            "patch_hash": candidate["patch_hash"],
            "repository_id": binding["repository_id"],
            "worktree_id": binding["worktree_id"],
            "base_revision": binding["base_revision"],
            "source_snapshot_hash": binding["source_snapshot_hash"],
            "verification_run_id": report["run_id"],
            "tenant": {"repository_id": binding["repository_id"], "worktree_id": binding["worktree_id"], "source_snapshot_hash": binding["source_snapshot_hash"]},  # SEC-04-T03
        },
        "risk_summary": {  # 49.1
            "severity": "low" if candidate["files_changed"] == 1 and candidate["lines_added"] + candidate["lines_deleted"] <= 40 else "moderate",
            "uncertainty": plan["uncertainty"],
            "blocking_risk": blocking,
            "blocking_reasons": ([f"verification verdict {report['verdict']}"] if report["verdict"] != "PASS" else []) + ([f"plan status {plan['status']}"] if plan["status"] != "PLANNED" else []),
            "mitigation": "apply only in an isolated worktree after hash-bound human approval; rollback to checkpoint",
        },
        "evidence_summary": {  # 49.2
            "completeness": "complete" if targets and examples else "partial",
            "freshness": report.get("verdict") and ("pinned@" + binding["base_revision"][:12]),
            "provenance": authority["authority_order"],
            "relation_status": authority["relation_status"],
            "target_count": len(targets),
            "example_count": len(examples),
            "gaps": [] if examples else ["no analogous examples"],
            "items": [{"path": e["canonical_path"], "kind": e["evidence_kind"], "locator": e["exact_locator"], "content_hash": e["content_hash"], "score": e["funnel"]["score"], "trust": e.get("trust")} for e in evidence],  # SEC-01-T02: trust marking travels to the surface
        },
        "parameter_summary": {  # 49.3 / 49.8
            "intent_kind": contract["intent_kind"],
            "title": _SEC.sanitize_directives(contract["title"]),  # SEC-01-T03: neutralized before display
            "description": _SEC.sanitize_directives(contract["description"]),
            "requested_by": contract["requested_by"],
            "allowed_paths": list(contract["allowed_paths"]),
            "forbidden_paths": list(contract["forbidden_paths"]),
            "max_changed_files": contract["max_changed_files"],
            "max_diff_lines": contract["max_diff_lines"],
            "recipe": candidate["recipe"],
        },
        "impact_summary": {  # 49.4 / 49.11
            "affected_paths": list(candidate["canonical_paths"]),
            "files_changed": candidate["files_changed"],
            "lines_added": candidate["lines_added"],
            "lines_deleted": candidate["lines_deleted"],
            "hunks": candidate["hunks"],
            "size_band": plan["expected_size_band_ceiling"],
            "irreversible_effects": [],
            "indirect": "none detected within declared scope; cross_reference check " + checks.get("cross_reference", {}).get("verdict", "MISSING"),
        },
        "rollback_summary": {  # 49.5 / 49.12
            "recoverable": True,
            "checkpoint_revision": plan["rollback"]["checkpoint_revision"],
            "method": plan["rollback"]["method"],
            "tested": "proof scheduled at SLICE-09 (archive + rollback demonstration)",
        },
        "hash_summary": {  # 49.6
            "source_snapshot_hash": binding["source_snapshot_hash"],
            "scope_contract_hash": contract["scope_contract_hash"],
            "plan_hash": plan["plan_hash"],
            "source_diff_hash": candidate["source_diff_hash"],
            "patch_hash": candidate["patch_hash"],
            "candidate_id": candidate["candidate_id"],
            "verification_report_hash": report["report_hash"],
        },
        "capability_contract": {  # 49.7
            "principal": "ScopedPrBuilderApplier (human-approved)",
            "capability": "patch.apply_isolated",
            "resource": "ScopedPrInertPatch",
            "effect": "apply candidate in an isolated worktree only",
            "scope": list(contract["allowed_paths"]),
            "constraints": ["approval.hash_bound == true", "approval.revision == run.base_revision", "approval.scope_hash == run.scope_contract_hash", "freshness_revalidation", "confinement_revalidation"],
            "approval": "REQUIRED — human reviewer must issue a receipt bound to candidate_id, patch_hash, base_revision and scope_contract_hash",
        },
        "preconditions": {  # 49.9
            "satisfied": sorted(c for c, j in checks.items() if j["verdict"] == "PASS"),
            "failed": failed,
            "unresolved": indeterminate,
        },
        "expected_effects": {  # 49.10
            "predicted": [f"rewrite {p} within scope" for p in candidate["canonical_paths"]],
            "ordering": [op["sequence"] for op in plan["operations"]],
            "bounds": candidate["limit_profile"],
            "forbidden": ["writes outside allowed_paths", "modification of the source worktree", "network access", "approval minting"],
        },
        "unified_diff": {  # 49.13
            "baseline_hash": binding["source_snapshot_hash"],
            "target_hash": candidate["patch_hash"],
            "read_only": True,
            "text": _SEC.protect_secrets(patch.decode("utf-8", errors="replace"), "ui"),  # SEC-06-T02: the surface shows the masked rendering
        },
        "review_history": [  # 49.14
            {"step": "SLICE-02.bind", "outcome": "bound", "ref": binding["worktree_hash"]},
            {"step": "SLICE-03.intent", "outcome": "accepted", "ref": contract["scope_contract_hash"]},
            {"step": "SLICE-04.plan", "outcome": plan["status"], "ref": plan["plan_hash"]},
            {"step": "SLICE-05.patch", "outcome": "inert_candidate", "ref": candidate["patch_hash"]},
            {"step": "SLICE-06.verify", "outcome": report["verdict"], "ref": report["report_hash"]},
            {"step": "SLICE-07.review", "outcome": "rendered_awaiting_human_decision", "ref": None},
        ],
        "approval_controls": {
            "available_decisions": ["APPROVE", "REJECT", "REQUEST_CHANGES"],
            "binds_to": ["candidate_id", "patch_hash", "base_revision", "scope_contract_hash"],
            "note": "Decisions are recorded by the approval adapter (SLICE-08); this surface cannot record or imply one.",
        },
        "verification": {"verdict": report["verdict"], "checks": {c: {"verdict": j["verdict"], "summary": j["summary"]} for c, j in checks.items()}, "sandbox_destroyed": report.get("sandbox_destroyed"), "source_tree_unchanged": report.get("source_tree_unchanged")},
    }
    # PAPER-GRD-*-T04: every paper guardrail is exposed before the state-changing action — rule, current state,
    # current values, blocking reason, what satisfies it. Display-only; hash-bound into the card; re-evaluated at apply.
    card["guardrails"] = GR.review_fragment(GR.card_decisions(GR.card_time_facts(candidate, contract, patch, context=context, plan=plan, evidence=evidence, report=report, evidence_gaps=card["evidence_summary"]["gaps"])), effect="patch.apply_isolated")
    # DATA-*-T04: intake states are shown on the card — non-admitted sources are surfaced for review, never inferred away.
    if intake is not None:
        from . import intake as _I
        card["intake"] = _I.review_fragment(intake)
    card["classification"] = _SEC.classify_output(patch.decode("utf-8", errors="replace") + "\n" + contract["title"] + "\n" + contract["description"])["classification"]  # SEC-06-T02: classified (over the raw diff) before display; the surface shows the masked rendering
    card["card_hash"] = lga.sha256_digest(lga.canonical_json(card))
    card["rendered_at"] = _now()
    return card


def _kv(rows: Sequence[tuple[str, Any]]) -> str:
    return "<table>" + "".join(f"<tr><th>{_e(k)}</th><td>{_e(v)}</td></tr>" for k, v in rows) + "</table>"


def render_html(card: Mapping[str, Any]) -> str:
    """Deterministic, script-free HTML for the review card (all values escaped); SEC-06-T02: classified + masked before display."""
    return _SEC.enforce_sec06_export("review_card.html", _render_html(card))


def _render_html(card: Mapping[str, Any]) -> str:
    ident = card["identity"]
    v = card["verification"]
    diff_lines = []
    for line in card["unified_diff"]["text"].splitlines():
        cls = "add" if line.startswith("+") and not line.startswith("+++") else "del" if line.startswith("-") and not line.startswith("---") else "hunk" if line.startswith("@@") else "meta" if line.startswith(("diff ", "---", "+++")) else "ctx"
        diff_lines.append(f'<div class="{cls}">{_e(line)}</div>')
    checks = "".join(f"<tr><td>{_e(c)}</td><td class='v-{_e(j['verdict']).lower()}'>{_e(j['verdict'])}</td><td>{_e(j['summary'])}</td></tr>" for c, j in v["checks"].items())
    evidence = "".join(f"<tr><td>{_e(i['kind'])}</td><td>{_e(i['path'])}</td><td>{_e(i['locator'])}</td><td class='mono'>{_e(i['content_hash'][7:23])}</td><td>{_e(i['score'])}</td></tr>" for i in card["evidence_summary"]["items"])
    history = "".join(f"<tr><td>{_e(h['step'])}</td><td>{_e(h['outcome'])}</td><td class='mono'>{_e((h['ref'] or '')[:30])}</td></tr>" for h in card["review_history"])
    pre = card["preconditions"]
    blocking = card["risk_summary"]["blocking_risk"]
    guard_html = GR.render_fragment_html(card["guardrails"], _e) if card.get("guardrails") else ""
    if card.get("intake"):
        from . import intake as _I
        guard_html += _I.render_fragment_html(card["intake"], _e)
    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>Scoped PR Builder — Review {_e(ident['candidate_id'][7:19])}</title>
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'">
<style>
body{{font:14px/1.45 system-ui,sans-serif;margin:0;padding:24px;color:#1b1b1b;background:#fafafa}}
h1{{font-size:20px}} h2{{font-size:16px;margin-top:28px;border-bottom:1px solid #ddd;padding-bottom:4px}}
table{{border-collapse:collapse;width:100%;margin:8px 0}} th,td{{text-align:left;vertical-align:top;padding:4px 8px;border-bottom:1px solid #eee}} th{{width:220px;color:#555;font-weight:600}}
.mono{{font-family:ui-monospace,monospace;font-size:12px}}
.banner{{padding:12px 16px;border-radius:6px;font-weight:600}} .banner.ok{{background:#e6f4ea;color:#137333}} .banner.block{{background:#fce8e6;color:#c5221f}}
.diff{{font-family:ui-monospace,monospace;font-size:12px;background:#fff;border:1px solid #ddd;padding:8px;overflow:auto;white-space:pre}}
.diff .add{{background:#e6ffec}} .diff .del{{background:#ffebe9}} .diff .hunk{{color:#6f42c1}} .diff .meta{{color:#57606a}}
.v-pass{{color:#137333;font-weight:600}} .v-fail{{color:#c5221f;font-weight:600}} .v-indeterminate{{color:#b06000;font-weight:600}}
.controls{{border:1px dashed #999;padding:12px;background:#fff}}
</style></head><body>
<h1>Scoped PR Builder — Human Review</h1>
<div class="banner {'block' if blocking else 'ok'}">{_e('BLOCKED — do not approve: ' + '; '.join(card['risk_summary']['blocking_reasons']) if blocking else 'Verification PASS — awaiting human decision (nothing has been applied)')}</div>
<h2>Identity (hash-bound)</h2>{_kv(list(ident.items()))}
<h2>Parameters (49.3 / 49.8)</h2>{_kv([(k, v2) for k, v2 in card['parameter_summary'].items()])}
<h2>Evidence (49.2)</h2>{_kv([('completeness', card['evidence_summary']['completeness']), ('provenance', card['evidence_summary']['provenance']), ('relation_status', card['evidence_summary']['relation_status']), ('gaps', ', '.join(card['evidence_summary']['gaps']) or 'none')])}
<table><tr><th>kind</th><th>path</th><th>locator</th><th>content hash</th><th>score</th></tr>{evidence}</table>
<h2>Uncertainty and risk (49.1)</h2>{_kv([('severity', card['risk_summary']['severity']), ('evidence_sufficiency', card['risk_summary']['uncertainty']['evidence_sufficiency']), ('example_count', card['risk_summary']['uncertainty']['example_count']), ('top_example_score', card['risk_summary']['uncertainty']['top_example_score']), ('blocking_risk', blocking), ('mitigation', card['risk_summary']['mitigation'])])}
<h2>Impact (49.4 / 49.11)</h2>{_kv([(k, v2) for k, v2 in card['impact_summary'].items()])}
<h2>Verification (independent, deterministic)</h2>{_kv([('verdict', v['verdict']), ('sandbox_destroyed', v['sandbox_destroyed']), ('source_tree_unchanged', v['source_tree_unchanged'])])}
<table><tr><th>check</th><th>verdict</th><th>summary</th></tr>{checks}</table>
<h2>Preconditions (49.9)</h2>{_kv([('satisfied', ', '.join(pre['satisfied'])), ('failed', ', '.join(pre['failed']) or 'none'), ('unresolved', ', '.join(pre['unresolved']) or 'none')])}
<h2>Capability contract (49.7)</h2>{_kv([(k, v2 if not isinstance(v2, list) else '; '.join(map(str, v2))) for k, v2 in card['capability_contract'].items()])}
<h2>Rollback plan (49.5 / 49.12)</h2>{_kv([(k, v2) for k, v2 in card['rollback_summary'].items()])}
<h2>Unified diff (49.13 — read-only, baseline {_e(card['unified_diff']['baseline_hash'][7:23])} → patch {_e(card['unified_diff']['target_hash'][7:23])})</h2>
<div class="diff">{''.join(diff_lines)}</div>
<h2>Hashes (49.6)</h2>{_kv([(k, v2) for k, v2 in card['hash_summary'].items()])}
<h2>Review history (49.14)</h2><table><tr><th>step</th><th>outcome</th><th>ref</th></tr>{history}</table>
{guard_html}
<h2>Approval controls</h2>
<div class="controls">Decisions: {_e(', '.join(card['approval_controls']['available_decisions']))}. A decision must be issued through the approval adapter as a receipt bound to {_e(', '.join(card['approval_controls']['binds_to']))}. {_e(card['approval_controls']['note'])}</div>
<p class="mono">card_hash {_e(card['card_hash'])} · rendered {_e(card['rendered_at'])} · {_e(card['renderer'])} · authority: {_e(card['authority'])} · classification: {_e(card.get('classification', 'unclassified'))}</p>
</body></html>
"""


__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "CARD_VERSION", "build_review_card", "render_html"]
