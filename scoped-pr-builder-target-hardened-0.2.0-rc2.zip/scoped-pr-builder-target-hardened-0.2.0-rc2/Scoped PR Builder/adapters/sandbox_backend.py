"""Sandbox backend capability discovery; never labels process isolation as container isolation."""
from __future__ import annotations
import shutil, platform
def available()->dict:
    return {'degraded_process':True,'bubblewrap':bool(shutil.which('bwrap')) and platform.system()!='Windows','docker':bool(shutil.which('docker'))}
def strongest()->str:
    a=available(); return 'bubblewrap' if a['bubblewrap'] else ('docker' if a['docker'] else 'degraded_process')
