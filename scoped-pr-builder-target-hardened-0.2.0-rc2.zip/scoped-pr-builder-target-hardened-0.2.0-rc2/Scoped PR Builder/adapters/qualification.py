"""Scoped PR Builder — test and adversarial qualification (Phase 12 / TEST-*).

``qualification/MATRIX.json`` is the overlay's test matrix (mirroring Tables/08 ``TestMatrixRow``): one named scenario per
mandatory qualification requirement — unit, integration, adversarial and end-to-end — each naming its deterministic
fixture, its harness function, the exact outcome it expects, whether it is mandatory for release, and the Tables row it
registers. ``adapters/qualification`` is the executable side: it loads and validates the matrix, pins every version a run
depends on, records each scenario run as a Filing Cabinet 12-shaped chained ledger row, asserts the exact expected outcome
(workflow state, allowed/denied effects, changed-path set, evidence/provenance closure, approval state, diagnostics,
rollback/cleanup), stores the first failure with everything a replay needs, refuses to read an indeterminate or skipped
mandatory scenario as a pass, and gates the production-readiness receipt on the offline regression run.

Build provenance: BUILD_NEW (stdlib), composing the overlay's own workflow, security, review, model and store adapters and
the Filing Cabinet 12 ledger shape. Yard candidates inspected and rejected: TestExplora (LLM test generation benchmark),
delulu (dataset + LLM judges), amplifier-bundle-routing-matrix (model routing tables, not a test matrix), axe/accessibility
tooling (node), promptflow templates (cloud).
"""
from __future__ import annotations

import json
import platform
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from . import contracts as C
from . import local_git_adapter as lga
from .archive_adapter import _chain_append, verify_chain_file

MATRIX_VERSION = "scoped_pr_builder.test_matrix/0.1.0"
MATRIX_PATH = Path(__file__).resolve().parent.parent / "qualification" / "MATRIX.json"
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
ADAPTER_ID = "scoped_pr_builder.qualification"
ADAPTER_VERSION = "0.1.0"
NS = "overlay.scoped_pr_builder.qualification"
KINDS = ("unit", "integration", "adversarial", "end_to_end")
VERDICTS = ("PASS", "FAIL", "INDETERMINATE", "SKIPPED", "BLOCKED")
PASSING = ("PASS",)
SCENARIO_REQUIRED = ("scenario_id", "kind", "title", "requirement", "fixture", "harness", "mandatory", "tables_row", "authoritative_suites", "introduced_by")
FIXTURE_NAMES = ("suite_corpus", "injection_corpus", "lonely_target", "failing_tests", "second_repository", "oversized_intent")


class QualificationRefusal(lga.AdapterError):
    """Raised by the qualification layer (matrix defect, unmet expectation, indeterminate mandatory scenario, blocked gate)."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_matrix(path: Path = MATRIX_PATH, *, registry: Mapping[str, Any] | None = None, repo_root: Path = REPO_ROOT) -> dict[str, Any]:
    """Load and validate the test matrix: every scenario names a kind, a declared fixture, a harness function, its
    mandatory flag, the Tables/08 row it registers and existing authoritative suites."""
    if not Path(path).is_file():
        raise QualificationRefusal("qualification.matrix_missing", f"test matrix not found: {path}")
    m = json.loads(Path(path).read_text(encoding="utf-8"))
    if m.get("matrix_version") != MATRIX_VERSION:
        raise QualificationRefusal("qualification.matrix_invalid", "unsupported matrix_version")
    for sid, s in (m.get("scenarios") or {}).items():
        missing = [k for k in SCENARIO_REQUIRED if k not in s]
        if missing or s["scenario_id"] != sid or not re.match(r"^TEST-(UNIT|INT|ADV|E2E)-\d{2}$", sid):
            raise QualificationRefusal("qualification.matrix_invalid", f"{sid}: missing {missing} / id")
        if s["kind"] not in KINDS:
            raise QualificationRefusal("qualification.matrix_invalid", f"{sid}: kind {s['kind']!r} is not one of {KINDS}")
        if s["fixture"] not in FIXTURE_NAMES:
            raise QualificationRefusal("qualification.matrix_invalid", f"{sid}: fixture {s['fixture']!r} is not a declared named fixture")
        if not isinstance(s["mandatory"], bool):
            raise QualificationRefusal("qualification.matrix_invalid", f"{sid}: mandatory must be a boolean")
        row = s["tables_row"]
        if not isinstance(row, Mapping) or row.get("record_schema") != "tables.test_matrices/TestMatrixRow" or not row.get("test_name") or row.get("case_id") is None:
            raise QualificationRefusal("qualification.matrix_invalid", f"{sid}: tables_row must be a TestMatrixRow with case_id and test_name")
        for f in s["authoritative_suites"]:
            if not (Path(repo_root) / f).is_file():
                raise QualificationRefusal("qualification.suite_unbound", f"{sid}: authoritative suite file does not exist: {f}")
    ids = [s["tables_row"]["case_id"] for s in (m.get("scenarios") or {}).values()]
    if len(set(ids)) != len(ids):
        raise QualificationRefusal("qualification.matrix_invalid", "Tables case_id values must be unique")
    body = {k: v for k, v in m.items() if k != "matrix_hash"}
    m["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return m


def assert_isolated(repo_root: Path, run_dir: Path) -> dict[str, Any]:
    """Isolation contract for every scenario: the run directory is outside the fixture repository, the fixture repository is
    not the tool's own repository, and both are real, distinct directories. A scenario that cannot prove this does not run."""
    repo, run = Path(repo_root).resolve(), Path(run_dir).resolve()
    if not (repo / ".git").exists():
        raise QualificationRefusal("qualification.fixture_invalid", f"{repo} is not a git fixture repository")
    if lga.path_within(run, repo):
        raise QualificationRefusal("qualification.not_isolated", "the run directory must lie outside the fixture repository")
    if lga.path_within(repo, REPO_ROOT.resolve()):
        raise QualificationRefusal("qualification.not_isolated", "a scenario never binds the tool's own repository")
    return {"repository": str(repo), "run_dir": str(run), "isolated": True}


def scenario(scenario_id: str, matrix: Mapping[str, Any] | None = None) -> dict[str, Any]:
    m = matrix or load_matrix()
    s = (m.get("scenarios") or {}).get(scenario_id)
    if s is None:
        raise QualificationRefusal("qualification.scenario_unknown", f"no such scenario {scenario_id!r}")
    return dict(s)


def mandatory_scenarios(matrix: Mapping[str, Any] | None = None) -> list[str]:
    m = matrix or load_matrix()
    return sorted(sid for sid, s in (m.get("scenarios") or {}).items() if s["mandatory"])


def tables_rows(matrix: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    """The Tables/08 test-matrix registration rows this overlay contributes (one per scenario, ordered by case_id)."""
    m = matrix or load_matrix()
    return sorted((dict(s["tables_row"], scenario_id=sid) for sid, s in (m.get("scenarios") or {}).items()), key=lambda r: r["case_id"])


__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "FIXTURE_NAMES", "KINDS", "MATRIX_PATH", "MATRIX_VERSION", "NS", "PASSING", "SCENARIO_REQUIRED", "VERDICTS", "QualificationRefusal", "assert_isolated", "load_matrix", "mandatory_scenarios", "scenario", "tables_rows"]


# --------------------------------------------------------------------------- #
# T02 — every scenario runs through Filing Cabinet 12 ledgers over isolated repository/worktree fixtures, with pinned
# tool/model/contract versions, the matrix's own seeds and timeouts, and no undeclared network
# --------------------------------------------------------------------------- #
CABINET_LEDGER = "qualification/cabinet_ledger.jsonl"
RUNTIME_REQUIRED = ("isolation", "pins", "seed", "timeout_s", "network")


def runtime_of(scenario_entry: Mapping[str, Any]) -> dict[str, Any]:
    """The declared runtime of one scenario: fixed seed, timeout and the network declaration (always ``none`` here)."""
    r = dict(scenario_entry.get("runtime") or {})
    r.setdefault("seed", 0)
    r.setdefault("timeout_s", 120)
    r.setdefault("network", "none")
    if r["network"] != "none":
        raise QualificationRefusal("qualification.network_declared", f"{scenario_entry['scenario_id']}: scenarios declare no network")
    if not isinstance(r["seed"], int) or not isinstance(r["timeout_s"], int) or r["timeout_s"] <= 0:
        raise QualificationRefusal("qualification.matrix_invalid", f"{scenario_entry['scenario_id']}: seed must be an integer and timeout_s a positive integer")
    return r


def environment_identity(pins: Mapping[str, Any]) -> dict[str, Any]:
    """The environment a replay must reproduce, as one hash over the pinned versions plus the interpreter identity."""
    body = {k: pins[k] for k in sorted(pins)}
    return {"pins": body, "environment_hash": lga.sha256_digest(lga.canonical_json(body)), "python": pins.get("python"), "platform": pins.get("platform"), "recorded_at": _now()}


def cabinet_path(run_dir: Path) -> Path:
    return Path(run_dir).resolve() / CABINET_LEDGER


def cabinet_rows(run_dir: Path) -> list[dict[str, Any]]:
    p = cabinet_path(run_dir)
    if not p.is_file():
        return []
    verify_chain_file(p)
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


def record_run(run_dir: Path, scenario_entry: Mapping[str, Any], observed: Mapping[str, Any], *, verdict: str, pins: Mapping[str, Any], runtime: Mapping[str, Any], isolation: Mapping[str, Any], started_at: str, finished_at: str) -> dict[str, Any]:
    """One chained Filing Cabinet 12 ``CabinetLedgerEntry``-shaped row per scenario run: what ran, in what world, over
    which pinned versions, with which ledgers, and what the podium verdict was."""
    if verdict not in VERDICTS:
        raise QualificationRefusal("qualification.verdict_invalid", f"{verdict!r} is not one of {VERDICTS}")
    env = environment_identity(pins)
    row = {"record_schema": "filing_cabinet.ledgers/CabinetLedgerEntry", "ledger_name": "scoped_pr_builder.qualification", "sophia_event": scenario_entry["scenario_id"],
           "charlotte_relation": scenario_entry["kind"], "landon_state": observed.get("state"), "professor_entry_hash": lga.sha256_digest(lga.canonical_json(observed)),
           "podium_certification": verdict, "recorded_at": finished_at,
           "run": {"scenario_id": scenario_entry["scenario_id"], "harness": scenario_entry["harness"], "fixture": scenario_entry["fixture"], "mandatory": bool(scenario_entry["mandatory"]),
                   "isolation": dict(isolation), "runtime": dict(runtime), "started_at": started_at, "finished_at": finished_at},
           "environment": env, "ledgers": dict(observed.get("provenance", {}).get("ledgers") or {}), "network_attempts": int(observed.get("network_attempts", 0)),
           "r12_replay_id": lga.sha256_digest(lga.canonical_json({"scenario": scenario_entry["scenario_id"], "environment_hash": env["environment_hash"], "fixture": scenario_entry["fixture"], "seed": runtime["seed"]}))}
    if row["network_attempts"]:
        raise QualificationRefusal("qualification.network_attempted", f"{scenario_entry['scenario_id']}: {row['network_attempts']} undeclared network attempt(s)")
    return _chain_append(cabinet_path(run_dir), row)


__all__ += ["CABINET_LEDGER", "RUNTIME_REQUIRED", "cabinet_path", "cabinet_rows", "environment_identity", "record_run", "runtime_of"]


# --------------------------------------------------------------------------- #
# T03 — each scenario asserts the exact outcome: workflow state, allowed/denied effects, changed-path set, evidence and
# provenance closure, approval state, diagnostics, and rollback/cleanup — never "it did not crash"
# --------------------------------------------------------------------------- #
EXPECT_KEYS = ("state", "granted_effects", "denied_codes", "changed_paths", "evidence_closure", "approval_decisions", "applied", "diagnostics", "source_tree_unchanged", "rollback", "worktrees_cleaned")


def expectation_of(scenario_entry: Mapping[str, Any]) -> dict[str, Any]:
    """The declared expectation of one scenario; every key is one of the closed set the assertion covers."""
    e = scenario_entry.get("expect")
    if not isinstance(e, Mapping) or not e:
        raise QualificationRefusal("qualification.matrix_invalid", f"{scenario_entry['scenario_id']}: an expectation is mandatory — a scenario that asserts nothing proves nothing")
    unknown = sorted(set(e) - set(EXPECT_KEYS))
    if unknown:
        raise QualificationRefusal("qualification.matrix_invalid", f"{scenario_entry['scenario_id']}: unknown expectation keys {unknown}")
    if "state" not in e:
        raise QualificationRefusal("qualification.matrix_invalid", f"{scenario_entry['scenario_id']}: the expected workflow state is mandatory")
    return dict(e)


def _cmp(kind: str, expected: Any, observed: Any) -> list[str]:
    if kind == "subset":
        missing = sorted(set(expected) - set(observed or []))
        return [f"missing {missing}"] if missing else []
    if kind == "exact_set":
        if sorted(expected) != sorted(observed or []):
            return [f"expected {sorted(expected)}, observed {sorted(observed or [])}"]
        return []
    return [] if expected == observed else [f"expected {expected!r}, observed {observed!r}"]


def assert_outcome(scenario_entry: Mapping[str, Any], observed: Mapping[str, Any]) -> dict[str, Any]:
    """Fail closed unless every declared expectation holds. Returns the per-key comparison so the receipt records what was
    asserted, not merely that something passed."""
    exp = expectation_of(scenario_entry)
    checks: dict[str, Any] = {}
    problems: list[str] = []
    pairs = {
        "state": ("equal", observed.get("state")),
        "granted_effects": ("subset", (observed.get("effects") or {}).get("granted")),
        "denied_codes": ("subset", (observed.get("effects") or {}).get("denied")),
        "changed_paths": ("exact_set", observed.get("changed_paths")),
        "approval_decisions": ("exact_set", (observed.get("approval") or {}).get("decisions")),
        "applied": ("equal", (observed.get("approval") or {}).get("applied")),
        "diagnostics": ("subset", observed.get("diagnostics")),
        "source_tree_unchanged": ("equal", observed.get("source_tree_unchanged")),
        "worktrees_cleaned": ("equal", (observed.get("rollback") or {}).get("worktrees_cleaned")),
    }
    for key, (kind, obs) in pairs.items():
        if key in exp:
            diff = _cmp(kind, exp[key], obs)
            checks[key] = {"expected": exp[key], "observed": obs, "ok": not diff}
            problems += [f"{key}: {d}" for d in diff]
    if "evidence_closure" in exp:
        ec = observed.get("evidence") or {}
        want = exp["evidence_closure"]
        seen = {k: ec.get(k) for k in want}
        ok = seen == dict(want)
        checks["evidence_closure"] = {"expected": want, "observed": seen, "ok": ok}
        if not ok:
            problems.append(f"evidence_closure: expected {want}, observed {seen}")
    if "rollback" in exp:
        rb = observed.get("rollback") or {}
        want = exp["rollback"]
        ok = all((rb.get("proof") or {}).get(k) == v if k in ("verdict", "checkpoint_verified") else (rb.get("abort") or {}).get(k) == v for k, v in want.items())
        checks["rollback"] = {"expected": want, "observed": {"proof": rb.get("proof"), "abort": rb.get("abort")}, "ok": ok}
        if not ok:
            problems.append(f"rollback: expected {want}, observed proof={rb.get('proof')} abort={rb.get('abort')}")
    # provenance closure is asserted for every scenario: every chained ledger the run wrote must still verify
    prov = observed.get("provenance") or {}
    checks["provenance_chains"] = {"expected": True, "observed": prov.get("chains_verified"), "ok": prov.get("chains_verified") is True}
    if prov.get("chains_verified") is not True:
        problems.append("provenance: a chained ledger written by this run no longer verifies")
    if problems:
        raise QualificationRefusal("qualification.expectation_unmet", f"{scenario_entry['scenario_id']}: " + "; ".join(problems[:6]))
    return {"asserted": sorted(checks), "checks": checks, "assertion_hash": lga.sha256_digest(lga.canonical_json(checks))}


__all__ += ["EXPECT_KEYS", "assert_outcome", "expectation_of"]


# --------------------------------------------------------------------------- #
# T04 — the first failure is stored with everything a replay needs (output, logs, hashes, environment identity, replay
# metadata), and an indeterminate or skipped mandatory scenario is never read as a pass
# --------------------------------------------------------------------------- #
FAILURES = "qualification/failures.jsonl"
NON_PASS_MANDATORY = ("FAIL", "INDETERMINATE", "SKIPPED", "BLOCKED")


def failures_path(run_dir: Path) -> Path:
    return Path(run_dir).resolve() / FAILURES


def failures(run_dir: Path) -> list[dict[str, Any]]:
    p = failures_path(run_dir)
    if not p.is_file():
        return []
    verify_chain_file(p)
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


def record_failure(run_dir: Path, scenario_entry: Mapping[str, Any], *, verdict: str, reason: str, observed: Mapping[str, Any] | None, pins: Mapping[str, Any], runtime: Mapping[str, Any], isolation: Mapping[str, Any], output: str = "", logs: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Store the FIRST failure of a scenario and nothing after it: the failing output and logs (masked), the observed
    outcome and its hash, every artifact hash the run produced, the environment identity, and the replay metadata
    (fixture, seed, timeout, harness, matrix hash) needed to reproduce it exactly. Later failures of the same scenario in
    the same run directory are counted, never overwritten."""
    from . import security as _SEC
    run_dir = Path(run_dir).resolve()
    sid = scenario_entry["scenario_id"]
    prior = [f for f in failures(run_dir) if f["scenario_id"] == sid]
    if prior:
        return dict(prior[0], repeat_count=len(prior) + 1, stored="first-failure kept; later failures are not overwritten")
    env = environment_identity(pins)
    obs = dict(observed or {})
    row = {"record_schema": f"{NS}/FirstFailure", "scenario_id": sid, "kind": scenario_entry["kind"], "mandatory": bool(scenario_entry["mandatory"]), "verdict": verdict,
           "reason": _SEC.protect_secrets(str(reason)[:2000], "log"), "output": _SEC.protect_secrets(str(output)[:8000], "log"),
           "logs": {k: _SEC.protect_secrets(str(v)[:4000], "log") for k, v in (logs or {}).items()},
           "observed": obs, "observed_hash": lga.sha256_digest(lga.canonical_json(obs)),
           "hashes": {"ledgers": dict((obs.get("provenance") or {}).get("ledgers") or {}), "workspace": {k: v for k, v in (obs.get("workspace") or {}).items() if k in ("tree_identity", "head", "status_hash")}},
           "environment": env,
           "replay": {"harness": scenario_entry["harness"], "fixture": scenario_entry["fixture"], "seed": runtime["seed"], "timeout_s": runtime["timeout_s"], "network": runtime["network"],
                      "isolation": dict(isolation), "matrix_hash": pins.get("matrix_hash"), "command": f"SPB_QUALIFICATION_ONLY={sid} python3 \"Scoped PR Builder/tests/test_qualification.py\"",
                      "replay_id": lga.sha256_digest(lga.canonical_json({"scenario": sid, "environment_hash": env["environment_hash"], "fixture": scenario_entry["fixture"], "seed": runtime["seed"]}))},
           "recorded_at": _now(), "writer": f"{ADAPTER_ID}/{ADAPTER_VERSION}"}
    return _chain_append(failures_path(run_dir), row)


def verdict_of(scenario_entry: Mapping[str, Any], verdict: str, *, reason: str = "") -> dict[str, Any]:
    """The verdict rule: only an executed PASS is a pass. An indeterminate, skipped or blocked MANDATORY scenario is a
    release-blocking non-pass — it is never silently promoted, and the reason travels with it."""
    if verdict not in VERDICTS:
        raise QualificationRefusal("qualification.verdict_invalid", f"{verdict!r} is not one of {VERDICTS}")
    mandatory = bool(scenario_entry["mandatory"])
    blocking = verdict in NON_PASS_MANDATORY and mandatory
    return {"scenario_id": scenario_entry["scenario_id"], "verdict": verdict, "mandatory": mandatory, "passed": verdict in PASSING,
            "release_blocking": blocking, "reason": str(reason)[:400],
            "note": "an indeterminate or skipped mandatory scenario is not a pass" if blocking and verdict != "FAIL" else ""}


def require_pass(scenario_entry: Mapping[str, Any], verdict: str, *, reason: str = "") -> dict[str, Any]:
    v = verdict_of(scenario_entry, verdict, reason=reason)
    if v["release_blocking"]:
        raise QualificationRefusal("qualification.mandatory_not_passed", f"{v['scenario_id']}: mandatory scenario is {verdict} — {reason or 'no reason recorded'}")
    return v


__all__ += ["FAILURES", "NON_PASS_MANDATORY", "failures", "failures_path", "record_failure", "require_pass", "verdict_of"]


# --------------------------------------------------------------------------- #
# T05 — every scenario is in the offline regression gate, and no production-readiness receipt can be issued until every
# mandatory scenario has a current PASS receipt on the tool's own chained evidence ledger
# --------------------------------------------------------------------------- #
EVIDENCE_KIND = "qualification_scenario"
READINESS_VERSION = "scoped_pr_builder.production_readiness/0.1.0"
WAIVER_RE = re.compile(r"skip|waive|bypass|disable|ignore|force|override", re.I)


def gate_scenario_id(scenario_id: str, matrix: Mapping[str, Any] | None = None) -> str:
    """The receipt id a scenario's evidence row carries, bound to the matrix hash so a changed matrix invalidates it."""
    m = matrix or load_matrix()
    return f"qualification:{scenario_id}@{m['computed_hash'][7:39]}"


def gate_ledger_path() -> Path:
    import os
    env = os.environ.get("SPB_QUALIFICATION_LEDGER")
    return Path(env) if env else (Path(__file__).resolve().parent.parent / "evidence" / "TEST_LEDGER.jsonl")


def _ledger(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    verify_chain_file(path)
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]


def offline_gate(*, ledger: Path | None = None, matrix: Mapping[str, Any] | None = None, inputs: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """The offline regression gate: for every MANDATORY scenario the tool's own chained evidence ledger must hold a PASS
    ``qualification_scenario`` receipt bound to the current matrix hash. Missing, stale, failed or indeterminate blocks;
    waiver-shaped inputs block by name — the component under evaluation cannot excuse itself from the matrix."""
    m = matrix or load_matrix()
    rows = _ledger(Path(ledger) if ledger is not None else gate_ledger_path())
    per: dict[str, Any] = {}
    for sid in sorted(m["scenarios"]):
        s = m["scenarios"][sid]
        want = gate_scenario_id(sid, m)
        mine = [r for r in rows if r.get("kind") == EVIDENCE_KIND and r.get("scenario_id", "").startswith(f"qualification:{sid}@")]
        current = [r for r in mine if r.get("scenario_id") == want]
        if not mine:
            status = "missing"
        elif not current:
            status = "stale"
        elif any(r.get("verdict") == "FAIL" for r in current):
            status = "failed"
        elif all(r.get("verdict") == "PASS" for r in current):
            status = "satisfied"
        else:
            status = "indeterminate"
        per[sid] = {"status": status, "mandatory": bool(s["mandatory"]), "kind": s["kind"], "receipts": len(current)}
    waivers = sorted(k for k in (inputs or {}) if WAIVER_RE.search(str(k)) or WAIVER_RE.search(str((inputs or {}).get(k))))
    blocking = sorted(sid for sid, v in per.items() if v["mandatory"] and v["status"] != "satisfied")
    decision = {"decision": "PROCEED" if not blocking and not waivers else "BLOCK", "gate": "offline_qualification", "matrix_hash": m["computed_hash"],
                "per_scenario": per, "blocking": blocking + (["WAIVER"] if waivers else []), "waivers_refused": waivers,
                "mandatory": mandatory_scenarios(m), "evaluated_at": _now()}
    return decision


def production_readiness_receipt(*, ledger: Path | None = None, matrix: Mapping[str, Any] | None = None, inputs: Mapping[str, Any] | None = None, pins: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """The production-readiness receipt exists only when the offline gate PROCEEDs. There is no path that issues one over a
    blocked gate: the refusal is raised, and no receipt object is returned."""
    decision = offline_gate(ledger=ledger, matrix=matrix, inputs=inputs)
    if decision["decision"] != "PROCEED":
        raise QualificationRefusal("qualification.readiness_blocked", f"production readiness blocked by {decision['blocking']}")
    body = {"record_schema": f"{NS}/ProductionReadinessReceipt", "readiness_version": READINESS_VERSION, "gate": decision["gate"], "matrix_hash": decision["matrix_hash"],
            "mandatory_scenarios": decision["mandatory"], "per_scenario": {sid: v["status"] for sid, v in decision["per_scenario"].items()},
            "environment": environment_identity(pins) if pins else None, "authority": "evidence_only — this receipt states that the offline qualification gate passed; it approves nothing",
            "issued_at": _now(), "writer": f"{ADAPTER_ID}/{ADAPTER_VERSION}"}
    body["receipt_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return body


def require_offline_gate(*, stage: str, ledger: Path | None = None, matrix: Mapping[str, Any] | None = None, inputs: Mapping[str, Any] | None = None) -> dict[str, Any]:
    d = offline_gate(ledger=ledger, matrix=matrix, inputs=inputs)
    if d["decision"] != "PROCEED":
        raise QualificationRefusal("qualification.offline_gate_blocked", f"{stage}: offline qualification gate blocked by {d['blocking']}")
    return d


__all__ += ["EVIDENCE_KIND", "READINESS_VERSION", "gate_ledger_path", "gate_scenario_id", "offline_gate", "production_readiness_receipt", "require_offline_gate"]
