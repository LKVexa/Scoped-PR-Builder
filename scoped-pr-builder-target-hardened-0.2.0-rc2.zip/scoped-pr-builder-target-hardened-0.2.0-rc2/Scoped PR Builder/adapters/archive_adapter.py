"""Scoped PR Builder — archival of state/provenance/audit receipts and rollback proof (SLICE-09).

``archive_run`` freezes every artifact of a run into a content-addressed bundle:
  * ``MANIFEST.json``        — one entry per artifact (step, path, sha256, bytes);
  * ``run-state.jsonl``      — hash-chained, append-only run-state transitions using the
                               vocabulary declared in ``scoped_pr_builder_contract.jad``;
  * ``provenance.json``      — output → input lineage (candidate ← plan ← evidence ← binding;
                               applied ← receipt ← card ← report ← candidate);
  * ``audit.jsonl``          — privileged effects (approval issuance, isolated apply,
                               rollback) with actor/channel/hashes;
  * ``run-<id>.tar.gz``      — the bytes, plus ``.sha256``.
Shapes follow Filing Cabinet (12: artifacts/manifests/ledgers/rollback records),
Archive Ledger (29.4 manifests, 29.5 provenance, 29.6 hashes) and Observer (01).

``prove_rollback`` executes the declared rollback method — discard the isolated
worktree and re-verify the checkpoint — and records a ``RollbackRecord``-shaped
proof with before/after identities. A rollback that leaves any trace (worktree
present, source tree changed, HEAD moved) is recorded as FAIL, never PASS.

Build provenance: BUILD_NEW (stdlib hashlib/tarfile/json); no yard donor
(see ``../PROVENANCE.jsonl``).
"""
from __future__ import annotations

import hashlib
import json
import tarfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from . import local_git_adapter as lga

ADAPTER_ID = "scoped_pr_builder.archive_adapter"
ADAPTER_VERSION = "0.1.0"
RUN_STATES = ("INTAKE", "BOUND", "INTENT_ACCEPTED", "PLANNED", "PATCH_INERT", "VERIFIED", "REVIEW_PENDING", "APPROVED", "APPLIED_ISOLATED", "ARCHIVED", "ROLLED_BACK", "BLOCKED", "ABSTAINED", "CANCELLED")
STEP_ARTIFACTS = (
    ("SLICE-02.bind", "suite40", "BOUND"),
    ("SLICE-03.intent", "intent", "INTENT_ACCEPTED"),
    ("SLICE-04.plan", "suite51", "PLANNED"),
    ("SLICE-04.plan", "plan", "PLANNED"),
    ("SLICE-05.patch", "candidate", "PATCH_INERT"),
    ("SLICE-06.verify", "verification", "VERIFIED"),
    ("SLICE-07.review", "review", "REVIEW_PENDING"),
    ("SLICE-08.approve", "approvals", "APPROVED"),
    ("SLICE-08.apply", "applied", "APPLIED_ISOLATED"),
)


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return "sha256:" + h.hexdigest()


def _load(run_dir: Path, rel: str) -> dict[str, Any]:
    p = run_dir / rel
    if not p.is_file():
        raise lga.AdapterError("archive.artifact_missing", f"required artifact missing: {rel}")
    return json.loads(p.read_text(encoding="utf-8"))


def _chain_append(path: Path, entry: dict[str, Any]) -> dict[str, Any]:
    prev = "genesis"
    if path.is_file():
        lines = [l for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
        if lines:
            prev = json.loads(lines[-1])["entry_hash"]
    entry = dict(entry, prev_hash=prev)
    entry["entry_hash"] = lga.sha256_digest(lga.canonical_json(entry))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(lga.canonical_json(entry) + "\n")
    return entry


def verify_chain_file(path: Path) -> int:
    """Return the entry count if the chain links and hashes; fail closed otherwise."""
    if not path.is_file():
        return 0
    prev = "genesis"
    n = 0
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        e = json.loads(line)
        if e.get("prev_hash") != prev:
            raise lga.AdapterError("archive.chain_broken", f"{path.name}: entry {n} does not link")
        body = {k: v for k, v in e.items() if k != "entry_hash"}
        if lga.sha256_digest(lga.canonical_json(body)) != e.get("entry_hash"):
            raise lga.AdapterError("archive.chain_tampered", f"{path.name}: entry {n} hash mismatch")
        prev = e["entry_hash"]
        n += 1
    return n


def _verify_applied_record(applied: Mapping[str, Any], *, binding: Mapping[str, Any] | None = None, contract: Mapping[str, Any] | None = None, candidate: Mapping[str, Any] | None = None) -> None:
    """Validate the content-addressed applied record before trusting any field in it."""
    if not isinstance(applied, Mapping) or not applied.get("record_hash"):
        raise lga.AdapterError("applied.record_invalid", "applied record is missing record_hash")
    body = {k: v for k, v in applied.items() if k != "record_hash"}
    if lga.sha256_digest(lga.canonical_json(body)) != applied.get("record_hash"):
        raise lga.AdapterError("applied.record_tampered", "applied record content does not match record_hash")
    checks = []
    if binding is not None:
        checks += [("base_revision", binding.get("base_revision"))]
    if contract is not None:
        checks += [("scope_contract_hash", contract.get("scope_contract_hash"))]
    if candidate is not None:
        checks += [("candidate_id", candidate.get("candidate_id")), ("patch_hash", candidate.get("patch_hash"))]
    for field, expected in checks:
        if applied.get(field) != expected:
            raise lga.AdapterError("applied.record_mismatch", f"applied record {field} does not match the bound run")
    if applied.get("source_tree_unchanged") is not True:
        raise lga.AdapterError("applied.record_invalid", "applied record does not prove the source tree remained unchanged")


def archive_run(run_dir: Path) -> dict[str, Any]:
    """Freeze all run artifacts into a content-addressed archive with chained state/audit ledgers."""
    run_dir = Path(run_dir).resolve()
    from . import security as _SEC
    _SEC.assert_audit_intact(run_dir, include_archive=False)  # SEC-08-T02: every input chain re-verified before the archive is frozen (its own chains are regenerated)
    binding = _load(run_dir, "suite40/binding.json")
    contract = _load(run_dir, "intent/scope_contract.json")
    plan = _load(run_dir, "plan/refactoring_plan.json")
    candidate = _load(run_dir, "candidate/candidate.json")
    report = _load(run_dir, "verification/report.json")
    card = _load(run_dir, "review/review_card.json")
    applied = _load(run_dir, "applied/applied.json")
    _verify_applied_record(applied, binding=binding, contract=contract, candidate=candidate)
    approval_path = run_dir / "approvals" / "ledger.jsonl"
    if not approval_path.is_file():
        raise lga.AdapterError("archive.artifact_missing", "required artifact missing: approvals/ledger.jsonl")
    approvals = [json.loads(l) for l in approval_path.read_text(encoding="utf-8").splitlines() if l.strip()]
    if not approvals:
        raise lga.AdapterError("archive.artifact_missing", "approvals/ledger.jsonl is empty")
    applied_receipt = next((r for r in approvals if r.get("receipt_hash") == applied.get("receipt_hash")), None)
    if applied_receipt is None:
        raise lga.AdapterError("archive.approval_missing", "the receipt that authorized the application is not present in approvals/ledger.jsonl")
    if applied_receipt.get("decision") != "APPROVE":
        raise lga.AdapterError("archive.approval_invalid", "the receipt recorded on the application is not an APPROVE decision")
    run_id = lga.sha256_digest(lga.canonical_json({"candidate": candidate["candidate_id"], "receipt": applied["receipt_hash"], "applied": applied["record_hash"]}))
    out = run_dir / "archive"
    out.mkdir(parents=True, exist_ok=True)

    # --- manifest --------------------------------------------------------------------
    entries = []
    for step, folder, _state in STEP_ARTIFACTS:
        base = run_dir / folder
        if not base.is_dir():
            raise lga.AdapterError("archive.artifact_missing", f"required step folder missing: {folder}")
        for p in sorted(base.rglob("*")):
            if p.is_file():
                entries.append({"step": step, "path": p.relative_to(run_dir).as_posix(), "sha256": _sha(p), "bytes": p.stat().st_size})
    from . import security as _SEC  # SEC-06-T02: the export boundary classifies every text artifact; restricted content never leaves
    for e in entries:
        p = run_dir / e["path"]
        if e["bytes"] <= 2_000_000 and p.suffix in (".json", ".jsonl", ".txt", ".md", ".patch", ".html", ".py", ".log", ".key"):
            c = _SEC.classify_output(p.read_text(encoding="utf-8", errors="replace"))
            e["classification"] = c["classification"]
            if c["classification"] == "restricted":
                _SEC.deny("SEC-06", "security.sec06.unclassified_export", f"{e['path']}: restricted (secret-shaped) content cannot be exported", subject={"artifact": e["path"], "sha256": e["sha256"]}, run_dir=run_dir)
        else:
            e["classification"] = "binary/unclassified"
    manifest = {
        "record_schema": "suite29.archive_ledger.manifests/ArchiveManifest",
        "adapter": f"{ADAPTER_ID}/{ADAPTER_VERSION}",
        "run_id": run_id,
        "candidate_id": candidate["candidate_id"],
        "base_revision": binding["base_revision"],
        "source_snapshot_hash": binding["source_snapshot_hash"],
        "post_apply_tree": applied["post_apply_tree"],
        "artifact_count": len(entries),
        "artifacts": entries,
    }
    manifest["manifest_hash"] = lga.sha256_digest(lga.canonical_json(manifest))
    manifest["archived_at"] = _now()
    (out / "MANIFEST.json").write_text(lga.canonical_json(manifest) + "\n", encoding="utf-8")

    # --- run-state chain ---------------------------------------------------------------
    state_path = out / "run-state.jsonl"
    if state_path.exists():
        state_path.unlink()
    refs = {"BOUND": binding["worktree_hash"], "INTENT_ACCEPTED": contract["scope_contract_hash"], "PLANNED": plan["plan_hash"], "PATCH_INERT": candidate["patch_hash"],
            "VERIFIED": report["report_hash"], "REVIEW_PENDING": card["card_hash"], "APPROVED": applied_receipt["receipt_hash"], "APPLIED_ISOLATED": applied["record_hash"]}
    for state in ("INTAKE", "BOUND", "INTENT_ACCEPTED", "PLANNED", "PATCH_INERT", "VERIFIED", "REVIEW_PENDING", "APPROVED", "APPLIED_ISOLATED", "ARCHIVED"):
        assert state in RUN_STATES
        _chain_append(state_path, {"record_schema": "overlay.scoped_pr_builder.state/ScopedPrRunContractRecord.run_state", "run_id": run_id, "run_state": state,
                                   "evidence_ref": refs.get(state, manifest["manifest_hash"] if state == "ARCHIVED" else None), "at": _now()})

    # --- provenance ------------------------------------------------------------------
    provenance = {
        "record_schema": "suite29.archive_ledger.provenance/ProvenanceLedgerRecord",
        "run_id": run_id,
        "links": [
            {"output": "binding", "hash": binding["worktree_hash"], "inputs": [{"repository_id": binding["repository_id"]}, {"base_revision": binding["base_revision"]}, {"source_snapshot_hash": binding["source_snapshot_hash"]}]},
            {"output": "scope_contract", "hash": contract["scope_contract_hash"], "inputs": [{"binding": binding["worktree_hash"]}, {"intent_id": contract["intent_id"]}]},
            {"output": "plan", "hash": plan["plan_hash"], "inputs": [{"scope_contract": contract["scope_contract_hash"]}, {"retrieval_id": plan["retrieval_id"]}] + [{"evidence": e["evidence_id"], "content_hash": e["content_hash"]} for e in plan["evidence_refs"]]},
            {"output": "candidate", "hash": candidate["candidate_id"], "inputs": [{"plan": plan["plan_hash"]}, {"patch_hash": candidate["patch_hash"]}, {"recipe": candidate["recipe"]}]},
            {"output": "verification_report", "hash": report["report_hash"], "inputs": [{"candidate": candidate["candidate_id"]}] + [{"job": j["job_id"], "check": j["check"], "verdict": j["verdict"]} for j in report["jobs"]]},
            {"output": "review_card", "hash": card["card_hash"], "inputs": [{"candidate": candidate["candidate_id"]}, {"verification_report": report["report_hash"]}]},
            {"output": "approval_receipt", "hash": applied_receipt["receipt_hash"], "inputs": [{"card": card["card_hash"]}, {"report": report["report_hash"]}, {"candidate": candidate["candidate_id"]}, {"approver": applied_receipt["approver_identity"]}]},
            {"output": "applied", "hash": applied["record_hash"], "inputs": [{"receipt": applied["receipt_hash"]}, {"candidate": candidate["candidate_id"]}, {"post_apply_tree": applied["post_apply_tree"]}]},
        ],
        "tool_versions": {"binding_adapter": f"{binding['adapter_id']}/{binding['adapter_version']}", "verification": report["adapter_id"] + "/" + report["adapter_version"], "archive": f"{ADAPTER_ID}/{ADAPTER_VERSION}"},
        "model_version": contract.get("model_version"),
    }
    provenance["provenance_hash"] = lga.sha256_digest(lga.canonical_json(provenance))
    (out / "provenance.json").write_text(lga.canonical_json(provenance) + "\n", encoding="utf-8")

    # --- audit (privileged effects) -------------------------------------------------------
    audit_path = out / "audit.jsonl"
    if audit_path.exists():
        audit_path.unlink()
    for r in approvals:
        _chain_append(audit_path, {"record_schema": "suite01.observer.runtime_events/PrivilegedEffect", "run_id": run_id, "effect": "approval.issue", "decision": r["decision"],
                                   "actor": _SEC.public_view(r)["approver"], "channel": r["approver_channel"], "receipt_hash": r["receipt_hash"], "at": r["issued_at"]})  # SEC-07-T03: audit rows carry the public view
    _chain_append(audit_path, {"record_schema": "suite01.observer.runtime_events/PrivilegedEffect", "run_id": run_id, "effect": "patch.apply_isolated", "actor": f"{applied['adapter_id']}/{applied['adapter_version']}",
                               "authorized_by": applied["receipt_hash"], "worktree": applied["applied_worktree"], "post_apply_tree": applied["post_apply_tree"], "at": applied["applied_at"]})

    # --- tarball -------------------------------------------------------------------------
    tar_path = out / f"run-{run_id[7:23]}.tar.gz"
    with tarfile.open(tar_path, "w:gz") as tar:
        for e in entries:
            tar.add(run_dir / e["path"], arcname=e["path"])
        for name in ("MANIFEST.json", "run-state.jsonl", "provenance.json", "audit.jsonl"):
            tar.add(out / name, arcname=f"archive/{name}")
    tar_hash = _sha(tar_path)
    (out / (tar_path.name + ".sha256")).write_text(f"{tar_hash[7:]}  {tar_path.name}\n", encoding="utf-8")
    return {"run_id": run_id, "manifest_hash": manifest["manifest_hash"], "provenance_hash": provenance["provenance_hash"], "artifact_count": len(entries),
            "run_state_entries": verify_chain_file(state_path), "audit_entries": verify_chain_file(audit_path), "archive_tarball": tar_path.name, "archive_tarball_sha256": tar_hash}


def prove_rollback(run_dir: Path, binding: lga.RepositoryBinding) -> dict[str, Any]:
    """Execute the declared rollback (discard the isolated worktree) and prove the checkpoint is intact."""
    run_dir = Path(run_dir).resolve()
    applied = _load(run_dir, "applied/applied.json")
    _verify_applied_record(applied, binding={"base_revision": binding.base_revision})
    root = lga.canonical_root(Path(binding.root_path))
    wt = Path(applied["applied_worktree"]).resolve()
    worktree_parent = (run_dir / "applied-worktrees").resolve()
    if not lga.path_within(wt, worktree_parent):
        raise lga.AdapterError("rollback.worktree_outside_run", f"applied worktree is outside the run's applied-worktrees directory: {wt}")
    linked_before = [Path(l[len("worktree "):]).resolve() for l in lga.git(root, "worktree", "list", "--porcelain").splitlines() if l.startswith("worktree ")]
    before = {
        "worktree_present": wt.exists(),
        "source_tree_identity": lga.tree_identity(root, binding.base_revision),
        "head": lga.git(root, "rev-parse", "HEAD"),
        "post_apply_tree": applied["post_apply_tree"],
        "linked_worktrees": [str(p) for p in linked_before if p != root],
    }
    if not before["worktree_present"]:
        raise lga.AdapterError("rollback.nothing_to_roll_back", "applied worktree is not present")
    # execute the rollback method declared in the plan
    lga.worktree_remove(root, wt)
    linked_after = [Path(l[len("worktree "):]).resolve() for l in lga.git(root, "worktree", "list", "--porcelain").splitlines() if l.startswith("worktree ")]
    after = {
        "worktree_present": wt.exists(),
        "source_tree_identity": lga.tree_identity(root, binding.base_revision),
        "head": lga.git(root, "rev-parse", "HEAD"),
        "status_clean": lga.git(root, "status", "--porcelain", "--untracked-files=all") == "",
        "linked_worktrees": [str(p) for p in linked_after if p != root],
    }
    expected_linked = sorted(str(p) for p in linked_before if p not in (root, wt))
    ok = (not after["worktree_present"] and after["source_tree_identity"] == binding.source_snapshot_hash and after["head"] == binding.current_revision
          and after["status_clean"] and sorted(after["linked_worktrees"]) == expected_linked)
    record = {
        "record_schema": "suite12.filing_cabinet.artifacts/RollbackRecord",
        "artifact_id": applied["candidate_id"],
        "from_version": applied["post_apply_tree"],
        "to_version": binding.source_snapshot_hash,
        "sophia_reason": "pilot rollback proof: discard isolated worktree and restore checkpoint",
        "landon_restore_pointer": f"{binding.base_revision}@{binding.root_path}",
        "professor_evidence_hash": lga.sha256_digest(lga.canonical_json({"before": before, "after": after})),
        "podium_approval": applied["receipt_hash"],
        "before": before,
        "after": after,
        "verdict": "PASS" if ok else "FAIL",
    }
    record["rollback_id"] = lga.sha256_digest(lga.canonical_json(record))
    record["recorded_at"] = _now()
    out = run_dir / "archive"
    out.mkdir(parents=True, exist_ok=True)
    (out / "rollback.json").write_text(lga.canonical_json(record) + "\n", encoding="utf-8")
    _chain_append(out / "run-state.jsonl", {"record_schema": "overlay.scoped_pr_builder.state/ScopedPrRunContractRecord.run_state", "run_id": _load(run_dir, "archive/MANIFEST.json")["run_id"],
                                            "run_state": "ROLLED_BACK" if ok else "BLOCKED", "evidence_ref": record["rollback_id"], "at": _now()})
    _chain_append(out / "audit.jsonl", {"record_schema": "suite01.observer.runtime_events/PrivilegedEffect", "run_id": _load(run_dir, "archive/MANIFEST.json")["run_id"], "effect": "rollback.execute",
                                        "actor": f"{ADAPTER_ID}/{ADAPTER_VERSION}", "authorized_by": applied["receipt_hash"], "verdict": record["verdict"], "at": _now()})
    return record


__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "RUN_STATES", "archive_run", "prove_rollback", "verify_chain_file"]
