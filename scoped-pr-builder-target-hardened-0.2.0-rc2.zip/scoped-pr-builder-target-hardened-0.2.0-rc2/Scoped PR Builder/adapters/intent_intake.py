"""Scoped PR Builder — refactor-intent intake and scope contract (SLICE-03).

Accepts ONE narrow refactor intent and turns it into an immutable, hash-bound
``ScopeContract`` that every later step must carry and revalidate. Intake is
strict and fails closed: unknown fields, non-canonical paths, empty scope, paths
absent from the pinned tree, thresholds outside the hard caps, or a binding that
does not match the intent are all rejected with a stable ``AdapterError`` code.

Authority: scope/authority semantics remain owned by Suite 50.6 (repository
confinement), Suite 13 (Chair), and the overlay policy; this module only encodes
them into a contract record shaped after ``ScopedPrRunContractRecord``
(``scoped_pr_builder_contract.jad``).

Diff-size threshold semantics (added + deleted lines, include/exclude path filters,
labelled size bands) follow the PullRequestQuantifier ``prquantifier.yaml`` model as a
PATTERN_ONLY reference (MIT; no code copied — see ``../PROVENANCE.jsonl``).
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

from . import local_git_adapter as lga
from . import security as _SEC
from . import hard_limits as _HL

CONTRACT_VERSION = "scoped_pr_builder.scope_contract/0.1.0"
INTENT_KINDS = ("tech_debt_refactor",)
# Hard caps come from CAP-01/GRD-01; an intent may narrow them but never widen them.
_HARD = _HL.hard_caps()
HARD_MAX_CHANGED_FILES = _HARD["max_changed_files"]
HARD_MAX_DIFF_LINES = _HARD["max_diff_lines"]
HARD_MAX_ALLOWED_PATHS = 32
MAX_TITLE_CHARS = 120
MAX_DESCRIPTION_CHARS = 2000
REQUIRED_FIELDS = ("kind", "title", "description", "allowed_paths", "max_changed_files", "max_diff_lines", "requested_by")
OPTIONAL_FIELDS = ("forbidden_paths", "repository_id", "base_revision", "source_snapshot_hash")
SIZE_BANDS = ((10, "extra_small"), (40, "small"), (100, "medium"), (400, "large"))


@dataclass(frozen=True)
class ScopeContract:
    """Immutable, hash-bound scope contract for one run (fields mirror the overlay .jad)."""

    contract_version: str
    intent_id: str
    intent_kind: str
    title: str
    description: str
    requested_by: str
    repository_id: str
    worktree_id: str
    base_revision: str
    source_snapshot_hash: str
    allowed_paths: tuple[str, ...]
    forbidden_paths: tuple[str, ...]
    allowed_paths_digest: str
    forbidden_paths_digest: str
    max_changed_files: int
    max_diff_lines: int
    size_band_ceiling: str
    scope_contract_hash: str
    created_at: str

    def to_json(self) -> str:
        return lga.canonical_json(asdict(self))


def _require_str(payload: Mapping[str, Any], key: str, limit: int) -> str:
    value = payload.get(key)
    if not isinstance(value, str) or not value.strip():
        raise lga.AdapterError("intent.field_invalid", f"{key} must be a non-empty string")
    if len(value) > limit:
        raise lga.AdapterError("intent.field_too_long", f"{key} exceeds {limit} characters")
    if "\x00" in value:
        raise lga.AdapterError("intent.field_invalid", f"{key} contains NUL")
    return value.strip()


def _require_int(payload: Mapping[str, Any], key: str, hard_cap: int) -> int:
    value = payload.get(key)
    if isinstance(value, bool) or not isinstance(value, int):
        raise lga.AdapterError("intent.threshold_invalid", f"{key} must be an integer")
    if value <= 0:
        raise lga.AdapterError("intent.threshold_invalid", f"{key} must be positive")
    if value > hard_cap:
        raise lga.AdapterError("intent.threshold_exceeds_cap", f"{key}={value} exceeds hard cap {hard_cap}")
    return value


def _paths(payload: Mapping[str, Any], key: str, *, allow_empty: bool) -> tuple[PurePosixPath, ...]:
    raw = payload.get(key, [] if allow_empty else None)
    if raw is None or not isinstance(raw, list) or any(not isinstance(p, str) for p in raw):
        raise lga.AdapterError("intent.paths_invalid", f"{key} must be a list of strings")
    if len(raw) > HARD_MAX_ALLOWED_PATHS:
        raise lga.AdapterError("intent.paths_too_many", f"{key} lists more than {HARD_MAX_ALLOWED_PATHS} entries")
    _SEC.validate_paths(raw, label=key)  # SEC-02-T02: injection-shaped paths refused with a trail row (stable code kept)
    roots = lga.validated_roots(raw, key, allow_empty=allow_empty)
    if len(set(roots)) != len(roots):
        raise lga.AdapterError("intent.paths_duplicate", f"{key} contains duplicates")
    return roots


def size_band(added_plus_deleted: int) -> str:
    for ceiling, label in SIZE_BANDS:
        if added_plus_deleted <= ceiling:
            return label
    return "extra_large"


def accept_intent(payload: Mapping[str, Any], binding: lga.RepositoryBinding) -> ScopeContract:
    """Validate one refactor intent against a pinned binding and mint its scope contract."""
    if not isinstance(payload, Mapping):
        raise lga.AdapterError("intent.malformed", "intent must be a JSON object")
    unknown = sorted(set(payload) - set(REQUIRED_FIELDS) - set(OPTIONAL_FIELDS))
    if unknown:
        raise lga.AdapterError("intent.unknown_fields", f"unknown fields rejected: {', '.join(unknown)}")
    missing = [k for k in REQUIRED_FIELDS if k not in payload]
    if missing:
        raise lga.AdapterError("intent.missing_fields", f"missing required fields: {', '.join(missing)}")
    kind = _require_str(payload, "kind", 64)
    if kind not in INTENT_KINDS:
        raise lga.AdapterError("intent.kind_unsupported", f"unsupported intent kind {kind!r}")
    title = _require_str(payload, "title", MAX_TITLE_CHARS)
    description = _require_str(payload, "description", MAX_DESCRIPTION_CHARS)
    requested_by = _require_str(payload, "requested_by", 200)
    max_files = _require_int(payload, "max_changed_files", HARD_MAX_CHANGED_FILES)
    max_lines = _require_int(payload, "max_diff_lines", HARD_MAX_DIFF_LINES)
    allowed = _paths(payload, "allowed_paths", allow_empty=False)
    forbidden = _paths(payload, "forbidden_paths", allow_empty=True)

    # The intent may pin identities; if it does they must match the live binding exactly.
    for key, actual in (("repository_id", binding.repository_id), ("base_revision", binding.base_revision), ("source_snapshot_hash", binding.source_snapshot_hash)):
        if key in payload and payload[key] != actual:
            raise lga.AdapterError("intent.binding_mismatch", f"{key} in intent does not match the bound repository")

    # Every allowed root must exist in the pinned tree (file or directory prefix).
    root = Path(binding.root_path)
    tree = lga.git_bytes(root, "ls-tree", "-r", "--name-only", "-z", binding.base_revision).decode("utf-8").split("\0")
    tree_paths = [PurePosixPath(p) for p in tree if p]
    for a in allowed:
        if not any(p == a or a in p.parents for p in tree_paths):
            raise lga.AdapterError("intent.path_not_in_tree", f"allowed path {a} does not exist at {binding.base_revision[:12]}")
    # Forbidden paths must not swallow the whole allowed scope.
    if all(lga.within(a, forbidden) for a in allowed):
        raise lga.AdapterError("intent.scope_empty_after_forbidden", "forbidden_paths cover every allowed path")
    # Allowed paths may not include the overlay's own audit/provenance files.
    guarded = (PurePosixPath("Scoped PR Builder/PROVENANCE.jsonl"), PurePosixPath("Scoped PR Builder/THIRD-PARTY-NOTICES.md"))
    for a in allowed:
        if any(g == a or a in g.parents for g in guarded):
            raise lga.AdapterError("intent.scope_covers_audit_ledger", f"allowed path {a} would expose the provenance/audit ledger to modification")

    allowed_s = tuple(p.as_posix() for p in allowed)
    forbidden_s = tuple(p.as_posix() for p in forbidden)
    created_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    intent_id = lga.sha256_digest(lga.canonical_json({
        "kind": kind, "title": title, "description": description, "requested_by": requested_by,
        "allowed": allowed_s, "forbidden": forbidden_s, "max_files": max_files, "max_lines": max_lines,
        "repository_id": binding.repository_id, "base_revision": binding.base_revision,
    }))
    body = {
        "contract_version": CONTRACT_VERSION,
        "intent_id": intent_id,
        "intent_kind": kind,
        "title": title,
        "description": description,
        "requested_by": requested_by,
        "repository_id": binding.repository_id,
        "worktree_id": binding.worktree_id,
        "base_revision": binding.base_revision,
        "source_snapshot_hash": binding.source_snapshot_hash,
        "allowed_paths": allowed_s,
        "forbidden_paths": forbidden_s,
        "allowed_paths_digest": lga.sha256_digest(lga.canonical_json(allowed_s)),
        "forbidden_paths_digest": lga.sha256_digest(lga.canonical_json(forbidden_s)),
        "max_changed_files": max_files,
        "max_diff_lines": max_lines,
        "size_band_ceiling": size_band(max_lines),
    }
    scope_hash = lga.sha256_digest(lga.canonical_json(body))
    contract = ScopeContract(**body, scope_contract_hash=scope_hash, created_at=created_at)
    # PAPER-CAP-01-T03: effect boundary — an accepted intent must satisfy the explicit-scope capability before anything proceeds.
    from . import guardrails as GR
    GR.enforce("evidence.retrieve", {"CAP-01": GR.facts_scope_intent(asdict(contract))}, rule_ids=["CAP-01"])
    return contract


def verify_contract_hash(contract: Mapping[str, Any]) -> None:
    """Fail closed if a stored contract's hash does not match its content (tamper check)."""
    body = {k: v for k, v in contract.items() if k not in ("scope_contract_hash", "created_at")}
    body["allowed_paths"] = tuple(body["allowed_paths"])
    body["forbidden_paths"] = tuple(body["forbidden_paths"])
    if lga.sha256_digest(lga.canonical_json(body)) != contract.get("scope_contract_hash"):
        raise lga.AdapterError("contract.tampered", "scope_contract_hash does not match contract content")


__all__ = ["CONTRACT_VERSION", "HARD_MAX_CHANGED_FILES", "HARD_MAX_DIFF_LINES", "ScopeContract", "accept_intent", "size_band", "verify_contract_hash"]
