"""Conservative Python import/test-impact graph; unknown dynamic edges stay explicit."""
from __future__ import annotations
import ast
from pathlib import Path
def build_python(root:Path)->dict:
    nodes={}; edges=[]; unknown=[]
    for p in sorted(root.rglob('*.py')):
        if '.git' in p.parts: continue
        rel=p.relative_to(root).as_posix(); nodes[rel]={'test':p.name.startswith('test_') or 'tests' in p.parts}
        try: t=ast.parse(p.read_text(encoding='utf-8'))
        except Exception: unknown.append(rel); continue
        for n in ast.walk(t):
            if isinstance(n,ast.Import):
                for a in n.names: edges.append({'from':rel,'import':a.name})
            elif isinstance(n,ast.ImportFrom): edges.append({'from':rel,'import':('.'*n.level)+(n.module or '')})
            elif isinstance(n,ast.Call) and isinstance(n.func,(ast.Attribute,ast.Subscript)): pass
    return {'nodes':nodes,'imports':edges,'unknown':unknown}
