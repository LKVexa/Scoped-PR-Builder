"""Scoped PR Builder — authorized data intake (Phase 04 / DATA-01..07).

``intake/SOURCES.json`` declares one authorized intake contract per evidence source: source identity (how the
source is identified and bound), permission scope (the only effects intake may exercise), revision/snapshot
identity (everything is read from the pinned revision through git plumbing — never from the working tree),
freshness (the binding is revalidated before and after collection), exclusion rules (paths that are never
read: secrets, keys, environment files, binaries, oversized blobs) and the authoritative suite the source
composes.

``admit`` is the only intake path. It returns an ``intake_record`` with one explicit state:

    ADMITTED     material was read from the pinned revision and normalized into canonical items
    UNAVAILABLE  the source does not exist for this repository (no export, no file) — never treated as empty
    PARTIAL      the source exists but is incomplete (e.g. shallow history) — never treated as complete
    STALE        the binding no longer matches the repository HEAD — nothing derived may be used
    DENIED       the permission scope does not cover the effect intake needs
    MALFORMED    the source exists but cannot be parsed into canonical records
    OVERSIZED    the source exceeds the declared size caps
    CONFLICTING  the source contradicts itself (e.g. two ownership files, disagreeing manifests)

Every state except ADMITTED routes to abstention or human review (T04); no state is ever inferred away.

Build provenance: BUILD_NEW (stdlib + git plumbing via local_git_adapter).
"""
from __future__ import annotations

import fnmatch
import json
import re
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Mapping, Sequence

from . import contracts as C
from . import local_git_adapter as lga
from . import security as _SEC

SOURCES_VERSION = "scoped_pr_builder.intake_sources/0.1.0"
SOURCES_PATH = Path(__file__).resolve().parent.parent / "intake" / "SOURCES.json"
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
STATES = ("ADMITTED", "UNAVAILABLE", "PARTIAL", "STALE", "DENIED", "MALFORMED", "OVERSIZED", "CONFLICTING")
SOURCE_REQUIRED = ("source_id", "version", "title", "identity", "permission_scope", "revision_identity", "freshness", "exclusion_rules", "size_caps", "authoritative_suites", "states", "introduced_by")
COLLECTORS: dict[str, Callable[..., dict[str, Any]]] = {}


class IntakeRefusal(lga.AdapterError):
    """Raised when intake cannot even start (unknown source, missing registry); states are never raised."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def register_collector(source_id: str):
    def deco(fn):
        COLLECTORS[source_id] = fn
        return fn
    return deco


def load_sources(path: Path = SOURCES_PATH, *, repo_root: Path = REPO_ROOT) -> dict[str, Any]:
    if not Path(path).is_file():
        raise IntakeRefusal("intake.registry_missing", f"intake source registry not found: {path}")
    reg = json.loads(Path(path).read_text(encoding="utf-8"))
    if reg.get("sources_version") != SOURCES_VERSION:
        raise IntakeRefusal("intake.registry_invalid", "unsupported sources_version")
    for sid, s in (reg.get("sources") or {}).items():
        missing = [k for k in SOURCE_REQUIRED if k not in s]
        if missing or s["source_id"] != sid:
            raise IntakeRefusal("intake.registry_invalid", f"{sid}: missing {missing} or id mismatch")
        if not s["permission_scope"] or any(e for e in s["permission_scope"] if not e.startswith(("repository.read", "artifact.read", "ledger.read"))):
            raise IntakeRefusal("intake.registry_invalid", f"{sid}: permission scope must be read-only")
        for f in s["authoritative_suites"]:
            if not (Path(repo_root) / f).is_file():
                raise IntakeRefusal("intake.suite_unbound", f"{sid}: authoritative suite file does not exist: {f}")
        if set(s["states"]) != set(STATES):
            raise IntakeRefusal("intake.registry_invalid", f"{sid}: every intake state needs a meaning")
    body = {k: v for k, v in reg.items() if k != "sources_hash"}
    reg["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return reg


def excluded(path: str, rules: Mapping[str, Any]) -> str | None:
    """Return the exclusion rule that hits ``path`` (never read), or None."""
    name = path.rsplit("/", 1)[-1]
    for pat in rules.get("path_patterns", []):
        if fnmatch.fnmatchcase(path, pat) or fnmatch.fnmatchcase(name, pat):
            return f"path_pattern:{pat}"
    for ext in rules.get("binary_extensions", []):
        if name.lower().endswith(ext):
            return f"binary_extension:{ext}"
    return None


def _tree(repo: Path, revision: str) -> list[tuple[str, str, int]]:
    """(path, blob, size) for every blob at the pinned revision."""
    out = []
    for line in lga.git(repo, "ls-tree", "-r", "-l", revision).splitlines():
        meta, path = line.split("\t", 1)
        parts = meta.split()
        if len(parts) >= 4 and parts[1] == "blob":
            out.append((path, parts[2], int(parts[3]) if parts[3] != "-" else 0))
    return out


def _item(source_id: str, kind: str, path: str, content: bytes | None, *, blob: str | None = None, size: int | None = None, extra: Mapping[str, Any] | None = None) -> dict[str, Any]:
    it = {"record_schema": "overlay.scoped_pr_builder.intake/IntakeItem", "source_id": source_id, "kind": kind, "canonical_path": path,
          "content_hash": lga.sha256_digest(content) if content is not None else None, "git_blob": blob, "size_bytes": size if size is not None else (len(content) if content is not None else None)}
    if extra:
        it.update(extra)
    return it


def admit(source_id: str, binding: lga.RepositoryBinding, *, granted_effects: Sequence[str], sources: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None, options: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Admit one evidence source for one pinned binding. Always returns an intake_record with an explicit state."""
    srcs = sources or load_sources()
    reg = registry or C.load_registry()
    s = srcs["sources"].get(source_id)
    if s is None:
        raise IntakeRefusal("intake.unknown_source", f"no such source {source_id!r}")
    repo = Path(binding.root_path)
    rec: dict[str, Any] = {"record_schema": "overlay.scoped_pr_builder.intake/IntakeRecord", "source_id": source_id, "source_version": s["version"], "repository_id": binding.repository_id, "worktree_id": binding.worktree_id,
                           "base_revision": binding.base_revision, "source_snapshot_hash": binding.source_snapshot_hash, "permission_scope": list(s["permission_scope"]), "granted_effects": sorted(granted_effects),
                           "state": "ADMITTED", "reason": "", "items": [], "excluded": [], "counts": {}, "freshness": {"status": "unchecked", "checked_at": None}, "admitted_at": _now()}
    # permission scope: intake may only exercise the effects the contract declares, and only if granted
    missing = [e for e in s["permission_scope"] if e not in granted_effects]
    if missing:
        rec.update(state="DENIED", reason=f"permission scope not granted: {missing}")
        return _seal(rec, reg)
    # revision identity + freshness before anything is read
    try:
        lga.revalidate_binding(binding)
        rec["freshness"] = {"status": "fresh", "checked_at": _now(), "pinned_revision": binding.base_revision}
    except lga.AdapterError as exc:
        rec.update(state="STALE", reason=f"binding no longer matches the repository: {exc}")
        rec["freshness"] = {"status": "stale", "checked_at": _now(), "pinned_revision": binding.base_revision}
        return _seal(rec, reg)
    # DATA-*-T03: pin the exact source identity (revision, git tree, snapshot hash) before anything is indexed
    rec["pin"] = pin(binding, repo)
    collector = COLLECTORS.get(source_id)
    if collector is None:
        rec.update(state="UNAVAILABLE", reason=f"no collector bound for {source_id} yet (T02); the source is not treated as empty")
        return _seal(rec, reg)
    try:
        result = collector(repo, binding, s, dict(options or {}))
    except lga.AdapterError as exc:
        rec.update(state="MALFORMED", reason=f"collector refused: {exc.code}: {exc}")
        return _seal(rec, reg)
    rec.update(result)
    # DATA-*-T03: the tree that was read must be the tree that was pinned (index integrity)
    try:
        verify_pin(rec["pin"], binding, repo)
    except lga.AdapterError as exc:
        rec.update(state="STALE", reason=f"{exc.code}: {exc}", items=[])
    # size caps after collection (never silently truncated)
    caps = s["size_caps"]
    total = sum(int(i.get("size_bytes") or 0) for i in rec["items"])
    if len(rec["items"]) > caps["max_items"] or total > caps["max_total_bytes"]:
        rec.update(state="OVERSIZED", reason=f"{len(rec['items'])} items / {total} bytes exceed caps {caps['max_items']} items / {caps['max_total_bytes']} bytes", items=[])
    # freshness after collection: the material read must still describe the pinned revision
    if rec["state"] == "ADMITTED":
        try:
            lga.revalidate_binding(binding)
        except lga.AdapterError as exc:
            rec.update(state="STALE", reason=f"repository moved during collection: {exc}", items=[])
    # DATA-*-T03: every item carries provenance and freshness; it is meaningless without them
    rec["items"] = [stamp(rec, it) for it in rec["items"]]
    rec["counts"] = {"items": len(rec["items"]), "excluded": len(rec["excluded"]), "bytes": sum(int(i.get("size_bytes") or 0) for i in rec["items"])}
    rec["trust"] = _SEC.trust_block("repository_content", scanned=False)  # SEC-01-T02: admitted sources are data, never instruction
    return _seal(rec, reg)


def _seal(rec: dict[str, Any], reg: Mapping[str, Any]) -> dict[str, Any]:
    if rec["state"] != "ADMITTED" and not rec["reason"]:
        rec["reason"] = f"state {rec['state']}"
    rec["intake_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in rec.items() if k != "intake_hash"}))
    C.validate_payload("intake_record", {k: v for k, v in rec.items() if k not in ("items", "excluded")}, registry=reg)
    return rec


def admit_all(binding: lga.RepositoryBinding, *, granted_effects: Sequence[str], sources: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> dict[str, dict[str, Any]]:
    srcs = sources or load_sources()
    return {sid: admit(sid, binding, granted_effects=granted_effects, sources=srcs, registry=registry) for sid in srcs["sources"]}


__all__ = ["COLLECTORS", "IntakeRefusal", "SOURCES_PATH", "SOURCES_VERSION", "STATES", "admit", "admit_all", "excluded", "load_sources", "register_collector"]


# --------------------------------------------------------------------------- #
# T02 — collectors: bind each source to its authoritative suite and normalize the #
# admitted material into canonical items, all read from the pinned revision      #
# --------------------------------------------------------------------------- #
def _read(repo: Path, revision: str, path: str, cap: int) -> bytes | None:
    data = lga.git_bytes(repo, "show", f"{revision}:{path}")
    return data if len(data) <= cap else None


def _walk(repo: Path, binding: lga.RepositoryBinding, s: Mapping[str, Any], *, select: Callable[[str], str | None], kind_default: str = "file") -> tuple[list[dict[str, Any]], list[dict[str, Any]], int]:
    """Iterate the pinned tree; return (items, excluded, oversized_count). Excluded paths are never read."""
    items, excluded_paths, oversized = [], [], 0
    rules, cap = s["exclusion_rules"], int(s["size_caps"]["max_item_bytes"])
    for path, blob, size in _tree(repo, binding.base_revision):
        kind = select(path)
        if kind is None:
            continue
        hit = excluded(path, rules)
        if hit:
            excluded_paths.append({"canonical_path": path, "rule": hit})
            continue
        if size > cap:
            oversized += 1
            excluded_paths.append({"canonical_path": path, "rule": f"size_cap:{cap}"})
            continue
        content = _read(repo, binding.base_revision, path, cap)
        items.append(_item(s["source_id"], kind, path, content, blob=blob, size=size))
    return items, excluded_paths, oversized


# @@ DATA-01
@register_collector("DATA-01")
def _collect_source_tree_and_history(repo: Path, binding: lga.RepositoryBinding, s: Mapping[str, Any], options: Mapping[str, Any]) -> dict[str, Any]:
    """DATA-01: every tracked blob at the pinned revision (hash-identified; excluded paths never read) plus the
    commit history reachable from it. A shallow repository yields PARTIAL — history is never assumed complete."""
    items, excluded_paths, _ = _walk(repo, binding, s, select=lambda p: "source_blob")
    shallow = lga.git(repo, "rev-parse", "--is-shallow-repository") == "true"
    count = int(lga.git(repo, "rev-list", "--count", binding.base_revision))
    limit = int(options.get("max_commits", s["size_caps"].get("max_commits", 2000)))
    log = lga.git(repo, "log", f"--max-count={limit}", "--format=%H%x1f%an%x1f%aI%x1f%s", binding.base_revision)
    commits = []
    for line in log.splitlines():
        h, an, at, subj = (line.split("\x1f") + ["", "", "", ""])[:4]
        commits.append(_item("DATA-01", "commit", h, None, extra={"author": an, "authored_at": at, "subject": subj[:200], "content_hash": lga.sha256_digest(line.encode("utf-8"))}))
    out = {"items": items + commits, "excluded": excluded_paths, "history": {"reachable_commits": count, "collected_commits": len(commits), "shallow": shallow, "complete": (not shallow) and len(commits) == count}}
    if shallow:
        out.update(state="PARTIAL", reason=f"repository is shallow: {count} reachable commit(s) but the full history is not present")
    elif len(commits) < count:
        out.update(state="PARTIAL", reason=f"history truncated to {len(commits)} of {count} commits by the collection cap")
    return out
# @@ DATA-02
MANIFEST_NAMES = ("pyproject.toml", "setup.py", "setup.cfg", "requirements.txt", "requirements-dev.txt", "package.json", "package-lock.json", "Cargo.toml", "Cargo.lock", "go.mod", "go.sum", "pom.xml", "build.gradle", "MANIFEST.json", "SHA256SUMS.txt", "Makefile", "CMakeLists.txt", "Dockerfile", "environment.yml")


@register_collector("DATA-02")
def _collect_build_metadata(repo: Path, binding: lga.RepositoryBinding, s: Mapping[str, Any], options: Mapping[str, Any]) -> dict[str, Any]:
    """DATA-02: build metadata and dependency manifests, normalized to (path, hash, declared dependency names).
    Two manifests declaring different pins for the same dependency are CONFLICTING."""
    items, excluded_paths, _ = _walk(repo, binding, s, select=lambda p: "manifest" if p.rsplit("/", 1)[-1] in MANIFEST_NAMES or p.rsplit("/", 1)[-1].startswith("requirements") else None)
    pins: dict[str, dict[str, str]] = {}
    for it in items:
        name = it["canonical_path"].rsplit("/", 1)[-1]
        text = _read(repo, binding.base_revision, it["canonical_path"], int(s["size_caps"]["max_item_bytes"])) or b""
        deps: dict[str, str] = {}
        if name.startswith("requirements"):
            for line in text.decode("utf-8", errors="replace").splitlines():
                m = re.match(r"^\s*([A-Za-z0-9_.-]+)\s*([=<>!~]=?\s*[^\s;#]+)?", line)
                if m and not line.lstrip().startswith(("#", "-")):
                    deps[m.group(1).lower()] = (m.group(2) or "").replace(" ", "")
        elif name == "package.json":
            try:
                pj = json.loads(text.decode("utf-8"))
                for sec in ("dependencies", "devDependencies"):
                    for k, v in (pj.get(sec) or {}).items():
                        deps[str(k).lower()] = str(v)
            except (ValueError, AttributeError) as exc:
                raise lga.AdapterError("intake.manifest_malformed", f"{it['canonical_path']}: {exc}") from exc
        it["dependencies"] = deps
        for k, v in deps.items():
            pins.setdefault(k, {})[it["canonical_path"]] = v
    conflicts = {k: v for k, v in pins.items() if len({x for x in v.values() if x}) > 1}
    out = {"items": items, "excluded": excluded_paths, "manifests": {"count": len(items), "dependencies": sum(len(i["dependencies"]) for i in items), "conflicts": conflicts}}
    if not items:
        out.update(state="UNAVAILABLE", reason="no build metadata or dependency manifest exists at the pinned revision")
    elif conflicts:
        out.update(state="CONFLICTING", reason=f"manifests disagree on {sorted(conflicts)[:5]}")
    return out
# @@ DATA-03
TEST_PATTERNS = ("tests/", "test/", "/tests/", "/test/")


@register_collector("DATA-03")
def _collect_tests(repo: Path, binding: lga.RepositoryBinding, s: Mapping[str, Any], options: Mapping[str, Any]) -> dict[str, Any]:
    """DATA-03: test suites and test helpers (test directories, test_*/ *_test modules, conftest/fixtures)."""
    def select(p: str) -> str | None:
        name = p.rsplit("/", 1)[-1]
        if name in ("conftest.py", "pytest.ini", "tox.ini") or "fixture" in p.lower():
            return "test_helper"
        if name.startswith("test_") or name.endswith(("_test.py", ".test.js", ".test.ts", "_test.go")) or any(p.startswith(t) or t in p for t in TEST_PATTERNS):
            return "test_module" if name.endswith((".py", ".js", ".ts", ".go", ".ja", ".jat", ".jate")) else "test_asset"
        return None
    items, excluded_paths, _ = _walk(repo, binding, s, select=select)
    out = {"items": items, "excluded": excluded_paths, "tests": {"modules": sum(1 for i in items if i["kind"] == "test_module"), "helpers": sum(1 for i in items if i["kind"] == "test_helper"), "assets": sum(1 for i in items if i["kind"] == "test_asset")}}
    if not items:
        out.update(state="UNAVAILABLE", reason="no test suite exists at the pinned revision")
    return out
# @@ DATA-04
def _collect_export(repo: Path, binding: lga.RepositoryBinding, s: Mapping[str, Any], export_path: str, kind: str, required: Sequence[str]) -> dict[str, Any]:
    """Platform-held sources (pull requests, issues) are admitted only from an authorized, committed export at a
    declared path; without it the source is UNAVAILABLE — never an empty history."""
    tree = {p: (b, sz) for p, b, sz in _tree(repo, binding.base_revision)}
    if export_path not in tree:
        return {"items": [], "excluded": [], "state": "UNAVAILABLE", "reason": f"no authorized export at {export_path} in the pinned revision; the {kind} history is unknown, not empty", "export": {"path": export_path, "present": False}}
    hit = excluded(export_path, s["exclusion_rules"])
    if hit:
        return {"items": [], "excluded": [{"canonical_path": export_path, "rule": hit}], "state": "DENIED", "reason": f"export path is excluded by {hit}", "export": {"path": export_path, "present": True}}
    raw = _read(repo, binding.base_revision, export_path, int(s["size_caps"]["max_item_bytes"]))
    if raw is None:
        return {"items": [], "excluded": [], "state": "OVERSIZED", "reason": f"export {export_path} exceeds max_item_bytes", "export": {"path": export_path, "present": True}}
    items, ids = [], set()
    for n, line in enumerate(raw.decode("utf-8", errors="replace").splitlines(), 1):
        if not line.strip():
            continue
        try:
            obj = json.loads(line)
        except ValueError:
            return {"items": [], "excluded": [], "state": "MALFORMED", "reason": f"{export_path} line {n} is not JSON", "export": {"path": export_path, "present": True}}
        missing = [k for k in required if k not in obj]
        if missing:
            return {"items": [], "excluded": [], "state": "MALFORMED", "reason": f"{export_path} line {n} lacks {missing}", "export": {"path": export_path, "present": True}}
        if obj["id"] in ids:
            return {"items": [], "excluded": [], "state": "CONFLICTING", "reason": f"{export_path} carries duplicate id {obj['id']!r}", "export": {"path": export_path, "present": True}}
        ids.add(obj["id"])
        items.append(_item(s["source_id"], kind, f"{export_path}#{obj['id']}", line.encode("utf-8"), extra={k: obj.get(k) for k in required}))
    return {"items": items, "excluded": [], "export": {"path": export_path, "present": True, "records": len(items), "content_hash": lga.sha256_digest(raw)}}


@register_collector("DATA-04")
def _collect_pull_requests(repo: Path, binding: lga.RepositoryBinding, s: Mapping[str, Any], options: Mapping[str, Any]) -> dict[str, Any]:
    """DATA-04: pull-request history and review comments from the authorized export (Plug 14.3 adapter contract)."""
    return _collect_export(repo, binding, s, s["identity"]["export_path"], "pull_request", ("id", "title", "state", "reviews"))
# @@ DATA-05
DOC_HINTS = ("adr", "design", "architecture", "rfc", "decision")


@register_collector("DATA-05")
def _collect_design_docs(repo: Path, binding: lga.RepositoryBinding, s: Mapping[str, Any], options: Mapping[str, Any]) -> dict[str, Any]:
    """DATA-05: ADRs and design documents (Knowledge Repository 41.1/41.2): markdown/text under docs/adr/design paths and root READMEs."""
    def select(p: str) -> str | None:
        low = p.lower(); name = low.rsplit("/", 1)[-1]
        if not name.endswith((".md", ".rst", ".txt", ".adoc")):
            return None
        if any(h in low for h in DOC_HINTS):
            return "adr" if "adr" in low or "decision" in low else "design_doc"
        if name.startswith("readme") or low.startswith("docs/"):
            return "documentation"
        return None
    items, excluded_paths, _ = _walk(repo, binding, s, select=select)
    numbers: dict[str, list[str]] = {}
    for it in items:
        m = re.match(r"^(\d+)", it["canonical_path"].rsplit("/", 1)[-1]) if it["kind"] == "adr" else None
        if m:
            it["adr_number"] = m.group(1)
            numbers.setdefault(m.group(1), []).append(it["canonical_path"])
    duplicates = {k: v for k, v in numbers.items() if len(v) > 1}
    out = {"items": items, "excluded": excluded_paths, "docs": {"adr": sum(1 for i in items if i["kind"] == "adr"), "design": sum(1 for i in items if i["kind"] == "design_doc"), "documentation": sum(1 for i in items if i["kind"] == "documentation"), "duplicate_adr_numbers": duplicates}}
    if not items:
        out.update(state="UNAVAILABLE", reason="no ADRs or design documents exist at the pinned revision")
    elif duplicates:
        out.update(state="CONFLICTING", reason=f"ADR numbers reused: {sorted(duplicates)[:5]}; which record governs must be reviewed, not guessed")
    return out
# @@ DATA-06
@register_collector("DATA-06")
def _collect_issues(repo: Path, binding: lga.RepositoryBinding, s: Mapping[str, Any], options: Mapping[str, Any]) -> dict[str, Any]:
    """DATA-06: issue/bug history from the authorized export (Plug 14.3 adapter contract)."""
    return _collect_export(repo, binding, s, s["identity"]["export_path"], "issue", ("id", "title", "state", "labels"))
# @@ DATA-07
OWNER_FILES = ("CODEOWNERS", ".github/CODEOWNERS", "docs/CODEOWNERS")


@register_collector("DATA-07")
def _collect_ownership(repo: Path, binding: lga.RepositoryBinding, s: Mapping[str, Any], options: Mapping[str, Any]) -> dict[str, Any]:
    """DATA-07: code ownership metadata (CODEOWNERS; Capability Manifests 55.2 command permissions). More than one
    ownership file is CONFLICTING (precedence must be decided by a human, not inferred)."""
    items, excluded_paths, _ = _walk(repo, binding, s, select=lambda p: "ownership" if p in OWNER_FILES else None)
    rules = []
    for it in items:
        text = (_read(repo, binding.base_revision, it["canonical_path"], int(s["size_caps"]["max_item_bytes"])) or b"").decode("utf-8", errors="replace")
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) < 2 or not all(o.startswith(("@", "mailto:")) or "@" in o for o in parts[1:]):
                return {"items": [], "excluded": excluded_paths, "state": "MALFORMED", "reason": f"{it['canonical_path']}: ownership line without owners: {line[:60]!r}"}
            rules.append({"pattern": parts[0], "owners": parts[1:], "file": it["canonical_path"]})
        it["rules"] = sum(1 for r in rules if r["file"] == it["canonical_path"])
    out = {"items": items, "excluded": excluded_paths, "ownership": {"files": [i["canonical_path"] for i in items], "rules": rules}}
    if not items:
        out.update(state="UNAVAILABLE", reason="no CODEOWNERS file exists at the pinned revision; ownership is unknown, not absent")
    elif len(items) > 1:
        out.update(state="CONFLICTING", reason=f"{len(items)} ownership files present ({', '.join(i['canonical_path'] for i in items)}); precedence must be reviewed")
    return out


# --------------------------------------------------------------------------- #
# T03 — pin before index; provenance + freshness on every derived record          #
# --------------------------------------------------------------------------- #
def pin(binding: lga.RepositoryBinding, repo: Path) -> dict[str, Any]:
    """The exact source identity every item is read against: full revision, content-addressed tree, snapshot hash."""
    if lga.tree_identity(repo, binding.base_revision) != binding.source_snapshot_hash:
        raise lga.AdapterError("intake.pin_mismatch", "the binding's snapshot hash does not describe the tree at its base revision")
    tree = "git-tree:" + lga.git(repo, "rev-parse", f"{binding.base_revision}^{{tree}}")
    p = {"base_revision": binding.base_revision, "git_tree": tree, "source_snapshot_hash": binding.source_snapshot_hash, "repository_id": binding.repository_id, "worktree_id": binding.worktree_id, "pinned_at": _now()}
    p["pin_hash"] = lga.sha256_digest(lga.canonical_json(p))
    return p


def verify_pin(pinned: Mapping[str, Any], binding: lga.RepositoryBinding, repo: Path) -> None:
    """Fail closed if the tree at the pinned revision is not the tree that was pinned (index integrity)."""
    if "git-tree:" + lga.git(repo, "rev-parse", f"{binding.base_revision}^{{tree}}") != pinned["git_tree"] or lga.tree_identity(repo, binding.base_revision) != pinned["source_snapshot_hash"] or binding.source_snapshot_hash != pinned["source_snapshot_hash"]:
        raise lga.AdapterError("intake.pin_mismatch", "the repository content at the pinned revision changed between pin and index")


def stamp(rec: Mapping[str, Any], item: Mapping[str, Any]) -> dict[str, Any]:
    """Attach provenance and freshness metadata to one item: it is meaningless without them."""
    return dict(item, base_revision=rec["pin"]["base_revision"], source_snapshot_hash=rec["pin"]["source_snapshot_hash"], git_tree=rec["pin"]["git_tree"], provenance_ref=rec["pin"]["pin_hash"],
                freshness_status=rec["freshness"]["status"], freshness_checked_at=rec["freshness"]["checked_at"], source_version=rec["source_version"])


def derive(rec: Mapping[str, Any], item: Mapping[str, Any], derived_kind: str, payload: Mapping[str, Any]) -> dict[str, Any]:
    """A record derived from an admitted item (index entry, evidence record, summary) inherits the item's provenance
    and freshness and links back to the sealed intake record; it can never outlive a STALE source."""
    if rec["state"] != "ADMITTED":
        raise lga.AdapterError("intake.not_admitted", f"cannot derive from a {rec['state']} source")
    for f in ("provenance_ref", "content_hash", "base_revision", "source_snapshot_hash", "freshness_status"):
        if f not in item or item[f] is None:
            raise lga.AdapterError("intake.provenance_incomplete", f"item lacks {f}; nothing may be derived from it")
    d = {"record_schema": f"overlay.scoped_pr_builder.intake/Derived.{derived_kind}", "derived_kind": derived_kind, "source_id": rec["source_id"], "intake_ref": rec["intake_hash"], "provenance_ref": item["provenance_ref"],
         "canonical_path": item["canonical_path"], "content_hash": item["content_hash"], "base_revision": item["base_revision"], "source_snapshot_hash": item["source_snapshot_hash"], "git_tree": item["git_tree"],
         "freshness_status": item["freshness_status"], "freshness_checked_at": item["freshness_checked_at"], "payload": dict(payload), "derived_at": _now()}
    d["derived_hash"] = lga.sha256_digest(lga.canonical_json(d))
    return d


__all__ += ["derive", "pin", "stamp", "verify_pin"]


# --------------------------------------------------------------------------- #
# T04 — explicit handling of every non-admitted state: abstention or review, never inference
# --------------------------------------------------------------------------- #
ROUTES = {"ADMITTED": "proceed", "UNAVAILABLE": "review", "PARTIAL": "review", "STALE": "abstain", "DENIED": "abstain", "MALFORMED": "review", "OVERSIZED": "review", "CONFLICTING": "review"}
ROUTE_REASON = {
    "UNAVAILABLE": "the source is unknown for this repository; a human must supply or waive it — it is not empty",
    "PARTIAL": "the source is incomplete; a human must decide whether the partial material suffices — it is not complete",
    "STALE": "the binding moved; the run must re-pin before anything derived is used",
    "DENIED": "the permission scope was not granted; nothing was read",
    "MALFORMED": "the source exists but could not be normalized; a human must inspect it — it is not inferred",
    "OVERSIZED": "the source exceeds the declared caps; a human must narrow or waive it — it is not truncated silently",
    "CONFLICTING": "the source contradicts itself; a human must resolve precedence — it is not guessed",
}


def route(rec: Mapping[str, Any]) -> dict[str, Any]:
    """Where an intake record goes next. Only ADMITTED proceeds; every other state blocks inference explicitly."""
    state = rec["state"]
    if state not in ROUTES:
        raise lga.AdapterError("intake.state_unknown", f"unknown intake state {state!r}")
    r = {"source_id": rec["source_id"], "state": state, "route": ROUTES[state], "may_infer": state == "ADMITTED", "reason": rec.get("reason") or ROUTE_REASON.get(state, ""), "intake_hash": rec.get("intake_hash")}
    r["route_hash"] = lga.sha256_digest(lga.canonical_json(r))
    return r


def require_admitted(records: Mapping[str, Mapping[str, Any]], needed: Sequence[str]) -> list[dict[str, Any]]:
    """Gate for a step that depends on sources: abstain routes refuse (intake.<state>), review routes are returned so
    the caller surfaces them; a needed source with no record at all is a missing fact (refused)."""
    reviews = []
    for sid in needed:
        rec = records.get(sid)
        if rec is None:
            raise lga.AdapterError("intake.missing", f"source {sid} was never admitted or refused; it cannot be assumed")
        r = route(rec)
        if r["route"] == "abstain":
            raise lga.AdapterError(f"intake.{rec['state'].lower()}", f"{sid}: {r['reason']}")
        if r["route"] == "review":
            reviews.append(r)
    return reviews


def review_fragment(records: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
    """Display-only card section: every source with its state, route, reason, counts, freshness and exclusions."""
    rows = []
    for sid, rec in sorted(records.items()):
        r = route(rec)
        rows.append({"source_id": sid, "state": rec["state"], "route": r["route"], "reason": r["reason"], "items": rec.get("counts", {}).get("items", 0), "excluded": rec.get("counts", {}).get("excluded", 0),
                     "freshness": rec.get("freshness", {}).get("status"), "base_revision": rec.get("base_revision"), "intake_hash": rec.get("intake_hash")})
    frag = {"authority": "display_only", "sources": rows, "needs_review": [r["source_id"] for r in rows if r["route"] == "review"], "abstaining": [r["source_id"] for r in rows if r["route"] == "abstain"],
            "note": "Non-admitted sources are never treated as empty or current; inference over them is refused."}
    frag["fragment_hash"] = lga.sha256_digest(lga.canonical_json(frag))
    return frag


def render_fragment_html(frag: Mapping[str, Any], esc: Any) -> str:
    rows = "".join(f"<tr><td>{esc(r['source_id'])}</td><td class='v-{'pass' if r['state'] == 'ADMITTED' else 'fail'}'>{esc(r['state'])}</td><td>{esc(r['route'])}</td><td>{esc(r['items'])}/{esc(r['excluded'])}</td><td>{esc(r['freshness'])}</td><td>{esc(r['reason'])}</td></tr>" for r in frag["sources"])
    return f"<h2>Evidence intake (authorized sources)</h2><table><tr><th>source</th><th>state</th><th>route</th><th>items/excluded</th><th>freshness</th><th>reason</th></tr>{rows}</table><p class=\"mono\">{esc(frag['note'])} fragment {esc(frag['fragment_hash'][7:23])}</p>"


__all__ += ["ROUTES", "render_fragment_html", "require_admitted", "review_fragment", "route"]
