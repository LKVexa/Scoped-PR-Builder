"""Deterministic repository-native verification command discovery.

Discovery is conservative: it looks for explicit project configuration or test
files, returns argv arrays only (never shell strings), and avoids treating the
mere presence of ``pyproject.toml`` as proof that pytest is the project's test
runner.
"""
from __future__ import annotations

import importlib.util
import json
import shutil
import sys
import tomllib
from pathlib import Path
from typing import Any

SAFE_NPM = {"test", "lint", "typecheck", "build"}
_IGNORED_DIRS = {".git", ".hg", ".svn", ".venv", "venv", "node_modules", "build", "dist", ".tox", ".nox"}


def _walk_test_files(root: Path, *, limit: int = 2000) -> list[Path]:
    found: list[Path] = []
    stack = [root]
    while stack and len(found) < limit:
        current = stack.pop()
        try:
            children = list(current.iterdir())
        except OSError:
            continue
        for child in children:
            if child.is_symlink():
                continue
            if child.is_dir():
                if child.name not in _IGNORED_DIRS:
                    stack.append(child)
            elif child.name.startswith("test_") and child.suffix == ".py":
                found.append(child)
                if len(found) >= limit:
                    break
    return sorted(found)


def _pyproject(root: Path) -> dict[str, Any]:
    path = root / "pyproject.toml"
    if not path.is_file():
        return {}
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, tomllib.TOMLDecodeError):
        return {}


def _declares_dependency(data: dict[str, Any], package: str) -> bool:
    project = data.get("project") if isinstance(data.get("project"), dict) else {}
    deps = list(project.get("dependencies") or [])
    optional = project.get("optional-dependencies") if isinstance(project.get("optional-dependencies"), dict) else {}
    for values in optional.values():
        if isinstance(values, list):
            deps.extend(values)
    needle = package.lower().replace("_", "-")
    for dep in deps:
        if not isinstance(dep, str):
            continue
        head = dep.split(";", 1)[0].strip().lower().replace("_", "-")
        if head.startswith(needle) and (len(head) == len(needle) or head[len(needle)] in "[<>=!~ "):
            return True
    return False


def discover(root: Path) -> list[dict[str, Any]]:
    root = Path(root).resolve()
    out: list[dict[str, Any]] = []
    pyproject = _pyproject(root)
    tool = pyproject.get("tool") if isinstance(pyproject.get("tool"), dict) else {}
    test_files = _walk_test_files(root)
    pytest_declared = bool((root / "pytest.ini").is_file() or (root / "conftest.py").is_file() or isinstance(tool.get("pytest"), dict) or _declares_dependency(pyproject, "pytest"))

    if pytest_declared:
        ready = importlib.util.find_spec("pytest") is not None
        out.append({"kind": "tests", "name": "pytest", "argv": [sys.executable, "-m", "pytest", "-q"] if ready else None, "cwd": ".", "status": "ready" if ready else "tool_missing"})
    elif test_files:
        out.append({"kind": "tests", "name": "unittest", "argv": [sys.executable, "-m", "unittest", "discover", "-p", "test_*.py"], "cwd": ".", "status": "ready"})

    package = root / "package.json"
    if package.is_file():
        try:
            scripts = (json.loads(package.read_text(encoding="utf-8")).get("scripts") or {})
        except (OSError, json.JSONDecodeError):
            scripts = {}
        if isinstance(scripts, dict):
            for name in ("test", "lint", "typecheck", "build"):
                if name in scripts:
                    out.append({"kind": "tests" if name == "test" else name, "name": f"npm:{name}", "argv": ["npm", "run", name, "--if-present"] if shutil.which("npm") else None, "cwd": ".", "status": "ready" if shutil.which("npm") else "tool_missing"})

    if (root / "go.mod").is_file():
        out.append({"kind": "tests", "name": "go test", "argv": ["go", "test", "./..."] if shutil.which("go") else None, "cwd": ".", "status": "ready" if shutil.which("go") else "tool_missing"})
    if (root / "Cargo.toml").is_file():
        out.append({"kind": "tests", "name": "cargo test", "argv": ["cargo", "test", "--workspace"] if shutil.which("cargo") else None, "cwd": ".", "status": "ready" if shutil.which("cargo") else "tool_missing"})

    ruff_declared = (root / "ruff.toml").is_file() or (root / ".ruff.toml").is_file() or isinstance(tool.get("ruff"), dict) or _declares_dependency(pyproject, "ruff")
    if ruff_declared:
        out.append({"kind": "lint", "name": "ruff", "argv": ["ruff", "check", "."] if shutil.which("ruff") else None, "cwd": ".", "status": "ready" if shutil.which("ruff") else "tool_missing"})
    mypy_declared = (root / "mypy.ini").is_file() or isinstance(tool.get("mypy"), dict) or _declares_dependency(pyproject, "mypy")
    if mypy_declared:
        out.append({"kind": "typecheck", "name": "mypy", "argv": ["mypy", "."] if shutil.which("mypy") else None, "cwd": ".", "status": "ready" if shutil.which("mypy") else "tool_missing"})
    return out
