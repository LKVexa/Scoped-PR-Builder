"""Scoped PR Builder — independent verification gates (Phase 08 / VERIFY-01..07).

``verification/CHECKS.json`` declares one independent verification check per mandatory condition — the patch applies
cleanly to the authorized revision, build/compile succeeds, required tests pass, static analysis/lint/type checks stay
within threshold, no unapproved files/symbols change, the diff stays below the review threshold, behavioral regression
checks pass where defined — each with a typed result (``pass`` / ``fail`` / ``blocked`` / ``indeterminate``), the
evidence references a result must carry, the suite that is authoritative for it and the sandboxed job(s) that execute
it. A check result is a sealed record (contract ``verification_check_result``); results are derived only from the
isolated runner's job records — never from planner or model assertions — and the gate (T03) consumes those records.

Build provenance: BUILD_NEW (stdlib), composing verification_runner (SLICE-06), repository_context_adapter (Suite
40.2 symbol extraction) and the contract registry. The fail-closed "only an explicit, executed verdict satisfies a gate"
rule and the capped failed-step diagnostic shape follow a pattern inspected in ``amplifier-bundle-attractor``
(``modules/loop-pipeline/.../outcome.py``, MIT) — no code copied; see ``../PROVENANCE.jsonl``.
"""
from __future__ import annotations

import json
import os
import platform
import resource
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Mapping, Sequence

from . import contracts as C
from . import local_git_adapter as lga

CHECKS_VERSION = "scoped_pr_builder.verification_checks/0.1.0"
CHECKS_PATH = Path(__file__).resolve().parent.parent / "verification" / "CHECKS.json"
OVERLAY_ROOT = Path(__file__).resolve().parent.parent
REPO_ROOT = OVERLAY_ROOT.parent
ADAPTER_ID = "scoped_pr_builder.verification_checks"
ADAPTER_VERSION = "0.1.0"
NS = "overlay.scoped_pr_builder.verification"
RESULTS = ("pass", "fail", "blocked", "indeterminate")
RESULT_SEMANTICS = {
    "pass": "the check executed against the exact candidate and authorized revision and every assertion held; carries executed evidence references",
    "fail": "the check executed and at least one assertion did not hold; diagnostics are reviewable",
    "blocked": "the check could not execute (a prerequisite check failed, an input was missing/unauthorized, or the sandbox could not be prepared); never counts as evidence",
    "indeterminate": "the check ran but produced no decisive verdict (timeout, tool unavailable, nothing to run); never counts as evidence",
}
CHECK_REQUIRED = ("check_id", "version", "title", "requirement", "typed_result", "evidence_requirements", "mandatory", "authoritative_suites", "independence", "introduced_by")
SUBJECT_FIELDS = ("candidate_id", "patch_hash", "base_revision", "scope_contract_hash", "source_snapshot_hash", "repository_id")


class CheckRefusal(lga.AdapterError):
    """Raised by the verification-check boundary (unknown check, malformed result, gate refusal)."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_checks(path: Path = CHECKS_PATH, *, registry: Mapping[str, Any] | None = None, repo_root: Path = REPO_ROOT) -> dict[str, Any]:
    """Load and validate the check registry; every check must bind to existing authoritative suites and declare the
    closed typed-result vocabulary and its evidence requirements."""
    if not Path(path).is_file():
        raise CheckRefusal("verify.registry_missing", f"check registry not found: {path}")
    reg = registry or C.load_registry()
    ck = json.loads(Path(path).read_text(encoding="utf-8"))
    if ck.get("checks_version") != CHECKS_VERSION:
        raise CheckRefusal("verify.registry_invalid", "unsupported checks_version")
    for cid, c in (ck.get("checks") or {}).items():
        missing = [k for k in CHECK_REQUIRED if k not in c]
        if missing or c["check_id"] != cid or not C.SEMVER_RE.match(c["version"]):
            raise CheckRefusal("verify.registry_invalid", f"{cid}: missing {missing} / id or version invalid")
        if list(c["typed_result"].get("enum", [])) != list(RESULTS):
            raise CheckRefusal("verify.registry_invalid", f"{cid}: typed_result.enum must be exactly {list(RESULTS)}")
        if not c["evidence_requirements"]:
            raise CheckRefusal("verify.registry_invalid", f"{cid}: evidence_requirements must not be empty")
        if c["mandatory"] not in (True, "when_defined"):
            raise CheckRefusal("verify.registry_invalid", f"{cid}: mandatory must be true or 'when_defined'")
        for f in c["authoritative_suites"]:
            if not (Path(repo_root) / f).is_file():
                raise CheckRefusal("verify.suite_unbound", f"{cid}: authoritative suite file does not exist: {f}")
    if "verification_check_result" not in reg["contracts"]:
        raise CheckRefusal("verify.registry_invalid", "contract verification_check_result is not registered")
    body = {k: v for k, v in ck.items() if k != "checks_hash"}
    ck["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return ck


def subject_of(binding: Any, contract: Mapping[str, Any], candidate: Mapping[str, Any]) -> dict[str, Any]:
    """The exact object a result speaks about: candidate + patch + authorized revision + scope + snapshot + repository."""
    if candidate.get("base_revision") != binding.base_revision or candidate.get("scope_contract_hash") != contract.get("scope_contract_hash"):
        raise CheckRefusal("verify.binding_mismatch", "candidate is not bound to this binding/scope contract")
    return {"candidate_id": candidate["candidate_id"], "patch_hash": candidate["patch_hash"], "base_revision": binding.base_revision, "scope_contract_hash": contract["scope_contract_hash"],
            "source_snapshot_hash": binding.source_snapshot_hash, "repository_id": binding.repository_id}


def _seal(rec: dict[str, Any]) -> dict[str, Any]:
    rec["result_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in rec.items() if k not in ("result_hash", "produced_at", "reproducibility")}))
    return rec


def typed_result(check: Mapping[str, Any], result: str, subject: Mapping[str, Any], *, executed: bool, executor: Mapping[str, Any] | None, evidence_refs: Sequence[Mapping[str, Any]], summary: str,
                 reasons: Sequence[str] = (), run_id: str | None = None, diagnostics: Sequence[Mapping[str, Any]] = (), registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Build one sealed, contract-valid check result. ``pass`` requires execution and executed evidence; every
    non-pass result requires at least one reason; the vocabulary is closed."""
    if result not in RESULTS:
        raise CheckRefusal("verify.result_invalid", f"{check['check_id']}: result must be one of {RESULTS}, got {result!r}")
    if result == "pass" and (not executed or not any(r.get("kind") == "job_record" for r in evidence_refs)):
        raise CheckRefusal("verify.result_invalid", f"{check['check_id']}: a pass requires execution and at least one job_record evidence reference")
    if result != "pass" and not reasons:
        raise CheckRefusal("verify.result_invalid", f"{check['check_id']}: a {result} result requires reasons")
    for k in SUBJECT_FIELDS:
        if not subject.get(k):
            raise CheckRefusal("verify.result_invalid", f"{check['check_id']}: subject.{k} is required")
    rec = {"record_schema": f"{NS}/CheckResult", "check_id": check["check_id"], "check_version": check["version"], "result": result, "subject": {k: subject[k] for k in SUBJECT_FIELDS},
           "executed": bool(executed), "executor": dict(executor or {"suite": None, "worker": None, "job_ids": []}), "evidence_refs": [dict(r) for r in evidence_refs], "summary": summary,
           "reasons": list(reasons), "diagnostics": [dict(d) for d in diagnostics], "run_id": run_id, "produced_by": f"adapters/verification_checks/{ADAPTER_VERSION}", "produced_at": _now()}
    _seal(rec)
    C.validate_payload("verification_check_result", rec, registry=registry)
    return rec


def verify_result(rec: Mapping[str, Any], *, registry: Mapping[str, Any] | None = None) -> None:
    """Fail closed on a result whose content no longer matches its hash or that violates the contract."""
    C.validate_payload("verification_check_result", rec, registry=registry)
    body = {k: v for k, v in rec.items() if k not in ("result_hash", "produced_at", "reproducibility")}
    if lga.sha256_digest(lga.canonical_json(body)) != rec.get("result_hash"):
        raise CheckRefusal("verify.result_tampered", f"{rec.get('check_id')}: result_hash does not match the result content")


def results_by_check(results: Sequence[Mapping[str, Any]]) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for r in results:
        if r["check_id"] in out:
            raise CheckRefusal("verify.result_duplicate", f"two results for {r['check_id']}; ambiguity is refused")
        out[r["check_id"]] = dict(r)
    return out


__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "CHECKS_PATH", "CHECKS_VERSION", "RESULTS", "RESULT_SEMANTICS", "SUBJECT_FIELDS", "CheckRefusal", "load_checks", "results_by_check", "subject_of", "typed_result", "verify_result"]


# --------------------------------------------------------------------------- #
# T02 — execution: every check runs through its authoritative suite's sandboxed job(s) (the SLICE-06 runner: a detached
# worktree pinned to the authorized revision, the exact candidate patch applied only there) and its typed result is
# derived from the runner's job records alone
# --------------------------------------------------------------------------- #
_RESULT_HOOKS: list[Callable[[list[dict[str, Any]], Mapping[str, Any], Mapping[str, Any]], None]] = []
TAIL_BYTES = 2048


def register_result_hook(fn: Callable[[list[dict[str, Any]], Mapping[str, Any], Mapping[str, Any]], None]) -> None:
    """Later waves enrich results after derivation (reproducibility capture); hooks never change a sealed body."""
    _RESULT_HOOKS.append(fn)


def _job_diag(j: Mapping[str, Any]) -> dict[str, Any]:
    """Reviewable, capped diagnostics for one job record (command, exit code, digests, stdout/stderr tails)."""
    return {"job_id": j["job_id"], "check": j["check"], "job_family": j["job_family"], "worker": j["worker"], "command": j["command"], "exit_code": j["exit_code"], "verdict": j["verdict"], "summary": j["summary"],
            "stdout_digest": j["stdout_digest"], "stderr_digest": j["stderr_digest"], "stdout_tail": (j.get("stdout_excerpt") or "")[-TAIL_BYTES:], "stderr_tail": (j.get("stderr_excerpt") or "")[-TAIL_BYTES:],
            "started_at": j["started_at"], "finished_at": j["finished_at"]}


def derive_result(check: Mapping[str, Any], report: Mapping[str, Any], subject: Mapping[str, Any], *, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Typed result for one check from the runner's job records: pass only when every required job is present and PASS;
    any FAIL → fail; any INDETERMINATE → indeterminate; a required job that never ran → blocked (naming the job that
    stopped the runner). The runner report must describe the subject exactly."""
    ex = check.get("execution")
    if not ex:
        return typed_result(check, "blocked", subject, executed=False, executor=None, evidence_refs=[], summary="no execution binding declared for this check", reasons=["execution not bound: the check has no sandboxed job declared"], run_id=report.get("run_id"), registry=registry)
    if report.get("candidate_id") != subject["candidate_id"] or report.get("patch_hash") != subject["patch_hash"] or report.get("base_revision") != subject["base_revision"] or report.get("scope_contract_hash") != subject["scope_contract_hash"]:
        raise CheckRefusal("verify.report_mismatch", f"{check['check_id']}: the verification report does not describe the subject candidate/revision/scope")
    jobs = {j["check"]: j for j in report.get("jobs", [])}
    required, also = list(ex["jobs"]), list(ex.get("also_failing", []))
    present = [jobs[n] for n in required if n in jobs] + [jobs[n] for n in also if n in jobs]
    executor = {"suite": ex["through"], "worker": present[0]["worker"] if present else None, "job_ids": [j["job_id"] for j in present], "sandbox_destroyed": bool(report.get("sandbox_destroyed")), "source_tree_unchanged": bool(report.get("source_tree_unchanged"))}
    refs = [{"kind": "job_record", "ref": j["job_id"], "job": j["check"], "verdict": j["verdict"], "stdout_digest": j["stdout_digest"], "stderr_digest": j["stderr_digest"]} for j in present]
    refs += [{"kind": "verification_report", "ref": report["report_hash"], "run_id": report["run_id"]}, {"kind": "patch", "ref": subject["patch_hash"]}, {"kind": "revision", "ref": subject["base_revision"]}, {"kind": "scope_contract", "ref": subject["scope_contract_hash"]}]
    refs += [{"kind": f"report:{fld}", "ref": lga.sha256_digest(lga.canonical_json(report.get(fld)))} for fld in ex.get("report_fields", []) if report.get(fld) is not None]
    diags = [_job_diag(j) for j in present]
    run_id = report.get("run_id")
    missing = [n for n in required if n not in jobs]
    verdicts = [j["verdict"] for j in present]
    if any(v == "FAIL" for v in verdicts):
        bad = [j for j in present if j["verdict"] == "FAIL"]
        return typed_result(check, "fail", subject, executed=True, executor=executor, evidence_refs=refs, summary="; ".join(f"{j['check']}: {j['summary']}" for j in bad), reasons=[f"{j['check']} FAIL: {j['summary']}" for j in bad], run_id=run_id, diagnostics=diags, registry=registry)
    if missing:
        stopper = next((j for j in report.get("jobs", []) if j["verdict"] != "PASS"), None)
        why = f"runner stopped at {stopper['check']} ({stopper['verdict']}: {stopper['summary']})" if stopper else "runner did not reach this job"
        return typed_result(check, "blocked", subject, executed=False, executor=executor, evidence_refs=refs, summary=f"not executed: {', '.join(missing)} never ran", reasons=[f"{n} not executed — {why}" for n in missing], run_id=run_id, diagnostics=diags, registry=registry)
    if any(v == "INDETERMINATE" for v in verdicts):
        ind = [j for j in present if j["verdict"] == "INDETERMINATE"]
        return typed_result(check, "indeterminate", subject, executed=True, executor=executor, evidence_refs=refs, summary="; ".join(f"{j['check']}: {j['summary']}" for j in ind), reasons=[f"{j['check']} INDETERMINATE: {j['summary']}" for j in ind], run_id=run_id, diagnostics=diags, registry=registry)
    if not report.get("source_tree_unchanged") or not report.get("sandbox_destroyed"):
        return typed_result(check, "fail", subject, executed=True, executor=executor, evidence_refs=refs, summary="verification touched the source tree or left its sandbox", reasons=["isolation violated: source_tree_unchanged/sandbox_destroyed is false"], run_id=run_id, diagnostics=diags, registry=registry)
    return typed_result(check, "pass", subject, executed=True, executor=executor, evidence_refs=refs, summary="; ".join(f"{j['check']}: {j['summary']}" for j in present), run_id=run_id, diagnostics=diags, registry=registry)


def derive_results(report: Mapping[str, Any], *, binding: Any, contract: Mapping[str, Any], candidate: Mapping[str, Any], checks: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    """One typed result per declared check, derived from one runner report over the exact subject."""
    from . import verification_runner as vr
    vr.verify_report_hash(report)
    ck = checks or load_checks(registry=registry)
    subject = subject_of(binding, contract, candidate)
    return [derive_result(c, report, subject, registry=registry) for c in ck["checks"].values()]


def run_checks(binding: Any, contract: Mapping[str, Any], candidate: Mapping[str, Any], patch: bytes, sandbox_parent: Path, *, timeout: int | None = None, run_tests: bool = True, select_tests: Sequence[str] | None = None,
               checks: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Execute every declared check against the exact candidate hash and the authorized revision: the SLICE-06 runner
    applies the patch only inside a detached worktree pinned to ``binding.base_revision`` (verify_candidate_hash refuses
    a patch that does not match the candidate before any sandbox exists) and every typed result is derived from the
    job records it wrote. Returns (report, results)."""
    from . import patch_generator as pg
    from . import verification_runner as vr
    pg.verify_candidate_hash(candidate, patch)
    subject = subject_of(binding, contract, candidate)
    started, t0 = _now(), time.monotonic()
    ru0 = resource.getrusage(resource.RUSAGE_CHILDREN)
    kw: dict[str, Any] = {"run_tests": run_tests, "select_tests": select_tests}
    if timeout:
        kw["timeout"] = int(timeout)
    report = json.loads(vr.verify_candidate(binding, contract, candidate, patch, Path(sandbox_parent), **kw).to_json())
    ru1 = resource.getrusage(resource.RUSAGE_CHILDREN)
    ctx = {"subject": subject, "started_at": started, "finished_at": _now(), "duration_s": round(time.monotonic() - t0, 3), "rusage_before": ru0, "rusage_after": ru1, "binding": binding, "contract": contract, "candidate": candidate}
    results = derive_results(report, binding=binding, contract=contract, candidate=candidate, checks=checks, registry=registry)
    for hook in _RESULT_HOOKS:
        hook(results, report, ctx)
    return report, results


__all__ += ["TAIL_BYTES", "derive_result", "derive_results", "register_result_hook", "run_checks"]


# --------------------------------------------------------------------------- #
# T03 — the gate: approval / application / release consume typed check results (receipts derived from executed jobs)
# and nothing else — a planner or model assertion is not an input; missing, stale, skipped, blocked, indeterminate,
# failed or tampered mandatory results block. (Pattern: only an explicit, executed verdict satisfies a gate — a defaulted
# success is unsatisfied; inspected in amplifier-bundle-attractor's goal-gate enforcement, MIT; no code copied.)
# --------------------------------------------------------------------------- #
GATE_STATUSES = ("satisfied", "missing", "failed", "blocked", "indeterminate", "stale", "skipped", "tampered")
DEFAULT_MAX_AGE_S = 86400


def _age_s(produced_at: str, now: str) -> float:
    a = datetime.fromisoformat(produced_at.replace("Z", "+00:00")); b = datetime.fromisoformat(now.replace("Z", "+00:00"))
    return (b - a).total_seconds()


def gate(results: Sequence[Mapping[str, Any]], subject: Mapping[str, Any], *, checks: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None, now: str | None = None, max_age_s: int | None = None) -> dict[str, Any]:
    """Evaluate every declared check against the exact subject. PROCEED only when every mandatory check has one
    untampered, executed, fresh result whose typed result is ``pass``; every other state names its reason and blocks."""
    ck = checks or load_checks(registry=registry)
    by = results_by_check(results)
    per: dict[str, dict[str, Any]] = {}
    blocking: list[str] = []
    for cid, c in ck["checks"].items():
        g = c.get("gate") or {}
        limit = int(max_age_s if max_age_s is not None else g.get("max_age_s", DEFAULT_MAX_AGE_S))
        r = by.get(cid)
        if r is None:
            status, reason = "missing", "no result exists for this mandatory check"
        else:
            try:
                verify_result(r, registry=registry)
            except lga.AdapterError as exc:
                status, reason = "tampered", str(exc)
            else:
                mismatch = [k for k in SUBJECT_FIELDS if r["subject"].get(k) != subject.get(k)]
                if mismatch:
                    status, reason = "stale", f"result describes another {'/'.join(mismatch)} than the subject under decision"
                elif now and _age_s(r["produced_at"], now) > limit:
                    status, reason = "stale", f"result is older than {limit}s"
                elif not r.get("executed"):
                    status, reason = "skipped", f"check was not executed: {'; '.join(r.get('reasons') or ['no reason recorded'])}"
                elif r["result"] == "pass":
                    status, reason = "satisfied", r["summary"]
                elif r["result"] == "fail":
                    status, reason = "failed", "; ".join(r.get("reasons") or [r["summary"]])
                else:
                    status, reason = r["result"], "; ".join(r.get("reasons") or [r["summary"]])
        per[cid] = {"status": status, "reason": reason, "result": r.get("result") if r else None, "result_hash": r.get("result_hash") if r else None, "evidence_refs": len(r.get("evidence_refs", [])) if r else 0}
        if status != "satisfied":
            blocking.append(cid)
    decision = {"record_schema": f"{NS}/GateDecision", "decision": "PROCEED" if not blocking else "BLOCK", "subject": {k: subject.get(k) for k in SUBJECT_FIELDS}, "mandatory": list(ck["checks"]), "per_check": per, "blocking": blocking,
                "checks_hash": ck["computed_hash"], "consumes": "verification_check_result receipts derived from executed sandbox jobs; planner/model assertions are not inputs", "evaluated_at": now or _now()}
    decision["decision_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in decision.items() if k not in ("decision_hash", "evaluated_at")}))
    return decision


def require_gate(results: Sequence[Mapping[str, Any]], subject: Mapping[str, Any], *, stage: str, **kw: Any) -> dict[str, Any]:
    """Fail closed at approval/application/release: raise ``verify.gate_blocked`` naming every blocking check."""
    d = gate(results, subject, **kw)
    if d["decision"] != "PROCEED":
        raise CheckRefusal("verify.gate_blocked", f"{stage}: verification gate BLOCK on {', '.join(d['blocking'])} — " + "; ".join(f"{c} {d['per_check'][c]['status']} ({d['per_check'][c]['reason']})" for c in d["blocking"]))
    return d


def assert_symbol_scope(worktree: Path, root: Path, revision: str, candidate: Mapping[str, Any], report: Mapping[str, Any]) -> dict[str, Any]:
    """VERIFY-05-T03 at the application boundary: re-derive the Suite 40.2 symbol change set in the applied worktree and
    require it to equal the one sealed in the verified report (report_hash-bound) — the symbols actually changed are
    exactly the symbols that were verified and approved."""
    from . import verification_runner as vr
    reviewed = report.get("symbol_changes")
    if not reviewed:
        raise CheckRefusal("verify.symbol_scope_missing", "the verification report carries no sealed symbol change set (VERIFY-05); application refused")
    changed = list(lga.changed_paths(worktree, revision))
    ok, msg, out = vr._symbol_diff(root, worktree, revision, changed, {PurePosixPath(p) for p in candidate["canonical_paths"]})
    actual = json.loads(out.decode("utf-8"))
    if not ok or actual["changed_symbols"] != reviewed["changed_symbols"] or actual["files"] != reviewed["files"]:
        raise CheckRefusal("verify.symbol_scope_mismatch", f"applied symbol changes differ from the verified/approved set: {msg}")
    return actual


__all__ += ["DEFAULT_MAX_AGE_S", "GATE_STATUSES", "assert_symbol_scope", "gate", "require_gate"]


# --------------------------------------------------------------------------- #
# T04 — reproducibility capture: stdout/stderr diagnostics (already sealed per job), tool versions, fixture/environment
# identity, timing, resource usage and artifact hashes ride with every result under ``reproducibility`` (outside the
# sealed body — the verdict never depends on wall-clock or host facts) with a fingerprint over the identity-bearing parts
# --------------------------------------------------------------------------- #
def capture_environment() -> dict[str, Any]:
    """Tool versions and host identity of the verifying environment (never secrets: only the scrubbed env key names)."""
    from . import verification_runner as vr
    try:
        git_v = subprocess.run(["git", "--version"], capture_output=True, text=True, timeout=10).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        git_v = "unavailable"
    return {"tool_versions": {"python": platform.python_version(), "python_implementation": platform.python_implementation(), "git": git_v, "verification_runner": f"{vr.ADAPTER_ID}/{vr.ADAPTER_VERSION}", "verification_checks": f"{ADAPTER_ID}/{ADAPTER_VERSION}"},
            "environment": {"platform": platform.platform(), "machine": platform.machine(), "os": os.name, "scrubbed_env_keys": sorted(vr._scrubbed_env()), "locale": "C", "network": "no proxy; git prompts disabled"}}


def _rusage_delta(a: Any, b: Any) -> dict[str, Any]:
    return {"utime_s": round(b.ru_utime - a.ru_utime, 4), "stime_s": round(b.ru_stime - a.ru_stime, 4), "maxrss_kb": int(b.ru_maxrss), "minor_faults": int(b.ru_minflt - a.ru_minflt), "block_in": int(b.ru_inblock - a.ru_inblock), "block_out": int(b.ru_oublock - a.ru_oublock), "scope": "RUSAGE_CHILDREN delta across the whole runner call (all sandbox jobs)"}


def _regression_definitions_hash(report: Mapping[str, Any]) -> str | None:
    for j in report.get("jobs", []):
        if j["check"] == "regression":
            head = (j.get("stdout_excerpt") or "").split("\n", 1)[0]
            if head.startswith("{"):
                try:
                    return json.loads(head).get("definitions_hash")
                except ValueError:
                    return None
    return None


def reproducibility(result: Mapping[str, Any], report: Mapping[str, Any], ctx: Mapping[str, Any], *, checks: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Everything needed to re-run this check and compare: what ran (tool versions), where (environment), on what
    (fixture identity: repository/revision/snapshot/base tree + the definitions the check was judged by), when and how
    long (timing), at what cost (resource usage), and the exact artifacts (hashes). Diagnostics are in the sealed body."""
    env = capture_environment()
    jobs = {j["job_id"]: j for j in report.get("jobs", [])}
    mine = [jobs[i] for i in result["executor"].get("job_ids", []) if i in jobs]
    per_job = []
    for j in mine:
        try:
            dur = _age_s(j["started_at"], j["finished_at"])
        except (ValueError, TypeError):
            dur = None
        per_job.append({"job_id": j["job_id"], "check": j["check"], "started_at": j["started_at"], "finished_at": j["finished_at"], "duration_s": dur, "resolution": "1s (job timestamps)"})
    ah = report.get("artifact_hashes") or {}
    artifacts = {"patch_hash": result["subject"]["patch_hash"], "report_hash": report.get("report_hash"), "base_tree": ah.get("base_tree"), "changed_files": dict(ah.get("changed_files") or {}),
                 "stdout_digests": {j["check"]: j["stdout_digest"] for j in mine}, "stderr_digests": {j["check"]: j["stderr_digest"] for j in mine}, "symbol_changes": lga.sha256_digest(lga.canonical_json(report["symbol_changes"])) if report.get("symbol_changes") else None}
    ck = checks or load_checks()
    fixture = {"repository_id": result["subject"]["repository_id"], "base_revision": result["subject"]["base_revision"], "source_snapshot_hash": result["subject"]["source_snapshot_hash"], "base_tree": ah.get("base_tree"),
               "scope_contract_hash": result["subject"]["scope_contract_hash"], "checks_hash": ck["computed_hash"], "regression_definitions_hash": _regression_definitions_hash(report), "sandbox": "detached worktree pinned to base_revision; destroyed after the run"}
    rep = {"tool_versions": env["tool_versions"], "environment": env["environment"], "fixture_identity": fixture,
           "timing": {"started_at": ctx.get("started_at"), "finished_at": ctx.get("finished_at"), "duration_s": ctx.get("duration_s"), "jobs": per_job},
           "resource_usage": _rusage_delta(ctx["rusage_before"], ctx["rusage_after"]) if ctx.get("rusage_before") is not None and ctx.get("rusage_after") is not None else None,
           "artifact_hashes": artifacts, "captured_by": f"adapters/verification_checks/{ADAPTER_VERSION}"}
    rep["fingerprint"] = lga.sha256_digest(lga.canonical_json({"tools": rep["tool_versions"], "env": {k: v for k, v in rep["environment"].items() if k != "scrubbed_env_keys"}, "fixture": fixture, "artifacts": artifacts, "result_hash": result["result_hash"]}))
    return rep


def verify_reproducibility(result: Mapping[str, Any]) -> None:
    """Fail closed if a result's reproducibility block was edited after capture (its fingerprint no longer matches)."""
    rep = result.get("reproducibility")
    if not rep:
        raise CheckRefusal("verify.reproducibility_missing", f"{result.get('check_id')}: no reproducibility capture")
    expected = lga.sha256_digest(lga.canonical_json({"tools": rep["tool_versions"], "env": {k: v for k, v in rep["environment"].items() if k != "scrubbed_env_keys"}, "fixture": rep["fixture_identity"], "artifacts": rep["artifact_hashes"], "result_hash": result["result_hash"]}))
    if expected != rep.get("fingerprint"):
        raise CheckRefusal("verify.reproducibility_tampered", f"{result.get('check_id')}: reproducibility fingerprint mismatch")


def _repro_hook(results: list[dict[str, Any]], report: Mapping[str, Any], ctx: Mapping[str, Any]) -> None:
    for r in results:
        r["reproducibility"] = reproducibility(r, report, ctx)


register_result_hook(_repro_hook)

__all__ += ["capture_environment", "reproducibility", "verify_reproducibility"]
