"""Scoped PR Builder — guardrail rules as machine-readable, executable policy (Phase 02 / PAPER-GRD-*).

``guardrails/RULES.json`` encodes each paper guardrail as a versioned rule: the statement, the deterministic
predicate kind, its parameters, the capability it evaluates under (Suite 55.3 Action Scope), the effects it
evaluates on, the authoritative suites it composes, a facts schema, and examples for every state. ``evaluate``
is the only decision path and yields exactly one of four explicit states:

    PASS        the facts satisfy the rule
    DENY        the facts violate the rule (or a required human approval is absent)
    ABSTAIN     the facts needed to decide are missing — never treated as PASS, never defaulted
    DIAGNOSTIC  the facts are present but inconsistent/malformed — refuse and surface the defect

No implicit fallback can widen scope or authority: every state except PASS blocks the effect, and every
decision is a hash-bound ``guardrail_decision`` record (contracts/REGISTRY.json) that carries the facts hash,
the reason and the evidence that produced it.

Build provenance: BUILD_NEW (stdlib). GRD-01 size bands follow the PullRequestQuantifier default profile
(MIT, pattern only, recorded at SLICE-03). Patterns per item are recorded in ../PROVENANCE.jsonl.
"""
from __future__ import annotations

import fnmatch
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from . import contracts as C
from . import local_git_adapter as lga

RULES_VERSION = "scoped_pr_builder.guardrail_rules/0.1.0"
RULES_PATH = Path(__file__).resolve().parent.parent / "guardrails" / "RULES.json"
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
STATES = ("PASS", "DENY", "ABSTAIN", "DIAGNOSTIC")
KINDS = ("bounded_size", "structure_change", "core_logic_human", "explicit_review")
RULE_REQUIRED = ("rule_id", "version", "title", "statement", "kind", "capability", "evaluates_on", "authoritative_suites", "requires_human", "parameters", "facts_schema", "states", "examples", "introduced_by")
DECL_RE = re.compile(r"^\+\s*(class|record|schema|module|service|agent|interface|workspace|experiment|def |function )\b")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_rules(path: Path = RULES_PATH, *, registry: Mapping[str, Any] | None = None, repo_root: Path | None = None) -> dict[str, Any]:
    """Load and self-validate the rule registry (exact suite-file binding; every state exampled)."""
    if not Path(path).is_file():
        raise lga.AdapterError("guardrail.registry_missing", f"rule registry not found: {path}")
    reg = registry or C.load_registry()
    corpus_root = Path(repo_root) if repo_root is not None else REPO_ROOT
    # An installed generic package intentionally does not bundle Suites 01–66. In a source/corpus checkout, exact
    # suite bindings remain mandatory. Supplying repo_root explicitly also requests strict binding.
    strict_suite_binding = repo_root is not None or (corpus_root / "Diff Patch and Review").is_dir()
    rules = json.loads(Path(path).read_text(encoding="utf-8"))
    if rules.get("rules_version") != RULES_VERSION:
        raise lga.AdapterError("guardrail.registry_invalid", "unsupported rules_version")
    entries = rules.get("rules")
    if not isinstance(entries, dict) or not entries:
        raise lga.AdapterError("guardrail.registry_invalid", "no rules declared")
    for rid, r in entries.items():
        missing = [k for k in RULE_REQUIRED if k not in r]
        if missing or r["rule_id"] != rid:
            raise lga.AdapterError("guardrail.registry_invalid", f"{rid}: missing {missing} or id mismatch")
        if r["kind"] not in KINDS or not C.SEMVER_RE.match(r["version"]):
            raise lga.AdapterError("guardrail.registry_invalid", f"{rid}: unknown kind or bad version")
        for f in r["authoritative_suites"]:
            if strict_suite_binding and not (corpus_root / f).is_file():
                raise lga.AdapterError("guardrail.suite_unbound", f"{rid}: authoritative suite file does not exist: {f}")
        if set(r["states"]) != set(STATES) or not all(s.lower() in r["examples"] for s in STATES):
            raise lga.AdapterError("guardrail.registry_invalid", f"{rid}: every state needs a meaning and an example")
        if not r["evaluates_on"]:
            raise lga.AdapterError("guardrail.registry_invalid", f"{rid}: evaluates_on is empty")
        try:
            C.validate(r["facts_schema"], r["examples"]["pass"], path=f"$.{rid}.examples.pass", registry=reg)
        except C.SchemaError as exc:
            raise lga.AdapterError("guardrail.registry_invalid", f"{rid}: pass example does not satisfy facts_schema: {exc}") from exc
    body = {k: v for k, v in rules.items() if k != "rules_hash"}
    rules["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    rules["authoritative_suites_bound"] = strict_suite_binding
    return rules


# --------------------------------------------------------------------------- #
# Predicates (deterministic, one per kind)                                       #
# --------------------------------------------------------------------------- #
def _band(lines: int, bands: Mapping[str, int]) -> str:
    for name, ceiling in bands.items():
        if lines <= ceiling:
            return name
    return "beyond_review"


def _p_bounded_size(p: Mapping[str, Any], f: Mapping[str, Any]) -> tuple[str, str, list[str]]:
    files, lines = f["changed_files"], f["lines_changed"]
    max_files = min(f["max_changed_files"], p["hard_max_changed_files"])
    max_lines = min(f["max_diff_lines"], p["hard_max_diff_lines"])
    if files < 0 or lines < 0 or (files == 0) != (lines == 0):
        return "DIAGNOSTIC", f"inconsistent size facts: files={files} lines={lines}", []
    band = _band(lines, p["size_bands"])
    order = list(p["size_bands"]) + ["beyond_review"]
    ceiling = f.get("size_band_ceiling") or p["reviewable_band_ceiling"]
    ev = [f"changed_files={files}/{max_files}", f"lines_changed={lines}/{max_lines}", f"size_band={band} (ceiling {ceiling})"]
    if files > max_files:
        return "DENY", f"{files} changed files exceed the reviewable maximum {max_files}", ev
    if lines > max_lines:
        return "DENY", f"{lines} changed lines exceed the reviewable maximum {max_lines}", ev
    if order.index(band) > order.index(ceiling):
        return "DENY", f"size band {band} is beyond the contract ceiling {ceiling}", ev
    return "PASS", f"{files} files / {lines} lines within limits (band {band})", ev


def _p_structure_change(p: Mapping[str, Any], f: Mapping[str, Any]) -> tuple[str, str, list[str]]:
    statuses = f["file_statuses"]
    unknown = [s for s in statuses if s["status"] not in p["known_statuses"]]
    if unknown:
        return "DIAGNOSTIC", f"unknown file status in {unknown[:3]}", []
    roots = tuple(lga.relative_path(a) for a in f["allowed_paths"])
    structural = [s for s in statuses if s["status"] != "modified"]
    out_of_scope = [s["path"] for s in statuses if not lga.within(lga.relative_path(s["path"]), roots)]
    added_decls = int(f.get("added_declarations", 0))
    ev = [f"structural_changes={[(s['path'], s['status']) for s in structural]}", f"out_of_scope={out_of_scope}", f"added_declarations={added_decls}"]
    needs_approval = bool(structural or out_of_scope or added_decls > 0)
    if not needs_approval:
        return "PASS", "no new files, deletions, renames, declarations or out-of-scope paths", ev
    ap = f.get("approval") or {}
    if ap.get("present") and ap.get("decision") == "APPROVE" and p["approval_scope"] in (ap.get("approves") or []):
        ev.append(f"approval={ap.get('approver_identity')} scope {p['approval_scope']}")
        return "PASS", "structural change explicitly approved by a human for scope " + p["approval_scope"], ev
    return "DENY", "new files / restructuring / new declarations / out-of-scope paths require explicit human approval", ev


def _p_core_logic_human(p: Mapping[str, Any], f: Mapping[str, Any]) -> tuple[str, str, list[str]]:
    touched = f["touched_symbols"]
    if any(t["in_degree"] < 0 or t["lines_changed"] < 0 for t in touched):
        return "DIAGNOSTIC", "negative impact counters", []
    core = []
    for t in touched:
        by_path = any(fnmatch.fnmatchcase(t["path"], pat) for pat in p["core_path_patterns"])
        if (t["in_degree"] >= p["in_degree_threshold"] or by_path) and t["lines_changed"] >= p["substantial_lines"]:
            core.append(t)
    ev = [f"touched={len(touched)}", f"substantial_core={[c['symbol'] for c in core]}"]
    if not core:
        return "PASS", "no substantial change to core business logic", ev
    h = f.get("human") or {}
    if h.get("involved") and h.get("approver_identity") and h.get("channel"):
        ev.append(f"human={h['approver_identity']} via {h['channel']}")
        return "PASS", "substantial core change with explicit human involvement", ev
    return "DENY", f"substantial change to core logic ({', '.join(c['symbol'] for c in core)}) without human involvement", ev


def _p_explicit_review(p: Mapping[str, Any], f: Mapping[str, Any]) -> tuple[str, str, list[str]]:
    r = f["receipt"]
    ev = [f"present={r.get('present')}", f"verified={r.get('verified')}", f"decision={r.get('decision')}", f"bound={r.get('bound_to_candidate')}", f"expired={r.get('expired')}"]
    if not r.get("present"):
        return "DENY", "no human review decision exists for this diff", ev
    if r.get("verified") is None:
        return "DIAGNOSTIC", "receipt present but never verified against the ledger", ev
    if not r.get("verified") or not r.get("bound_to_candidate"):
        return "DENY", "review receipt is not a verified, hash-bound decision for this candidate", ev
    if r.get("decision") != "APPROVE":
        return "DENY", f"human decision is {r.get('decision')}; the diff stays subject to review", ev
    if r.get("expired"):
        return "DENY", "review approval has expired; a fresh explicit review is required", ev
    return "PASS", "explicit, verified, unexpired human APPROVE bound to this diff", ev


PREDICATES = {"bounded_size": _p_bounded_size, "structure_change": _p_structure_change, "core_logic_human": _p_core_logic_human, "explicit_review": _p_explicit_review}


# --------------------------------------------------------------------------- #
# Evaluation                                                                    #
# --------------------------------------------------------------------------- #
def evaluate(rule_id: str, facts: Any, *, effect: str, rules: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Evaluate one rule on one facts object for one effect; returns a validated guardrail_decision record."""
    reg = registry or C.load_registry()
    rs = rules or load_rules(registry=reg)
    r = rs["rules"].get(rule_id)
    if r is None:
        raise lga.AdapterError("guardrail.unknown", f"no such rule {rule_id!r}")
    if effect not in r["evaluates_on"]:
        raise lga.AdapterError("guardrail.not_applicable", f"{rule_id} does not evaluate on {effect!r}")
    state, reason, evidence = "ABSTAIN", "facts missing; the rule cannot be decided and the effect is withheld", []
    if isinstance(facts, Mapping) and facts:
        missing = [k for k in r["facts_schema"].get("required", []) if k not in facts]
        if missing:
            state, reason = "ABSTAIN", f"facts missing: {missing}; the effect is withheld (no fallback)"
        else:
            try:
                C.validate(r["facts_schema"], facts, path="$.facts", registry=reg)
                state, reason, evidence = PREDICATES[r["kind"]](r["parameters"], facts)
            except C.SchemaError as exc:
                state, reason = "DIAGNOSTIC", f"facts malformed: {exc}"
    decision = {"rule_id": rule_id, "rule_version": r["version"], "title": r["title"], "kind": r["kind"], "effect": effect, "capability": r["capability"], "state": state, "blocking": state != "PASS",
                "reason": reason, "evidence": evidence, "requires_human": bool(r["requires_human"]), "facts_hash": lga.sha256_digest(lga.canonical_json(facts)), "evaluated_at": _now()}
    decision["decision_hash"] = lga.sha256_digest(lga.canonical_json(decision))
    C.validate_payload("guardrail_decision", decision, registry=reg)
    return decision


def evaluate_all(facts_by_rule: Mapping[str, Any], *, effect: str, rules: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None, rule_ids: Sequence[str] | None = None) -> list[dict[str, Any]]:
    """Evaluate every rule that applies to ``effect`` (optionally only ``rule_ids``); a rule without facts ABSTAINs (blocks)."""
    reg = registry or C.load_registry()
    rs = rules or load_rules(registry=reg)
    out = []
    for rid, r in rs["rules"].items():
        if effect in r["evaluates_on"] and (rule_ids is None or rid in rule_ids):
            out.append(evaluate(rid, facts_by_rule.get(rid), effect=effect, rules=rs, registry=reg))
    return out


__all__ = ["KINDS", "PREDICATES", "RULES_PATH", "RULES_VERSION", "STATES", "evaluate", "evaluate_all", "load_rules"]


# --------------------------------------------------------------------------- #
# T02 — fact providers: compose the authoritative suites; derive facts from real  #
# overlay artifacts (no policy duplicated, no model input)                       #
# --------------------------------------------------------------------------- #
def _diff_file_blocks(patch_text: str) -> list[dict[str, Any]]:
    """Parse a unified diff into per-file blocks: path, status (added/deleted/renamed/modified), +/- line counts, added declaration count."""
    blocks: list[dict[str, Any]] = []
    cur: dict[str, Any] | None = None
    for line in patch_text.splitlines():
        if line.startswith("diff --git "):
            parts = line.split(" ")
            path = parts[3][2:] if len(parts) >= 4 and parts[3].startswith("b/") else parts[-1]
            cur = {"path": path, "status": "modified", "added": 0, "deleted": 0, "added_declarations": 0, "_added_decl_lines": [], "_deleted_decl_lines": []}
            blocks.append(cur)
        elif cur is None:
            continue
        elif line.startswith("new file mode"):
            cur["status"] = "added"
        elif line.startswith("deleted file mode"):
            cur["status"] = "deleted"
        elif line.startswith("rename from") or line.startswith("rename to"):
            cur["status"] = "renamed"
        elif line.startswith("+++") or line.startswith("---"):
            continue
        elif line.startswith("+"):
            cur["added"] += 1
            if DECL_RE.match(line):
                cur["_added_decl_lines"].append(line[1:].strip())
        elif line.startswith("-"):
            cur["deleted"] += 1
            if re.match(r"^-\s*(class|record|schema|module|service|agent|interface|workspace|experiment|def |function )\b", line):
                cur["_deleted_decl_lines"].append(line[1:].strip())
    for b in blocks:
        b["added_declarations"] = len(set(b.pop("_added_decl_lines", [])) - set(b.pop("_deleted_decl_lines", [])))
    return blocks


def facts_bounded_size(candidate: Mapping[str, Any], contract: Mapping[str, Any]) -> dict[str, Any]:
    """GRD-01 facts from the Suite 50.1 bounded diff plan carried by a CandidatePatch and the scope contract (50.6)."""
    return {"changed_files": int(candidate["files_changed"]), "lines_changed": int(candidate["lines_added"]) + int(candidate["lines_deleted"]),
            "max_changed_files": int(contract["max_changed_files"]), "max_diff_lines": int(contract["max_diff_lines"]), "size_band_ceiling": contract["size_band_ceiling"],
            "source": f"patch_generator.CandidatePatch {candidate['candidate_id'][:23]} / scope {contract['scope_contract_hash'][:23]}"}


def facts_structure_change(patch_text: str, contract: Mapping[str, Any], *, approval: Mapping[str, Any] | None = None, approved_scopes: Sequence[str] = ()) -> dict[str, Any]:
    """GRD-02 facts from the unified diff (git name-status semantics), the scope contract's allowed paths and — when a
    verified Suite 50.5 receipt is supplied — the explicit scopes the human approved."""
    blocks = _diff_file_blocks(patch_text)
    facts: dict[str, Any] = {"file_statuses": [{"path": b["path"], "status": b["status"]} for b in blocks], "allowed_paths": list(contract["allowed_paths"]),
                             "added_declarations": sum(b["added_declarations"] for b in blocks), "source": "unified diff blocks + scope contract allowed_paths"}
    if approval is not None:
        facts["approval"] = {"present": True, "decision": approval.get("decision"), "approver_identity": approval.get("approver_identity"), "approves": list(approved_scopes), "receipt_hash": approval.get("receipt_hash")}
    return facts


def facts_core_logic(patch_text: str, symbols: Sequence[Mapping[str, Any]], dependencies: Sequence[Mapping[str, Any]], *, human: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """GRD-03 facts from the diff and the Suite 40.2/40.3 symbol + dependency records: one touched entry per changed
    file (module symbol when declared), in-degree = number of dependency edges targeting that file."""
    blocks = _diff_file_blocks(patch_text)
    by_file: dict[str, list[Mapping[str, Any]]] = {}
    for s in symbols:
        by_file.setdefault(s["file_path"], []).append(s)
    touched = []
    for b in blocks:
        path = b["path"]
        mods = [s for s in by_file.get(path, []) if s.get("symbol_kind") == "module"]
        name = mods[0]["qualified_name"] if mods else (by_file.get(path, [{}])[0].get("qualified_name") or path)
        base = path.rsplit("/", 1)[-1]
        in_degree = sum(1 for d in dependencies if d.get("target_node") in (path, base) or str(d.get("target_node", "")).endswith("/" + base))
        touched.append({"symbol": name, "path": path, "in_degree": in_degree, "lines_changed": b["added"] + b["deleted"]})
    facts: dict[str, Any] = {"touched_symbols": touched, "source": "unified diff blocks × repository_context_adapter symbols/dependencies (Suite 40.2/40.3)"}
    if human is not None:
        facts["human"] = dict(human)
    return facts


def facts_explicit_review(receipt: Mapping[str, Any] | None, *, candidate: Mapping[str, Any], card: Mapping[str, Any], report: Mapping[str, Any], run_dir: Path | None = None, key: bytes | None = None, now: Any = None) -> dict[str, Any]:
    """GRD-04 facts from the Suite 50.5 receipt path: presence, ledger verification (approval_adapter.verify_receipt when a
    key and run_dir are supplied; otherwise verified=null → DIAGNOSTIC), decision, hash binding and expiry."""
    from . import approval_adapter as aa
    if receipt is None:
        return {"receipt": {"present": False}, "source": "no receipt supplied"}
    bound = all(receipt.get(f) == v for f, v in {"candidate_id": candidate["candidate_id"], "patch_hash": candidate["patch_hash"], "base_revision": candidate["base_revision"],
                                                   "scope_contract_hash": candidate["scope_contract_hash"], "card_hash": card["card_hash"], "verification_report_hash": report["report_hash"]}.items())
    verified: bool | None = None
    expired: bool | None = None
    if run_dir is not None and key is not None:
        try:
            aa.verify_receipt(run_dir, key, receipt, candidate=candidate, card=card, report=report, now=now)
            verified, expired = True, False
        except lga.AdapterError as exc:
            # ledger-verified receipts that fail on decision / expiry / supersession are still *verified* facts;
            # only ledger/binding failures mean the receipt cannot be trusted at all
            verified = exc.code in ("approval.not_approved", "approval.expired", "approval.superseded")
            expired = exc.code == "approval.expired"
            if exc.code == "approval.superseded":
                receipt = dict(receipt, decision="SUPERSEDED")
    return {"receipt": {"present": True, "verified": verified, "decision": receipt.get("decision"), "bound_to_candidate": bound, "expired": expired,
                        "approver_identity": receipt.get("approver_identity"), "receipt_hash": receipt.get("receipt_hash")}, "source": "approval_adapter.verify_receipt over approvals/ledger.jsonl"}


FACT_PROVIDERS = {"bounded_size": facts_bounded_size, "structure_change": facts_structure_change, "core_logic_human": facts_core_logic, "explicit_review": facts_explicit_review}
__all__ += ["FACT_PROVIDERS", "facts_bounded_size", "facts_core_logic", "facts_explicit_review", "facts_structure_change"]


# --------------------------------------------------------------------------- #
# T03 — enforcement at orchestration and effect boundaries                        #
# --------------------------------------------------------------------------- #
SEVERITY = {"DIAGNOSTIC": 3, "DENY": 2, "ABSTAIN": 1, "PASS": 0}


class GuardrailRefusal(lga.AdapterError):
    """A blocked effect: carries every decision that was evaluated (PASS ones included) for the audit trail."""

    def __init__(self, code: str, message: str, decisions: Sequence[Mapping[str, Any]]) -> None:
        super().__init__(code, message)
        self.decisions = [dict(d) for d in decisions]


def enforce(effect: str, facts_by_rule: Mapping[str, Any] | None, *, run: Any = None, rules: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None, rule_ids: Sequence[str] | None = None) -> list[dict[str, Any]]:
    """Evaluate every rule that applies to ``effect`` (optionally only ``rule_ids`` — the effect boundary inside an
    adapter enforces the capability that adapter is responsible for); append one audit row per decision on ``run``
    (when given); refuse with ``guardrail.<state>`` if any decision blocks. No fallback: missing facts ABSTAIN and block."""
    decisions = evaluate_all(facts_by_rule or {}, effect=effect, rules=rules, registry=registry, rule_ids=rule_ids)
    if run is not None:
        for d in decisions:
            run._audit(effect="guardrail.evaluate", rule_id=d["rule_id"], guarded_effect=effect, verdict=d["state"], blocking=d["blocking"], reason=d["reason"], decision_hash=d["decision_hash"], evidence=d["evidence"])
    blocking = sorted((d for d in decisions if d["blocking"]), key=lambda d: -SEVERITY[d["state"]])
    if blocking:
        worst = blocking[0]
        raise GuardrailRefusal(f"guardrail.{worst['state'].lower()}", f"{worst['rule_id']} {worst['state']}: {worst['reason']}", decisions)
    return decisions


def apply_time_facts(binding: Any, contract: Mapping[str, Any], candidate: Mapping[str, Any], patch: bytes, card: Mapping[str, Any], report: Mapping[str, Any],
                     receipt: Mapping[str, Any], run_dir: Path, key: bytes, *, approved_scopes: Sequence[str] = ()) -> dict[str, Any]:
    """Facts for every rule at the effect boundary patch.apply_isolated, derived from the artifacts under application."""
    from . import repository_context_adapter as rca
    text = patch.decode("utf-8", errors="replace")
    ctx = rca.build_context(Path(binding.root_path), binding.base_revision)
    human = {"involved": True, "approver_identity": receipt.get("approver_identity"), "channel": receipt.get("approver_channel")} if receipt else None
    return {
        "GRD-01": facts_bounded_size(candidate, contract),
        "GRD-02": facts_structure_change(text, contract, approval=receipt, approved_scopes=approved_scopes),
        "GRD-03": facts_core_logic(text, ctx.symbols, ctx.dependencies, human=human),
        "GRD-04": facts_explicit_review(receipt, candidate=candidate, card=card, report=report, run_dir=run_dir, key=key),
        "CAP-03": facts_atomic_bounded_diff(candidate),
        "CAP-04": facts_halt_on_failure(report, None, step="verification"),
    }


def record_decisions(run_dir: Path, effect: str, candidate_id: str, decisions: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Persist the decision set for one effect on one candidate (run directory, outside the repository)."""
    out = {"effect": effect, "candidate_id": candidate_id, "decisions": [dict(d) for d in decisions], "recorded_at": _now()}
    out["decisions_hash"] = lga.sha256_digest(lga.canonical_json(out["decisions"]))
    p = Path(run_dir) / "guardrails" / f"{effect.replace('.', '_')}-{candidate_id[7:19]}.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(out, indent=2, sort_keys=True), encoding="utf-8")
    return out


__all__ += ["GuardrailRefusal", "SEVERITY", "apply_time_facts", "enforce", "record_decisions"]


# --------------------------------------------------------------------------- #
# T04 — exposure on the human review surface before any state-changing action     #
# --------------------------------------------------------------------------- #
def card_time_facts(candidate: Mapping[str, Any], contract: Mapping[str, Any], patch: bytes, *, context: Any = None, plan: Mapping[str, Any] | None = None,
                    evidence: Sequence[Mapping[str, Any]] | None = None, report: Mapping[str, Any] | None = None, evidence_gaps: Sequence[str] = ()) -> dict[str, Any]:
    """Facts available at review time (before any decision exists): size and structure from the candidate/diff,
    impact from the repository context when supplied, the honest pre-review state for GRD-04 (no receipt), and —
    Phase 03 — the five capability facts from the contract, evidence + plan, candidate and verification report."""
    text = patch.decode("utf-8", errors="replace")
    facts: dict[str, Any] = {"GRD-01": facts_bounded_size(candidate, contract), "GRD-02": facts_structure_change(text, contract), "GRD-04": {"receipt": {"present": False}, "source": "review time: no human decision exists yet"}}
    if context is not None:
        facts["GRD-03"] = facts_core_logic(text, context.symbols, context.dependencies)
    facts["CAP-01"] = facts_scope_intent(contract)
    facts["CAP-03"] = facts_atomic_bounded_diff(candidate)
    if plan is not None and evidence is not None:
        facts["CAP-02"] = facts_analogous_evidence({"evidence": list(evidence)}, plan)
        facts["CAP-05"] = facts_knowledge_gaps(plan, evidence_gaps=evidence_gaps)
    if report is not None:
        facts["CAP-04"] = facts_halt_on_failure(report, plan, step="verification")
    return facts


def card_decisions(facts: Mapping[str, Any], *, rules: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    """One decision per rule for the review card: rules that guard the pending action are evaluated on
    patch.apply_isolated, every other rule on the first effect it declares."""
    reg = registry or C.load_registry()
    rs = rules or load_rules(registry=reg)
    out = []
    for rid, r in rs["rules"].items():
        effect = "patch.apply_isolated" if "patch.apply_isolated" in r["evaluates_on"] else r["evaluates_on"][0]
        out.append(evaluate(rid, facts.get(rid), effect=effect, rules=rs, registry=reg))
    return out


def review_fragment(decisions: Sequence[Mapping[str, Any]], *, effect: str, rules: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Display-only card section: every rule with its statement, current state, current values (evidence),
    blocking reason and what would satisfy it. Never records or implies a decision."""
    rs = rules or load_rules(registry=registry)
    rows = []
    for d in decisions:
        r = rs["rules"][d["rule_id"]]
        exp = r.get("review_exposure") or {}
        rows.append({"rule_id": d["rule_id"], "title": r["title"], "statement": r["statement"], "state": d["state"], "blocking": d["blocking"], "reason": d["reason"], "effect": d["effect"],
                     "current_values": list(d["evidence"]), "capability": d["capability"], "requires_human": d["requires_human"], "satisfied_by": exp.get("satisfied_by", ""), "card_section": exp.get("card_section", "49.7 Capability Contract"), "decision_hash": d["decision_hash"]})
    frag = {"authority": "display_only", "effect": effect, "rules": rows, "all_pass": all(not d["blocking"] for d in decisions), "blocking_reasons": [f"{d['rule_id']} {d['state']}: {d['reason']}" for d in decisions if d["blocking"]],
            "note": "Guardrails are re-evaluated at the effect boundary on live facts; this section shows the state known before the human decision."}
    frag["fragment_hash"] = lga.sha256_digest(lga.canonical_json(frag))
    return frag


def render_fragment_html(frag: Mapping[str, Any], esc: Any) -> str:
    """HTML for the guardrail section (values escaped by the renderer's escaper)."""
    rows = "".join(f"<tr><td>{esc(r['rule_id'])}</td><td>{esc(r['title'])}</td><td class='v-{esc(r['state']).lower()}'>{esc(r['state'])}</td><td>{esc(r['reason'])}</td><td class='mono'>{esc('; '.join(r['current_values']))}</td><td>{esc(r['satisfied_by'])}</td></tr>" for r in frag["rules"])
    head = "All guardrails PASS for the pending action" if frag["all_pass"] else "Blocking: " + "; ".join(frag["blocking_reasons"])
    return f"<h2>Guardrails (paper rules — before {esc(frag['effect'])})</h2><div class=\"banner {'ok' if frag['all_pass'] else 'block'}\">{esc(head)}</div><table><tr><th>rule</th><th>title</th><th>state</th><th>reason</th><th>current values</th><th>satisfied by</th></tr>{rows}</table><p class=\"mono\">{esc(frag['note'])} fragment {esc(frag['fragment_hash'][7:23])}</p>"


__all__ += ["card_time_facts", "render_fragment_html", "review_fragment"]


# --------------------------------------------------------------------------- #
# Phase 03 — core scoped-refactor capabilities as rules (PAPER-CAP-01..05)        #
# --------------------------------------------------------------------------- #
CAP_KINDS = ("scope_intent", "analogous_evidence", "atomic_bounded_diff", "halt_on_failure", "knowledge_gap_surfacing")
KINDS = KINDS + CAP_KINDS
BANDS = ("low", "medium", "high")


def _p_scope_intent(p: Mapping[str, Any], f: Mapping[str, Any]) -> tuple[str, str, list[str]]:
    ev = [f"intent_kind={f['intent_kind']}", f"allowed_paths={len(f['allowed_paths'])}", f"forbidden_paths={len(f.get('forbidden_paths', []))}", f"caps={f['max_changed_files']}f/{f['max_diff_lines']}l", f"hash_verified={f['hash_verified']}"]
    if f["max_changed_files"] < 1 or f["max_diff_lines"] < 1 or set(f["allowed_paths"]) & set(f.get("forbidden_paths", [])):
        return "DIAGNOSTIC", "scope contract is self-contradictory (zero caps or a path both allowed and forbidden)", ev
    if f["intent_kind"] not in p["allowed_kinds"]:
        return "DENY", f"intent kind {f['intent_kind']!r} is not a scoped refactoring intent", ev
    if not f["allowed_paths"]:
        return "DENY", "intent carries no explicit scope boundary (allowed_paths is empty)", ev
    if f["max_changed_files"] > p["hard_max_changed_files"] or f["max_diff_lines"] > p["hard_max_diff_lines"]:
        return "DENY", "requested scope exceeds the overlay hard caps", ev
    if not f["hash_verified"]:
        return "DENY", "scope contract hash does not verify; the intent cannot be trusted", ev
    return "PASS", f"explicitly scoped {f['intent_kind']} intent with a verified contract", ev


def _p_analogous_evidence(p: Mapping[str, Any], f: Mapping[str, Any]) -> tuple[str, str, list[str]]:
    n, refs, known = f["example_count"], f["referenced_examples"], set(f["evidence_ids"])
    conv = f.get("conventions_observed") or {}
    ev = [f"example_count={n}", f"exact_pinned={f['exact_pinned']}", f"referenced={len(refs)}", f"conventions={sorted(k for k, v in conv.items() if v)}", f"plan_status={f['plan_status']}"]
    if n > 0 and not f["exact_pinned"]:
        return "DIAGNOSTIC", "analogous examples are not all exact, pinned locators", ev
    invented = [r for r in refs if r not in known]
    if invented:
        return "DENY", f"the plan cites {len(invented)} example(s) that are not in the retrieved evidence (invented references)", ev
    if f["plan_status"] == "PLANNED" and n < p["min_examples"]:
        return "DENY", f"a plan proceeded with {n} analogous example(s); at least {p['min_examples']} required", ev
    if f["plan_status"] == "ABSTAIN":
        return "PASS", "no sufficient analogous evidence: the plan abstained instead of inventing conventions", ev
    if not any(conv.values()):
        return "DENY", "examples were retrieved but no repository convention was observed from them", ev
    return "PASS", f"{n} exact pinned example(s) inspected; conventions observed: {', '.join(sorted(k for k, v in conv.items() if v))}", ev


def _p_atomic_bounded_diff(p: Mapping[str, Any], f: Mapping[str, Any]) -> tuple[str, str, list[str]]:
    ev = [f"files={f['files_changed']}/{f['threshold_files']}", f"lines={f['lines_changed']}/{f['threshold_lines']}", f"hunks={f['hunks']}", f"single_recipe={f['single_recipe']}", f"inert={f['inert']}"]
    if (f["lines_changed"] > 0) != (f["hunks"] > 0) or f["threshold_files"] < 1 or f["threshold_lines"] < 1:
        return "DIAGNOSTIC", "diff statistics are inconsistent (lines without hunks or zero thresholds)", ev
    if not f["inert"]:
        return "DENY", "candidate is not inert (it touched the source worktree)", ev
    if not f["single_recipe"]:
        return "DENY", "candidate bundles more than one operation; diffs must be atomic", ev
    if f["files_changed"] > f["threshold_files"] or f["lines_changed"] > f["threshold_lines"]:
        return "DENY", f"diff exceeds the configured threshold ({f['threshold_files']} files / {f['threshold_lines']} lines)", ev
    if f["hunks"] > p["max_hunks_per_file"] * max(1, f["files_changed"]):
        return "DENY", f"{f['hunks']} hunks exceed {p['max_hunks_per_file']} per file; split the diff", ev
    return "PASS", f"atomic inert diff within the configured threshold ({f['files_changed']} files / {f['lines_changed']} lines / {f['hunks']} hunks)", ev


def _p_halt_on_failure(p: Mapping[str, Any], f: Mapping[str, Any]) -> tuple[str, str, list[str]]:
    diags = f.get("diagnostics") or []
    ev = [f"step={f['step']}", f"verdict={f['verdict']}", f"confidence_band={f['confidence_band']}", f"evidence_sufficiency={f['evidence_sufficiency']}", f"diagnostics={len(diags)}"]
    if f["verdict"] in ("FAIL", "INDETERMINATE") and not diags:
        return "DIAGNOSTIC", f"step {f['step']} reported {f['verdict']} without diagnostics; a halt must explain itself", ev
    if f["verdict"] == "FAIL":
        return "DENY", f"halt: step {f['step']} failed — " + "; ".join(diags[:3]), ev
    if f["verdict"] == "INDETERMINATE":
        return "ABSTAIN", f"halt: step {f['step']} is indeterminate — " + "; ".join(diags[:3]), ev
    if BANDS.index(f["confidence_band"]) < BANDS.index(p["min_confidence_band"]) or f["evidence_sufficiency"] != "sufficient":
        return "ABSTAIN", f"halt: confidence dropped to {f['confidence_band']} ({f['evidence_sufficiency']} evidence)", ev
    return "PASS", f"step {f['step']} passed with {f['confidence_band']} confidence", ev


def _p_knowledge_gap_surfacing(p: Mapping[str, Any], f: Mapping[str, Any]) -> tuple[str, str, list[str]]:
    claims, gaps = f["claims"], f.get("gaps") or []
    ev = [f"claims={len(claims)}", f"unsupported={sum(1 for c in claims if not c.get('evidence_refs'))}", f"gaps={len(gaps)}", f"surfaced={f['surfaced']}", f"memory_promotion={f['memory_promotion']}"]
    if f["memory_promotion"] not in p["allowed_memory_promotion"]:
        return "DIAGNOSTIC", f"memory promotion state {f['memory_promotion']!r} is not allowed (unverified memory must never be promoted)", ev
    unsupported = [c for c in claims if not c.get("evidence_refs")]
    if unsupported:
        return "DENY", f"{len(unsupported)} claim(s) carry no evidence reference: invented rather than surfaced", ev
    if gaps and not f["surfaced"]:
        return "DENY", f"{len(gaps)} knowledge gap(s) exist but were not surfaced to the human", ev
    if gaps:
        return "PASS", f"{len(gaps)} knowledge gap(s) surfaced instead of invented: " + "; ".join(gaps[:2]), ev
    return "PASS", "every claim is evidence-backed and no knowledge gap is open", ev


PREDICATES.update({"scope_intent": _p_scope_intent, "analogous_evidence": _p_analogous_evidence, "atomic_bounded_diff": _p_atomic_bounded_diff, "halt_on_failure": _p_halt_on_failure, "knowledge_gap_surfacing": _p_knowledge_gap_surfacing})


# ---- fact providers (compose the authoritative suites; no policy duplicated) ----------------------
def facts_scope_intent(contract: Mapping[str, Any]) -> dict[str, Any]:
    """CAP-01 facts from an accepted ScopeContract (Suite 50.6 confinement + 65.01 intake); hash verified via intent_intake."""
    from . import intent_intake as ii
    try:
        ii.verify_contract_hash(contract)
        verified = True
    except lga.AdapterError:
        verified = False
    return {"intent_kind": contract.get("intent_kind"), "allowed_paths": list(contract.get("allowed_paths", [])), "forbidden_paths": list(contract.get("forbidden_paths", [])),
            "max_changed_files": int(contract.get("max_changed_files", 0)), "max_diff_lines": int(contract.get("max_diff_lines", 0)), "hash_verified": verified, "source": "intent_intake.ScopeContract + verify_contract_hash"}


def _conventions_from_paths(examples: Sequence[Mapping[str, Any]], targets: Sequence[Mapping[str, Any]]) -> dict[str, bool]:
    ex_paths = [e["canonical_path"] for e in examples]
    tgt_dirs = {t["canonical_path"].rsplit("/", 1)[0] for t in targets if "/" in t["canonical_path"]}
    naming = bool(ex_paths) and all(re.match(r"^(\d+(\.\d+)?_)?[A-Za-z0-9_.-]+$", p.rsplit("/", 1)[-1]) for p in ex_paths)
    structure = any(p.rsplit("/", 1)[0] in tgt_dirs or p.count("/") == next(iter(t["canonical_path"].count("/") for t in targets), 0) for p in ex_paths) if targets else bool(ex_paths)
    testing = any("test" in p.lower() for p in ex_paths)
    error_handling = any(p.endswith((".ja", ".jad", ".jasec", ".jaa", ".py")) for p in ex_paths)  # profile files carry assert/emit or raise conventions
    return {"naming": naming, "structure": structure, "testing": testing, "error_handling": error_handling}


def facts_analogous_evidence(bundle: Any, plan: Mapping[str, Any]) -> dict[str, Any]:
    """CAP-02 facts from the Suite 51.2 retrieval bundle and the advisory plan: exact pinned examples, conventions observed
    from their paths, and every example the plan cites (must be in the evidence)."""
    evidence = list(bundle.evidence) if hasattr(bundle, "evidence") else list(bundle["evidence"])
    examples = [e for e in evidence if e["evidence_kind"] == "analogous_example"]
    targets = [e for e in evidence if e["evidence_kind"] == "target_source"]
    refs = sorted({r for op in plan.get("operations", []) for r in op.get("guided_by_examples", [])})
    return {"example_count": len(examples), "exact_pinned": all(e.get("match_status") == "exact_pinned" and "@" in e.get("exact_locator", "") for e in examples), "evidence_ids": [e["evidence_id"] for e in evidence],
            "referenced_examples": refs, "conventions_observed": _conventions_from_paths(examples, targets), "plan_status": plan.get("status"), "source": "evidence_retrieval.EvidenceBundle (51.2) + build_plan"}


def facts_atomic_bounded_diff(candidate: Mapping[str, Any]) -> dict[str, Any]:
    """CAP-03 facts from the Suite 50.1/50.2 bounded diff/patch plans carried by a CandidatePatch (threshold = the contract's limit profile)."""
    lp = candidate.get("limit_profile") or {}
    recipe = candidate.get("recipe") or ""
    return {"files_changed": int(candidate["files_changed"]), "lines_changed": int(candidate["lines_added"]) + int(candidate["lines_deleted"]), "hunks": int(candidate["hunks"]),
            "threshold_files": int(lp.get("max_changed_files", 0)), "threshold_lines": int(lp.get("max_diff_lines", 0)), "single_recipe": bool(recipe) and "+" not in recipe and "," not in recipe,
            "inert": bool(candidate.get("inert")), "source": "patch_generator.CandidatePatch limit_profile (configurable via the scope contract)"}


def _confidence_band(plan: Mapping[str, Any] | None) -> str:
    u = (plan or {}).get("uncertainty") or {}
    if u.get("evidence_sufficiency") != "sufficient":
        return "low"
    return "high" if (u.get("example_count") or 0) >= 3 else "medium"


def facts_halt_on_failure(report: Mapping[str, Any] | None = None, plan: Mapping[str, Any] | None = None, *, step: str | None = None) -> dict[str, Any]:
    """CAP-04 facts from the verification report (step verdict + per-check diagnostics) and the plan's uncertainty (confidence band)."""
    if report is not None:
        bad = [j for j in report.get("jobs", []) if j.get("verdict") in ("FAIL", "INDETERMINATE")]
        diags = [f"{j.get('check')}: {j.get('summary') or j.get('stderr_excerpt') or 'no detail'}" for j in bad]
        return {"step": step or "verification", "verdict": report.get("verdict"), "diagnostics": diags, "confidence_band": _confidence_band(plan) if plan else "high", "evidence_sufficiency": ((plan or {}).get("uncertainty") or {}).get("evidence_sufficiency", "sufficient"), "source": "verification_runner report jobs + plan.uncertainty"}
    u = (plan or {}).get("uncertainty") or {}
    verdict = "PASS" if (plan or {}).get("status") == "PLANNED" else "INDETERMINATE"
    diags = [] if verdict == "PASS" else [str((plan or {}).get("abstain_reason") or "")]
    return {"step": step or "plan", "verdict": verdict, "diagnostics": [d for d in diags if d], "confidence_band": _confidence_band(plan), "evidence_sufficiency": u.get("evidence_sufficiency", "insufficient"), "source": "plan.status + plan.uncertainty (51.4 authority resolution)"}


def facts_knowledge_gaps(plan: Mapping[str, Any], *, evidence_gaps: Sequence[str] = ()) -> dict[str, Any]:
    """CAP-05 facts from the advisory plan: every operation is a claim that must cite evidence; gaps come from the plan's
    abstention reason and the review card's evidence gaps; memory is never promoted unverified (51.6 / Perceiver 16.6)."""
    # an abstaining plan proposes nothing: its would-be operations are not claims, its abstention reason is the surfaced gap
    claims = [] if plan.get("status") == "ABSTAIN" else [{"kind": op.get("operation"), "path": op.get("path"), "evidence_refs": list(op.get("guided_by_examples", []))} for op in plan.get("operations", [])]
    gaps = [g for g in ([plan.get("abstain_reason")] if plan.get("status") == "ABSTAIN" else []) + list(evidence_gaps) if g]
    return {"claims": claims, "gaps": gaps, "surfaced": bool(gaps) and (plan.get("status") == "ABSTAIN" or bool(evidence_gaps)), "memory_promotion": "none_unverified", "source": "build_plan operations/abstain_reason + card evidence gaps; memory promotion denied at retrieval_query"}


FACT_PROVIDERS.update({"scope_intent": facts_scope_intent, "analogous_evidence": facts_analogous_evidence, "atomic_bounded_diff": facts_atomic_bounded_diff, "halt_on_failure": facts_halt_on_failure, "knowledge_gap_surfacing": facts_knowledge_gaps})
__all__ += ["CAP_KINDS", "facts_analogous_evidence", "facts_atomic_bounded_diff", "facts_halt_on_failure", "facts_knowledge_gaps", "facts_scope_intent"]
