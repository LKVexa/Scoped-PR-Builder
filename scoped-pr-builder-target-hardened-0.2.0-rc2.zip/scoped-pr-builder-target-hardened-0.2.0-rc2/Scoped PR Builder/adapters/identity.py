"""Verified identity record abstraction; free-form labels are never connected-mode authority."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import re

from . import local_git_adapter as lga


@dataclass(frozen=True)
class VerifiedIdentity:
    issuer: str
    subject: str
    method: str
    repository: str
    expires_at: str
    evidence_hash: str


def _expiry(value: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError) as exc:
        raise lga.AdapterError("identity.expiry_invalid", "identity expiry must be an ISO-8601 timestamp with timezone") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise lga.AdapterError("identity.expiry_invalid", "identity expiry must include a timezone")
    return parsed.astimezone(timezone.utc)


def require_current(identity: VerifiedIdentity | None, *, repository: str) -> VerifiedIdentity:
    if identity is None or identity.repository != repository:
        raise lga.AdapterError("identity.required", "verified repository-bound identity required")
    for field in ("issuer", "subject", "method", "repository"):
        if not str(getattr(identity, field, "")).strip():
            raise lga.AdapterError("identity.invalid", f"identity {field} is required")
    if not re.fullmatch(r"sha256:[0-9a-fA-F]{64}", str(identity.evidence_hash)):
        raise lga.AdapterError("identity.evidence_invalid", "identity evidence_hash must be a sha256 digest")
    if _expiry(identity.expires_at) <= datetime.now(timezone.utc):
        raise lga.AdapterError("identity.expired", "identity has expired")
    return identity
