"""Scoped PR Builder — boundary ports: the only wired path across a declared boundary (Phase 01 / *-T02).

``architecture/wiring.json`` binds each boundary of ``architecture/boundaries.json`` to the overlay
adapter that serves it, using stable identifiers only: ``port:<boundary_id>``, the adapter id, the
entry points by name, and the registered contract ids a message may carry in each direction. A port
declares ``side_channels: []`` and the loader proves it: the serving adapter source is scanned for
network/IPC imports and any hit refuses the whole wiring (``wiring.side_channel``).

``Run.cross`` is the executable form of Plug 14.3 ``translate`` for the overlay: every message is
bounded (canonical size), version-checked, identity-pinned to the run, admitted by the boundary check,
wrapped in a validated ``api_envelope``, and recorded on the run's hash-chained audit ledger — on
admission *and* on refusal (the denial reason is recorded, never swallowed). Privileged effects need an
idempotency key; a replay with the same key and payload returns the recorded envelope without a
second effect (``REPLAY_SAME``), and a different payload under the same key is refused.

Identity across boundaries (ARCH-*-T03): a run pins the canonical identity block; every crossing carries it
unchanged except for the two fields a boundary's ``identity_policy`` lets it set (``provenance_ref`` advances
to the head of the run's provenance chain; ``model_version`` may be set only at the model boundary). Each
admitted crossing appends a provenance link and extends the run's trace vector (``<base>.<hop>``, after the
CorrelationVector 2.1 Increment/Extend protocol — Microsoft, MIT, pattern only), so identity, provenance
references and causal order are carried end to end and any stale or foreign identity is refused.

Decision references (API-*-T03): a contract whose ``decision_influence`` is state-changing may cross only
with the immutable identities and policy/provenance references it declares; missing references refuse.

Fail-closed behavior (ARCH-*-T04): every refusal at a port is classified into one of five declared failure
classes — unavailable, stale, unauthorized, malformed, version_incompatible — and the denial reason and class
are recorded on the run audit ledger before the refusal propagates. Availability is checked at crossing time
(serving adapter importable, authoritative suite files present); anything unclassifiable is ``malformed``.

Lifecycle (API-*-T04): a contract's ``lifecycle`` block declares compatibility, migration steps, idempotency
and deprecation; a deprecated or sunset contract is refused at the port (``contract.deprecated``), and every
privileged effect a boundary allows must be wired with an idempotency requirement so a retry can never
duplicate it (``wiring.privileged_without_idempotency`` at load).

Build provenance: BUILD_NEW (stdlib). Patterns consulted are recorded per item in ../PROVENANCE.jsonl.
"""
from __future__ import annotations

import ast
import importlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from . import architecture as A
from . import contracts as C
from . import controls as K
from . import guardrails as GR
from . import local_git_adapter as lga
from .archive_adapter import _chain_append, verify_chain_file

WIRING_VERSION = "scoped_pr_builder.architecture_wiring/0.1.0"
WIRING_PATH = Path(__file__).resolve().parent.parent / "architecture" / "wiring.json"
ADAPTERS_DIR = Path(__file__).resolve().parent
DEFAULT_MAX_PAYLOAD_BYTES = 262_144
FORBIDDEN_IMPORTS = ("socket", "ssl", "http", "urllib", "ftplib", "smtplib", "xmlrpc", "asyncio", "multiprocessing", "ctypes", "requests", "httpx", "aiohttp")
IDENTITY_FIELDS = ("run_id", "repository_id", "worktree_id", "base_revision", "source_snapshot_hash", "scope_contract_hash", "policy_hash", "tool_version", "model_version", "provenance_ref")
SETTABLE_FIELDS = ("provenance_ref", "model_version")
FAILURE_CLASSES = ("unavailable", "stale", "unauthorized", "malformed", "version_incompatible")
DEFAULT_CLASS_OF_CODE = {
    "boundary.unavailable": "unavailable", "wiring.adapter_missing": "unavailable", "wiring.entry_point_missing": "unavailable", "wiring.port_missing": "unavailable", "boundary.suite_unbound": "unavailable",
    "provenance.stale_ref": "stale", "freshness.stale": "stale", "freshness.inconsistent": "stale", "idempotency.conflict": "stale",
    "boundary.effect_denied": "unauthorized", "boundary.effect_not_allowed": "unauthorized", "identity.mismatch": "unauthorized", "identity.refs_missing": "unauthorized", "identity.field_not_settable": "unauthorized", "policy.denied": "unauthorized", "idempotency.required": "unauthorized", "wiring.contract_not_wired": "unauthorized", "boundary.contract_not_accepted": "unauthorized",
    "version.incompatible": "version_incompatible", "version.invalid": "version_incompatible", "contract.deprecated": "version_incompatible", "contract.sunset": "version_incompatible", "lifecycle.migration_invalid": "version_incompatible",
    "guardrail.deny": "unauthorized", "guardrail.abstain": "malformed", "guardrail.diagnostic": "malformed",
    "boundary.payload_invalid": "malformed", "boundary.malformed": "malformed", "schema.invalid": "malformed", "payload.unbounded": "malformed", "boundary.identity_missing": "malformed", "boundary.identity_invalid": "malformed", "boundary.unknown": "malformed", "contract.unknown": "malformed", "identity.payload_id_missing": "malformed",
}
PRIVILEGED_EFFECTS = ("patch.apply_isolated", "rollback.execute", "approval.issue_by_human", "artifact.register", "ledger.append", "state.append", "worktree.isolate", "verification.run_isolated")
PORT_REQUIRED = ("port_id", "boundary_id", "adapter_id", "serving_adapter", "entry_points", "inbound_contracts", "outbound_contracts", "message_map", "side_channels", "idempotency_required_effects", "introduced_by")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _scan_side_channels(module_name: str) -> list[str]:
    """Static import scan of one overlay adapter module: any network/IPC import is a side channel."""
    src = ADAPTERS_DIR / f"{module_name}.py"
    if not src.is_file():
        raise lga.AdapterError("wiring.adapter_missing", f"serving adapter source not found: {module_name}")
    tree = ast.parse(src.read_text(encoding="utf-8"))
    hits = []
    for node in ast.walk(tree):
        names = []
        if isinstance(node, ast.Import):
            names = [a.name for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module:
            names = [node.module]
        for n in names:
            root = n.split(".")[0]
            if root in FORBIDDEN_IMPORTS:
                hits.append(f"{module_name}: import {n} (line {node.lineno})")
    return hits


def load_wiring(path: Path = WIRING_PATH, *, boundaries: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Load and self-validate the port wiring: stable ids, existing boundaries, importable entry points,
    contract subsets, and an empty, proven side-channel list."""
    if not Path(path).is_file():
        raise lga.AdapterError("wiring.registry_missing", f"wiring registry not found: {path}")
    w = json.loads(Path(path).read_text(encoding="utf-8"))
    if w.get("wiring_version") != WIRING_VERSION:
        raise lga.AdapterError("wiring.registry_invalid", "unsupported wiring_version")
    reg = registry or C.load_registry()
    b = boundaries or A.load_boundaries(registry=reg)
    ports = w.get("ports")
    if not isinstance(ports, dict) or not ports:
        raise lga.AdapterError("wiring.registry_invalid", "no ports declared")
    for pid, p in ports.items():
        missing = [k for k in PORT_REQUIRED if k not in p]
        if missing or p["port_id"] != pid:
            raise lga.AdapterError("wiring.registry_invalid", f"{pid}: missing {missing} or id mismatch")
        entry = b["boundaries"].get(p["boundary_id"])
        if entry is None or pid != f"port:{p['boundary_id']}":
            raise lga.AdapterError("wiring.registry_invalid", f"{pid}: unknown boundary or unstable port id")
        if not set(p["inbound_contracts"]) <= set(entry["input_contracts"]) or not set(p["outbound_contracts"]) <= set(entry["output_contracts"]):
            raise lga.AdapterError("wiring.registry_invalid", f"{pid}: port contracts exceed the boundary's declared contracts")
        if p["side_channels"] != []:
            raise lga.AdapterError("wiring.side_channel", f"{pid}: declares a side channel")
        hits = _scan_side_channels(p["serving_adapter"])
        if hits:
            raise lga.AdapterError("wiring.side_channel", f"{pid}: {hits}")
        try:
            mod = importlib.import_module(f"{__package__}.{p['serving_adapter']}")
        except Exception as exc:  # pragma: no cover - import failure is a wiring defect
            raise lga.AdapterError("wiring.adapter_missing", f"{pid}: cannot import {p['serving_adapter']}: {exc}") from exc
        for ep in p["entry_points"]:
            if not callable(getattr(mod, ep, None)):
                raise lga.AdapterError("wiring.entry_point_missing", f"{pid}: {p['serving_adapter']}.{ep} is not callable")
        for cid, m in p["message_map"].items():
            if cid not in p["inbound_contracts"] + p["outbound_contracts"] or m.get("entry_point") not in p["entry_points"]:
                raise lga.AdapterError("wiring.registry_invalid", f"{pid}: message_map for {cid!r} names an unknown contract or entry point")
        for eff in p["idempotency_required_effects"]:
            if eff not in entry["allowed_effects"]:
                raise lga.AdapterError("wiring.registry_invalid", f"{pid}: idempotency effect {eff!r} is not allowed at the boundary")
        if p.get("privileged_effects_guarded"):
            for eff in entry["allowed_effects"]:
                if eff in PRIVILEGED_EFFECTS and eff not in p["idempotency_required_effects"]:
                    raise lga.AdapterError("wiring.privileged_without_idempotency", f"{pid}: privileged effect {eff!r} is allowed but not idempotency-guarded")
    body = {k: v for k, v in w.items() if k != "wiring_hash"}
    w["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return w


def payload_limit(contract_id: str, registry: Mapping[str, Any]) -> int:
    prof = registry["contracts"].get(contract_id, {}).get("validation_profile", {})
    return int(prof.get("max_payload_bytes", DEFAULT_MAX_PAYLOAD_BYTES))


class Run:
    """A pinned run: one identity, one run directory outside the repository, one audit chain."""

    def __init__(self, run_dir: Path, identity: Mapping[str, Any], *, repo_root: Path | None = None, registry: Mapping[str, Any] | None = None,
                 boundaries: Mapping[str, Any] | None = None, wiring: Mapping[str, Any] | None = None, actor: str = "overlay.scoped_pr_builder") -> None:
        self.run_dir = Path(run_dir).resolve()
        if repo_root is not None:
            root = Path(repo_root).resolve()
            if self.run_dir == root or root in self.run_dir.parents:
                raise lga.AdapterError("run.inside_repository", "run directory must be outside the repository root")
        self.registry = registry or C.load_registry()
        self.boundaries = boundaries or A.load_boundaries(registry=self.registry)
        self.wiring = wiring or load_wiring(boundaries=self.boundaries, registry=self.registry)
        try:
            C.validate(C.DEFS["identity"], identity, path="$.identity", registry=self.registry)
        except C.SchemaError as exc:
            raise lga.AdapterError("run.identity_invalid", str(exc)) from exc
        self.identity = json.loads(lga.canonical_json(identity))
        self.identity_hash = lga.sha256_digest(lga.canonical_json(self.identity))
        self.actor = actor
        self.audit_path = self.run_dir / "audit.jsonl"
        self.idempotency_path = self.run_dir / "idempotency.jsonl"
        self.provenance_path = self.run_dir / "provenance.jsonl"
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.trace_base = self.identity["run_id"].split(":")[1][:22]
        self.hop = self._provenance_count()
        self.provenance_head = self._provenance_head()

    # -- identity carried across boundaries (ARCH-*-T03) ------------------------------------------ #
    def _provenance_links(self) -> list[dict[str, Any]]:
        if not self.provenance_path.is_file():
            return []
        verify_chain_file(self.provenance_path)
        return [json.loads(l) for l in self.provenance_path.read_text(encoding="utf-8").splitlines() if l.strip()]

    def _provenance_count(self) -> int:
        return len(self._provenance_links())

    def _provenance_head(self) -> str:
        links = self._provenance_links()
        return links[-1]["entry_hash"] if links else self.identity.get("provenance_ref") or self.identity_hash

    def current_identity(self) -> dict[str, Any]:
        """The identity block every outgoing message must carry: pinned fields plus the current provenance head."""
        return dict(self.identity, provenance_ref=self.provenance_head)

    def trace_vector(self) -> str:
        return f"{self.trace_base}.{self.hop}"

    def _identity_policy(self, boundary_id: str) -> dict[str, Any]:
        entry = self.boundaries["boundaries"][boundary_id]
        pol = entry.get("identity_policy") or {}
        immutable = tuple(pol.get("immutable_across", [f for f in IDENTITY_FIELDS if f not in SETTABLE_FIELDS]))
        return {"immutable": immutable, "may_set": tuple(pol.get("may_set", [])), "provenance_ref_required": bool(pol.get("provenance_ref_required", False))}

    def _check_identity(self, boundary_id: str, ident: Mapping[str, Any]) -> dict[str, Any]:
        pol = self._identity_policy(boundary_id)
        for f in pol["immutable"]:
            if f in SETTABLE_FIELDS:
                continue
            if ident.get(f) != self.identity.get(f):
                raise lga.AdapterError("identity.mismatch", f"identity field {f!r} differs from the run's pinned identity")
        ref = ident.get("provenance_ref")
        if pol["provenance_ref_required"] and not ref:
            raise lga.AdapterError("identity.refs_missing", "this boundary requires a provenance_ref")
        if ref is not None and ref != self.provenance_head:
            raise lga.AdapterError("provenance.stale_ref", "identity carries a provenance_ref that is not the run's current head")
        if ident.get("model_version") != self.identity.get("model_version") and "model_version" not in pol["may_set"]:
            raise lga.AdapterError("identity.field_not_settable", f"{boundary_id} may not set model_version")
        return dict(ident, provenance_ref=self.provenance_head)

    def _check_decision_refs(self, contract_id: str, ident: Mapping[str, Any], payload: Any) -> None:
        """API-*-T03: state-changing messages must carry immutable identities and policy/provenance references."""
        infl = self.registry["contracts"][contract_id].get("decision_influence")
        if not infl or not infl.get("state_changing"):
            return
        for f in infl.get("required_identity", []):
            if not ident.get(f):
                raise lga.AdapterError("identity.refs_missing", f"{contract_id} is state-changing and requires identity.{f}")
        for f in infl.get("required_refs", []):
            if not ident.get(f):
                raise lga.AdapterError("identity.refs_missing", f"{contract_id} is state-changing and requires reference {f}")
        for path in infl.get("required_payload_ids", []):
            cur: Any = payload
            for seg in path.split("."):
                cur = cur.get(seg) if isinstance(cur, Mapping) else None
            if not isinstance(cur, str) or not (re.match(r"^sha256:[0-9a-f]{64}$", cur) or re.match(r"^[0-9a-f]{40}$", cur)):
                raise lga.AdapterError("identity.payload_id_missing", f"{contract_id} requires immutable id at payload.{path}")

    def _provenance_append(self, boundary_id: str, direction: str, contract_id: str, payload_hash: str, crossing_hash: str) -> dict[str, Any]:
        self.hop += 1
        link = {"record_schema": "suite29.archive_ledger.provenance/ProvenanceLink", "run_id": self.identity["run_id"], "trace_vector": self.trace_vector(), "boundary_id": boundary_id,
                "direction": direction, "contract_id": contract_id, "payload_hash": payload_hash, "crossing_hash": crossing_hash, "parent_ref": self.provenance_head, "at": _now()}
        entry = _chain_append(self.provenance_path, link)
        self.provenance_head = entry["entry_hash"]
        return entry

    # -- ledgers ---------------------------------------------------------------------------------- #
    def _audit(self, **fields: Any) -> dict[str, Any]:
        row = {"record_schema": "suite01.observer.runtime_events/PrivilegedEffect", "run_id": self.identity["run_id"], "actor": self.actor, "at": _now(), **fields}
        return _chain_append(self.audit_path, row)

    def audit_entries(self) -> list[dict[str, Any]]:
        if not self.audit_path.is_file():
            return []
        verify_chain_file(self.audit_path)
        return [json.loads(l) for l in self.audit_path.read_text(encoding="utf-8").splitlines() if l.strip()]

    def _idempotency_ledger(self) -> list[dict[str, Any]]:
        if not self.idempotency_path.is_file():
            return []
        return [json.loads(l) for l in self.idempotency_path.read_text(encoding="utf-8").splitlines() if l.strip()]

    # -- fail-closed classification (ARCH-*-T04) -------------------------------------------------- #
    def classify(self, boundary_id: str | None, code: str) -> str:
        """Map a refusal code to the boundary's declared failure class (falls back to the default table, then malformed)."""
        entry = self.boundaries["boundaries"].get(boundary_id or "", {})
        classes = (entry.get("failure_behavior") or {}).get("classes") or {}
        for cls, spec in classes.items():
            if code in spec.get("codes", []):
                return cls
        return DEFAULT_CLASS_OF_CODE.get(code, "malformed")

    def _check_available(self, boundary_id: str, port: Mapping[str, Any]) -> None:
        entry = self.boundaries["boundaries"][boundary_id]
        repo_root = A.REPO_ROOT
        for suite in entry["authoritative_suites"]:
            if not (repo_root / suite["file"]).is_file():
                raise lga.AdapterError("boundary.unavailable", f"{boundary_id}: authoritative suite file missing at crossing time: {suite['file']}")
        try:
            importlib.import_module(f"{__package__}.{port['serving_adapter']}")
        except Exception as exc:  # pragma: no cover
            raise lga.AdapterError("boundary.unavailable", f"{boundary_id}: serving adapter unavailable: {exc}") from exc

    def _check_lifecycle(self, contract_id: str, entry: Mapping[str, Any]) -> None:
        """API-*-T04: deprecated/sunset contracts are refused; migration steps must be monotonic semver."""
        lc = entry.get("lifecycle")
        if not lc:
            return
        dep = lc.get("deprecation") or {}
        status = dep.get("status", "active")
        if status == "sunset":
            raise lga.AdapterError("contract.sunset", f"{contract_id} is sunset; use {dep.get('replaced_by')!r}")
        if status == "deprecated" and not dep.get("accept_until_sunset", False):
            raise lga.AdapterError("contract.deprecated", f"{contract_id} is deprecated; migrate to {dep.get('replaced_by')!r}")
        prev = None
        for step in lc.get("migration", []):
            K.parse_semver(step["from"]); K.parse_semver(step["to"])
            if K.parse_semver(step["to"]) <= K.parse_semver(step["from"]) or (prev and K.parse_semver(step["from"]) != prev):
                raise lga.AdapterError("lifecycle.migration_invalid", f"{contract_id}: migration steps must chain forward")
            prev = K.parse_semver(step["to"])

    # -- the wired crossing ----------------------------------------------------------------------- #
    def cross(self, boundary_id: str, effect: str, contract_id: str, payload: Any, *, direction: str = "inbound", idempotency_key: str | None = None,
              declared_version: str | None = None, identity: Mapping[str, Any] | None = None, guardrail_facts: Mapping[str, Any] | None = None) -> dict[str, Any]:
        """Cross one boundary with one schema-validated message. Returns the envelope, the crossing receipt,
        the audit entry and the replay verdict; refuses with a stable code and records the denial."""
        port = self.wiring["ports"].get(f"port:{boundary_id}")
        try:
            if port is None:
                raise lga.AdapterError("wiring.port_missing", f"no port wired for boundary {boundary_id!r}")
            self._check_available(boundary_id, port)
            entry = self.registry["contracts"].get(contract_id)
            if entry is None:
                raise lga.AdapterError("contract.unknown", f"no such contract {contract_id!r}")
            self._check_lifecycle(contract_id, entry)
            accepted = port["inbound_contracts"] if direction == "inbound" else port["outbound_contracts"]
            if contract_id not in accepted:
                raise lga.AdapterError("wiring.contract_not_wired", f"{port['port_id']} does not carry {contract_id!r} {direction}")
            raw = lga.canonical_json(payload).encode("utf-8")
            limit = payload_limit(contract_id, self.registry)
            if len(raw) > limit:
                raise lga.AdapterError("payload.unbounded", f"payload is {len(raw)} bytes; {contract_id} allows at most {limit}")
            if declared_version is not None:
                if not C.SEMVER_RE.match(declared_version):
                    raise lga.AdapterError("version.invalid", f"declared version {declared_version!r} is not semver")
                K.require_compatible(declared_version, entry["version"])
            if boundary_id not in self.boundaries["boundaries"]:
                raise lga.AdapterError("boundary.unknown", f"no such boundary {boundary_id!r}")
            supplied = json.loads(lga.canonical_json(identity)) if identity is not None else self.current_identity()
            ident = self._check_identity(boundary_id, supplied)
            self._check_decision_refs(contract_id, ident, payload)
            message = {"boundary_id": boundary_id, "direction": direction, "effect": effect, "payload_contract": contract_id, "identity": ident, "payload": payload}
            receipt = A.check_crossing(message, boundaries=self.boundaries, registry=self.registry)
            if effect in port["idempotency_required_effects"] and not idempotency_key:
                raise lga.AdapterError("idempotency.required", f"effect {effect!r} at {port['port_id']} requires an idempotency key")
            # PAPER-GRD-*-T03: every guardrail that applies to this effect is evaluated here; a blocking state refuses
            # (guardrail.deny / guardrail.abstain / guardrail.diagnostic) and every decision is on the audit ledger.
            decisions = GR.enforce(effect, guardrail_facts, run=self, registry=self.registry)
            envelope = {"contract_id": contract_id, "contract_version": entry["version"], "direction": direction, "boundary_id": boundary_id, "identity": ident,
                        "payload": payload, "payload_hash": receipt["payload_hash"], "idempotency_key": idempotency_key, "emitted_at": _now()}
            C.validate_payload("api_envelope", envelope, registry=self.registry)
            replay = "EXECUTE"
            if idempotency_key:
                replay = K.replay_check(self._idempotency_ledger(), idempotency_key, receipt["payload_hash"])
        except lga.AdapterError as exc:
            self._audit(effect=effect, boundary_id=boundary_id, direction=direction, contract_id=contract_id, verdict="DENIED", denial_code=exc.code,
                        denial_class=self.classify(boundary_id, exc.code), reason=str(exc), fail_closed=True)
            raise
        link = None
        if replay == "EXECUTE":
            link = self._provenance_append(boundary_id, direction, contract_id, receipt["payload_hash"], receipt["crossing_hash"])
            envelope["identity"] = dict(ident, provenance_ref=self.provenance_head)
            if "trace_vector" in self.registry["contracts"]["api_envelope"]["schema"].get("properties", {}):
                envelope["trace_vector"] = link["trace_vector"]
            audit = self._audit(effect=effect, boundary_id=boundary_id, direction=direction, contract_id=contract_id, payload_hash=receipt["payload_hash"],
                                crossing_hash=receipt["crossing_hash"], verdict="ADMITTED", idempotency_key=idempotency_key, trace_vector=link["trace_vector"], provenance_ref=self.provenance_head,
                                guardrail_decisions=[d["decision_hash"] for d in decisions])
            if idempotency_key:
                with self.idempotency_path.open("a", encoding="utf-8") as f:
                    f.write(lga.canonical_json({"idempotency_key": idempotency_key, "result_hash": receipt["payload_hash"], "audit_entry_hash": audit["entry_hash"]}) + "\n")
        else:
            audit = self._audit(effect="replay.observed", boundary_id=boundary_id, direction=direction, contract_id=contract_id, payload_hash=receipt["payload_hash"],
                                crossing_hash=receipt["crossing_hash"], verdict="REPLAY_SAME", idempotency_key=idempotency_key)
        C.validate_payload("audit_event", audit, registry=self.registry)
        return {"envelope": envelope, "crossing": receipt, "audit_entry": audit, "replay": replay, "port_id": port["port_id"], "provenance_link": link, "provenance_ref": self.provenance_head, "guardrail_decisions": decisions}

    def dispatch(self, boundary_id: str, effect: str, contract_id: str, payload: Mapping[str, Any], **kw: Any) -> dict[str, Any]:
        """Cross, then invoke the wired entry point with the message fields mapped by name (only for ports
        whose message_map declares ``kwargs``; composed entry points are reached through tools/spb.py)."""
        crossed = self.cross(boundary_id, effect, contract_id, payload, **kw)
        port = self.wiring["ports"][crossed["port_id"]]
        m = port["message_map"].get(contract_id, {})
        if "kwargs" not in m:
            raise lga.AdapterError("wiring.not_dispatchable", f"{contract_id} at {port['port_id']} is not directly dispatchable")
        if crossed["replay"] == "REPLAY_SAME":
            return {"crossed": crossed, "result": None, "executed": False}
        mod = importlib.import_module(f"{__package__}.{port['serving_adapter']}")
        fn = getattr(mod, m["entry_point"])
        kwargs = {param: payload[field] for param, field in m["kwargs"].items()}
        for param, conv in m.get("coerce", {}).items():
            if conv == "path":
                kwargs[param] = Path(kwargs[param])
        result = fn(**kwargs)
        return {"crossed": crossed, "result": result, "executed": True}


__all__ = ["DEFAULT_CLASS_OF_CODE", "DEFAULT_MAX_PAYLOAD_BYTES", "FAILURE_CLASSES", "FORBIDDEN_IMPORTS", "IDENTITY_FIELDS", "PRIVILEGED_EFFECTS", "Run", "SETTABLE_FIELDS", "WIRING_PATH", "WIRING_VERSION", "load_wiring", "payload_limit"]
