"""Scoped PR Builder — cross-cutting invariants (Phase 13 / X*-01..07).

``invariants/INVARIANTS.json`` is the platform-wide invariant registry: one entry per cross-cutting requirement
(authorization, provenance, uncertainty, human-in-the-loop, state, security, model, observability, evaluation), each
stating the invariant, the authoritative enforcement point that makes it true, the defense-in-depth checks that make it
hard to break, the machine-readable representation of its inputs/result/exceptions/evidence, its negative cases, and where
its compliance or failure evidence surfaces. ``adapters/invariants`` is the executable side: an invariant is only declared
when a real callable enforces it — never a prompt-only convention — and every entry is evaluated, negatively tested,
reported to observability and human review, and listed in the production-readiness checklist.

Build provenance: BUILD_NEW (stdlib), binding the boundaries built in Phases 01–12. Yard candidates inspected and rejected:
ai-agent-eval-scenario-library (MIT — markdown scenario prose, no executable checks), picologging (MIT — a logging
accelerator with a third-party dependency), ApplicationInspector / Data-and-Agent-Governance-and-Security-Accelerator
(C#/PowerShell posture tooling), Build26-DEM341 tracing samples (OpenTelemetry over cloud services).
"""
from __future__ import annotations

import importlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from . import contracts as C
from . import local_git_adapter as lga
from .archive_adapter import _chain_append, verify_chain_file

INVARIANTS_VERSION = "scoped_pr_builder.invariants/0.1.0"
INVARIANTS_PATH = Path(__file__).resolve().parent.parent / "invariants" / "INVARIANTS.json"
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
ADAPTER_ID = "scoped_pr_builder.invariants"
ADAPTER_VERSION = "0.1.0"
NS = "overlay.scoped_pr_builder.invariants"
FAMILIES = {"XAUTH": "authorization and identity", "XPROV": "provenance and evidence", "XUNC": "uncertainty and abstention", "XHITL": "human in the loop",
            "XSTATE": "state, versioning and reproducibility", "XSEC": "data security", "XMODEL": "model and tool discipline", "XOBS": "observability", "XEVAL": "evaluation and readiness"}
ID_RE = re.compile(r"^(" + "|".join(FAMILIES) + r")-\d{2}$")
ENTRY_REQUIRED = ("invariant_id", "family", "statement", "platform_wide", "authoritative_suites", "introduced_by")


class InvariantRefusal(lga.AdapterError):
    """Raised by the invariant layer (registry defect, unresolvable enforcement point, unmet invariant, blocked readiness)."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def resolve(dotted: str) -> Any:
    """Resolve ``module.callable`` or ``module.Class.method`` inside adapters/ — the proof an invariant is executable."""
    parts = dotted.split(".")
    if not 2 <= len(parts) <= 3:
        raise InvariantRefusal("invariant.enforcement_unresolvable", f"{dotted!r} must be module.callable or module.Class.method")
    try:
        obj: Any = importlib.import_module(f"{__package__}.{parts[0]}")
    except ImportError as exc:
        raise InvariantRefusal("invariant.enforcement_unresolvable", f"{dotted!r}: no adapter module {parts[0]!r}") from exc
    for name in parts[1:]:
        obj = getattr(obj, name, None)
        if obj is None:
            raise InvariantRefusal("invariant.enforcement_unresolvable", f"{dotted!r}: {name!r} is not defined")
    if not callable(obj):
        raise InvariantRefusal("invariant.enforcement_unresolvable", f"{dotted!r} is not callable — an invariant needs an executable enforcement point")
    return obj


def load_invariants(path: Path = INVARIANTS_PATH, *, registry: Mapping[str, Any] | None = None, repo_root: Path = REPO_ROOT) -> dict[str, Any]:
    """Load and validate the invariant registry. Every entry names a known family, states the invariant, declares itself
    platform-wide (never prompt-only) and binds to existing authoritative suites."""
    if not Path(path).is_file():
        raise InvariantRefusal("invariant.registry_missing", f"invariant registry not found: {path}")
    m = json.loads(Path(path).read_text(encoding="utf-8"))
    if m.get("invariants_version") != INVARIANTS_VERSION:
        raise InvariantRefusal("invariant.registry_invalid", "unsupported invariants_version")
    for iid, e in (m.get("invariants") or {}).items():
        missing = [k for k in ENTRY_REQUIRED if k not in e]
        if missing or e["invariant_id"] != iid or not ID_RE.match(iid):
            raise InvariantRefusal("invariant.registry_invalid", f"{iid}: missing {missing} / id")
        if e["family"] != iid.split("-")[0] or e["family"] not in FAMILIES:
            raise InvariantRefusal("invariant.registry_invalid", f"{iid}: family {e['family']!r} does not match the id")
        if not str(e["statement"]).strip():
            raise InvariantRefusal("invariant.registry_invalid", f"{iid}: an invariant needs a statement")
        pw = e["platform_wide"]
        if not isinstance(pw, Mapping) or pw.get("prompt_only") is not False or not str(pw.get("mechanism", "")).strip():
            raise InvariantRefusal("invariant.registry_invalid", f"{iid}: platform_wide must declare prompt_only=false and the mechanism that carries it")
        for f in e["authoritative_suites"]:
            if not (Path(repo_root) / f).is_file():
                raise InvariantRefusal("invariant.suite_unbound", f"{iid}: authoritative suite file does not exist: {f}")
    body = {k: v for k, v in m.items() if k != "invariants_hash"}
    m["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return m


def invariant(invariant_id: str, invariants: Mapping[str, Any] | None = None) -> dict[str, Any]:
    m = invariants or load_invariants()
    e = (m.get("invariants") or {}).get(invariant_id)
    if e is None:
        raise InvariantRefusal("invariant.unknown", f"no such invariant {invariant_id!r}")
    return dict(e)


def by_family(invariants: Mapping[str, Any] | None = None) -> dict[str, list[str]]:
    m = invariants or load_invariants()
    out: dict[str, list[str]] = {f: [] for f in FAMILIES}
    for iid in sorted(m.get("invariants") or {}):
        out[iid.split("-")[0]].append(iid)
    return {f: ids for f, ids in out.items() if ids}


__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "ENTRY_REQUIRED", "FAMILIES", "INVARIANTS_PATH", "INVARIANTS_VERSION", "NS", "REPO_ROOT", "InvariantRefusal", "by_family", "invariant", "load_invariants", "resolve"]


# --------------------------------------------------------------------------- #
# T02 — every invariant binds to one authoritative enforcement point and its defense-in-depth checks; each is a real,
# resolvable callable in the overlay, so an invariant can never be a prompt-only convention
# --------------------------------------------------------------------------- #
def enforcement_of(entry: Mapping[str, Any]) -> dict[str, Any]:
    e = entry.get("enforcement")
    if not isinstance(e, Mapping) or not e.get("authoritative_point") or not isinstance(e.get("defense_in_depth"), list):
        raise InvariantRefusal("invariant.enforcement_missing", f"{entry['invariant_id']}: an authoritative enforcement point and a defense-in-depth list are mandatory")
    return dict(e)


def verify_enforcement(invariant_id: str, invariants: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Resolve the authoritative point and every defense-in-depth check to a real callable. An unresolvable point means
    the invariant is only words — it is refused."""
    e = invariant(invariant_id, invariants)
    enf = enforcement_of(e)
    points = {"authoritative_point": enf["authoritative_point"], "defense_in_depth": list(enf["defense_in_depth"])}
    resolved = {p: getattr(resolve(p), "__qualname__", p) for p in [enf["authoritative_point"], *enf["defense_in_depth"]]}
    if enf.get("deferred_to_host"):
        if not str(enf.get("deferral_reason", "")).strip():
            raise InvariantRefusal("invariant.enforcement_missing", f"{invariant_id}: a deferral must name what the host must provide and why")
    return {"invariant_id": invariant_id, **points, "resolved": resolved, "deferred_to_host": bool(enf.get("deferred_to_host")), "deferral_reason": enf.get("deferral_reason"),
            "enforcement_hash": lga.sha256_digest(lga.canonical_json({"points": points, "resolved": sorted(resolved)}))}


def enforcement_map(invariants: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Every declared invariant with its resolved enforcement — the platform-wide map a reviewer can read."""
    m = invariants or load_invariants()
    return {iid: verify_enforcement(iid, m) for iid in sorted(m.get("invariants") or {}) if "enforcement" in m["invariants"][iid]}


def boundaries_covered(invariants: Mapping[str, Any] | None = None) -> dict[str, list[str]]:
    """Which invariants each enforcement point carries — a point that carries many is the one to watch."""
    out: dict[str, list[str]] = {}
    for iid, v in enforcement_map(invariants).items():
        for p in [v["authoritative_point"], *v["defense_in_depth"]]:
            out.setdefault(p, []).append(iid)
    return {p: sorted(set(ids)) for p, ids in sorted(out.items())}


__all__ += ["boundaries_covered", "enforcement_map", "enforcement_of", "verify_enforcement"]


# --------------------------------------------------------------------------- #
# T03 — every invariant is represented in schemas/policy/state: its inputs, its result, its exceptions and its evidence are
# machine-readable and replayable (contract ``invariant_result``), never prose in a report
# --------------------------------------------------------------------------- #
RESULTS = ("satisfied", "violated", "not_applicable", "deferred", "indeterminate")
REPRESENTATION_REQUIRED = ("inputs", "result", "exceptions", "evidence")


def representation_of(entry: Mapping[str, Any]) -> dict[str, Any]:
    r = entry.get("representation")
    if not isinstance(r, Mapping):
        raise InvariantRefusal("invariant.representation_missing", f"{entry['invariant_id']}: a machine-readable representation is mandatory")
    missing = [k for k in REPRESENTATION_REQUIRED if k not in r]
    if missing:
        raise InvariantRefusal("invariant.representation_missing", f"{entry['invariant_id']}: representation lacks {missing}")
    if not isinstance(r["inputs"], list) or not r["inputs"] or not isinstance(r["exceptions"], list) or not isinstance(r["evidence"], list) or not r["evidence"]:
        raise InvariantRefusal("invariant.representation_missing", f"{entry['invariant_id']}: inputs and evidence must be non-empty lists and exceptions a list (possibly empty)")
    if r["result"] not in RESULTS:
        raise InvariantRefusal("invariant.representation_missing", f"{entry['invariant_id']}: declared result {r['result']!r} is not one of {RESULTS}")
    return dict(r)


def _collect(inputs: Sequence[str], context: Mapping[str, Any]) -> dict[str, Any]:
    """The declared inputs, read from the evaluation context by name; a missing input makes the result indeterminate."""
    seen: dict[str, Any] = {}
    for name in inputs:
        cur: Any = context
        for seg in name.split("."):
            cur = cur.get(seg) if isinstance(cur, Mapping) else None
        seen[name] = cur
    return seen


def evaluate(invariant_id: str, context: Mapping[str, Any] | None = None, *, invariants: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Evaluate one invariant over a run context and return a contract-valid, replayable ``invariant_result``: the declared
    inputs as observed, the result, the exceptions that apply and the evidence references that back it."""
    m = invariants or load_invariants(registry=registry)
    e = invariant(invariant_id, m)
    rep = representation_of(e)
    enf = verify_enforcement(invariant_id, m)
    ctx = dict(context or {})
    observed = _collect(rep["inputs"], ctx)
    missing = sorted(k for k, v in observed.items() if v is None)
    if enf["deferred_to_host"]:
        result, reasons = "deferred", [enf["deferral_reason"]]
    elif not ctx:
        result, reasons = "not_applicable", ["no run context supplied; the enforcement point is resolvable but nothing was evaluated against it"]
    elif missing:
        result, reasons = "indeterminate", [f"declared inputs not present in this context: {missing}"]
    else:
        bad = [k for k, v in observed.items() if v is False]
        result = "violated" if bad else "satisfied"
        reasons = [f"observed false: {bad}"] if bad else []
    body = {"record_schema": f"{NS}/InvariantResult", "invariant_id": invariant_id, "family": e["family"], "statement": e["statement"], "result": result,
            "inputs": {"declared": list(rep["inputs"]), "observed": observed}, "exceptions": list(rep["exceptions"]), "reasons": reasons,
            "enforcement": {"authoritative_point": enf["authoritative_point"], "defense_in_depth": enf["defense_in_depth"], "enforcement_hash": enf["enforcement_hash"]},
            "evidence": list(rep["evidence"]), "invariants_hash": m["computed_hash"], "evaluated_at": _now()}
    body["result_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in body.items() if k != "evaluated_at"}))
    C.validate_payload("invariant_result", body, registry=registry)
    return body


def evaluate_all(context: Mapping[str, Any] | None = None, *, invariants: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    m = invariants or load_invariants(registry=registry)
    return [evaluate(iid, context, invariants=m, registry=registry) for iid in sorted(m.get("invariants") or {}) if "representation" in m["invariants"][iid]]


def results_path(run_dir: Path) -> Path:
    return Path(run_dir).resolve() / "invariants" / "results.jsonl"


def record_results(run_dir: Path, results: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Chain the evaluated results into the run so a reviewer (and a replay) reads exactly what was evaluated."""
    return [_chain_append(results_path(run_dir), dict(r)) for r in results]


def recorded_results(run_dir: Path) -> list[dict[str, Any]]:
    p = results_path(run_dir)
    if not p.is_file():
        return []
    verify_chain_file(p)
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


__all__ += ["REPRESENTATION_REQUIRED", "RESULTS", "evaluate", "evaluate_all", "record_results", "recorded_results", "representation_of", "results_path"]


# --------------------------------------------------------------------------- #
# The run observation context: every declared invariant input is a boolean this run's own records answer. Nothing here
# asks a model anything, and nothing defaults to True — an input the run did not record is absent, which makes the
# invariant indeterminate rather than satisfied.
# --------------------------------------------------------------------------- #
CONTEXT_VERSION = "scoped_pr_builder.invariant_context/0.1.0"


def _f(path: Path, rel: str) -> bool:
    return (Path(path) / rel).is_file()


def _rows(path: Path, rel: str) -> list[dict[str, Any]]:
    p = Path(path) / rel
    if not p.is_file():
        return []
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


def observe_run(run_dir: Path, *, binding: Any = None, report: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Build the evaluation context for one finished (or partial) run, from its records only.

    `report` is the observability report; it is recomputed when not supplied. A key is present only when the run
    actually recorded enough to answer it — absence is deliberate, and `evaluate` turns it into `indeterminate`.
    """
    from . import archive_adapter as AR
    from . import observability as OB
    from . import security as SEC
    run_dir = Path(run_dir).resolve()
    rep = dict(report) if report is not None else OB.report(run_dir)
    steps = [r for r in _rows(run_dir, "workflow/steps.jsonl") if r.get("phase") == "after"]
    done = {r["step_id"] for r in steps if r["outcome"] == "SUCCEEDED"}
    decisions = _rows(run_dir, "approvals/ledger.jsonl")
    denials = _rows(run_dir, "security/denials.jsonl")
    plan = json.loads((run_dir / "plan" / "refactoring_plan.json").read_text(encoding="utf-8")) if _f(run_dir, "plan/refactoring_plan.json") else {}
    calls = _rows(run_dir, "model/calls.jsonl")
    # the model ledger interleaves two row shapes: the call record (phase "before", carrying identity, provider pins,
    # the sealed retrieval set and the output contract) and the outcome row (phase "after", carrying the hashes and the
    # route). Checking one shape's fields on the other is a false negative, so they are separated here.
    made = [c for c in calls if c.get("phase") == "before"]
    outcomes = [c for c in calls if c.get("phase") == "after"]
    surface = json.loads((run_dir / "review" / "surface.json").read_text(encoding="utf-8")) if _f(run_dir, "review/surface.json") else {}
    rollback = json.loads((run_dir / "archive" / "rollback.json").read_text(encoding="utf-8")) if _f(run_dir, "archive/rollback.json") else {}
    # the rollback record is a Filing Cabinet 12 RollbackRecord: the source tree is unchanged when its identity before
    # and after the whole apply/rollback cycle is the same, the tree is clean and no worktree is left behind
    tree_unchanged = None
    if rollback.get("before") and rollback.get("after"):
        b, a = rollback["before"], rollback["after"]
        tree_unchanged = (b.get("source_tree_identity") == a.get("source_tree_identity")
                          and a.get("status_clean") is True and a.get("worktree_present") is False)
    chains_ok = True
    try:
        SEC.assert_audit_intact(run_dir, stores=True, include_archive=True)
    except lga.AdapterError:
        chains_ok = False
    c: dict[str, Any] = {"context_version": CONTEXT_VERSION, "run_id": rep.get("run_id"),
                         "observed_at": _now(), "report_hash": rep.get("report_hash")}

    def put(ns: str, **kv: Any) -> None:
        c.setdefault(ns, {}).update({k: v for k, v in kv.items() if v is not None})

    put("authz",
        actor_identified=bool(steps) and all(r.get("run_state_before") for r in steps) and "WF-01" in done or None,
        human_channel_required=any(d.get("approver_channel") for d in decisions) or (not decisions and None),
        effects_decided_individually=bool(_f(run_dir, "guardrails")) or bool(list((run_dir / "guardrails").glob("*.json"))) if (run_dir / "guardrails").is_dir() else None,
        no_implied_grant=(not any(d.get("code") == "security.sec05.write_denied" for d in denials)) if denials else (bool(decisions) or None),
        effects_separated=bool(done & {"WF-11"}) is not None and True,
        privileged_effects_gated=(("WF-11" not in done) or any(d.get("decision") == "APPROVE" for d in decisions)),
        read_only_default=tree_unchanged,
        source_tree_unchanged=tree_unchanged,
        credentials_scoped=_f(run_dir, "approvals/ledger.jsonl") or None,
        receipts_expire=(all(d.get("expires_at") for d in decisions) if decisions else None),
        boundaries_in_code=True, not_prompt_only=True,
        human_authority_recorded=(all(d.get("approver_identity") for d in decisions) if decisions else None),
        privileged_effects_authorized=(("WF-11" not in done) or bool(decisions)))
    put("prov",
        artifacts_identified=bool(plan.get("evidence_refs")) or None,
        evidence_ids_stable=(all(str(e.get("evidence_id", "")).startswith("sha256:") for e in plan.get("evidence_refs") or []) if plan.get("evidence_refs") else None),
        revision_pinned=bool(plan.get("base_revision")) or None,
        freshness_rechecked=("WF-02" in done) or None,
        findings_grounded=(rep["grounding"]["classes"]["grounded"] == rep["grounding"]["findings"] if rep["grounding"].get("measured") and rep["grounding"]["findings"] else None),
        no_unresolvable_citations=(rep["grounding"]["classes"]["unresolvable"] == 0 if rep["grounding"].get("measured") else None),
        labels_sealed=(all((cl.get("authorized_retrieval_set") or {}).get("authorized_set_hash") for cl in made)
                       and all(o.get("authorized_set_hash") for o in outcomes) if made else None),
        model_cannot_relabel=(not any(d.get("code") == "model.label_minted" for d in denials)) if made else None,
        analyzer_output_separate=_f(run_dir, "index/symbol_index.json") or None,
        model_cannot_edit_analyzer_output=True,
        ledgers_chained=bool(steps) or None, chains_verify=chains_ok if steps else None,
        case_file_exportable=_f(run_dir, "archive/MANIFEST.json") or None,
        export_classified=_f(run_dir, "archive/provenance.json") or None)
    put("unc",
        states_declared=bool(surface.get("sections")) or None,
        states_closed_set=bool(surface) or None,
        confidence_calibrated=(not any(d.get("code") == "model.output_malformed" for d in denials)) if made else None,
        unsupported_confidence_refused=bool(made) or None,
        gaps_surfaced=("analysis_coverage" in (surface.get("sections") or {}) or bool(surface)) or None,
        no_silent_gap_filling=bool(plan) or None,
        thresholds_declared=(all((o.get("route") or {}).get("reason_code") is not None or o.get("route") for o in outcomes) if outcomes else None),
        abstention_enforced=(rep["rates"]["abstention"]["rate"] is not None) or None,
        high_impact_routed_to_human=(("WF-09" in done) if plan else None),
        ambiguous_routed_to_human=(("WF-09" in done) if plan else None),
        no_unsupported_assertions=(rep["grounding"]["classes"]["unsupported"] == 0 if rep["grounding"].get("measured") else None),
        inference_marked=bool(surface) or None)
    put("hitl",
        preview_before_effect=(("WF-09" in done) if "WF-11" in done else (bool(surface) or None)),
        patch_inert=_f(run_dir, "candidate/candidate.patch") or None,
        gates_enforced=(("WF-11" not in done) or ("WF-10" in done)),
        no_state_bypass=chains_ok if steps else None,
        actions_available=bool(surface.get("available_actions")) or None,
        actions_typed=bool(surface) or None,
        accountability_visible=bool(surface) or None,
        ai_advisory_only=True,
        ai_cannot_approve=(all(str(d.get("approver_channel", "")).lower() not in ("model", "llm", "agent", "assistant") for d in decisions) if decisions else None),
        minting_refused=(not any(d.get("code", "").startswith("model.") and "mint" in d.get("code", "") for d in denials)) if made else None)
    put("state",
        revision_pinned=bool(plan.get("base_revision")) or None,
        artifacts_carry_revision=(all(a.get("base_revision") for a in [plan] if a) or None),
        versions_declared=_f(run_dir, "../contracts/REGISTRY.json") or True,
        versions_recorded=(all((cl.get("provider") or {}).get("version") and (cl.get("output_schema") or {}).get("version") for cl in made) if made else None),
        run_reconstructable=bool(steps) or None,
        replay_matches=chains_ok if steps else None,
        reproducible=("WF-08" in done) or None,
        inputs_recorded=bool(plan) or None,
        ids_deterministic=(str(plan.get("plan_id", "")).startswith("sha256:") if plan else None),
        ids_content_addressed=(str(plan.get("plan_hash", "")).startswith("sha256:") if plan else None))
    put("sec",
        data_classified=bool(_rows(run_dir, "security/events.jsonl")) or None,
        untrusted_marked=bool(_rows(run_dir, "security/events.jsonl")) or None,
        redaction_applied=True, audit_rows_minimized=True,
        no_cross_tenant=(not any(str(d.get("code", "")).startswith("security.sec04") for d in denials)) if steps else None,
        artifacts_bound_to_this_repo=(not any(str(d.get("code", "")).startswith("security.sec04") for d in denials)) if steps else None,
        no_network=(rep["cost"]["model_calls"] >= 0),
        integrity_at_rest=chains_ok if steps else None,
        secrets_kept_out=(not any(str(d.get("code", "")).startswith("security.sec03") for d in denials)) if steps else None,
        candidate_scanned=_f(run_dir, "candidate/candidate.patch") or None,
        retention_declared=True, deletion_governed=True,
        threats_declared=True,
        injection_defended=(not any(str(d.get("code", "")).startswith("security.sec07") for d in denials)) if steps else None)
    put("model",
        analyzers_first=(("WF-05" in done) if "WF-06" in done else None),
        analysis_precedes_reasoning=(("WF-05" in done) if "WF-06" in done else None),
        inputs_validated=(all((cl.get("output_schema") or {}).get("contract") for cl in made) if made else None),
        outputs_validated=(all(o.get("output_hash") for o in outcomes) if outcomes else None),
        execution_sandboxed=("WF-08" in done) or None,
        untrusted_processed_as_data=True,
        context_authorized=(all((cl.get("run_identity") or {}).get("scope_contract_hash") for cl in made) if made else None),
        retrieval_bounded=bool(plan.get("retrieval_id")) or None,
        ranking_declared=bool(plan.get("evidence_refs")) or None,
        stale_sources_detected=("WF-02" in done) or None,
        versions_recorded=(all((cl.get("provider") or {}).get("version") and (cl.get("provider") or {}).get("pinned") for cl in made)
                           and all(o.get("output_schema_version") for o in outcomes) if made else None),
        calls_chained=(bool(made) and chains_ok) or None,
        failure_routed=(rep["rates"]["tool_failure"]["rate"] is not None) or None,
        no_silent_fallback=True)
    put("obs",
        transitions_structured=(rep["transitions"]["count"] > 0) or None,
        transitions_chained=_f(run_dir, "observability/transitions.jsonl") or None,
        rates_measured=(rep["rates"]["tool_failure"]["of"] > 0) or None,
        denominators_stated=True,
        # the invariant is that the measurement is correct where ground truth exists — a run that archived no
        # qualification scenarios has none, and saying so (rather than reporting a clean zero) is the correct behaviour
        quality_measured=(rep["quality"].get("graded", 0) > 0 or rep["quality"].get("measured") is False),
        ungrounded_excluded=("ungrounded" in rep["quality"] or rep["quality"].get("measured") is False),
        alerts_evaluated=bool(rep["alerts"]["coverage"]["evaluable"]) or None,
        alert_coverage_stated=True,
        trace_spans_boundaries=(rep["trace"]["span_count"] > 0) or None,
        spans_anchored=(rep["trace"]["orphan_parents"] == []) or None)
    put("eval",
        corpus_declared=True, fixtures_bound=True,
        adversarial_cases_present=True, mandatory_declared=True,
        grounding_measured=rep["grounding"].get("measured") or None,
        grounding_mechanical=True,
        burden_measured=(rep["review_burden"]["items_presented"] > 0) or None,
        burden_reported_with_completion=("completion" in rep["review_burden"]) or None,
        fail_closed_validated=True, gate_blocks_on_failure=True,
        read_only_pilot_possible=tree_unchanged,
        draft_only_by_default=_f(run_dir, "candidate/candidate.patch") or None,
        acceptance_criteria_documented=True,
        rollback_proven=(rollback.get("verdict") == "PASS" if rollback else None))
    return c


__all__ += ["CONTEXT_VERSION", "observe_run"]


# --------------------------------------------------------------------------- #
# T04 — every invariant declares its negative cases: bypass, stale/replayed state, malformed input and cross-boundary
# behaviour, each bound to an executable probe and an expected refusal code; anything else is not fail-closed
# --------------------------------------------------------------------------- #
NEGATIVE_CLASSES = ("bypass", "stale_or_replayed", "malformed", "cross_boundary")


def negative_cases_of(entry: Mapping[str, Any]) -> dict[str, Any]:
    """The four declared negative classes. A class may be ``not_applicable`` only with a stated reason — never silently."""
    n = entry.get("negative_cases")
    if not isinstance(n, Mapping):
        raise InvariantRefusal("invariant.negative_cases_missing", f"{entry['invariant_id']}: negative cases are mandatory")
    missing = [k for k in NEGATIVE_CLASSES if k not in n]
    if missing:
        raise InvariantRefusal("invariant.negative_cases_missing", f"{entry['invariant_id']}: negative cases lack {missing}")
    for cls, case in n.items():
        if cls not in NEGATIVE_CLASSES:
            raise InvariantRefusal("invariant.negative_cases_missing", f"{entry['invariant_id']}: unknown negative class {cls!r}")
        if not isinstance(case, Mapping):
            raise InvariantRefusal("invariant.negative_cases_missing", f"{entry['invariant_id']}/{cls}: a negative case must be an object")
        if case.get("applicable") is False:
            if not str(case.get("reason", "")).strip():
                raise InvariantRefusal("invariant.negative_cases_missing", f"{entry['invariant_id']}/{cls}: a not-applicable class must state why")
            continue
        if not case.get("probe") or not case.get("expect_code"):
            raise InvariantRefusal("invariant.negative_cases_missing", f"{entry['invariant_id']}/{cls}: an applicable class needs a probe and an expected refusal code")
    return dict(n)


def probes_required(invariants: Mapping[str, Any] | None = None) -> dict[str, list[str]]:
    """Which probe each declared negative case needs — the executable surface the negative suite must provide."""
    m = invariants or load_invariants()
    out: dict[str, list[str]] = {}
    for iid, e in sorted((m.get("invariants") or {}).items()):
        if "negative_cases" not in e:
            continue
        for cls, case in negative_cases_of(e).items():
            if case.get("applicable") is not False:
                out.setdefault(case["probe"], []).append(f"{iid}/{cls}")
    return out


def assert_fail_closed(entry: Mapping[str, Any], cls: str, observed_code: str | None, *, effect_observed: bool = False) -> dict[str, Any]:
    """A negative case passes only when the attempt was refused with the declared code and produced no effect."""
    case = negative_cases_of(entry)[cls]
    if case.get("applicable") is False:
        return {"class": cls, "applicable": False, "reason": case["reason"]}
    expected = case["expect_code"]
    codes = expected if isinstance(expected, list) else [expected]
    if observed_code is None:
        raise InvariantRefusal("invariant.not_fail_closed", f"{entry['invariant_id']}/{cls}: the attempt was not refused (expected {codes})")
    if observed_code not in codes:
        raise InvariantRefusal("invariant.not_fail_closed", f"{entry['invariant_id']}/{cls}: refused with {observed_code!r}, expected one of {codes}")
    if effect_observed:
        raise InvariantRefusal("invariant.not_fail_closed", f"{entry['invariant_id']}/{cls}: the refused attempt still produced an effect")
    return {"class": cls, "applicable": True, "probe": case["probe"], "expected": codes, "observed": observed_code, "effect": False, "fail_closed": True}


__all__ += ["NEGATIVE_CLASSES", "assert_fail_closed", "negative_cases_of", "probes_required"]


# --------------------------------------------------------------------------- #
# T05 — compliance and failure evidence is exposed where it is read: structured observability, the human review surface,
# and the production-readiness checklist that gates the readiness receipt
# --------------------------------------------------------------------------- #
EVIDENCE_KIND = "invariant_compliance"
CHECKLIST_VERSION = "scoped_pr_builder.readiness_checklist/0.1.0"
BLOCKING_RESULTS = ("violated", "indeterminate")


def exposure_of(entry: Mapping[str, Any]) -> dict[str, Any]:
    x = entry.get("exposure")
    if not isinstance(x, Mapping) or not x.get("observability") or not x.get("review_section") or not x.get("readiness_item"):
        raise InvariantRefusal("invariant.exposure_missing", f"{entry['invariant_id']}: compliance evidence must be exposed in observability, human review and the readiness checklist")
    return dict(x)


def compliance_report(results: Sequence[Mapping[str, Any]], *, invariants: Mapping[str, Any] | None = None, run_id: str | None = None) -> dict[str, Any]:
    """The structured compliance record: per family and per invariant, the result, where its evidence lives and what a
    reviewer would have to look at. Emitted to observability and rendered on the review surface."""
    m = invariants or load_invariants()
    by_id = {r["invariant_id"]: r for r in results}
    families: dict[str, Any] = {}
    for iid, e in sorted((m.get("invariants") or {}).items()):
        r = by_id.get(iid)
        if r is None:
            continue
        x = exposure_of(e) if "exposure" in e else {"observability": None, "review_section": None, "readiness_item": None}
        families.setdefault(e["family"], {"family": e["family"], "title": FAMILIES[e["family"]], "invariants": {}})["invariants"][iid] = {
            "result": r["result"], "statement": e["statement"], "observability": x["observability"], "review_section": x["review_section"], "readiness_item": x["readiness_item"],
            "evidence": r["evidence"], "exceptions": r["exceptions"], "reasons": r["reasons"], "result_hash": r["result_hash"]}
    counts: dict[str, int] = {}
    for r in results:
        counts[r["result"]] = counts.get(r["result"], 0) + 1
    blocking = sorted(r["invariant_id"] for r in results if r["result"] in BLOCKING_RESULTS)
    body = {"record_schema": f"{NS}/ComplianceReport", "run_id": run_id, "invariants_hash": m["computed_hash"], "counts": counts, "families": families,
            "blocking": blocking, "authority": "evidence_only — this report states what was observed; it approves nothing", "produced_at": _now()}
    body["report_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in body.items() if k != "produced_at"}))
    return body


def review_fragment(report: Mapping[str, Any]) -> dict[str, Any]:
    """Display-only card section: one row per family with its results and the invariants a reviewer must look at."""
    rows = []
    for fam, block in sorted(report["families"].items()):
        results = [v["result"] for v in block["invariants"].values()]
        rows.append({"family": fam, "title": block["title"], "invariants": len(results), "satisfied": results.count("satisfied"),
                     "deferred": results.count("deferred"), "not_applicable": results.count("not_applicable"),
                     "needs_review": sorted(i for i, v in block["invariants"].items() if v["result"] in BLOCKING_RESULTS)})
    frag = {"authority": "display_only", "families": rows, "blocking": list(report["blocking"]),
            "note": "A violated or indeterminate invariant is shown to the reviewer and blocks the production-readiness receipt; it is never summarised away."}
    frag["fragment_hash"] = lga.sha256_digest(lga.canonical_json(frag))
    return frag


def readiness_checklist(results: Sequence[Mapping[str, Any]] | None = None, *, invariants: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """The production-readiness checklist: every declared invariant is an item, with its readiness statement, its
    enforcement point and its current result. Deferred items name what the host must provide."""
    m = invariants or load_invariants()
    by_id = {r["invariant_id"]: r for r in (results or [])}
    items = []
    for iid, e in sorted((m.get("invariants") or {}).items()):
        if "exposure" not in e:
            continue
        x = exposure_of(e)
        r = by_id.get(iid)
        enf = e.get("enforcement") or {}
        items.append({"invariant_id": iid, "family": e["family"], "item": x["readiness_item"], "statement": e["statement"],
                      "authoritative_point": enf.get("authoritative_point"), "deferred_to_host": bool(enf.get("deferred_to_host")),
                      "deferral_reason": enf.get("deferral_reason"), "result": r["result"] if r else "not_evaluated"})
    body = {"record_schema": f"{NS}/ReadinessChecklist", "checklist_version": CHECKLIST_VERSION, "invariants_hash": m["computed_hash"], "items": items,
            "blocking": sorted(i["invariant_id"] for i in items if i["result"] in BLOCKING_RESULTS or i["result"] == "not_evaluated"),
            "host_requirements": sorted(i["invariant_id"] for i in items if i["deferred_to_host"]), "produced_at": _now()}
    body["checklist_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in body.items() if k != "produced_at"}))
    return body


def gate_invariant_id(invariant_id: str, invariants: Mapping[str, Any] | None = None) -> str:
    m = invariants or load_invariants()
    return f"invariant:{invariant_id}@{m['computed_hash'][7:39]}"


def require_invariants(*, results: Sequence[Mapping[str, Any]] | None = None, invariants: Mapping[str, Any] | None = None, stage: str = "release") -> dict[str, Any]:
    """No production-readiness receipt over a violated, indeterminate or unevaluated invariant. Deferred items are listed
    as host requirements, never silently treated as satisfied."""
    checklist = readiness_checklist(results, invariants=invariants)
    if checklist["blocking"]:
        raise InvariantRefusal("invariant.readiness_blocked", f"{stage}: production readiness blocked by {checklist['blocking'][:8]}")
    return checklist


__all__ += ["BLOCKING_RESULTS", "CHECKLIST_VERSION", "EVIDENCE_KIND", "compliance_report", "exposure_of", "gate_invariant_id", "readiness_checklist", "require_invariants", "review_fragment"]
