"""Scoped PR Builder — governed workflow state machine (Phase 06 / WF-01..12).

``workflow/WORKFLOW.json`` declares the twelve paper workflow steps as versioned states/transitions over the
run-state machine of ``controls`` (INTAKE → BOUND → INTENT_ACCEPTED → PLANNED → PATCH_INERT → VERIFIED →
REVIEW_PENDING → APPROVED → APPLIED_ISOLATED → ARCHIVED, terminal ROLLED_BACK / BLOCKED / ABSTAINED / CANCELLED).
Each step declares its preconditions (prior steps, admissible run states, evidence), inputs, outputs, timestamps and
terminal/error states; ``WorkflowRun`` persists every attempt (before and after) as hash-chained step records under
``<run_dir>/workflow/steps.jsonl`` — the executable mirror of ``scoped_pr_builder_state.dmk`` — and is replayable
from that file alone.

The orchestrator holds no authority: it advances the run state only through ``controls.validate_transition`` with
the evidence hashes a step actually produced, and it never synthesizes evidence, permissions, approvals or
verification results a step did not receive.

Build provenance: BUILD_NEW (stdlib), composing controls / components / adapters.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Mapping, Sequence

from . import contracts as C
from . import controls as CT
from . import local_git_adapter as lga
from . import security as _SEC
from .archive_adapter import _chain_append, verify_chain_file

WORKFLOW_VERSION = "scoped_pr_builder.workflow/0.1.0"
WORKFLOW_PATH = Path(__file__).resolve().parent.parent / "workflow" / "WORKFLOW.json"
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
STEP_SCHEMA = "overlay.scoped_pr_builder.workflow/StepRecord"
OUTCOMES = ("SUCCEEDED", "FAILED", "BLOCKED", "ABSTAINED", "CANCELLED", "TIMEOUT")
STEP_REQUIRED = ("step_id", "version", "title", "order", "run_state_from", "run_state_to", "transition_evidence", "preconditions", "inputs", "outputs", "timestamps", "terminal_states", "authoritative_suites", "introduced_by")
_EXEC: dict[str, Callable[..., dict[str, Any]]] = {}


class WorkflowRefusal(lga.AdapterError):
    """Raised by the workflow boundary (precondition unmet, state mismatch, step not executable, ...)."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def register_step(step_id: str):
    def deco(fn):
        _EXEC[step_id] = fn
        return fn
    return deco


def load_workflow(path: Path = WORKFLOW_PATH, *, registry: Mapping[str, Any] | None = None, repo_root: Path = REPO_ROOT) -> dict[str, Any]:
    if not Path(path).is_file():
        raise WorkflowRefusal("workflow.registry_missing", f"workflow registry not found: {path}")
    wf = json.loads(Path(path).read_text(encoding="utf-8"))
    if wf.get("workflow_version") != WORKFLOW_VERSION:
        raise WorkflowRefusal("workflow.registry_invalid", "unsupported workflow_version")
    orders = []
    for sid, s in (wf.get("steps") or {}).items():
        missing = [k for k in STEP_REQUIRED if k not in s]
        if missing or s["step_id"] != sid or not C.SEMVER_RE.match(s["version"]):
            raise WorkflowRefusal("workflow.registry_invalid", f"{sid}: missing {missing} / id or version invalid")
        for st in list(s["run_state_from"]) + [s["run_state_to"]]:
            if st not in CT.STATES:
                raise WorkflowRefusal("workflow.registry_invalid", f"{sid}: unknown run state {st!r}")
        for frm in s["run_state_from"]:
            path_states = [frm] + list(s.get("intermediate_states", [])) + [s["run_state_to"]]
            if s["run_state_to"] != frm and not s.get("terminal_step"):
                for a, b in zip(path_states, path_states[1:]):
                    if b not in CT.TRANSITIONS.get(a, ()):
                        raise WorkflowRefusal("workflow.registry_invalid", f"{sid}: {a} -> {b} is not a declared run-state transition")
        pre = s["preconditions"]
        if any(k not in pre for k in ("prior_steps", "run_states", "evidence")):
            raise WorkflowRefusal("workflow.registry_invalid", f"{sid}: preconditions need prior_steps, run_states, evidence")
        for p in pre["prior_steps"]:
            if p not in wf["steps"]:
                raise WorkflowRefusal("workflow.registry_invalid", f"{sid}: prior step {p} undeclared")
        if set(s["terminal_states"]) - set(OUTCOMES):
            raise WorkflowRefusal("workflow.registry_invalid", f"{sid}: unknown terminal state")
        for f in s["authoritative_suites"]:
            if not (Path(repo_root) / f).is_file():
                raise WorkflowRefusal("workflow.suite_unbound", f"{sid}: authoritative suite file does not exist: {f}")
        orders.append(int(s["order"]))
    if orders and sorted(orders) != list(range(1, len(orders) + 1)):
        raise WorkflowRefusal("workflow.registry_invalid", "step orders must be 1..N without gaps")
    body = {k: v for k, v in wf.items() if k != "workflow_hash"}
    wf["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return wf


def _identity(value: Any) -> Any:
    """Identity view of an input/output for the step record: hashes/ids for mappings, digests for bytes, values otherwise."""
    from . import components as K
    v = K.canon(value)
    if isinstance(v, Mapping):
        ids = {k: v[k] for k in sorted(v) if k.endswith(("_hash", "_id", "_revision")) and isinstance(v[k], str)}
        return ids or {"digest": K.digest(v)}
    if isinstance(v, list):
        return {"count": len(v), "digest": K.digest(v)}
    return v


class WorkflowRun:
    """One governed run: current run state, completed steps, produced artifacts, persisted attempts (chained)."""

    def __init__(self, run_dir: Path, *, run_id: str, workflow: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> None:
        self.run_dir = Path(run_dir).resolve()
        _SEC.use_trail(self.run_dir)  # SEC-01-T02: every denial in this run lands on the run's security trail
        self.run_id = run_id
        self.registry = registry or C.load_registry()
        self.workflow = workflow or load_workflow(registry=self.registry)
        self.steps_path = self.run_dir / "workflow" / "steps.jsonl"
        self.events_path = self.run_dir / "workflow" / "events.jsonl"
        self.state = CT.START_STATE
        self.completed: dict[str, dict[str, Any]] = {}
        self.attempts: dict[str, int] = {}
        self.last_attempt: dict[str, dict[str, Any]] = {}
        self.artifacts: dict[str, Any] = {}
        self.evidence: dict[str, str] = {}
        self._intermediate: list[dict[str, Any]] = []

    # ---- persistence / replay ------------------------------------------------------------------------------
    def records(self) -> list[dict[str, Any]]:
        if not self.steps_path.is_file():
            return []
        verify_chain_file(self.steps_path)
        return [json.loads(l) for l in self.steps_path.read_text(encoding="utf-8").splitlines() if l.strip()]

    @classmethod
    def load(cls, run_dir: Path, *, workflow: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None) -> "WorkflowRun":
        """Rebuild the run purely from its chained step records (review / replay of a failed or finished run)."""
        run_dir = Path(run_dir).resolve()
        path = run_dir / "workflow" / "steps.jsonl"
        if not path.is_file():
            raise WorkflowRefusal("workflow.no_records", f"no step records under {run_dir}")
        verify_chain_file(path)
        rows = [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
        run = cls(run_dir, run_id=rows[0]["run_id"], workflow=workflow, registry=registry)
        for r in rows:
            run.attempts[r["step_id"]] = max(run.attempts.get(r["step_id"], 0), int(r["attempt_no"]))
            if r["phase"] == "after":
                run.state = r["run_state_after"]
                run.last_attempt[r["step_id"]] = r
                if r["outcome"] == "SUCCEEDED":
                    run.completed[r["step_id"]] = r
                    run.evidence.update(r.get("evidence", {}))
        return run

    def _persist(self, row: dict[str, Any]) -> dict[str, Any]:
        row = {"record_schema": STEP_SCHEMA, "workflow_version": WORKFLOW_VERSION, "run_id": self.run_id, **row}
        row["record_hash"] = lga.sha256_digest(lga.canonical_json(row))
        return _chain_append(self.steps_path, row)

    def _emit(self, kind: str, payload: Mapping[str, Any]) -> None:  # WF-*-T04 binds structured events here
        return None

    # ---- preconditions ---------------------------------------------------------------------------------------
    def step(self, step_id: str) -> dict[str, Any]:
        s = self.workflow["steps"].get(step_id)
        if s is None:
            raise WorkflowRefusal("workflow.step_unknown", f"no such step {step_id!r}")
        return s

    def check_preconditions(self, step_id: str) -> dict[str, Any]:
        """Fail closed unless every prior step SUCCEEDED, the run is in an admissible state, and the evidence exists."""
        s = self.step(step_id)
        if self.state in CT.TERMINAL_STATES:
            raise WorkflowRefusal("workflow.terminal", f"run is terminal ({self.state}); {step_id} cannot start")
        pre = s["preconditions"]
        missing = [p for p in pre["prior_steps"] if p not in self.completed]
        if missing:
            raise WorkflowRefusal("workflow.precondition_unmet", f"{step_id} requires successful {missing}; the next state is unreachable until they succeed")
        if self.state not in pre["run_states"]:
            raise WorkflowRefusal("workflow.state_mismatch", f"{step_id} admits run states {pre['run_states']}, run is {self.state}")
        lacking = [e for e in pre["evidence"] if e not in self.evidence]
        if lacking:
            raise WorkflowRefusal("workflow.evidence_missing", f"{step_id} requires evidence {lacking}; nothing is assumed")
        return {"prior_steps": list(pre["prior_steps"]), "run_state": self.state, "evidence": {e: self.evidence[e] for e in pre["evidence"]}, "satisfied": True}

    def advance(self, to_state: str, evidence: Mapping[str, str]) -> dict[str, Any]:
        """An intermediate run-state transition inside a step (validated by controls; recorded on the step's after row)."""
        t = CT.validate_transition(self.state, to_state, evidence)
        self.state = to_state
        self.evidence.update(t["evidence"])
        self._intermediate.append(t)
        return t

    def next_state_reachable(self, step_id: str) -> bool:
        try:
            self.check_preconditions(step_id)
            return True
        except lga.AdapterError:
            return False

    # ---- attempts ---------------------------------------------------------------------------------------------
    def _attempt_identity(self, step_id: str, inputs_hash: str, retry: bool) -> tuple[str, int, str | None]:
        n = self.attempts.get(step_id, 0) + 1
        return lga.sha256_digest(lga.canonical_json({"run": self.run_id, "step": step_id, "attempt": n})), n, None

    def start_step(self, step_id: str, inputs: Mapping[str, Any], *, retry: bool = False) -> dict[str, Any]:
        """Open one attempt: preconditions checked and persisted with the input identities before anything runs."""
        s = self.step(step_id)
        if self.state in CT.TERMINAL_STATES:
            raise WorkflowRefusal("workflow.terminal", f"run is terminal ({self.state}); {step_id} cannot start")
        if step_id in self.completed:
            raise WorkflowRefusal("workflow.step_already_succeeded", f"{step_id} already succeeded in this run")
        if step_id in self.last_attempt and self.last_attempt[step_id]["outcome"] != "SUCCEEDED" and not retry:
            raise WorkflowRefusal("workflow.retry_required", f"{step_id} failed before; an explicit retry allocates a new attempt")
        pre = self.check_preconditions(step_id)
        undeclared = sorted(set(inputs) - set(s["inputs"]))
        if undeclared:
            raise WorkflowRefusal("workflow.input_undeclared", f"{step_id}: undeclared inputs {undeclared}")
        idents = {k: _identity(v) for k, v in inputs.items()}
        from . import components as K
        inputs_hash = K.digest(idents)
        attempt_id, n, replay_of = self._attempt_identity(step_id, inputs_hash, retry)
        self.attempts[step_id] = n
        att = {"step_id": step_id, "step_version": s["version"], "attempt_id": attempt_id, "attempt_no": n, "replay_of": replay_of, "phase": "before", "preconditions": pre, "inputs": idents, "inputs_hash": inputs_hash,
               "run_state_before": self.state, "started_at": _now(), "outcome": None}
        att = self._persist(att)
        self._emit("runtime.step_started", {"step_id": step_id, "attempt_id": attempt_id, "attempt_no": n, "run_state": self.state})
        self._emit("evidence.inputs", {"step_id": step_id, "attempt_id": attempt_id, "inputs": idents, "inputs_hash": inputs_hash})
        self._emit("provenance.attempt", {"step_id": step_id, "attempt_id": attempt_id, "replay_of": replay_of, "before_record": att["record_hash"]})
        return att

    def _predicate(self, s: Mapping[str, Any], outputs: Mapping[str, Any]) -> tuple[bool, str]:  # WF-*-T03 binds success predicates here
        return True, "no success predicate declared yet (T03)"

    def _route(self, s: Mapping[str, Any], code: str, attempt_no: int) -> tuple[str | None, str]:  # WF-*-T03 binds fail-closed routes here
        return None, "no fail-closed route declared yet (T03); the run stays in its state and does not advance"

    def finish_step(self, attempt: Mapping[str, Any], *, outputs: Mapping[str, Any] | None = None, error: lga.AdapterError | None = None) -> dict[str, Any]:
        """Close an attempt: on success evaluate the predicate and advance the run state through validate_transition
        with the evidence produced; on failure record the error and route fail-closed (never forward)."""
        s = self.step(attempt["step_id"]); step_id = s["step_id"]
        outputs = dict(outputs or {})
        before = attempt["run_state_before"]
        intermediate, self._intermediate = list(self._intermediate), []
        evidence = {name: outputs[name] for name in s["transition_evidence"] if isinstance(outputs.get(name), str)}
        outcome, reason, code, route_state, transition = "SUCCEEDED", "", None, None, None
        if error is not None:
            code = getattr(error, "code", "error"); reason = f"{code}: {error}"
            route_state, why = self._route(s, code, int(attempt["attempt_no"]))
            outcome = {"CANCELLED": "CANCELLED", "ABSTAINED": "ABSTAINED", "BLOCKED": "BLOCKED"}.get(route_state or "", "FAILED")
            if code in ("component.timeout", "workflow.timeout"):
                outcome = "TIMEOUT" if route_state is None else outcome
            reason = f"{reason} → {why}"
        else:
            ok, why = self._predicate(s, outputs)
            if not ok:
                code, reason = "workflow.predicate_failed", f"success predicate not satisfied: {why}"
                route_state, rwhy = self._route(s, code, int(attempt["attempt_no"]))
                outcome = {"ABSTAINED": "ABSTAINED", "BLOCKED": "BLOCKED", "CANCELLED": "CANCELLED"}.get(route_state or "", "FAILED")
                reason = f"{reason} → {rwhy}"
            else:
                reason = why
                lacking = [n for n in s["transition_evidence"] if n not in evidence]
                if lacking:
                    raise WorkflowRefusal("workflow.evidence_missing", f"{step_id} succeeded without producing transition evidence {lacking}; the transition is refused")
                if s["run_state_to"] != self.state:
                    transition = CT.validate_transition(self.state, s["run_state_to"], evidence)
                    self.state = s["run_state_to"]
        if route_state and route_state != self.state:
            declared = CT.TRANSITIONS.get(self.state, ())
            target = route_state if route_state in declared else ("BLOCKED" if "BLOCKED" in declared else None)
            if target is None:
                reason += f"; no declared transition from {self.state} to {route_state} — the run stays in {self.state} (recorded, not advanced)"
                route_state, outcome = None, "FAILED"
            else:
                if target != route_state:
                    reason += f"; {route_state} not reachable from {self.state} → {target}"
                    route_state = target
                transition = CT.validate_transition(self.state, target, {})
                self.state = target
        out_idents = {k: _identity(v) for k, v in outputs.items()} if outcome == "SUCCEEDED" else {}
        row = {"step_id": step_id, "step_version": s["version"], "attempt_id": attempt["attempt_id"], "attempt_no": attempt["attempt_no"], "replay_of": attempt.get("replay_of"), "phase": "after", "before_record": attempt["record_hash"],
               "inputs_hash": attempt["inputs_hash"], "outputs": out_idents, "evidence": evidence if outcome == "SUCCEEDED" else {}, "started_at": attempt["started_at"], "finished_at": _now(),
               "run_state_before": before, "run_state_after": self.state, "transition": transition, "intermediate_transitions": intermediate, "outcome": outcome, "reason": reason, "error_code": code, "route": route_state}
        row = self._persist(row)
        self.last_attempt[step_id] = row
        if outcome == "SUCCEEDED":
            self.completed[step_id] = row
            self.evidence.update(evidence)
            for k, v in outputs.items():
                self.artifacts[k] = v
        self._emit("evidence.outputs", {"step_id": step_id, "attempt_id": attempt["attempt_id"], "outputs": out_idents, "evidence": row["evidence"]})
        self._emit("decision.outcome", {"step_id": step_id, "attempt_id": attempt["attempt_id"], "outcome": outcome, "reason": reason, "route": route_state, "run_state": self.state})
        self._emit("provenance.link", {"step_id": step_id, "attempt_id": attempt["attempt_id"], "before_record": attempt["record_hash"], "after_record": row["record_hash"], "transition_hash": (transition or {}).get("transition_hash")})
        self._emit("runtime.step_finished", {"step_id": step_id, "attempt_id": attempt["attempt_id"], "outcome": outcome, "run_state": self.state})
        return row

    def run_step(self, step_id: str, inputs: Mapping[str, Any] | None = None, *, retry: bool = False) -> dict[str, Any]:
        """start → execute the bound step (T02) → finish; an unbound step refuses before any attempt is opened."""
        inputs = dict(inputs or {})
        if step_id not in _EXEC:
            self.step(step_id)
            raise WorkflowRefusal("workflow.step_not_executable", f"{step_id} declared but not yet composed (T02)")
        att = self.start_step(step_id, inputs, retry=retry)
        try:
            outputs = _EXEC[step_id](self, inputs)
        except lga.AdapterError as exc:
            return self.finish_step(att, error=exc)
        return self.finish_step(att, outputs=outputs)

    def summary(self) -> dict[str, Any]:
        return {"run_id": self.run_id, "run_state": self.state, "completed": sorted(self.completed), "attempts": dict(self.attempts), "evidence": dict(self.evidence), "records": len(self.records())}


__all__ = ["OUTCOMES", "STEP_SCHEMA", "WORKFLOW_PATH", "WORKFLOW_VERSION", "WorkflowRefusal", "WorkflowRun", "load_workflow", "register_step"]


# --------------------------------------------------------------------------- #
# T02 — step executors: each composes its authoritative suite through the existing adapters/components and hands
# forward only what it received or deterministically produced — never synthesized evidence, permissions or approvals
# --------------------------------------------------------------------------- #
from . import approval_adapter as _aa
from . import archive_adapter as _ar
from . import components as _K
from . import intake as _I
from . import intent_intake as _ii
from . import verification_checks as _VC

ANALYSIS_EFFECTS = ("repository.bind", "repository.read", "worktree.isolate", "diff.generate_inert", "verification.run_isolated", "review.render", "ledger.append")
PRIVILEGED_EFFECTS = ("patch.apply_isolated", "rollback.execute")


def _w(path: Path, payload: Any) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = lga.canonical_json(payload) + "\n"
    path.write_text(text, encoding="utf-8")
    return lga.sha256_digest(text)


def _need(run: WorkflowRun, *names: str) -> tuple[Any, ...]:
    out = []
    for n in names:
        if n not in run.artifacts:
            raise WorkflowRefusal("workflow.artifact_missing", f"artifact {n!r} was not produced by a prior successful step; nothing is assumed")
        out.append(run.artifacts[n])
    return tuple(out)


def _decide(run: WorkflowRun, effects: Sequence[str], context: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    """Policy decisions for effects, from the rule set and actor the run received at WF-01 — the orchestrator grants nothing."""
    authority, = _need(run, "authority")
    return [CT.policy_decide(authority["rule_set"], e, authority["role"], context or {}) for e in effects]


# @@ WF-01
@register_step("WF-01")
def _step_authenticate(run: WorkflowRun, inputs: Mapping[str, Any]) -> dict[str, Any]:
    """WF-01 Authenticate and establish authority (Chair 13 authorization / policy gates, 44.5 enforcement, 55.4 policy-bound
    execution rights): every requested effect is decided by the policy layer; the run carries only what was allowed."""
    actor, rule_set = inputs.get("actor"), inputs.get("rule_set")
    if not isinstance(actor, Mapping) or not actor.get("identity") or not actor.get("role"):
        raise WorkflowRefusal("authority.actor_missing", "an authenticated actor identity and role are required; none is assumed")
    if not isinstance(rule_set, Mapping):
        raise WorkflowRefusal("authority.rule_set_missing", "a policy rule set is required; the orchestrator holds no policy of its own")
    C.validate_payload("policy_layer", rule_set, registry=run.registry)
    required = list(inputs.get("required_effects") or ANALYSIS_EFFECTS)
    deferred = list(inputs.get("deferred_effects") or PRIVILEGED_EFFECTS)
    decisions = [CT.policy_decide(rule_set, e, actor["role"]) for e in required]
    denied = [d for d in decisions if d["decision"] != "allow"]
    if denied:
        raise WorkflowRefusal("authority.denied", f"policy denied {[d['effect'] for d in denied]}: {denied[0]['reason']}")
    deferred_decisions = [CT.policy_decide(rule_set, e, actor["role"]) for e in deferred]
    authority = {"record_schema": "overlay.scoped_pr_builder.workflow/Authority", "actor": {"identity": actor["identity"], "role": actor["role"]}, "role": actor["role"], "policy_hash": rule_set["policy_hash"], "policy_version": rule_set.get("policy_version"),
                 "granted_effects": [d["effect"] for d in decisions], "decisions": decisions, "deferred": [{"effect": d["effect"], "requires": d["requires"], "decided_now": d["decision"], "note": "re-decided at the step that exercises it, with the proofs it requires"} for d in deferred_decisions],
                 "rule_set": dict(rule_set), "established_at": _now()}
    authority["authority_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in authority.items() if k not in ("established_at", "rule_set")}))
    return {"authority": authority, "authority_hash": authority["authority_hash"], "granted_effects": authority["granted_effects"]}
# @@ WF-02
@register_step("WF-02")
def _step_pin(run: WorkflowRun, inputs: Mapping[str, Any]) -> dict[str, Any]:
    """WF-02 Pin the target artifacts and revisions (40.4 freshness, 40.6 provenance, 51.5, 65.01 intake): an exact binding of
    repository / worktree / revision / snapshot; the run directory must lie outside the repository."""
    authority, = _need(run, "authority")
    if "repository.bind" not in authority["granted_effects"]:
        raise WorkflowRefusal("authority.denied", "repository.bind was not granted at WF-01")
    repo = inputs.get("repo")
    if not repo:
        raise WorkflowRefusal("workflow.input_missing", "WF-02 requires the repository path")
    binding = lga.bind_repository(Path(repo), inputs.get("revision") or "HEAD")
    root = lga.canonical_root(Path(binding.root_path))
    if lga.path_within(run.run_dir, root):
        raise WorkflowRefusal("workflow.run_dir_inside_repository", "the run directory must lie outside the bound repository")
    _w(run.run_dir / "suite40" / "binding.json", json.loads(binding.to_json()))
    return {"binding": binding, "worktree_hash": binding.worktree_hash, "base_revision": binding.base_revision, "source_snapshot_hash": binding.source_snapshot_hash}
# @@ WF-03
@register_step("WF-03")
def _step_collect(run: WorkflowRun, inputs: Mapping[str, Any]) -> dict[str, Any]:
    """WF-03 Collect only authorized evidence (51.1/51.2/51.4, Funnel 09, Chair 13, 44.5, 55.4): accept the scope contract that
    bounds the run, then admit the evidence sources under the granted read scope (Phase 04 intake); the source tree must be ADMITTED."""
    authority, binding = _need(run, "authority", "binding")
    intent = inputs.get("intent")
    if not isinstance(intent, Mapping):
        raise WorkflowRefusal("workflow.input_missing", "WF-03 requires the intent payload (requested_by, kind, allowed paths, caps)")
    lga.revalidate_binding(binding)
    contract = json.loads(_ii.accept_intent(intent, binding).to_json())
    records = _I.admit_all(binding, granted_effects=authority["granted_effects"], registry=run.registry)
    reviews = _I.require_admitted(records, ["DATA-01"])
    _w(run.run_dir / "intent" / "scope_contract.json", contract)
    _w(run.run_dir / "intake" / "records.json", {sid: {k: v for k, v in r.items() if k not in ("items", "excluded")} for sid, r in records.items()})
    summary = {sid: {"state": r["state"], "route": _I.route(r)["route"], "items": r["counts"].get("items", 0), "intake_hash": r["intake_hash"]} for sid, r in records.items()}
    return {"scope_contract": contract, "scope_contract_hash": contract["scope_contract_hash"], "intake_records": records, "intake_summary": summary, "intake_reviews": reviews}
# @@ WF-04
@register_step("WF-04")
def _step_index(run: WorkflowRun, inputs: Mapping[str, Any]) -> dict[str, Any]:
    """WF-04 Normalize and index the evidence (51.1/51.2/51.4, Funnel 09, Filing Cabinet 12, 58.2, 65.01): COMP-01/02/03 over the
    pinned binding; declared packages only from the admitted DATA-02 record."""
    authority, binding, records = _need(run, "authority", "binding", "intake_records")
    g = authority["granted_effects"]
    r1 = _K.invoke("COMP-01", {"binding": binding}, granted_effects=g, registry=run.registry)
    idx, deps = r1.outputs["symbol_index"], r1.outputs["dependency_records"]
    r2 = _K.invoke("COMP-02", {"binding": binding, "symbol_index": idx, "dependency_records": deps}, granted_effects=g, registry=run.registry)
    r3 = _K.invoke("COMP-03", {"binding": binding, "dependency_records": deps, "manifest_intake": records.get("DATA-02")}, granted_effects=g, registry=run.registry)
    _w(run.run_dir / "index" / "symbol_index.json", idx); _w(run.run_dir / "index" / "code_graph.json", r2.outputs["code_graph"]); _w(run.run_dir / "index" / "dependency_graph.json", r3.outputs["dependency_graph"])
    return {"symbol_index": idx, "dependency_records": deps, "code_graph": r2.outputs["code_graph"], "dependency_graph": r3.outputs["dependency_graph"], "index_hash": idx["index_hash"],
            "component_results": {"COMP-01": r1.result_hash, "COMP-02": r2.result_hash, "COMP-03": r3.result_hash}}
# @@ WF-05
@register_step("WF-05")
def _step_deterministic_analysis(run: WorkflowRun, inputs: Mapping[str, Any]) -> dict[str, Any]:
    """WF-05 Run deterministic analysis first (Filing Cabinet 12, 58.2, 65.01, Observer 01, Chair 13, 44.5, 55.4): exact evidence
    retrieval and convention learning (COMP-04) before any model reasoning; results are pinned and hash-bound."""
    authority, binding, contract, idx, records = _need(run, "authority", "binding", "scope_contract", "symbol_index", "intake_records")
    r = _K.invoke("COMP-04", {"binding": binding, "scope_contract": contract, "symbol_index": idx, "intake": records}, granted_effects=authority["granted_effects"], registry=run.registry)
    eb = r.outputs["evidence_bundle"]
    _w(run.run_dir / "suite51" / "evidence.json", eb["evidence"]); _w(run.run_dir / "suite51" / "authority.json", eb["authority"]); _w(run.run_dir / "analysis" / "convention_profile.json", r.outputs["convention_profile"])
    return {"convention_profile": r.outputs["convention_profile"], "evidence_bundle": eb, "retrieval_id": eb["retrieval_id"], "profile_hash": r.outputs["convention_profile"]["profile_hash"], "component_results": {"COMP-04": r.result_hash}}
# @@ WF-06
@register_step("WF-06")
def _step_model_reasoning(run: WorkflowRun, inputs: Mapping[str, Any]) -> dict[str, Any]:
    """WF-06 Run model reasoning only over authorized, provenance-bearing context (51.x, Funnel 09, Chair 13, 44.5): the advisory
    plan (COMP-06) is derived from the pinned evidence bundle and convention profile only; an abstention is surfaced, never filled."""
    authority, binding, contract, eb, prof = _need(run, "authority", "binding", "scope_contract", "evidence_bundle", "convention_profile")
    try:  # MODEL-*-T02: the plan comes through the model boundary (pinned provider, labeled context, recorded call, routed output)
        r = _K.invoke("COMP-06", {"binding": binding, "scope_contract": contract, "evidence_bundle": eb, "convention_profile": prof, "run_dir": run.run_dir}, granted_effects=authority["granted_effects"], registry=run.registry)
    except _K.ComponentRefusal as exc:
        if exc.code == "component.model_output_refused":
            raise WorkflowRefusal("workflow.human_decision_required", f"WF-06: {exc}") from exc  # human review — never automatic repair
        raise
    plan, call = r.outputs["refactoring_plan"], r.outputs["model_call"]
    _w(run.run_dir / "plan" / "refactoring_plan.json", plan); _w(run.run_dir / "model" / "call.json", call)
    if plan["status"] != "PLANNED":
        raise WorkflowRefusal("plan.abstain", f"the plan abstained: {plan.get('abstain_reason')}")
    return {"refactoring_plan": plan, "plan_hash": plan["plan_hash"], "model_call_id": call["call_id"], "component_results": {"COMP-06": r.result_hash}}
# @@ WF-07
@register_step("WF-07")
def _step_generate(run: WorkflowRun, inputs: Mapping[str, Any]) -> dict[str, Any]:
    """WF-07 Generate a bounded draft artifact (Filing Cabinet 12, 58.2, 65.01, Observer 01, Chair 13, 44.5, 55.4): one inert,
    bounded candidate from a registered recipe (COMP-07); the patch is never applied here."""
    authority, binding, contract, plan = _need(run, "authority", "binding", "scope_contract", "refactoring_plan")
    recipe = inputs.get("recipe")
    if not recipe:
        raise WorkflowRefusal("workflow.input_missing", "WF-07 requires a registered recipe name")
    r = _K.invoke("COMP-07", {"binding": binding, "scope_contract": contract, "refactoring_plan": plan, "recipe": recipe}, granted_effects=authority["granted_effects"], registry=run.registry)
    cand = r.outputs["candidate"]; patch = r.outputs["patch_text"].encode("utf-8")
    _w(run.run_dir / "candidate" / "candidate.json", cand); (run.run_dir / "candidate" / "candidate.patch").write_bytes(patch)
    return {"candidate": cand, "patch": patch, "patch_hash": cand["patch_hash"], "candidate_id": cand["candidate_id"], "component_results": {"COMP-07": r.result_hash}}
# @@ WF-08
@register_step("WF-08")
def _step_verify(run: WorkflowRun, inputs: Mapping[str, Any]) -> dict[str, Any]:
    """WF-08 Verify the output with independent tools/checks (Filing Cabinet 12, 58.2, 65.01, Observer 01, Chair 13, 44.5): the
    governor (COMP-09) must ALLOW, the impact engine (COMP-05) reports reach, and the isolated runner (COMP-08) must PASS."""
    authority, binding, contract, cand, patch, idx, cg, dg = _need(run, "authority", "binding", "scope_contract", "candidate", "patch", "symbol_index", "code_graph", "dependency_graph")
    g = authority["granted_effects"]
    gov = _K.invoke("COMP-09", {"scope_contract": contract, "candidate": cand}, granted_effects=g, registry=run.registry).outputs["governor_decision"]
    _w(run.run_dir / "verification" / "governor_decision.json", gov)
    if gov["verdict"] == "REFUSE":
        raise WorkflowRefusal("governor.refused", f"size/scope governor refused: {gov['reason']}")
    if gov["verdict"] == "ABSTAIN":
        raise WorkflowRefusal("governor.abstained", f"size/scope governor could not decide: {gov['reason']}")
    imp = _K.invoke("COMP-05", {"binding": binding, "candidate": cand, "patch": patch, "symbol_index": idx, "code_graph": cg, "dependency_graph": dg, "scope_contract": contract}, granted_effects=g, registry=run.registry).outputs["impact_report"]
    _w(run.run_dir / "verification" / "impact_report.json", imp)
    r = _K.invoke("COMP-08", {"binding": binding, "scope_contract": contract, "candidate": cand, "patch": patch, "impact_report": imp}, granted_effects=g, registry=run.registry, sandbox=run.run_dir / "sandbox")
    report = r.outputs["verification_report"]
    _w(run.run_dir / "verification" / "report.json", report)
    if report["verdict"] == "FAIL":
        raise WorkflowRefusal("verification.failed", "isolated verification FAILED: " + "; ".join(f"{j['check']}={j['verdict']}" for j in report["jobs"] if j["verdict"] != "PASS"))
    if report["verdict"] != "PASS":
        raise WorkflowRefusal("verification.indeterminate", "isolated verification is INDETERMINATE: " + "; ".join(f"{j['check']}={j['verdict']}" for j in report["jobs"] if j["verdict"] != "PASS"))
    # VERIFY-*-T03: the gate consumes typed check receipts (derived from executed jobs), never the planner's or model's word
    results = r.outputs["check_results"]
    subject = _VC.subject_of(binding, contract, cand)
    decision = _VC.gate(results, subject, registry=run.registry)
    _w(run.run_dir / "verification" / "check_results.json", results); _w(run.run_dir / "verification" / "gate_decision.json", decision)
    if decision["decision"] != "PROCEED":
        raise WorkflowRefusal("verify.gate_blocked", "verification gate BLOCK on " + ", ".join(f"{c} ({decision['per_check'][c]['status']})" for c in decision["blocking"]))
    return {"governor_decision": gov, "impact_report": imp, "verification_report": report, "test_selection": r.outputs["test_selection"], "report_hash": report["report_hash"], "check_results": results, "gate_decision": decision, "gate_decision_hash": decision["decision_hash"], "component_results": {"COMP-09": gov["decision_hash"], "COMP-05": imp["impact_hash"], "COMP-08": r.result_hash}}
# @@ WF-09
@register_step("WF-09")
def _step_expose(run: WorkflowRun, inputs: Mapping[str, Any]) -> dict[str, Any]:
    """WF-09 Expose evidence, uncertainty, scope and verification results to the human reviewer (50.5, 44.4, 49.14, 66.08, 50.6,
    55.3): the review card (COMP-10) with intake states, impact and guardrails; display-only, gate PENDING_HUMAN."""
    authority, binding, contract, eb, plan, cand, patch, report, imp, records = _need(run, "authority", "binding", "scope_contract", "evidence_bundle", "refactoring_plan", "candidate", "patch", "verification_report", "impact_report", "intake_records")
    r = _K.invoke("COMP-10", {"binding": binding, "scope_contract": contract, "evidence": eb["evidence"], "authority": eb["authority"], "refactoring_plan": plan, "candidate": cand, "patch": patch, "verification_report": report, "impact_report": imp, "intake": records},
                  granted_effects=authority["granted_effects"], registry=run.registry)
    card = r.outputs["review_card"]
    _w(run.run_dir / "review" / "review_card.json", card); (run.run_dir / "review" / "review_card.html").write_text(r.outputs["html"], encoding="utf-8")
    from . import review_surface as _RS  # HUMAN-*-T02: the reviewer surface, bound to the run/candidate hashes and persisted beside the card
    arts = dict(run.artifacts, review_card=card)
    surface = _RS.bind_view(_RS.build_surface(arts, run_id=run.run_id, run_dir=run.run_dir, registry=run.registry), arts, run_id=run.run_id)
    _w(run.run_dir / "review" / "surface.json", surface); (run.run_dir / "review" / "surface.html").write_text(_RS.render_surface_html(surface), encoding="utf-8")
    return {"review_card": card, "card_hash": card["card_hash"], "approval_gate": r.outputs["approval_gate"], "review_surface_hash": surface["view_hash"], "component_results": {"COMP-10": r.result_hash}}
# @@ WF-10
@register_step("WF-10")
def _step_human_decision(run: WorkflowRun, inputs: Mapping[str, Any]) -> dict[str, Any]:
    """WF-10 Require the paper-specified human decision before any subsequent state change (50.5, 44.4, 49.14, 66.08): a signed,
    hash-bound APPROVE receipt issued by a human through the approval adapter is verified; nothing else advances the run."""
    binding, contract, cand, card, report, results = _need(run, "binding", "scope_contract", "candidate", "review_card", "verification_report", "check_results")
    _VC.require_gate(results, _VC.subject_of(binding, contract, cand), stage="WF-10", registry=run.registry)  # VERIFY-*-T03: re-gated on receipts before any human decision is accepted
    receipt, key = inputs.get("receipt"), inputs.get("key")
    if not isinstance(receipt, Mapping) or not isinstance(key, (bytes, bytearray)):
        raise WorkflowRefusal("workflow.human_decision_required", "WF-10 requires the human's approval receipt and the verification key; the orchestrator cannot decide")
    _SEC.enforce_sec01_effect(receipt, card, plan=run.artifacts.get("refactoring_plan"), run_dir=run.run_dir)  # SEC-01-T02: the effect boundary
    _aa.verify_receipt(run.run_dir, bytes(key), receipt, candidate=cand, card=card, report=report)
    from . import review_surface as _RS  # HUMAN-*-T04: a verified receipt over changed bound inputs, or invalidated by a later human command, is never reused
    _RS.assert_approval_current(run.run_dir, receipt, run.artifacts)
    decision = {"decision": receipt["decision"], "approver_identity": receipt["approver_identity"], "approver_channel": receipt.get("approver_channel"), "receipt_hash": receipt["receipt_hash"], "issued_at": receipt.get("issued_at")}
    if inputs.get("command") is not None:  # HUMAN-*-T03: the decision links to the reviewer's executed typed command (what was shown → what was decided)
        from . import review_surface as _RS
        decision["command"] = _RS.verify_command_for_receipt(run.run_dir, inputs["command"], receipt, registry=run.registry)
    _w(run.run_dir / "review" / "human_decision.json", decision)
    return {"approval_receipt": dict(receipt), "receipt_hash": receipt["receipt_hash"], "human_decision": decision}
# @@ WF-11
@register_step("WF-11")
def _step_record(run: WorkflowRun, inputs: Mapping[str, Any]) -> dict[str, Any]:
    """WF-11 Record the full evidence and decision trail (51.x, Funnel 09, Anthology 02, Archive Ledger 29.5, Cypher 11): the approved
    candidate is applied in an isolated worktree only after the privileged effect is re-decided with the verified receipt and fresh
    revalidation proofs, then every artifact is frozen into the content-addressed archive with chained state/audit ledgers."""
    authority, binding, contract, cand, patch, report, card, receipt = _need(run, "authority", "binding", "scope_contract", "candidate", "patch", "verification_report", "review_card", "approval_receipt")
    key = inputs.get("key")
    if not isinstance(key, (bytes, bytearray)):
        raise WorkflowRefusal("workflow.input_missing", "WF-11 requires the approval verification key")
    lga.revalidate_binding(binding)
    results, = _need(run, "check_results")
    _SEC.assert_audit_intact(run.run_dir)  # SEC-08-T02: every chain re-verified before the privileged effect
    _SEC.require_release_gate(stage="WF-11", inputs=inputs, run_dir=run.run_dir)  # SEC-*-T05: mandatory, non-waivable security regression gate
    _VC.require_gate(results, _VC.subject_of(binding, contract, cand), stage="WF-11", registry=run.registry)  # VERIFY-*-T03: re-gated on receipts before the privileged effect is decided
    allowed = tuple(PurePosixPath(p) for p in contract["allowed_paths"]); forbidden = tuple(PurePosixPath(p) for p in contract.get("forbidden_paths", ()))
    confined = all(lga.within(PurePosixPath(p), allowed) and not lga.within(PurePosixPath(p), forbidden) for p in cand["canonical_paths"])
    decision = _decide(run, ["patch.apply_isolated"], {"human_approval_receipt_verified": run.completed.get("WF-10") is not None, "freshness_revalidated": True, "confinement_revalidated": confined})[0]
    if decision["decision"] != "allow":
        raise WorkflowRefusal("authority.denied", f"patch.apply_isolated: {decision['reason']}")
    _SEC.guard_write("patch.apply_isolated", {"identity": receipt.get("approver_identity"), "channel": receipt.get("approver_channel")}, authorized_by=receipt, decision=decision, run_dir=run.run_dir)  # SEC-05-T02
    applied = _aa.apply_isolated(binding, contract, cand, patch, report, card, receipt, bytes(key), run.run_dir, run.run_dir / "applied-worktrees")
    a = json.loads(applied.to_json())
    _w(run.run_dir / "applied" / "applied.json", a)
    run.advance("APPLIED_ISOLATED", {"applied_record_hash": a["record_hash"]})
    manifest = _ar.archive_run(run.run_dir)
    return {"applied_record": a, "applied_record_hash": a["record_hash"], "archive_manifest": manifest, "manifest_hash": manifest["manifest_hash"], "apply_decision": decision}
# @@ WF-12
@register_step("WF-12")
def _step_rollback_or_abort(run: WorkflowRun, inputs: Mapping[str, Any]) -> dict[str, Any]:
    """WF-12 Rollback/abort cleanly when scope, evidence, authorization or verification conditions fail (Filing Cabinet 12, 43.5,
    43.13, 65.26, 50.6, 55.3): after an isolated apply, the declared rollback executes and proves the checkpoint (COMP-11); before
    that, an abort routes the run to its terminal state with the source tree proven untouched."""
    reason = inputs.get("reason") or {}
    kind, cause = reason.get("kind"), reason.get("cause") or "unspecified"
    binding = run.artifacts.get("binding")
    if kind == "rollback":
        if run.state not in ("APPLIED_ISOLATED", "ARCHIVED"):
            raise WorkflowRefusal("rollback.nothing_to_roll_back", f"no isolated application exists in state {run.state}")
        authority, = _need(run, "authority")
        decision = _decide(run, ["rollback.execute"], {"human_approval_receipt_verified": run.completed.get("WF-10") is not None})[0]
        if decision["decision"] != "allow":
            raise WorkflowRefusal("authority.denied", f"rollback.execute: {decision['reason']}")
        receipt, = _need(run, "approval_receipt")
        _SEC.assert_audit_intact(run.run_dir)
        _SEC.guard_write("rollback.execute", {"identity": receipt.get("approver_identity"), "channel": receipt.get("approver_channel")}, authorized_by=receipt, decision=decision, run_dir=run.run_dir)
        r = _K.invoke("COMP-11", {"binding": binding, "action": "rollback", "run_dir": str(run.run_dir)}, granted_effects=list(authority["granted_effects"]) + ["rollback.execute"], registry=run.registry)
        proof = r.outputs["rollback_proof"]
        return {"rollback_proof": proof, "rollback_hash": proof["rollback_hash"], "rollback_decision": decision}
    if kind == "abort":
        checkpoint = None
        if binding is not None:
            root = lga.canonical_root(Path(binding.root_path))
            checkpoint = {"source_tree_identity": lga.tree_identity(root, binding.base_revision), "intact": lga.tree_identity(root, binding.base_revision) == binding.source_snapshot_hash}
            _w(run.run_dir / "workflow" / "abort.json", {"cause": cause, "code": reason.get("code"), "checkpoint": checkpoint, "run_state": run.state, "at": _now()})
        raise WorkflowRefusal(reason.get("code") or "workflow.cancelled", f"abort: {cause}" + (f" (checkpoint intact: {checkpoint['intact']})" if checkpoint else ""))
    raise WorkflowRefusal("workflow.input_invalid", "WF-12 requires reason.kind of 'rollback' or 'abort'")


# --------------------------------------------------------------------------- #
# T03 — exact success predicates and fail-closed routes (authorization failure, stale context, insufficient evidence,
# tool failure, verification failure, cancellation, timeout) — evaluated by the runtime, declared per step in WORKFLOW.json
# --------------------------------------------------------------------------- #
FAILURE_KINDS = ("authorization_failure", "stale_context", "insufficient_evidence", "tool_failure", "verification_failure", "cancellation", "timeout")
ROUTE_CODES = {
    "authorization_failure": ("policy.", "authority.", "approval.", "component.capability_missing", "component.human_gate_bypass", "component.scope_widening", "intake.denied", "workflow.human_decision_required", "workflow.run_dir_inside_repository"),
    "stale_context": ("freshness.", "component.binding_mismatch", "intake.stale", "intake.pin_mismatch", "worktree.", "revision.", "review.revision_mismatch", "apply.candidate_mismatch"),
    "insufficient_evidence": ("plan.abstain", "governor.abstained", "guardrail.abstain", "retrieval.no_targets", "intake.missing", "intake.unavailable", "intake.partial", "intake.conflicting", "workflow.artifact_missing", "workflow.evidence_missing", "workflow.predicate_failed"),
    "tool_failure": ("component.", "patch.", "candidate.", "recipe.", "context.", "archive.", "intake.malformed", "intake.oversized", "rollback.", "workflow.input"),
    "verification_failure": ("verification.", "governor.refused", "guardrail.deny", "guardrail.diagnostic", "verify.", "review.", "apply."),
    "cancellation": ("workflow.cancelled",),
    "timeout": ("component.timeout", "workflow.timeout"),
}
DEFAULT_ROUTES = {"authorization_failure": "BLOCKED", "stale_context": "BLOCKED", "insufficient_evidence": "ABSTAINED", "tool_failure": "RETRY_THEN_BLOCKED", "verification_failure": "BLOCKED", "cancellation": "CANCELLED", "timeout": "RETRY_THEN_BLOCKED"}
_PREDICATE: dict[str, Callable[[Mapping[str, Any], "WorkflowRun"], tuple[bool, str]]] = {}


def register_predicate(step_id: str):
    def deco(fn):
        _PREDICATE[step_id] = fn
        return fn
    return deco


def classify_failure(code: str) -> str:
    """Map an error code to one of the seven paper failure kinds (timeout and cancellation checked first; unknown → tool_failure)."""
    for kind in ("timeout", "cancellation", "authorization_failure", "stale_context", "insufficient_evidence", "verification_failure", "tool_failure"):
        if any(code == p or code.startswith(p) for p in ROUTE_CODES[kind]):
            return kind
    return "tool_failure"


def _step_predicate(self: "WorkflowRun", s: Mapping[str, Any], outputs: Mapping[str, Any]) -> tuple[bool, str]:
    """The declared success predicate: every declared output present, every transition evidence a digest, and the
    step-specific executable check (registered under the step id) satisfied."""
    decl = s.get("success_predicate")
    if not decl:
        return True, "no success predicate declared yet (T03)"
    missing = [o for o in decl.get("required_outputs", []) if o not in outputs or outputs[o] is None]
    if missing:
        return False, f"required outputs missing: {missing}"
    bad = [e for e in s["transition_evidence"] if not isinstance(outputs.get(e), str) or not outputs[e].startswith("sha256:")]
    if bad:
        return False, f"transition evidence not a digest: {bad}"
    fn = _PREDICATE.get(s["step_id"])
    if fn is None:
        return False, f"{s['step_id']}: predicate declared but no executable check bound"
    ok, why = fn(outputs, self)
    return ok, (f"{decl['statement']} — {why}" if ok else why)


def _step_route(self: "WorkflowRun", s: Mapping[str, Any], code: str, attempt_no: int) -> tuple[str | None, str]:
    """Fail-closed route for a failure: the declared terminal state for its kind; RETRY_THEN_BLOCKED keeps the run in its
    state (a new attempt may be opened) until the attempt budget is exhausted, then BLOCKED. Never forward."""
    routes = s.get("routes")
    if not routes:
        return None, "no fail-closed route declared yet (T03); the run stays in its state and does not advance"
    kind = classify_failure(code)
    target = routes.get(kind, "BLOCKED")
    if target == "not_applicable":
        target = "BLOCKED"
    if target == "RETRY_THEN_BLOCKED":
        budget = int(s.get("max_attempts", 1))
        if attempt_no < budget:
            return None, f"{kind}: attempt {attempt_no}/{budget} failed; the run stays in {self.state} — an explicit retry allocates a new attempt"
        return "BLOCKED", f"{kind}: attempt budget {budget} exhausted → BLOCKED"
    return target, f"{kind} → {target}"


WorkflowRun._predicate = _step_predicate  # type: ignore[assignment]
WorkflowRun._route = _step_route  # type: ignore[assignment]


def _has(outputs: Mapping[str, Any], *keys: str) -> bool:
    return all(k in outputs and outputs[k] is not None for k in keys)


# @@ WF-01
@register_predicate("WF-01")
def _pred_wf01(o: Mapping[str, Any], run: "WorkflowRun") -> tuple[bool, str]:
    a = o.get("authority") or {}
    if not a.get("actor", {}).get("identity") or not a.get("policy_hash"):
        return False, "authority lacks an actor identity or policy hash"
    if any(d["decision"] != "allow" for d in a.get("decisions", [])) or not a.get("granted_effects"):
        return False, "not every required effect was allowed"
    if any(d["decided_now"] == "allow" and "human_approval" in d["requires"] for d in a.get("deferred", [])):
        return False, "a human-gated effect was allowed before any human decision exists"
    return True, f"{len(a['granted_effects'])} effects allowed by policy {a['policy_hash'][:23]}; privileged effects deferred"
# @@ WF-02
@register_predicate("WF-02")
def _pred_wf02(o: Mapping[str, Any], run: "WorkflowRun") -> tuple[bool, str]:
    b = o.get("binding")
    if b is None or not getattr(b, "base_revision", None):
        return False, "no binding"
    try:
        lga.revalidate_binding(b)
    except lga.AdapterError as exc:
        return False, f"binding stale immediately after pinning: {exc}"
    return True, f"pinned {b.base_revision[:12]} snapshot {b.source_snapshot_hash[:23]}"
# @@ WF-03
@register_predicate("WF-03")
def _pred_wf03(o: Mapping[str, Any], run: "WorkflowRun") -> tuple[bool, str]:
    recs = o.get("intake_records") or {}
    if not recs or recs.get("DATA-01", {}).get("state") != "ADMITTED":
        return False, "the source tree was not ADMITTED"
    if any(r["state"] in ("DENIED",) for r in recs.values()):
        return False, "an evidence source was DENIED under the granted scope"
    return True, f"scope contract {o['scope_contract_hash'][:23]}; sources {sorted(k for k, r in recs.items() if r['state'] == 'ADMITTED')} admitted, others surfaced for review"
# @@ WF-04
@register_predicate("WF-04")
def _pred_wf04(o: Mapping[str, Any], run: "WorkflowRun") -> tuple[bool, str]:
    idx, cg, dg = o.get("symbol_index") or {}, o.get("code_graph") or {}, o.get("dependency_graph") or {}
    b = run.artifacts.get("binding")
    if not all(x.get("base_revision") == getattr(b, "base_revision", None) for x in (idx, cg, dg)):
        return False, "an index artifact is not bound to the pinned revision"
    if cg.get("derived_from", {}).get("index_hash") != idx.get("index_hash"):
        return False, "the code graph does not derive from this index"
    return True, f"index {idx['index_hash'][:23]} ({idx['symbol_count']} symbols), graph {cg['edge_count']} edges, build order {dg['build_order_status']}"
# @@ WF-05
@register_predicate("WF-05")
def _pred_wf05(o: Mapping[str, Any], run: "WorkflowRun") -> tuple[bool, str]:
    eb, prof = o.get("evidence_bundle") or {}, o.get("convention_profile") or {}
    c = run.artifacts.get("scope_contract") or {}
    if eb.get("scope_contract_hash") != c.get("scope_contract_hash") or prof.get("scope_contract_hash") != c.get("scope_contract_hash"):
        return False, "evidence or profile belongs to another scope contract"
    if not any(e.get("match_status") == "exact_pinned" for e in eb.get("evidence", [])):
        return False, "no exact pinned evidence retrieved"
    return True, f"{len(eb['evidence'])} exact pinned evidence records; profile confidence {prof['confidence']}"
# @@ WF-06
@register_predicate("WF-06")
def _pred_wf06(o: Mapping[str, Any], run: "WorkflowRun") -> tuple[bool, str]:
    plan = o.get("refactoring_plan") or {}
    if plan.get("status") != "PLANNED" or plan.get("authority") != "advisory_only":
        return False, "the plan is not a PLANNED advisory plan"
    refs = {r["evidence_id"] for r in plan.get("evidence_refs", [])}
    cited = {x for op in plan.get("operations", []) for x in op.get("guided_by_examples", [])}
    if not cited or not cited <= refs:
        return False, "the plan cites examples outside its provenance-bearing evidence"
    return True, f"PLANNED over {len(refs)} evidence refs; {len(plan['operations'])} operation(s)"
# @@ WF-07
@register_predicate("WF-07")
def _pred_wf07(o: Mapping[str, Any], run: "WorkflowRun") -> tuple[bool, str]:
    cand, patch = o.get("candidate") or {}, o.get("patch")
    if not cand.get("inert") or not isinstance(patch, (bytes, bytearray)):
        return False, "candidate is not inert or carries no diff"
    if lga.sha256_digest(bytes(patch)) != cand.get("patch_hash"):
        return False, "diff bytes do not match the candidate hash"
    c = run.artifacts.get("scope_contract") or {}
    if cand.get("files_changed", 0) > c.get("max_changed_files", 0) or (cand.get("lines_added", 0) + cand.get("lines_deleted", 0)) > c.get("max_diff_lines", 0):
        return False, "candidate exceeds the contract's limit profile"
    return True, f"inert candidate {cand['candidate_id'][:23]}: {cand['files_changed']} file(s), {cand['lines_added'] + cand['lines_deleted']} lines"
# @@ WF-08
@register_predicate("WF-08")
def _pred_wf08(o: Mapping[str, Any], run: "WorkflowRun") -> tuple[bool, str]:
    gov, rep = o.get("governor_decision") or {}, o.get("verification_report") or {}
    cand = run.artifacts.get("candidate") or {}
    if gov.get("verdict") != "ALLOW" or rep.get("verdict") != "PASS":
        return False, f"governor {gov.get('verdict')}, verification {rep.get('verdict')}"
    if rep.get("candidate_id") != cand.get("candidate_id") or rep.get("patch_hash") != cand.get("patch_hash"):
        return False, "the verification report does not describe the candidate"
    if not rep.get("source_tree_unchanged") or not rep.get("sandbox_destroyed"):
        return False, "verification touched the source tree or left its sandbox"
    g = o.get("gate_decision") or {}
    if g.get("decision") != "PROCEED" or g.get("blocking") or not o.get("check_results"):
        return False, "verification gate did not PROCEED on typed check receipts"
    return True, f"governor ALLOW; verification PASS ({len(rep['jobs'])} jobs); gate PROCEED on {len(o['check_results'])} typed checks; impact {o['impact_report']['risk_band']}"
# @@ WF-09
@register_predicate("WF-09")
def _pred_wf09(o: Mapping[str, Any], run: "WorkflowRun") -> tuple[bool, str]:
    card, gate = o.get("review_card") or {}, o.get("approval_gate") or {}
    if card.get("authority") != "display_only" or gate.get("state") != "PENDING_HUMAN":
        return False, "the review surface is not display-only or the gate is not pending a human"
    if card.get("preconditions", {}).get("failed") or card.get("preconditions", {}).get("unresolved"):
        return False, "card preconditions failed/unresolved"
    if "intake" not in card or "impact" not in card or "guardrails" not in card:
        return False, "card lacks intake, impact or guardrail exposure"
    return True, f"card {card['card_hash'][:23]} exposes evidence, intake, impact, guardrails; gate PENDING_HUMAN"
# @@ WF-10
@register_predicate("WF-10")
def _pred_wf10(o: Mapping[str, Any], run: "WorkflowRun") -> tuple[bool, str]:
    r = o.get("approval_receipt") or {}
    if r.get("decision") != "APPROVE" or not r.get("approver_identity") or not r.get("signature"):
        return False, "no signed APPROVE receipt from an identified human"
    cand, card, rep = run.artifacts.get("candidate") or {}, run.artifacts.get("review_card") or {}, run.artifacts.get("verification_report") or {}
    if r.get("candidate_id") != cand.get("candidate_id") or r.get("card_hash") != card.get("card_hash") or r.get("verification_report_hash") != rep.get("report_hash"):
        return False, "receipt is not bound to exactly this candidate, card and report"
    return True, f"APPROVE by {r['approver_identity']} bound to candidate {cand['candidate_id'][:23]}"
# @@ WF-11
@register_predicate("WF-11")
def _pred_wf11(o: Mapping[str, Any], run: "WorkflowRun") -> tuple[bool, str]:
    a, m, d = o.get("applied_record") or {}, o.get("archive_manifest") or {}, o.get("apply_decision") or {}
    if d.get("decision") != "allow" or "human_approval" not in d.get("requires", []):
        return False, "the privileged effect was not allowed on a verified human approval"
    if a.get("receipt_hash") != (run.artifacts.get("approval_receipt") or {}).get("receipt_hash"):
        return False, "applied record is not bound to the verified receipt"
    if not m.get("manifest_hash") or int(m.get("artifact_count", 0)) < 8:
        return False, "archive manifest incomplete"
    return True, f"applied in isolation ({a['applied_worktree'].rsplit('/', 1)[-1]}), archived {m['artifact_count']} artifacts, manifest {m['manifest_hash'][:23]}"
# @@ WF-12
@register_predicate("WF-12")
def _pred_wf12(o: Mapping[str, Any], run: "WorkflowRun") -> tuple[bool, str]:
    p, d = o.get("rollback_proof") or {}, o.get("rollback_decision") or {}
    if d.get("decision") != "allow" or p.get("verdict") != "PASS" or not p.get("checkpoint_verified"):
        return False, "rollback not allowed or the checkpoint was not proven intact"
    return True, f"rolled back to checkpoint {p['source_snapshot_hash'][:23]} (proof {p['rollback_id'][:23]})"


__all__ += ["DEFAULT_ROUTES", "FAILURE_KINDS", "ROUTE_CODES", "classify_failure", "register_predicate"]


# --------------------------------------------------------------------------- #
# T04 — structured runtime / evidence / decision / provenance events before and after every transition (chained),
# idempotent retries for pure steps, a new attempt identity otherwise
# --------------------------------------------------------------------------- #
EVENT_SCHEMA = "overlay.scoped_pr_builder.workflow/Event"
EVENT_CATEGORIES = ("runtime", "evidence", "decision", "provenance")


def _emit_event(self: "WorkflowRun", kind: str, payload: Mapping[str, Any]) -> dict[str, Any]:
    category = kind.split(".", 1)[0]
    if category not in EVENT_CATEGORIES:
        raise WorkflowRefusal("workflow.event_invalid", f"unknown event category {category!r}")
    row = {"record_schema": EVENT_SCHEMA, "workflow_version": WORKFLOW_VERSION, "run_id": self.run_id, "kind": kind, "category": category, "at": _now(), "payload": dict(payload)}
    return _chain_append(self.events_path, row)


def _events(self: "WorkflowRun") -> list[dict[str, Any]]:
    if not self.events_path.is_file():
        return []
    verify_chain_file(self.events_path)
    return [json.loads(l) for l in self.events_path.read_text(encoding="utf-8").splitlines() if l.strip()]


def _attempt_identity_v4(self: "WorkflowRun", step_id: str, inputs_hash: str, retry: bool) -> tuple[str, int, str | None]:
    """Idempotent steps retried over identical inputs keep their attempt identity (a replay); anything else — different
    inputs, or a step with effects — is a new attempt with a new identity that links to the attempt it supersedes."""
    s = self.step(step_id)
    n = self.attempts.get(step_id, 0) + 1
    last = self.last_attempt.get(step_id)
    mode = (s.get("idempotency") or {}).get("mode", "new_attempt")
    if retry and last is not None and mode == "idempotent_replay" and last.get("inputs_hash") == inputs_hash:
        return last["attempt_id"], n, last["attempt_id"]
    ident = lga.sha256_digest(lga.canonical_json({"run": self.run_id, "step": step_id, "attempt": n, "inputs": inputs_hash}))
    return ident, n, (last["attempt_id"] if retry and last is not None else None)


WorkflowRun._emit = _emit_event  # type: ignore[assignment]
WorkflowRun._attempt_identity = _attempt_identity_v4  # type: ignore[assignment]
WorkflowRun.events = _events  # type: ignore[attr-defined]

__all__ += ["EVENT_CATEGORIES", "EVENT_SCHEMA"]
