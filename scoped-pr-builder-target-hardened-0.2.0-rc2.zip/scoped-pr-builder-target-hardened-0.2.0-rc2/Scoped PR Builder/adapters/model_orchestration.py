"""Scoped PR Builder — model orchestration and abstention (Phase 10 / MODEL-01..07).

``model/PROVIDERS.json`` is the model-provider/orchestration contract: the approved, version-pinned providers (Suite 54.1;
here one deterministic local advisor — an LLM provider would be another pinned entry behind the same boundary), the
versioned prompt policy (scope, evidence, uncertainty and abstention rules), and one executable condition per mandatory
requirement. ``adapters/model_orchestration`` is the only path through which model reasoning reaches the run: it labels
the authorized retrieval context by source, assembles the versioned prompt, records every call (provider/model/version,
prompt policy, authorized retrieval set, deterministic analyzer inputs, output schema version, run identity) on a chained
ledger, validates the structured output before use, refuses anything the model path may not mint (permissions, approvals,
evidence, source labels, verification receipts) and routes missing evidence, policy conflicts, stale context, malformed
output or low confidence to abstention / human review — never to automatic repair.

Build provenance: BUILD_NEW (stdlib), composing evidence_retrieval (Suite 51.x labels + build_plan), contracts, guardrails
and the security trail. Yard candidates inspected and rejected: amplifier provider modules (ollama/vLLM/chat-completions —
async clients, amplifier-core, and a JIT "synthetic result" repair path that contradicts the abstention rule), agentpex
(LLM-as-judge over langfuse/openai), promptflow templates (cloud tooling).
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Mapping, Sequence

from . import contracts as C
from . import local_git_adapter as lga
from .archive_adapter import _chain_append, verify_chain_file

PROVIDERS_VERSION = "scoped_pr_builder.model_providers/0.1.0"
PROVIDERS_PATH = Path(__file__).resolve().parent.parent / "model" / "PROVIDERS.json"
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
ADAPTER_ID = "scoped_pr_builder.model_orchestration"
ADAPTER_VERSION = "0.1.0"
NS = "overlay.scoped_pr_builder.model"
OUTPUT_SCHEMA_VERSION = "0.1.0"
CANNOT = ("mint_permissions", "mint_approvals", "assert_verification", "expand_scope")
PROVIDER_REQUIRED = ("provider_id", "kind", "version", "pinned", "network", "implementation", "output_contract", "approved_by", "introduced_by")
PROMPT_SECTIONS = ("scope", "evidence", "uncertainty", "abstention")
FORBIDDEN_OUTPUT_KEYS = ("granted_effects", "capabilities", "permissions", "grants", "approval", "approved", "approval_receipt", "receipt", "receipt_hash", "signature", "verification_report", "verification_verdict", "verdict", "check_results", "source_labels", "sources", "evidence_records", "evidence", "policy_decision", "human_approval", "prompt_policy_version", "authority_override")
IMPACT = ("high", "low")
CONFIDENCE = ("high", "medium", "low")
ROUTE_REASONS = {"insufficient_evidence": "abstain", "out_of_scope": "abstain", "stale_context": "abstain", "low_confidence": "abstain", "malformed_output": "human_review", "ambiguous_authority": "human_review", "self_grant": "human_review", "fabricated_evidence": "human_review", "provider_unapproved": "human_review"}
_PROVIDERS: dict[str, Callable[..., dict[str, Any]]] = {}


class ModelRefusal(lga.AdapterError):
    """Raised by the model boundary (unapproved provider, malformed/overreaching/fabricated output, stale context)."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def register_provider(provider_id: str):
    """Bind an implementation to an approved provider id. Approval lives in PROVIDERS.json, never in code."""
    def deco(fn):
        _PROVIDERS[provider_id] = fn
        return fn
    return deco


def load_model_contract(path: Path = PROVIDERS_PATH, *, registry: Mapping[str, Any] | None = None, repo_root: Path = REPO_ROOT) -> dict[str, Any]:
    """Load and validate the provider/orchestration contract: every provider version-pinned with an approved suite and a
    registered output contract; the prompt policy (when declared) versioned with all four rule sections; every condition
    bound to existing suites."""
    if not Path(path).is_file():
        raise ModelRefusal("model.registry_missing", f"model provider registry not found: {path}")
    reg = registry or C.load_registry()
    m = json.loads(Path(path).read_text(encoding="utf-8"))
    if m.get("providers_version") != PROVIDERS_VERSION:
        raise ModelRefusal("model.registry_invalid", "unsupported providers_version")
    for pid, p in (m.get("providers") or {}).items():
        missing = [k for k in PROVIDER_REQUIRED if k not in p]
        if missing or p["provider_id"] != pid or not C.SEMVER_RE.match(p["version"]) or p["pinned"] is not True:
            raise ModelRefusal("model.registry_invalid", f"{pid}: missing {missing} / id, version pin invalid")
        if p["network"] != "none":
            raise ModelRefusal("model.registry_invalid", f"{pid}: only local, network-free providers are approved here")
        if p["output_contract"] not in reg["contracts"]:
            raise ModelRefusal("model.registry_invalid", f"{pid}: output contract {p['output_contract']!r} is not registered")
        if not (Path(repo_root) / p["approved_by"]).is_file():
            raise ModelRefusal("model.suite_unbound", f"{pid}: approving suite file does not exist: {p['approved_by']}")
    pp = m.get("prompt_policy")
    if pp is not None:
        if not C.SEMVER_RE.match(str(pp.get("version", ""))) or any(not (pp.get("sections") or {}).get(s) for s in PROMPT_SECTIONS):
            raise ModelRefusal("model.registry_invalid", f"prompt_policy needs a semver version and the sections {PROMPT_SECTIONS}")
    for cid, c in (m.get("conditions") or {}).items():
        if not c.get("rule") or not c.get("bound_to") or not c.get("enforced_by"):
            raise ModelRefusal("model.registry_invalid", f"{cid}: condition needs rule, bound_to, enforced_by")
        for f in c["bound_to"]:
            if not (Path(repo_root) / f).is_file():
                raise ModelRefusal("model.suite_unbound", f"{cid}: bound suite file does not exist: {f}")
    body = {k: v for k, v in m.items() if k != "providers_hash"}
    m["computed_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return m


def provider_entry(provider_id: str, contract: Mapping[str, Any]) -> dict[str, Any]:
    """MODEL-01: only an approved, version-pinned provider may be called; the pin is recorded per run."""
    p = (contract.get("providers") or {}).get(provider_id)
    if p is None or p.get("pinned") is not True:
        raise ModelRefusal("model.provider_unapproved", f"provider {provider_id!r} is not an approved, pinned provider (54.1)")
    if provider_id not in _PROVIDERS:
        raise ModelRefusal("model.provider_unbound", f"provider {provider_id!r} has no bound implementation")
    return dict(p)


# ---- MODEL-03: source-labeled retrieval context ---------------------------------------------------------------------
def label_sources(evidence: Sequence[Mapping[str, Any]], *, retrieval_id: str, binding: Any) -> dict[str, Any]:
    """The authorized retrieval set as the model may see it: every item labeled with its source (repository path @ revision,
    locator), kind, authority order and trust marking; labels are minted here — from Suite 51 records — never by a model."""
    items = []
    for e in evidence:
        if e.get("repository_id") != binding.repository_id or e.get("source_snapshot_hash") != binding.source_snapshot_hash:
            raise ModelRefusal("model.context_unauthorized", f"evidence {e.get('evidence_id', '?')[:23]} is not from the bound repository snapshot")
        items.append({"evidence_id": e["evidence_id"], "source_label": f"repository:{e['canonical_path']}@{binding.base_revision[:12]}", "locator": e["exact_locator"], "content_hash": e["content_hash"], "kind": e["evidence_kind"],
                      "authority": "repository_evidence", "trust": (e.get("trust") or {}).get("origin", "untrusted"), "minted_by": "adapters/evidence_retrieval (Suite 51.1/51.4)"})
    ids = sorted(i["evidence_id"] for i in items)
    return {"record_schema": f"{NS}/AuthorizedRetrievalSet", "retrieval_id": retrieval_id, "repository_id": binding.repository_id, "base_revision": binding.base_revision, "source_snapshot_hash": binding.source_snapshot_hash,
            "items": items, "count": len(items), "authorized_set_hash": lga.sha256_digest(lga.canonical_json(ids))}


# ---- MODEL-02: versioned prompt policy -------------------------------------------------------------------------------
def assemble_prompt(contract: Mapping[str, Any], scope_contract: Mapping[str, Any], sources: Mapping[str, Any]) -> dict[str, Any]:
    """System prompt sections rendered from the versioned policy: scope (allowed/forbidden paths, limits), evidence (only the
    labeled set, cite by id), uncertainty (declare a band with its basis) and abstention (when to abstain instead of answer)."""
    pp = contract.get("prompt_policy")
    if pp is None:
        raise ModelRefusal("model.prompt_policy_missing", "no versioned prompt policy is declared; model reasoning is refused")
    rendered = {}
    for s in PROMPT_SECTIONS:
        rendered[s] = pp["sections"][s].format(allowed=", ".join(scope_contract["allowed_paths"]), forbidden=", ".join(scope_contract.get("forbidden_paths", [])) or "none", max_files=scope_contract["max_changed_files"], max_lines=scope_contract["max_diff_lines"],
                                               count=sources["count"], authorized_set_hash=sources["authorized_set_hash"][7:23], cannot=", ".join(CANNOT))
    body = {"record_schema": f"{NS}/Prompt", "policy_version": pp["version"], "sections": rendered, "scope_contract_hash": scope_contract["scope_contract_hash"], "authorized_set_hash": sources["authorized_set_hash"], "cannot": list(CANNOT)}
    body["prompt_hash"] = lga.sha256_digest(lga.canonical_json(body))
    return body


# ---- MODEL-04..06: executable conditions over a structured output --------------------------------------------------
def check_no_self_grant(raw: Mapping[str, Any]) -> list[str]:
    """MODEL-06: keys through which a model output could mint permissions, approvals, evidence, source labels or
    verification are refused before the output is even validated."""
    return sorted(k for k in raw if k in FORBIDDEN_OUTPUT_KEYS or any(k.startswith(p) for p in ("grant", "approv", "receipt", "verif", "permission", "capabilit")))


def validate_output(raw: Mapping[str, Any], *, registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """MODEL-04: the structured output must validate against the registered contract before any use."""
    try:
        C.validate_payload("model_output", raw, registry=registry)
    except lga.AdapterError as exc:
        raise ModelRefusal("model.output_malformed", f"model output does not validate: {exc}") from exc
    if raw.get("authority") != "advisory_only" or sorted(raw.get("cannot", [])) != sorted(CANNOT):
        raise ModelRefusal("model.output_malformed", "model output must be advisory_only and declare every incapacity")
    return dict(raw)


def check_evidence_refs(output: Mapping[str, Any], sources: Mapping[str, Any]) -> dict[str, list[str]]:
    """MODEL-05: high-impact conclusions cite authorized evidence; references outside the authorized set are fabricated."""
    ids = {i["evidence_id"] for i in sources["items"]}
    missing, fabricated = [], []
    for c in output.get("conclusions", []):
        refs = list(c.get("evidence_refs", []))
        bad = [r for r in refs if r not in ids]
        fabricated += bad
        if c.get("impact") == "high" and not [r for r in refs if r in ids]:
            missing.append(c.get("claim", "")[:80])
    return {"missing": missing, "fabricated": sorted(set(fabricated))}


def check_scope(output: Mapping[str, Any], scope_contract: Mapping[str, Any]) -> list[str]:
    """Policy conflict: proposed operations outside the allowed roots (or inside forbidden ones) or beyond the limits."""
    allowed = [PurePosixPath(p) for p in scope_contract["allowed_paths"]]
    forbidden = [PurePosixPath(p) for p in scope_contract.get("forbidden_paths", [])]
    bad = []
    for op in output.get("operations", []):
        p = PurePosixPath(str(op.get("path", "")))
        if not lga.within(p, allowed) or lga.within(p, forbidden) or str(p).startswith(("/", "..")):
            bad.append(str(p))
    if len(output.get("operations", [])) > int(scope_contract["max_changed_files"]):
        bad.append(f"{len(output['operations'])} operations exceed max_changed_files={scope_contract['max_changed_files']}")
    return bad


def check_context_fresh(output: Mapping[str, Any], sources: Mapping[str, Any], binding: Any) -> list[str]:
    """Stale context: the output must speak about the authorized retrieval set at the bound revision."""
    stale = []
    if output.get("retrieval_id") != sources["retrieval_id"]:
        stale.append("retrieval_id differs from the authorized retrieval set")
    if output.get("base_revision") != binding.base_revision:
        stale.append("base_revision differs from the live binding")
    if sources.get("source_snapshot_hash") != binding.source_snapshot_hash:
        stale.append("the retrieval set was taken over another source snapshot")
    return stale


def check_confidence(output: Mapping[str, Any], sources: Mapping[str, Any]) -> list[str]:
    """Unsupported confidence: a high band needs at least one high-impact conclusion grounded in authorized evidence and a
    stated basis; low confidence routes to abstention."""
    ids = {i["evidence_id"] for i in sources["items"]}
    conf = output.get("confidence") or {}
    grounded = [c for c in output.get("conclusions", []) if any(r in ids for r in c.get("evidence_refs", []))]
    problems = []
    if conf.get("band") == "high" and (not grounded or not str(conf.get("basis", "")).strip()):
        problems.append("high confidence without grounded conclusions or a stated basis")
    if conf.get("band") == "low":
        problems.append("low confidence")
    return problems


CONDITIONS: dict[str, str] = {"MODEL-01": "provider_entry", "MODEL-02": "assemble_prompt", "MODEL-03": "label_sources", "MODEL-04": "validate_output", "MODEL-05": "check_evidence_refs", "MODEL-06": "check_no_self_grant", "MODEL-07": "check_context_fresh"}

__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "CANNOT", "CONDITIONS", "CONFIDENCE", "FORBIDDEN_OUTPUT_KEYS", "IMPACT", "OUTPUT_SCHEMA_VERSION", "PROMPT_SECTIONS", "PROVIDERS_PATH", "PROVIDERS_VERSION", "ROUTE_REASONS", "ModelRefusal", "assemble_prompt", "check_confidence", "check_context_fresh", "check_evidence_refs", "check_no_self_grant", "check_scope", "label_sources", "load_model_contract", "provider_entry", "register_provider", "validate_output"]


# --------------------------------------------------------------------------- #
# T02 — every model call is recorded: provider/model/version, prompt/policy version, authorized retrieval set,
# deterministic analyzer inputs, output schema version and run identity — chained under <run_dir>/model/calls.jsonl
# --------------------------------------------------------------------------- #
def _digest_inputs(analyzer_inputs: Mapping[str, Any] | None) -> dict[str, str]:
    """Deterministic analyzer inputs (symbol index, graphs, impact, conventions…) travel as content digests only."""
    out = {}
    for k, v in (analyzer_inputs or {}).items():
        if isinstance(v, Mapping) and any(h in v for h in ("index_hash", "graph_hash", "impact_hash", "profile_hash", "records_hash")):
            out[k] = next(v[h] for h in ("index_hash", "graph_hash", "impact_hash", "profile_hash", "records_hash") if h in v)
        else:
            out[k] = lga.sha256_digest(lga.canonical_json(v))
    return out


def call_record(provider: Mapping[str, Any], prompt: Mapping[str, Any], sources: Mapping[str, Any], *, binding: Any, scope_contract: Mapping[str, Any], analyzer_inputs: Mapping[str, Any] | None, run_id: str | None, purpose: str) -> dict[str, Any]:
    """The 'before' record of one model call — everything that determines the call, sealed before the provider runs."""
    rec = {"record_schema": f"{NS}/ModelCallRecord", "phase": "before", "purpose": purpose, "provider": {"provider_id": provider["provider_id"], "kind": provider["kind"], "version": provider["version"], "model": provider.get("model", provider["provider_id"]), "pinned": True},
           "prompt": {"policy_version": prompt["policy_version"], "prompt_hash": prompt["prompt_hash"]}, "authorized_retrieval_set": {"retrieval_id": sources["retrieval_id"], "authorized_set_hash": sources["authorized_set_hash"], "count": sources["count"]},
           "deterministic_inputs": _digest_inputs(analyzer_inputs), "output_schema": {"contract": provider["output_contract"], "version": OUTPUT_SCHEMA_VERSION},
           "run_identity": {"run_id": run_id, "repository_id": binding.repository_id, "base_revision": binding.base_revision, "source_snapshot_hash": binding.source_snapshot_hash, "scope_contract_hash": scope_contract["scope_contract_hash"]}, "called_at": _now()}
    rec["call_id"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in rec.items() if k not in ("called_at", "phase")}))
    return rec


def record_call(run_dir: Path | None, rec: Mapping[str, Any]) -> dict[str, Any]:
    """Append one record to the run's chained model-call ledger (no run directory → returned sealed, not persisted)."""
    row = dict(rec)
    if run_dir is None:
        row["entry_hash"] = lga.sha256_digest(lga.canonical_json(row))
        row["persisted"] = False
        return row
    out = _chain_append(Path(run_dir).resolve() / "model" / "calls.jsonl", row)
    out["persisted"] = True
    return out


def calls(run_dir: Path) -> list[dict[str, Any]]:
    p = Path(run_dir).resolve() / "model" / "calls.jsonl"
    verify_chain_file(p)
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()] if p.is_file() else []


@register_provider("deterministic-advisor")
def _provider_deterministic_advisor(*, prompt: Mapping[str, Any], sources: Mapping[str, Any], scope_contract: Mapping[str, Any], bundle: Any, binding: Any, analyzer_inputs: Mapping[str, Any]) -> dict[str, Any]:
    """The one approved local provider: a deterministic advisor that derives the advisory plan from the labeled evidence
    (evidence_retrieval.build_plan) and states its conclusions with the evidence ids they rest on. No network, no
    randomness, no model weights — an LLM provider would sit behind exactly the same boundary."""
    from . import evidence_retrieval as er
    plan = er.build_plan(scope_contract, bundle)
    plan["model_version"] = "deterministic-advisor/0.1.0"
    plan["plan_hash"] = lga.sha256_digest(lga.canonical_json({k: v for k, v in plan.items() if k not in ("plan_hash", "created_at")}))
    by_path = {i["locator"].split("@", 1)[0]: i["evidence_id"] for i in sources["items"]}
    examples = [i["evidence_id"] for i in sources["items"] if i["kind"] == "analogous_example"]
    conclusions = [{"claim": f"{op['path']}: {op['operation']} within the declared scope", "impact": "high", "evidence_refs": [x for x in [by_path.get(op["path"])] if x] + examples[:3]} for op in plan["operations"]]
    band = "high" if plan["status"] == "PLANNED" and examples else "low"
    return {"record_schema": f"{NS}/ModelOutput", "provider_id": "deterministic-advisor", "provider_version": "0.1.0", "output_schema_version": OUTPUT_SCHEMA_VERSION, "status": plan["status"], "authority": "advisory_only", "cannot": list(CANNOT),
            "scope_contract_hash": scope_contract["scope_contract_hash"], "retrieval_id": bundle.retrieval_id, "base_revision": binding.base_revision, "conclusions": conclusions, "operations": [{"path": op["path"], "operation": op["operation"], "source_content_hash": op["source_content_hash"]} for op in plan["operations"]],
            "confidence": {"band": band, "basis": f"{len(examples)} analogous example(s) and {plan['uncertainty']['target_count']} target(s) in the authorized set" if examples else "no analogous evidence"},
            "abstention": None if plan["status"] == "PLANNED" else {"reason_code": "insufficient_evidence", "detail": plan.get("abstain_reason") or "insufficient evidence"}, "plan": plan}


def invoke(provider_id: str, *, binding: Any, scope_contract: Mapping[str, Any], bundle: Any, analyzer_inputs: Mapping[str, Any] | None = None, run_dir: Path | None = None, run_id: str | None = None,
           purpose: str = "advisory_plan", contract: Mapping[str, Any] | None = None, registry: Mapping[str, Any] | None = None, **rejected: Any) -> dict[str, Any]:
    """One governed model call: approved pinned provider (MODEL-01) → labeled authorized context (MODEL-03) → versioned prompt
    (MODEL-02) → 'before' record → provider → structured output evaluated (MODEL-04/05/06) and routed (T03) → 'after' record.
    Waiver- or repair-shaped keyword arguments are refused by name."""
    bad = sorted(k for k in rejected if re.search(r"skip|repair|bypass|waive|force|override", k, re.I))
    if bad or rejected:
        raise ModelRefusal("model.input_refused", f"refused keyword arguments: {sorted(rejected)} (no skips, repairs or overrides)")
    ctr = contract or load_model_contract(registry=registry)
    provider = provider_entry(provider_id, ctr)
    sources = label_sources(bundle.evidence, retrieval_id=bundle.retrieval_id, binding=binding)
    if bundle.scope_contract_hash != scope_contract["scope_contract_hash"]:
        raise ModelRefusal("model.context_unauthorized", "evidence bundle was retrieved for another scope contract")
    prompt = assemble_prompt(ctr, scope_contract, sources)
    before = record_call(run_dir, call_record(provider, prompt, sources, binding=binding, scope_contract=scope_contract, analyzer_inputs=analyzer_inputs, run_id=run_id, purpose=purpose))
    seal = seal_sources(sources)  # T04: the labeled set is sealed before the provider sees it
    raw = _PROVIDERS[provider_id](prompt=prompt, sources=sources, scope_contract=scope_contract, bundle=bundle, binding=binding, analyzer_inputs=analyzer_inputs or {})
    result = evaluate(raw, provider=provider, prompt=prompt, sources=sources, binding=binding, scope_contract=scope_contract, run_dir=run_dir, call_id=before["call_id"], registry=registry, sources_seal=seal)
    return result


def evaluate(raw: Any, *, provider: Mapping[str, Any], prompt: Mapping[str, Any], sources: Mapping[str, Any], binding: Any, scope_contract: Mapping[str, Any], run_dir: Path | None = None, call_id: str | None = None, registry: Mapping[str, Any] | None = None, sources_seal: str | None = None) -> dict[str, Any]:
    """The post-call half of the boundary (T02 baseline: validate, refuse minting, record the 'after' row). T03 binds the
    abstention / human-review routing here."""
    refusals: list[dict[str, str]] = []
    output: dict[str, Any] | None = None
    if not isinstance(raw, Mapping):
        refusals.append({"code": "model.output_malformed", "detail": f"provider returned {type(raw).__name__}, not a structured object"})
    else:
        refusals += detect_minting(raw, run_dir=run_dir, subject={"call_id": call_id}) or ([{"code": "model.self_grant", "detail": f"output attempts to mint through {check_no_self_grant(raw)}"}] if check_no_self_grant(raw) else [])  # T04: any depth; trail row; never stripped
        if not refusals:
            try:
                output = validate_output(raw, registry=registry)
            except ModelRefusal as exc:
                refusals.append({"code": exc.code, "detail": str(exc)[:300]})
    if output is not None:
        if output.get("provider_id") != provider["provider_id"] or output.get("provider_version") != provider["version"] or output.get("output_schema_version") != OUTPUT_SCHEMA_VERSION:
            refusals.append({"code": "model.pin_mismatch", "detail": "output claims another provider/version/schema than the pinned call"})
        if output.get("scope_contract_hash") != scope_contract["scope_contract_hash"]:
            refusals.append({"code": "model.scope_mismatch", "detail": "output names another scope contract"})
        minted_refs = plan_refs_authorized(output, sources)  # T04: evidence minted inside the plan
        if minted_refs:
            refusals.append({"code": "model.evidence_minted", "detail": f"plan cites evidence outside the authorized set: {minted_refs[:3]}"})
    if sources_seal is not None and seal_sources(sources) != sources_seal:  # T04: labels are minted once, before the provider ran
        refusals.append({"code": "model.label_minted", "detail": "the labeled retrieval set changed after sealing"})
    after = {"record_schema": f"{NS}/ModelCallRecord", "phase": "after", "call_id": call_id, "provider": {"provider_id": provider["provider_id"], "version": provider["version"]}, "prompt_hash": prompt["prompt_hash"], "authorized_set_hash": sources["authorized_set_hash"],
             "output_hash": lga.sha256_digest(lga.canonical_json(raw)) if isinstance(raw, Mapping) else None, "output_schema_version": OUTPUT_SCHEMA_VERSION, "refusals": refusals, "finished_at": _now()}
    route = _route(output, refusals, sources=sources, binding=binding, scope_contract=scope_contract)
    after["route"] = {k: route[k] for k in ("route", "reason_code", "detail")}
    rec = record_call(run_dir, after)
    return {"output": output if route["route"] == "accept" else None, "raw_output": output, "route": route, "refusals": refusals, "record": rec, "sources": sources, "prompt": prompt, "provider": {"provider_id": provider["provider_id"], "version": provider["version"]}}


CONDITIONS["MODEL-07"] = "evaluate"
__all__ += ["call_record", "calls", "evaluate", "invoke", "record_call"]


# --------------------------------------------------------------------------- #
# T03 — structured output validated before use; missing evidence, policy conflicts, stale context, malformed output or low
# confidence route to abstention / human review — never to automatic repair
# --------------------------------------------------------------------------- #
def abstention_record(reason_code: str, detail: str, *, scope_contract: Mapping[str, Any], run_state: str = "ABSTAINED", registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """A contract-valid abstention (Suite 47/IMPL-07 shape) — the artifact a refused model call leaves behind."""
    rec = {"reason_code": reason_code, "evidence_sufficiency": "insufficient" if reason_code in ("insufficient_evidence", "stale_context") else "sufficient", "detail": detail[:400], "run_state": run_state, "scope_contract_hash": scope_contract["scope_contract_hash"], "abstained_at": _now()}
    C.validate_payload("abstention", rec, registry=registry)
    return rec


def route_output(output: Mapping[str, Any] | None, refusals: Sequence[Mapping[str, str]], *, sources: Mapping[str, Any], binding: Any, scope_contract: Mapping[str, Any], registry: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Decide what a model call becomes. Order matters and every branch is terminal: malformed / minting / pin mismatch →
    human review; fabricated evidence → human review (a fabricated reference is not a gap, it is an attempt); stale context
    → abstain; policy conflict (scope) → abstain (out_of_scope); missing evidence for a high-impact conclusion → abstain;
    a declared abstention is honoured; unsupported or low confidence → abstain; otherwise accept. Nothing is repaired."""
    def result(route: str, code: str | None, detail: str, checks: Mapping[str, Any]) -> dict[str, Any]:
        d = {"route": route, "reason_code": code, "detail": detail[:400], "checks": dict(checks), "repair": "never — refused outputs are routed, not fixed"}
        if route == "abstain":
            d["abstention"] = abstention_record({"low_confidence": "insufficient_evidence", "fabricated_evidence": "insufficient_evidence"}.get(code, code), detail, scope_contract=scope_contract, registry=registry)
        return d
    if refusals or output is None:
        codes = [r["code"] for r in refusals]
        code = "self_grant" if any(c in codes for c in ("model.self_grant", "model.evidence_minted", "model.verification_minted", "model.label_minted")) else ("provider_unapproved" if "model.pin_mismatch" in codes else "malformed_output")  # T04
        return result("human_review", code, "; ".join(r["detail"] for r in refusals) or "no output", {"refusals": codes})
    checks: dict[str, Any] = {}
    refs = check_evidence_refs(output, sources); checks["evidence"] = refs
    if refs["fabricated"]:
        return result("human_review", "fabricated_evidence", f"evidence references outside the authorized set: {refs['fabricated'][:3]}", checks)
    stale = check_context_fresh(output, sources, binding); checks["freshness"] = stale
    if stale:
        return result("abstain", "stale_context", "; ".join(stale), checks)
    scope = check_scope(output, scope_contract); checks["scope"] = scope
    if scope:
        return result("abstain", "out_of_scope", f"proposed operations conflict with the scope contract: {scope[:3]}", checks)
    if refs["missing"]:
        return result("abstain", "insufficient_evidence", f"high-impact conclusions without authorized evidence: {refs['missing'][:3]}", checks)
    if output.get("status") == "ABSTAIN" or output.get("abstention"):
        a = output.get("abstention") or {}
        return result("abstain", a.get("reason_code", "insufficient_evidence"), a.get("detail", "the provider abstained"), checks)
    conf = check_confidence(output, sources); checks["confidence"] = conf
    if conf:
        return result("abstain", "low_confidence", "; ".join(conf), checks)
    return result("accept", None, "validated; grounded; within scope; fresh; confidence supported", checks)


def _route(output: Mapping[str, Any] | None, refusals: list[dict[str, str]], *, sources: Mapping[str, Any], binding: Any, scope_contract: Mapping[str, Any]) -> dict[str, Any]:
    return route_output(output, refusals, sources=sources, binding=binding, scope_contract=scope_contract)


__all__ += ["abstention_record", "route_output"]



# --------------------------------------------------------------------------- #
# T04 — the model path cannot mint capabilities, approvals, evidence, source labels or verification receipts: those come
# only from the authoritative deterministic/control layers named here; a model output that carries their shapes — at any
# depth — is refused with a trail row, and the layers themselves never take model output as an input
# --------------------------------------------------------------------------- #
MINTED_ONLY_BY: dict[str, dict[str, Any]] = {
    "capabilities": {"layer": "adapters/controls.policy_decide (Chair 13 / 44.5 / 55.4) → WF-04 authority record", "callable": "controls.policy_decide", "keys": ("granted_effects", "capabilities", "permissions", "grants", "authority_override", "principal_role", "policy_decision", "capability_grant"),
                     "shapes": ("AuthorityRecord", "PolicyDecision")},
    "approvals": {"layer": "adapters/approval_adapter.issue_receipt (Cypher 11 / 50.5 — human channel, ledger HMAC)", "callable": "approval_adapter.issue_receipt", "keys": ("approval", "approved", "approval_receipt", "receipt", "receipt_hash", "signature", "human_approval", "approver_identity", "approver_channel", "nonce"),
                  "shapes": ("ApprovalReceipt", "Receipt", "ApprovalGate")},
    "evidence": {"layer": "adapters/evidence_retrieval.retrieve_examples (Suite 51.1 / 51.4)", "callable": "evidence_retrieval.retrieve_examples", "keys": ("evidence", "evidence_records", "evidence_record", "analogous_examples", "podium_receipt", "charlotte_validation"),
                 "shapes": ("EvidenceRecord", "AuthorityRecord", "EvidenceBundle")},
    "source_labels": {"layer": "adapters/model_orchestration.label_sources over Suite 51 records (never a model)", "callable": "model_orchestration.label_sources", "keys": ("source_labels", "sources", "source_label", "minted_by", "authorized_retrieval_set", "authorized_set_hash"),
                      "shapes": ("AuthorizedRetrievalSet",)},
    "verification_receipts": {"layer": "adapters/verification_checks.derive_results / run_checks (43.9 / 57.4) over sandboxed job records", "callable": "verification_checks.derive_results", "keys": ("verification_report", "verification_verdict", "verdict", "check_results", "check_result", "result_hash", "job_record", "job_records", "executed"),
                              "shapes": ("CheckResult", "VerificationReport", "JobRecord")},
}
_SHAPE_RE = re.compile("|".join(sorted({s for m in MINTED_ONLY_BY.values() for s in m["shapes"]})))
_KEY_TO_KIND = {k: kind for kind, m in MINTED_ONLY_BY.items() for k in m["keys"]}


def control_layers() -> dict[str, str]:
    """What mints what — the authoritative layer per artifact class (the model path is on none of these lists)."""
    return {kind: m["layer"] for kind, m in MINTED_ONLY_BY.items()}


def minting_attempts(raw: Any, path: str = "$") -> list[dict[str, str]]:
    """Every place — at any depth, the open ``plan`` object included — where an output carries a shape that only a control
    layer may produce: a forbidden key, a record_schema naming a controlled record, or an authority other than advisory."""
    found: list[dict[str, str]] = []
    if isinstance(raw, Mapping):
        for k, v in raw.items():
            here = f"{path}.{k}"
            if k in _KEY_TO_KIND:
                found.append({"path": here, "key": str(k), "mints": _KEY_TO_KIND[k]})
            elif k == "authority" and v not in ("advisory_only", "display_only"):
                found.append({"path": here, "key": "authority", "mints": "capabilities"})
            elif k == "record_schema" and isinstance(v, str) and _SHAPE_RE.search(v):
                found.append({"path": here, "key": "record_schema", "mints": next(kind for kind, m in MINTED_ONLY_BY.items() if any(s in v for s in m["shapes"]))})
            found += minting_attempts(v, here)
    elif isinstance(raw, (list, tuple)):
        for i, v in enumerate(raw):
            found += minting_attempts(v, f"{path}[{i}]")
    return found


def detect_minting(raw: Any, *, run_dir: Path | None = None, subject: Mapping[str, Any] | None = None) -> list[dict[str, str]]:
    """The refusal half of MODEL-06/T04: every minting attempt becomes a chained SEC-01 trail row (the model channel is
    untrusted data) and a refusal the router sends to human review — never silently stripped, never repaired."""
    attempts = minting_attempts(raw) if isinstance(raw, Mapping) else []
    if not attempts:
        return []
    from . import security as _SEC
    kinds = sorted({a["mints"] for a in attempts})
    _SEC.record_denial("SEC-01", "security.sec01.model_minting_attempt", f"model output carries {', '.join(kinds)} shapes at {[a['path'] for a in attempts][:5]}", actor={"channel": "model"}, subject=dict(subject or {}, attempts=len(attempts)), run_dir=run_dir)
    code = {"capabilities": "model.self_grant", "approvals": "model.self_grant", "evidence": "model.evidence_minted", "source_labels": "model.evidence_minted", "verification_receipts": "model.verification_minted"}
    by_code: dict[str, list[str]] = {}
    for k in kinds:
        by_code.setdefault(code[k], []).append(f"{k} through {[a['path'] for a in attempts if a['mints'] == k][:3]}")
    return [{"code": c, "detail": "output attempts to mint " + "; ".join(d)} for c, d in by_code.items()]


def plan_refs_authorized(output: Mapping[str, Any], sources: Mapping[str, Any]) -> list[str]:
    """Evidence minted inside the plan: every evidence reference the plan carries (evidence_refs, guided_by_examples) must
    name an item of the authorized retrieval set — the model cannot enlarge the set by citing what it was never given."""
    ids = {i["evidence_id"] for i in sources["items"]}
    plan = output.get("plan") or {}
    bad = [r.get("evidence_id") if isinstance(r, Mapping) else r for r in plan.get("evidence_refs", [])]
    for op in plan.get("operations", []):
        bad += list(op.get("guided_by_examples", []))
    return sorted({str(r) for r in bad if r not in ids})


def seal_sources(sources: Mapping[str, Any]) -> str:
    return lga.sha256_digest(lga.canonical_json(sources))


def assert_labels_unchanged(sources: Mapping[str, Any], seal: str) -> None:
    """Source labels are minted once, before the provider runs; a provider that touched the labeled set is refused."""
    if seal_sources(sources) != seal:
        raise ModelRefusal("model.label_minted", "the authorized retrieval set was altered after labeling")


def verify_source_labels(sources: Mapping[str, Any], bundle: Any, binding: Any) -> None:
    """Re-derive the labels from the Suite 51 records; a labeled set that does not re-derive was minted elsewhere."""
    again = label_sources(bundle.evidence, retrieval_id=bundle.retrieval_id, binding=binding)
    if again["authorized_set_hash"] != sources.get("authorized_set_hash") or [i["source_label"] for i in again["items"]] != [i.get("source_label") for i in sources.get("items", [])]:
        raise ModelRefusal("model.label_minted", "source labels do not re-derive from the authorized retrieval set")


def verify_control_layers() -> dict[str, Any]:
    """Structural proof that no control layer takes model output: each named callable exists and none of its parameters
    is a model output, a raw output or a plan."""
    import importlib
    import inspect
    out = {}
    for kind, m in MINTED_ONLY_BY.items():
        mod, _, name = m["callable"].partition(".")
        fn = getattr(importlib.import_module(f"adapters.{mod}"), name)
        params = list(inspect.signature(fn).parameters)
        leaks = [p for p in params if re.search(r"model|raw|output|plan|llm|prompt", p, re.I)]
        if leaks:
            raise ModelRefusal("model.control_layer_exposed", f"{m['callable']} accepts {leaks} — a control layer cannot consume model output")
        out[kind] = {"callable": m["callable"], "parameters": params}
    return out


CONDITIONS["MODEL-06"] = "detect_minting"
__all__ += ["MINTED_ONLY_BY", "assert_labels_unchanged", "control_layers", "detect_minting", "minting_attempts", "plan_refs_authorized", "seal_sources", "verify_control_layers", "verify_source_labels"]
