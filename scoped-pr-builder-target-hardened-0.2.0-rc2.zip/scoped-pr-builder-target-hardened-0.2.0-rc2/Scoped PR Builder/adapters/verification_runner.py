"""Scoped PR Builder — isolated verification through Sandbox/Worker/Release Plane (SLICE-06).

Runs the mandatory independent checks for ONE candidate patch inside a throwaway,
detached worktree pinned to the candidate's base revision. The source repository is
never modified: the patch is applied only inside the sandbox worktree, which is
destroyed afterwards (logs are kept in the run directory).

Checks (every one is a deterministic subprocess or pure function; no model):
  applicability   ``git apply --check`` against the exact base revision
  scope_diff      changed paths ⊆ candidate.canonical_paths ⊆ allowed − forbidden
  size_limits     files / added+deleted lines within the scope contract
  build           ``py_compile`` of changed Python + JA-family structural check
  tests           overlay unit tests executed in the sandbox
  lint            deterministic rules (EOF newline, trailing whitespace, SHA256SUMS validity)
  cross_reference Suite 01–66 invariants on the patched tree (structural)

Verdict semantics: overall PASS only when every mandatory check is PASS; any FAIL →
FAIL; a check that cannot run → INDETERMINATE (never PASS). Job records mirror the
Suite 56/57/60 job/worker vocabulary (job_id, job_family, worker, exit_code, digests).

Donor provenance: the per-changed-path verifier pattern and the verdict shape
(accepted / check / summary / artifacts) are ADAPTED from AutoSaddler
``src/autosaddler/v2/plugins/meta_are/verification.py`` (MIT). Everything else is
target-native. See ``../PROVENANCE.jsonl``.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Sequence

from . import local_git_adapter as lga
from . import security as _SEC
from . import tool_discovery as _TD

ADAPTER_ID = "scoped_pr_builder.verification_runner"
ADAPTER_VERSION = "0.1.0"
MANDATORY_CORPUS = ("applicability", "scope_diff", "size_limits", "build", "tests", "lint", "cross_reference")
MANDATORY_GENERIC = ("applicability", "scope_diff", "size_limits", "build", "tests", "lint")
MANDATORY = MANDATORY_CORPUS  # compatibility
VERIFICATION_PROFILES = ("corpus", "generic")
JA_FAMILY = {".ja", ".jad", ".jasec", ".jaa", ".jaops", ".jasp", ".jaui", ".jate", ".dmk", ".deepml"}
HEADER_RE = re.compile(r"^(?:(?:ja|deepml) [a-z.]+ \d+\.\d+|profile ja\.[a-z_.]+)\s*$", re.M)
SHA_LINE_RE = re.compile(r"^[0-9a-f]{64}  \S.*$")
FILE_PREFIX_RE = re.compile(r"^(\d{2})(?:[._]\d+)?[._]")
SUITE_REF_RE = re.compile(r"\bSuite_(\d{2})_")
DMK_REF_RE = re.compile(r'from\s+dmk\("([^"]+)"\)')
DEFAULT_TIMEOUT = 120


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _scrubbed_env(cwd: Path | None = None) -> dict[str, str]:
    """Minimal environment: no proxies, no tokens, prompts disabled."""
    keep = {"PATH", "HOME", "LANG", "LC_ALL", "TMPDIR", "SYSTEMROOT", "TEMP", "TMP"}
    env = {k: v for k, v in os.environ.items() if k in keep}
    env.update({"GIT_TERMINAL_PROMPT": "0", "LC_ALL": "C", "PYTHONDONTWRITEBYTECODE": "1", "NO_PROXY": "*", "no_proxy": "*"})
    if cwd is not None:
        env["PYTHONPATH"] = str(Path(cwd).resolve())
    return env


@dataclass(frozen=True)
class JobRecord:
    """Suite 56/57/60-shaped job record for one check executed by the sandbox worker."""

    job_id: str
    run_id: str
    job_family: str
    check: str
    worker: str
    mandatory: bool
    command: str
    exit_code: int | None
    stdout_digest: str
    stderr_digest: str
    stdout_excerpt: str
    stderr_excerpt: str
    verdict: str
    summary: str
    started_at: str
    finished_at: str
    artifacts: tuple[str, ...] = ()


@dataclass(frozen=True)
class VerificationReport:
    adapter_id: str
    adapter_version: str
    run_id: str
    candidate_id: str
    patch_hash: str
    base_revision: str
    scope_contract_hash: str
    verification_profile: str
    sandbox_worktree: str
    sandbox_destroyed: bool
    source_tree_unchanged: bool
    jobs: list[dict[str, Any]] = field(default_factory=list)
    verdict: str = "INDETERMINATE"
    symbol_changes: dict[str, Any] = field(default_factory=dict)
    artifact_hashes: dict[str, Any] = field(default_factory=dict)
    report_hash: str = ""

    def to_json(self) -> str:
        return lga.canonical_json(asdict(self))


def _job(run_id: str, check: str, family: str, mandatory: bool, command: str, exit_code, out: bytes, err: bytes, verdict: str, summary: str, started: str, artifacts=()) -> JobRecord:
    return JobRecord(
        job_id=lga.sha256_digest(lga.canonical_json({"run": run_id, "check": check, "cmd": command})),
        run_id=run_id, job_family=family, check=check, worker=f"{ADAPTER_ID}/{ADAPTER_VERSION}", mandatory=mandatory,
        command=command, exit_code=exit_code, stdout_digest=lga.sha256_digest(out), stderr_digest=lga.sha256_digest(err),
        stdout_excerpt=_SEC.protect_secrets(out.decode("utf-8", errors="replace")[-1200:], "log"), stderr_excerpt=_SEC.protect_secrets(err.decode("utf-8", errors="replace")[-1200:], "log"),  # SEC-03-T03
        verdict=verdict, summary=summary, started_at=started, finished_at=_now(), artifacts=tuple(artifacts),
    )


def _run(cmd: list[str], cwd: Path, timeout: int, stdin: bytes | None = None) -> tuple[int | None, bytes, bytes]:
    cmd = _SEC.validate_argv(cmd, sandbox=cwd)  # SEC-02-T02: argv vectors only, control bytes refused, paths confined to sandbox/overlay
    try:
        p = subprocess.run(cmd, cwd=cwd, input=stdin, capture_output=True, timeout=timeout, env=_scrubbed_env(cwd))
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired as exc:
        return None, exc.stdout or b"", (exc.stderr or b"") + b"\n[timeout]"
    except FileNotFoundError as exc:
        return None, b"", str(exc).encode()


def _brace_balance(text: str) -> bool:
    depth = 0
    in_str = esc = False
    for ch in text:
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth < 0:
                return False
    return depth == 0


def _xref_structural(worktree: Path) -> tuple[bool, str]:
    """Suite 01–66 numbering + dmk/Suite_NN resolution on the patched tree (structural, fast)."""
    suites: dict[int, list[str]] = {}
    for d in sorted(p for p in worktree.iterdir() if p.is_dir() and p.name != ".git" and p.name != "Scoped PR Builder"):
        nums = {int(m.group(1)) for f in d.iterdir() if (m := FILE_PREFIX_RE.match(f.name))}
        if len(nums) == 1:
            suites.setdefault(nums.pop(), []).append(d.name)
    missing = [n for n in range(1, 67) if n not in suites]
    dup = {n: v for n, v in suites.items() if len(v) > 1}
    if missing or dup:
        return False, f"suite numbering broken: missing={missing} duplicated={dup}"
    problems = []
    for path in worktree.rglob("*"):
        if not path.is_file() or path.suffix not in JA_FAMILY or ".git" in path.parts:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        for m in DMK_REF_RE.finditer(text):
            if not (path.parent / m.group(1)).is_file():
                problems.append(f"{path.relative_to(worktree)} -> unresolved dmk {m.group(1)}")
        for m in SUITE_REF_RE.finditer(text):
            if int(m.group(1)) not in suites:
                problems.append(f"{path.relative_to(worktree)} -> unresolved Suite_{m.group(1)}")
        if not _brace_balance(text):
            problems.append(f"{path.relative_to(worktree)} -> unbalanced braces")
    return (not problems), ("ok: 66 suites, all dmk/Suite_NN references resolve" if not problems else "; ".join(problems[:10]))


def _lint(worktree: Path, changed: list[PurePosixPath]) -> tuple[bool, str]:
    findings = []
    for rel in changed:
        p = worktree.joinpath(*rel.parts)
        if not p.is_file():
            continue
        raw = p.read_bytes()
        if b"\x00" in raw[:8192]:
            continue
        text = raw.decode("utf-8", errors="replace")
        if text and not text.endswith("\n"):
            findings.append(f"{rel}: missing newline at EOF")
        for i, line in enumerate(text.splitlines(), 1):
            if line.rstrip() != line:
                findings.append(f"{rel}:{i}: trailing whitespace")
        if rel.name == "SHA256SUMS.txt":
            for i, line in enumerate(text.splitlines(), 1):
                if not SHA_LINE_RE.match(line):
                    findings.append(f"{rel}:{i}: malformed digest line")
                    continue
                digest, name = line[:64], line[66:]
                target = p.parent / name
                if not target.is_file():
                    findings.append(f"{rel}:{i}: {name} does not exist")
                elif hashlib.sha256(target.read_bytes()).hexdigest() != digest:
                    findings.append(f"{rel}:{i}: digest mismatch for {name}")
        if p.suffix in JA_FAMILY:
            if not HEADER_RE.search(text):
                findings.append(f"{rel}: missing language header")
            if not _brace_balance(text):
                findings.append(f"{rel}: unbalanced braces")
    return (not findings), ("clean" if not findings else "; ".join(findings[:20]))


def _static_analysis(sandbox: Path, changed: list[PurePosixPath], contract: Mapping[str, Any]) -> tuple[bool, str, bytes]:
    """VERIFY-04-T02 — Safety Gate 28.1 AST check (every changed Python file must parse) + 28.2 lint findings, counted
    against the configured threshold (``scope_contract.lint_threshold``, default 0 — no new findings). Type checks: no
    checker is declared for this corpus; recorded as not_configured, never as a pass."""
    import ast
    threshold = int(contract.get("lint_threshold", 0) or 0)
    findings: list[str] = []
    parsed = 0
    for p in changed:
        if p.suffix != ".py":
            continue
        f = sandbox.joinpath(*p.parts)
        if not f.is_file():
            continue
        try:
            ast.parse(f.read_text(encoding="utf-8", errors="replace"), filename=p.as_posix())
            parsed += 1
        except SyntaxError as exc:
            findings.append(f"{p.as_posix()}: AST: {exc.msg} (line {exc.lineno})")
    ok, msg = _lint(sandbox, changed)
    if not ok:
        findings += [m.strip() for m in msg.split(";") if m.strip()]
    body = {"record_schema": "suite28.safety_gate.ast/StaticAnalysisRecord", "threshold": threshold, "threshold_source": "scope_contract.lint_threshold (default 0)", "findings": findings, "finding_count": len(findings), "ast_parsed_files": parsed, "type_check": "not_configured"}
    within = len(findings) <= threshold
    summary = f"{len(findings)} finding(s) vs threshold {threshold}; {parsed} python file(s) parsed; type check not configured" if within else f"{len(findings)} finding(s) exceed threshold {threshold}: " + "; ".join(findings[:10])
    return within, summary, lga.canonical_json(body).encode("utf-8")
def _symbol_diff(root: Path, sandbox: Path, revision: str, changed: list[PurePosixPath], declared: set[PurePosixPath]) -> tuple[bool, str, bytes]:
    """VERIFY-05-T02 — Suite 40.2 symbol records of every changed file before (pinned blob) and after (sandbox): the
    per-file symbol change set (added / removed / modified spans) is sealed as evidence; any symbol change outside the
    declared files fails. Symbols are extracted by the repository context adapter's own Suite 40.2 extractors."""
    from .repository_context_adapter import extract_ja_symbols, extract_py_symbols

    def spans(rel: str, text: str) -> dict[str, str]:
        if rel.endswith(".py"):
            recs = extract_py_symbols(rel, text)
        elif PurePosixPath(rel).suffix in JA_FAMILY:
            recs = extract_ja_symbols(rel, text)
        else:
            return {}
        lines = text.splitlines()
        return {f"{k}:{q}": lga.sha256_digest("\n".join(lines[max(s - 1, 0):max(e, s)])) for k, q, s, e in recs}

    changes: dict[str, dict[str, Any]] = {}
    undeclared: list[str] = []
    for p in changed:
        rel = p.as_posix()
        try:
            before = lga.read_blob(root, revision, p).decode("utf-8", errors="replace")
        except lga.AdapterError:
            before = ""
        after_path = sandbox.joinpath(*p.parts)
        after = after_path.read_text(encoding="utf-8", errors="replace") if after_path.is_file() else ""
        a, b = spans(rel, before), spans(rel, after)
        entry = {"added": sorted(set(b) - set(a)), "removed": sorted(set(a) - set(b)), "modified": sorted(k for k in set(a) & set(b) if a[k] != b[k]), "unchanged": len([k for k in set(a) & set(b) if a[k] == b[k]])}
        if entry["added"] or entry["removed"] or entry["modified"]:
            changes[rel] = entry
        if p not in declared:
            undeclared.append(rel)
    out = lga.canonical_json({"record_schema": "suite40.repository_context_engine.symbols/SymbolChangeSet", "changed_symbols": changes, "files": [p.as_posix() for p in changed], "declared_files": sorted(d.as_posix() for d in declared)}).encode("utf-8")
    if undeclared:
        return False, f"symbols changed in undeclared file(s): {undeclared}", out
    n = sum(len(e["added"]) + len(e["removed"]) + len(e["modified"]) for e in changes.values())
    return True, f"{n} symbol(s) added/removed/modified across {len(changes)} file(s); every change inside a declared file", out
REGRESSION_PATH = Path(__file__).resolve().parent.parent / "verification" / "REGRESSION.json"


def _regression(sandbox: Path, changed: list[PurePosixPath], timeout: int) -> tuple[str, str, bytes, bytes, int | None]:
    """VERIFY-07-T02 — behavioral regression checks declared by the overlay (``verification/REGRESSION.json``; the
    definitions belong to the tool, never to the candidate under test), run in the sandbox for every changed path they
    apply to. PASS when every applicable check exits as expected; FAIL on any mismatch; INDETERMINATE on timeout or when
    the definitions are missing; PASS with an explicit empty applicability list when nothing is defined for these paths."""
    import fnmatch
    if not REGRESSION_PATH.is_file():
        return "INDETERMINATE", "regression definitions missing", b"", b"verification/REGRESSION.json not found", None
    raw = REGRESSION_PATH.read_bytes()
    defs = json.loads(raw.decode("utf-8"))
    subst = {"{python}": sys.executable, "{overlay}": str(REGRESSION_PATH.parent.parent), "{sandbox}": str(sandbox)}
    applied, not_applicable, outs, errs = [], [], [], []
    timed_out = False
    for d in defs.get("checks", []):
        targets = sorted({p for p in _SEC.sanitize_for_tool(changed) if any(fnmatch.fnmatch(p, pat) for pat in d["applies_to"])})  # SEC-02-T03: canonical paths only reach tool argv
        if not targets:
            not_applicable.append(d["id"])
            continue
        for group in ([[t] for t in targets] if d.get("per_path") else [targets]):
            argv = [a.replace("{path}", group[0]).replace("{python}", subst["{python}"]).replace("{overlay}", subst["{overlay}"]).replace("{sandbox}", subst["{sandbox}"]) for a in d["argv"]]
            code, out, err = _run(argv, sandbox, min(int(d.get("timeout_s", timeout)), timeout))
            expected = int(d.get("expect_exit", 0))
            applied.append({"id": d["id"], "title": d["title"], "paths": group, "argv": argv, "exit_code": code, "expected_exit": expected, "ok": code == expected})
            outs.append(f"[{d['id']} {group[0]}]\n".encode() + out); errs.append(err)
            timed_out = timed_out or code is None
    body = {"record_schema": "suite57.test_jobs/BehavioralRegressionRecord", "definitions_hash": lga.sha256_digest(raw), "applied": applied, "not_applicable": not_applicable}
    header = lga.canonical_json(body).encode("utf-8") + b"\n"
    if not applied:
        return "PASS", f"no behavioral regression checks defined for the changed paths (definitions {body['definitions_hash'][:23]}; {len(not_applicable)} definition(s) not applicable)", header, b"", 0
    if timed_out:
        return "INDETERMINATE", "a regression check timed out", header + b"".join(outs), b"".join(errs), None
    bad = [a for a in applied if not a["ok"]]
    if bad:
        return "FAIL", "; ".join(f"{a['id']} on {a['paths'][0]} exited {a['exit_code']} (expected {a['expected_exit']})" for a in bad), header + b"".join(outs), b"".join(errs), 1
    return "PASS", f"{len(applied)} applicable regression check(s) passed ({', '.join(sorted({a['id'] for a in applied}))})", header + b"".join(outs), b"".join(errs), 0
def verify_candidate(
    binding: lga.RepositoryBinding,
    contract: Mapping[str, Any],
    candidate: Mapping[str, Any],
    patch: bytes,
    sandbox_parent: Path,
    *,
    timeout: int = DEFAULT_TIMEOUT,
    run_tests: bool = True,
    select_tests: Sequence[str] | None = None,
    profile: str = "corpus",
) -> VerificationReport:
    """Verify ``candidate`` in an isolated worktree; the source repository is left untouched."""
    from . import patch_generator as pg  # local import to avoid cycles

    if profile not in VERIFICATION_PROFILES:
        raise lga.AdapterError("verify.profile_unknown", f"unknown verification profile {profile!r}")
    pg.verify_candidate_hash(candidate, patch)
    if candidate["base_revision"] != binding.base_revision or candidate["scope_contract_hash"] != contract["scope_contract_hash"]:
        raise lga.AdapterError("verify.binding_mismatch", "candidate is not bound to this binding/scope contract")
    root = Path(binding.root_path)
    before_tree = lga.tree_identity(root, binding.base_revision)
    before_status = lga.git(root, "status", "--porcelain", "--untracked-files=all")
    run_id = lga.sha256_digest(lga.canonical_json({"cand": candidate["candidate_id"], "at": _now()}))
    sandbox = lga.worktree_add(root, Path(sandbox_parent) / f"verify-{candidate['candidate_id'][7:19]}", binding.base_revision)
    jobs: list[JobRecord] = []
    changed: list[PurePosixPath] = []
    symbol_changes: dict[str, Any] = {}
    artifact_hashes: dict[str, Any] = {"patch_hash": candidate["patch_hash"], "base_tree": before_tree, "changed_files": {}}
    try:
        # 1. applicability (check only) ---------------------------------------------------
        started = _now()
        code, out, err = _run(["git", "apply", "--check", "-"], sandbox, timeout, patch)
        jobs.append(_job(run_id, "applicability", "patch_review", True, "git apply --check -", code, out, err,
                         "PASS" if code == 0 else ("INDETERMINATE" if code is None else "FAIL"),
                         "patch applies to exact base revision" if code == 0 else "patch does not apply cleanly", started))
        if code != 0:
            raise _Abort()
        # 2. apply inside the sandbox only ------------------------------------------------
        started = _now()
        code, out, err = _run(["git", "apply", "-"], sandbox, timeout, patch)
        if code != 0:
            jobs.append(_job(run_id, "sandbox_apply", "patch_review", True, "git apply -", code, out, err, "FAIL", "apply in sandbox failed", started))
            raise _Abort()
        changed = list(lga.changed_paths(sandbox, binding.base_revision))
        artifact_hashes = {"patch_hash": candidate["patch_hash"], "base_tree": before_tree, "changed_files": {p.as_posix(): lga.sha256_digest(sandbox.joinpath(*p.parts).read_bytes()) for p in changed if sandbox.joinpath(*p.parts).is_file()}}
        # 3. scope diff ----------------------------------------------------------------
        started = _now()
        allowed = lga.validated_roots(contract["allowed_paths"], "allowed_paths")
        forbidden = lga.validated_roots(contract.get("forbidden_paths", ()), "forbidden_paths", allow_empty=True)
        declared = {PurePosixPath(p) for p in candidate["canonical_paths"]}
        try:
            lga.require_within_scope(changed, allowed, forbidden)
            undeclared = sorted(str(p) for p in changed if p not in declared)
            if undeclared:
                raise lga.AdapterError("scope.undeclared", f"changed paths not declared by candidate: {undeclared}")
            jobs.append(_job(run_id, "scope_diff", "patch_review", True, "changed_paths ⊆ declared ⊆ allowed−forbidden", 0, lga.canonical_json([str(p) for p in changed]).encode(), b"", "PASS", f"{len(changed)} path(s) confined", started))
        except lga.AdapterError as exc:
            _SEC.record_denial("SEC-02", "security.sec02.scope_injection", str(exc), subject={"candidate_id": candidate["candidate_id"], "changed": [str(p) for p in changed][:20]})  # SEC-02-T02
            jobs.append(_job(run_id, "scope_diff", "patch_review", True, "changed_paths ⊆ declared ⊆ allowed−forbidden", 1, b"", str(exc).encode(), "FAIL", str(exc), started))
            raise _Abort()
        # 3b. symbol diff (VERIFY-05-T02: Suite 40.2 symbol records before/after, every change inside a declared file) --
        started = _now()
        sym_ok, sym_msg, sym_out = _symbol_diff(root, sandbox, binding.base_revision, changed, declared)
        jobs.append(_job(run_id, "symbol_diff", "patch_review", False, "Suite 40.2 symbol records: (after − before) ⊆ declared files", 0 if sym_ok else 1, sym_out, b"" if sym_ok else sym_msg.encode(), "PASS" if sym_ok else "FAIL", sym_msg, started))
        symbol_changes = json.loads(sym_out.decode("utf-8"))
        if not sym_ok:
            raise _Abort()
        # 4. size limits ---------------------------------------------------------------
        started = _now()
        code, out, err = _run(["git", "diff", "--numstat", binding.base_revision, "--"], sandbox, timeout)
        added = deleted = 0
        for line in out.decode().splitlines():
            parts = line.split("\t")
            if len(parts) >= 2 and parts[0].isdigit() and parts[1].isdigit():
                added += int(parts[0])
                deleted += int(parts[1])
        ok = len(changed) <= contract["max_changed_files"] and (added + deleted) <= contract["max_diff_lines"]
        jobs.append(_job(run_id, "size_limits", "patch_review", True, "git diff --numstat", code, out, err, "PASS" if ok else "FAIL",
                         f"{len(changed)} files, +{added}/-{deleted} vs limits {contract['max_changed_files']} files / {contract['max_diff_lines']} lines", started))
        if not ok:
            raise _Abort()
        # 5. build ----------------------------------------------------------------------
        started = _now()
        py = [str(sandbox.joinpath(*p.parts)) for p in changed if p.suffix == ".py"]
        if py:
            code, out, err = _run([sys.executable, "-m", "py_compile", *py], sandbox, timeout)
        else:
            code, out, err = 0, b"no python files changed", b""
        ja_ok, ja_msg = _lint(sandbox, [p for p in changed if p.suffix in JA_FAMILY])
        verdict = "PASS" if code == 0 and ja_ok else ("INDETERMINATE" if code is None else "FAIL")
        jobs.append(_job(run_id, "build", "build_jobs", True, "py_compile changed .py + JA structural check", code, out, err + ja_msg.encode(), verdict, "compiled/structurally valid" if verdict == "PASS" else ja_msg, started))
        # 6. tests ----------------------------------------------------------------------
        started = _now()
        tests_dir = sandbox / "Scoped PR Builder" / "tests"
        test_files = sorted(tests_dir.glob("test_*.py")) if profile == "corpus" and tests_dir.is_dir() else []
        # COMP-08-T03: incremental selection — only the modules an impact report names, when they exist in the sandbox;
        # a selection that names nothing runnable falls back to the full suite (an empty selection is not evidence).
        selected_note = ""
        if select_tests:
            chosen = [tf for tf in test_files if tf.relative_to(sandbox).as_posix() in set(select_tests)]
            if chosen:
                selected_note = f" (incremental: {len(chosen)} of {len(test_files)} selected by impact)"
                test_files = chosen
        if run_tests and test_files:
            outs, errs, worst = [], [], 0
            for tf in test_files:
                c, o, e = _run([sys.executable, str(tf)], sandbox, timeout)
                outs.append(o); errs.append(e)
                worst = worst if c == 0 else (1 if c is not None else 2)
            code = 0 if worst == 0 else (None if worst == 2 else 1)
            out, err = b"".join(outs), b"".join(errs)
            verdict = "PASS" if code == 0 else ("INDETERMINATE" if code is None else "FAIL")
            summary = f"{len(test_files)} test module(s) {'passed' if code == 0 else 'failed'}{selected_note}"
        elif run_tests and profile == "generic":
            discovered=[x for x in _TD.discover(sandbox) if x.get("kind") == "tests"]
            runnable=[x for x in discovered if x.get("argv") and x.get("status","ready") != "tool_missing"]
            if runnable:
                outs=[]; errs=[]; worst=0
                for spec in runnable:
                    c,o,e=_run(list(spec["argv"]), sandbox / spec.get("cwd","."), timeout)
                    outs.append(o); errs.append(e); worst = worst if c == 0 else (1 if c is not None else 2)
                code=0 if worst==0 else (None if worst==2 else 1); out=b''.join(outs); err=b''.join(errs)
                verdict="PASS" if code==0 else ("INDETERMINATE" if code is None else "FAIL")
                summary=f"{len(runnable)} repository-native test command(s) {'passed' if code==0 else 'failed'}"
            else:
                code,out,err,verdict,summary=None,b'',b'no repository-native tests/tool available',"INDETERMINATE","no repository-native tests/tool available"
        else:
            code, out, err, verdict, summary = None, b"", b"tests disabled", "INDETERMINATE", "tests disabled"
        jobs.append(_job(run_id, "tests", "test_jobs", True, "repository-native tests" if profile == "generic" else "python3 <each test module>", code, out, err, verdict, summary, started))
        # 6b. behavioral regression (VERIFY-07-T02: overlay-declared checks, where defined for the changed paths) --------
        started = _now()
        rg_verdict, rg_msg, rg_out, rg_err, rg_code = _regression(sandbox, changed, timeout)
        jobs.append(_job(run_id, "regression", "test_jobs", False, "verification/REGRESSION.json checks applicable to the changed paths", rg_code, rg_out, rg_err, rg_verdict, rg_msg, started))
        # 7. lint -----------------------------------------------------------------------
        started = _now()
        ok, msg = _lint(sandbox, changed)
        jobs.append(_job(run_id, "lint", "evaluation_jobs", True, "deterministic lint rules", 0 if ok else 1, msg.encode(), b"", "PASS" if ok else "FAIL", msg, started))
        # 7b. static analysis (VERIFY-04-T02: Safety Gate 28.1 AST + 28.2 lint findings within the configured threshold) --
        started = _now()
        sa_ok, sa_msg, sa_out = _static_analysis(sandbox, changed, contract)
        jobs.append(_job(run_id, "static_analysis", "evaluation_jobs", False, "ast.parse changed .py + lint findings ≤ threshold", 0 if sa_ok else 1, sa_out, b"" if sa_ok else sa_msg.encode(), "PASS" if sa_ok else "FAIL", sa_msg, started))
        # 8. cross-reference ---------------------------------------------------------------
        started = _now()
        if profile == "corpus":
            ok, msg = _xref_structural(sandbox)
            jobs.append(_job(run_id, "cross_reference", "evaluation_jobs", True, "Suite 01–66 structural cross-reference", 0 if ok else 1, msg.encode(), b"", "PASS" if ok else "FAIL", msg, started))
        else:
            jobs.append(_job(run_id, "cross_reference", "evaluation_jobs", False, "Suite 01–66 structural cross-reference (corpus-only)", None, b"", b"", "INDETERMINATE", "not applicable in generic verification profile", started))
    except _Abort:
        pass
    finally:
        lga.worktree_remove(root, sandbox)
    destroyed = not sandbox.exists()
    unchanged = lga.tree_identity(root, binding.base_revision) == before_tree and lga.git(root, "status", "--porcelain", "--untracked-files=all") == before_status
    present = {j.check: j.verdict for j in jobs}
    mandatory_names = MANDATORY_CORPUS if profile == "corpus" else MANDATORY_GENERIC
    if any(present.get(c) == "FAIL" for c in mandatory_names) or not unchanged:
        verdict = "FAIL"
    elif all(present.get(c) == "PASS" for c in mandatory_names):
        verdict = "PASS"
    else:
        verdict = "INDETERMINATE"
    report = VerificationReport(
        adapter_id=ADAPTER_ID, adapter_version=ADAPTER_VERSION, run_id=run_id, candidate_id=candidate["candidate_id"],
        patch_hash=candidate["patch_hash"], base_revision=binding.base_revision, scope_contract_hash=contract["scope_contract_hash"],
        verification_profile=profile, sandbox_worktree=str(sandbox), sandbox_destroyed=destroyed, source_tree_unchanged=unchanged,
        jobs=[asdict(j) for j in jobs], verdict=verdict, symbol_changes=symbol_changes, artifact_hashes=artifact_hashes,
    )
    body = asdict(report); body.pop("report_hash")
    return VerificationReport(**{**body, "report_hash": lga.sha256_digest(lga.canonical_json(body))})


def verify_report_hash(report: Mapping[str, Any]) -> None:
    """Fail closed if a stored/received report's content does not match its report_hash."""
    body = {k: v for k, v in report.items() if k != "report_hash"}
    body["report_hash"] = ""
    expected = lga.sha256_digest(lga.canonical_json({k: v for k, v in body.items() if k != "report_hash"}))
    if expected != report.get("report_hash"):
        raise lga.AdapterError("report.tampered", "report_hash does not match report content")


class _Abort(Exception):
    pass


__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "MANDATORY", "MANDATORY_CORPUS", "MANDATORY_GENERIC", "VERIFICATION_PROFILES", "JobRecord", "VerificationReport", "verify_candidate", "verify_report_hash"]
