"""Scoped PR Builder — executable controls behind registered contracts (Phase 01 / IMPL-*, API-*).

Each function is the enforceable form of a contract in ``contracts/REGISTRY.json``; the
registry entry names the function that executes it. All controls are deterministic,
dependency-free, and fail closed with stable ``AdapterError`` codes.
"""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Mapping, Sequence

from . import local_git_adapter as lga

# --------------------------------------------------------------------------- #
# IMPL-03 — versioned workflow state machine                                     #
# --------------------------------------------------------------------------- #
STATE_MACHINE_VERSION = "scoped_pr_builder.run_state_machine/0.1.0"
START_STATE = "INTAKE"
ANALYSIS_STATES = ("BOUND", "INTENT_ACCEPTED", "PLANNED", "PATCH_INERT", "VERIFIED")
REVIEW_STATES = ("REVIEW_PENDING",)
APPROVAL_STATES = ("APPROVED", "APPLIED_ISOLATED", "ARCHIVED")
TERMINAL_STATES = ("ROLLED_BACK", "BLOCKED", "ABSTAINED", "CANCELLED")
STATES = (START_STATE,) + ANALYSIS_STATES + REVIEW_STATES + APPROVAL_STATES + TERMINAL_STATES
TRANSITIONS: dict[str, tuple[str, ...]] = {
    "INTAKE": ("BOUND", "BLOCKED", "CANCELLED"),
    "BOUND": ("INTENT_ACCEPTED", "BLOCKED", "CANCELLED"),
    "INTENT_ACCEPTED": ("PLANNED", "ABSTAINED", "BLOCKED", "CANCELLED"),
    "PLANNED": ("PATCH_INERT", "ABSTAINED", "BLOCKED", "CANCELLED"),
    "PATCH_INERT": ("VERIFIED", "BLOCKED", "CANCELLED"),
    "VERIFIED": ("REVIEW_PENDING", "BLOCKED", "CANCELLED"),
    "REVIEW_PENDING": ("APPROVED", "BLOCKED", "CANCELLED"),
    "APPROVED": ("APPLIED_ISOLATED", "BLOCKED", "CANCELLED"),
    "APPLIED_ISOLATED": ("ARCHIVED", "ROLLED_BACK", "BLOCKED"),
    "ARCHIVED": ("ROLLED_BACK",),
    "ROLLED_BACK": (), "BLOCKED": (), "ABSTAINED": (), "CANCELLED": (),
}
# Preconditions: the evidence a transition must carry (checked by name; values are hashes).
TRANSITION_EVIDENCE: dict[tuple[str, str], tuple[str, ...]] = {
    ("INTAKE", "BOUND"): ("worktree_hash",),
    ("BOUND", "INTENT_ACCEPTED"): ("scope_contract_hash",),
    ("INTENT_ACCEPTED", "PLANNED"): ("plan_hash",),
    ("PLANNED", "PATCH_INERT"): ("patch_hash",),
    ("PATCH_INERT", "VERIFIED"): ("report_hash",),
    ("VERIFIED", "REVIEW_PENDING"): ("card_hash",),
    ("REVIEW_PENDING", "APPROVED"): ("receipt_hash",),
    ("APPROVED", "APPLIED_ISOLATED"): ("applied_record_hash",),
    ("APPLIED_ISOLATED", "ARCHIVED"): ("manifest_hash",),
}


def validate_transition(from_state: str, to_state: str, evidence: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Admit a state transition only if it is declared and carries its required evidence hashes."""
    if from_state not in STATES or to_state not in STATES:
        raise lga.AdapterError("state.unknown", f"unknown state in {from_state!r} -> {to_state!r}")
    if from_state in TERMINAL_STATES:
        raise lga.AdapterError("state.terminal", f"{from_state} is terminal; no transitions leave it")
    if to_state not in TRANSITIONS[from_state]:
        raise lga.AdapterError("state.transition_denied", f"{from_state} -> {to_state} is not a declared transition")
    required = TRANSITION_EVIDENCE.get((from_state, to_state), ())
    evidence = evidence or {}
    for name in required:
        value = evidence.get(name)
        if not isinstance(value, str) or not re.match(r"^sha256:[0-9a-f]{64}$", value):
            raise lga.AdapterError("state.evidence_missing", f"{from_state} -> {to_state} requires evidence {name!r} as a sha256 digest")
    rec = {"state_machine_version": STATE_MACHINE_VERSION, "from": from_state, "to": to_state, "evidence": {k: evidence[k] for k in required}, "verdict": "ADMITTED"}
    rec["transition_hash"] = lga.sha256_digest(lga.canonical_json(rec))
    return rec


def validate_sequence(states: Sequence[str], evidence: Sequence[Mapping[str, Any]] | None = None) -> list[dict[str, Any]]:
    """Validate a whole run-state sequence (as recorded in archive/run-state.jsonl)."""
    if not states or states[0] != START_STATE:
        raise lga.AdapterError("state.bad_start", f"sequence must start at {START_STATE}")
    out = []
    for i in range(1, len(states)):
        ev = (evidence[i] if evidence and i < len(evidence) else {}) or {}
        out.append(validate_transition(states[i - 1], states[i], ev))
    return out


# --------------------------------------------------------------------------- #
# IMPL-06 — enforceable policy layer (the executable form of scoped_pr_builder_policy.jasec)
# --------------------------------------------------------------------------- #
import fnmatch


def policy_decide(rule_set: Mapping[str, Any], effect: str, principal_role: str, context: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Deterministic policy decision. explicit_deny_wins: a deny pattern beats any grant; ungranted effects are
    denied; effects requiring human approval / revalidation are denied unless the context proves them."""
    context = context or {}
    if rule_set.get("conflict_resolution") != "explicit_deny_wins":
        raise lga.AdapterError("policy.rule_set_invalid", "rule set must declare explicit_deny_wins")
    requires: list[str] = []
    reason = None
    for pattern in rule_set.get("deny_by_default", []):
        if fnmatch.fnmatchcase(effect, pattern) and effect not in rule_set.get("grants", {}).get(principal_role, []):
            reason = f"denied by default pattern {pattern!r}"
            break
    if reason is None and effect not in rule_set.get("grants", {}).get(principal_role, []):
        reason = f"effect {effect!r} not granted to role {principal_role!r}"
    if reason is None and effect in rule_set.get("require_human_approval", []):
        requires.append("human_approval")
        if not context.get("human_approval_receipt_verified"):
            reason = "human approval receipt not verified"
    if reason is None:
        for need in rule_set.get("require_revalidation", {}).get(effect, []):
            requires.append(f"{need}_revalidation")
            if not context.get(f"{need}_revalidated"):
                reason = f"{need} revalidation not proven"
                break
    decision = {"effect": effect, "principal_role": principal_role, "decision": "deny" if reason else "allow", "reason": reason or "granted and all requirements proven",
                "requires": requires, "policy_hash": rule_set.get("policy_hash", "")}
    return decision


# --------------------------------------------------------------------------- #
# IMPL-09 — audit logging requirements                                          #
# --------------------------------------------------------------------------- #
def audit_check(entries: Sequence[Mapping[str, Any]], requirements: Mapping[str, Any]) -> dict[str, Any]:
    """Every required privileged effect must appear in the (already chain-verified) audit entries; each entry
    must name an actor and a time. Missing effects are reported, never assumed."""
    effects = [e.get("effect") for e in entries]
    missing = [eff for eff in requirements.get("required_effects", []) if eff not in effects]
    malformed = [i for i, e in enumerate(entries) if not e.get("actor") or not e.get("at") or not e.get("effect")]
    verdict = "PASS" if not missing and not malformed else "FAIL"
    return {"verdict": verdict, "missing_effects": missing, "malformed_entries": malformed, "entry_count": len(entries)}


# --------------------------------------------------------------------------- #
# API-04 — uncertainty / abstention consistency                                  #
# --------------------------------------------------------------------------- #
def check_uncertainty(u: Mapping[str, Any]) -> None:
    """Insufficient evidence must carry an abstain reason; sufficient evidence must not claim a reason to abstain."""
    if u.get("evidence_sufficiency") == "insufficient" and not u.get("abstain_reason"):
        raise lga.AdapterError("uncertainty.reason_missing", "insufficient evidence requires an abstain_reason")
    if u.get("evidence_sufficiency") == "sufficient" and u.get("abstain_reason"):
        raise lga.AdapterError("uncertainty.inconsistent", "sufficient evidence cannot carry an abstain_reason")
    if u.get("confidence_band") == "high" and (u.get("example_count") or 0) < 3:
        raise lga.AdapterError("uncertainty.overclaim", "high confidence requires at least 3 corroborating examples")


# --------------------------------------------------------------------------- #
# API-06 — idempotency for retried workflow steps                               #
# --------------------------------------------------------------------------- #
def idempotency_key(run_id: str, step: str, inputs: Mapping[str, Any]) -> str:
    """Deterministic key: same run, step and canonical inputs -> same key; anything else -> different key."""
    if not re.match(r"^sha256:[0-9a-f]{64}$", run_id or ""):
        raise lga.AdapterError("idempotency.run_id_invalid", "run_id must be a sha256 digest")
    if not step or not re.match(r"^[a-z][a-z0-9_.-]{1,63}$", step):
        raise lga.AdapterError("idempotency.step_invalid", "step must be a short lowercase identifier")
    return lga.sha256_digest(lga.canonical_json({"run_id": run_id, "step": step, "inputs": inputs}))


def replay_check(ledger: Sequence[Mapping[str, Any]], key: str, result_hash: str) -> str:
    """Retried step semantics: unseen key -> 'EXECUTE'; same key + same result -> 'REPLAY_SAME'; same key + different result -> refuse."""
    prior = [e for e in ledger if e.get("idempotency_key") == key]
    if not prior:
        return "EXECUTE"
    if all(e.get("result_hash") == result_hash for e in prior):
        return "REPLAY_SAME"
    raise lga.AdapterError("idempotency.conflict", "a retried step produced a different result for the same idempotency key")


# --------------------------------------------------------------------------- #
# API-08 — backward-compatible versioning / migration                            #
# --------------------------------------------------------------------------- #
def parse_semver(v: str) -> tuple[int, int, int]:
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)$", v or "")
    if not m:
        raise lga.AdapterError("version.invalid", f"not a semver string: {v!r}")
    return tuple(int(x) for x in m.groups())  # type: ignore[return-value]


def compatibility(declared: str, supported: str) -> str:
    """Contract compatibility policy: same major and declared minor <= supported minor -> COMPATIBLE;
    same major, newer minor -> NEEDS_UPGRADE (reader too old); different major -> INCOMPATIBLE (migration required)."""
    d, s = parse_semver(declared), parse_semver(supported)
    if d[0] != s[0]:
        return "INCOMPATIBLE"
    if d[1] > s[1]:
        return "NEEDS_UPGRADE"
    return "COMPATIBLE"


def require_compatible(declared: str, supported: str) -> None:
    verdict = compatibility(declared, supported)
    if verdict != "COMPATIBLE":
        raise lga.AdapterError("version.incompatible", f"declared {declared} vs supported {supported}: {verdict}")


# --------------------------------------------------------------------------- #
# IMPL-10 — offline benchmark / regression gate                                  #
# --------------------------------------------------------------------------- #
GATE_METRICS = {
    "scope_expansion_fail_closed_rate": ("test_adversarial_pilot.py",),
    "fabricated_approval_fail_closed_rate": ("test_adversarial_pilot.py", "test_approval_adapter.py"),
    "stale_context_fail_closed_rate": ("test_local_git_adapter.py", "test_intent_intake.py"),
    "pinned_revision_reproducibility": ("test_repository_context_adapter.py", "test_evidence_retrieval.py", "test_patch_generator.py"),
    "cross_reference_integrity": ("test_verification_runner.py",),
    "source_worktree_untouched_rate": ("test_verification_runner.py", "test_approval_adapter.py", "test_adversarial_pilot.py"),
    "rollback_proof_rate": ("test_archive_adapter.py",),
}


def run_offline_benchmark(tests_dir: Path, *, timeout: int = 600) -> dict[str, Any]:
    """Run the overlay test modules and derive the evaluation-gate metrics declared in scoped_pr_builder_evaluation.jate.
    A metric whose backing module is missing or cannot run is INDETERMINATE and fails the gate."""
    results: dict[str, dict[str, Any]] = {}
    for module in sorted(Path(tests_dir).glob("test_*.py")):
        try:
            p = subprocess.run([sys.executable, str(module)], capture_output=True, timeout=timeout, cwd=Path(tests_dir).parent.parent)
            ok = p.returncode == 0
            results[module.name] = {"ok": ok, "stdout_digest": lga.sha256_digest(p.stdout), "stderr_digest": lga.sha256_digest(p.stderr), "tail": p.stderr.decode("utf-8", errors="replace")[-300:]}
        except subprocess.TimeoutExpired:
            results[module.name] = {"ok": None, "tail": "timeout"}
    metrics = {}
    for metric, modules in GATE_METRICS.items():
        vals = [results.get(m, {}).get("ok") for m in modules]
        metrics[metric] = None if any(v is None for v in vals) else (1.0 if all(vals) else 0.0)
    verdict = "PASS" if all(v == 1.0 for v in metrics.values()) else ("INDETERMINATE" if any(v is None for v in metrics.values()) else "FAIL")
    gate = {"gate_version": "scoped_pr_builder.evaluation_gate/0.1.0", "metrics": metrics, "thresholds": {m: 1.0 for m in GATE_METRICS}, "modules": results, "verdict": verdict}
    gate["gate_hash"] = lga.sha256_digest(lga.canonical_json(gate))
    return gate


__all__ = ["STATES", "TRANSITIONS", "TERMINAL_STATES", "STATE_MACHINE_VERSION", "GATE_METRICS", "audit_check", "check_uncertainty", "policy_decide", "compatibility", "idempotency_key", "parse_semver", "replay_check", "require_compatible", "run_offline_benchmark", "validate_sequence", "validate_transition"]


# --------------------------------------------------------------------------- #
# IMPL-*-T02 — control bindings: the dispatcher that makes a registered control executable
# --------------------------------------------------------------------------- #
CONTROL_HANDLERS: dict[str, Any] = {}


def register_control(control_id: str):
    def deco(fn):
        CONTROL_HANDLERS[control_id] = fn
        return fn
    return deco


def run_control(control_id: str, payload: Any, *, registry: Mapping[str, Any] | None = None, run: Any = None) -> dict[str, Any]:
    """Execute the bound control for ``control_id`` on ``payload``; returns a hash-bound ENFORCED record or
    refuses with the control's stable code. Unknown controls and non-object payloads are refused.
    When a ``run`` (wiring.Run) is given, decision-relevant results — enforced or refused — are exposed to the
    review surface (card fragment) and appended to the run's audit chain (IMPL-*-T04)."""
    from . import contracts as _C
    reg = registry or _C.load_registry()
    entry = reg["contracts"].get(control_id)
    if entry is None or control_id not in CONTROL_HANDLERS or "binding" not in entry:
        raise lga.AdapterError("control.unknown", f"no bound control {control_id!r}")
    if not isinstance(payload, Mapping):
        refusal = _refusal(control_id, entry, payload, lga.AdapterError("control.malformed", "control payload must be an object"))
        expose(refusal.failure_record, run, entry)
        raise refusal
    try:
        result = CONTROL_HANDLERS[control_id](dict(payload), reg)
    except lga.AdapterError as exc:
        refusal = _refusal(control_id, entry, payload, exc)
        expose(refusal.failure_record, run, entry)
        raise refusal from exc
    rec = {"control_id": control_id, "control_version": entry["version"], "binding": entry["binding"]["adapter"], "scaffold_suite": entry["binding"]["scaffold_suite"],
           "input_hash": lga.sha256_digest(lga.canonical_json(payload)), "result": result, "verdict": "ENFORCED"}
    for f in entry.get("provenance_fields", []):
        if f not in rec and not (isinstance(result, Mapping) and f in result):
            refusal = _refusal(control_id, entry, payload, lga.AdapterError("control.provenance_incomplete", f"enforced record lacks provenance field {f!r}"))
            expose(refusal.failure_record, run, entry)
            raise refusal
    rec["control_hash"] = lga.sha256_digest(lga.canonical_json(rec))
    rec["exposure"] = expose(rec, run, entry)
    return rec


# IMPL-*-T04 — exposure: whenever a control result can change a workflow decision it reaches the review surface and the audit trail.
def expose(record: Mapping[str, Any], run: Any, entry: Mapping[str, Any]) -> dict[str, Any]:
    """Build the display-only review-card fragment declared by ``review_exposure`` and append a chained audit event on ``run``.
    Refusals are exposed exactly like enforcements (denied actions are logged). Without a run nothing is exposed and the
    result says so — exposure is never assumed."""
    exp = entry.get("review_exposure")
    if not exp or run is None:
        return {"exposed": False, "reason": "no review_exposure declared" if not exp else "no run supplied"}
    result = record.get("result") if isinstance(record.get("result"), Mapping) else {}
    fields = {f: (record[f] if f in record else result.get(f)) for f in exp["fields"]}
    record_hash = record.get("control_hash") or record.get("failure_hash")
    fragment = {"card_section": exp["card_section"], "authority": "display_only", "control_id": record["control_id"], "verdict": record["verdict"], "fields": fields,
                "decision_relevant": bool(exp.get("decision_relevant", True)), "record_hash": record_hash, "transition_to": record.get("transition_to")}
    fragment["fragment_hash"] = lga.sha256_digest(lga.canonical_json(fragment))
    audit_fields = {"effect": exp["audit_effect"], "control_id": record["control_id"], "verdict": record["verdict"], "record_hash": record_hash, "fragment_hash": fragment["fragment_hash"],
                    "card_section": exp["card_section"], "transition_to": record.get("transition_to")}
    if record["verdict"] == "REFUSED":
        audit_fields.update(denial_code=record.get("code"), reason=record.get("reason"), fail_closed=True)
    audit = run._audit(**audit_fields)
    return {"exposed": True, "fragment": fragment, "audit_entry_hash": audit["entry_hash"]}


# IMPL-*-T03 — error states: every refusal is a declared state with a fail-closed transition; nothing undeclared proceeds.
GENERIC_ERROR_STATES: dict[str, str] = {"schema.invalid": "BLOCKED", "control.malformed": "BLOCKED", "contract.unknown": "BLOCKED", "control.provenance_incomplete": "BLOCKED", "control.undeclared_error": "BLOCKED"}


class ControlRefusal(lga.AdapterError):
    """A control refusal carrying its failure record (declared error state + fail-closed transition + provenance)."""

    def __init__(self, code: str, message: str, failure_record: Mapping[str, Any]) -> None:
        super().__init__(code, message)
        self.failure_record = dict(failure_record)


def _refusal(control_id: str, entry: Mapping[str, Any], payload: Any, exc: lga.AdapterError) -> ControlRefusal:
    states = entry.get("error_states")
    declared = {s["code"]: s for s in (states or [])}
    code, reason = exc.code, str(exc)
    if code in declared:
        transition = declared[code]["transition"]
    elif code in GENERIC_ERROR_STATES:
        transition = GENERIC_ERROR_STATES[code]
    elif states is None:
        transition = "BLOCKED"  # control has not declared its states yet: still fail closed, code passes through
    else:
        reason = f"{code} is not a declared error state of {control_id}: {reason}"
        code, transition = "control.undeclared_error", "BLOCKED"
    failure = {"control_id": control_id, "control_version": entry["version"], "code": code, "reason": reason, "transition_to": transition,
               "input_hash": lga.sha256_digest(lga.canonical_json(payload)) if not isinstance(payload, (bytes, bytearray)) else lga.sha256_digest(bytes(payload)),
               "binding": entry.get("binding", {}).get("adapter"), "scaffold_suite": entry.get("binding", {}).get("scaffold_suite"), "verdict": "REFUSED"}
    failure["failure_hash"] = lga.sha256_digest(lga.canonical_json(failure))
    return ControlRefusal(code, reason, failure)


@register_control("scope_contract")
def _control_scope_contract(p: Mapping[str, Any], reg: Mapping[str, Any]) -> dict[str, Any]:
    """IMPL-01-T02: a scope contract is enforceable only if schema-valid, hash-consistent, path-confined and within the hard caps."""
    from . import contracts as _C
    from . import intent_intake as _I
    _C.validate_payload("scope_contract", p, registry=reg)
    _I.verify_contract_hash(p)
    allowed = lga.validated_roots(p["allowed_paths"], "allowed_paths")
    forbidden = lga.validated_roots(p["forbidden_paths"], "forbidden_paths", allow_empty=True)
    if p["max_changed_files"] > _I.HARD_MAX_CHANGED_FILES or p["max_diff_lines"] > _I.HARD_MAX_DIFF_LINES:
        raise lga.AdapterError("scope.cap_exceeded", "scope exceeds the overlay hard caps")
    for f in forbidden:
        if lga.within(f, allowed) and f in allowed:
            raise lga.AdapterError("scope.contradictory", f"{f} is both allowed and forbidden")
    return {"scope_contract_hash": p["scope_contract_hash"], "allowed_roots": [str(a) for a in allowed], "forbidden_roots": [str(f) for f in forbidden], "size_band_ceiling": p["size_band_ceiling"]}


@register_control("payload_validation")
def _control_payload_validation(p: Mapping[str, Any], reg: Mapping[str, Any]) -> dict[str, Any]:
    """IMPL-02-T02: validate an arbitrary payload against a named registered contract; returns the validation receipt."""
    from . import contracts as _C
    if "contract_id" not in p or "payload" not in p:
        raise lga.AdapterError("control.malformed", "payload_validation needs contract_id and payload")
    receipt = _C.validate_payload(p["contract_id"], p["payload"], registry=reg)
    _C.validate_payload("payload_validation", receipt, registry=reg)
    return receipt


@register_control("run_state_machine")
def _control_run_state_machine(p: Mapping[str, Any], reg: Mapping[str, Any]) -> dict[str, Any]:
    """IMPL-03-T02: admit a whole recorded state sequence with its evidence; the last admitted transition is returned."""
    from . import contracts as _C
    states = p.get("states")
    if not isinstance(states, list) or len(states) < 2:
        raise lga.AdapterError("control.malformed", "run_state_machine needs a states list of length >= 2")
    admitted = validate_sequence(states, p.get("evidence") or [])
    for t in admitted:
        _C.validate_payload("run_state_machine", t, registry=reg)
    return {"transitions": len(admitted), "final_state": states[-1], "last": admitted[-1]}


def provenance_hash(links: Sequence[Mapping[str, Any]], model_version: Any) -> str:
    return lga.sha256_digest(lga.canonical_json({"links": list(links), "model_version": model_version}))


@register_control("provenance_model")
def _control_provenance_model(p: Mapping[str, Any], reg: Mapping[str, Any]) -> dict[str, Any]:
    """IMPL-04-T02: a provenance bundle is closed only if every link is hash-bound, outputs are unique and the bundle hash matches."""
    from . import contracts as _C
    _C.validate_payload("provenance_model", p, registry=reg)
    outputs = [l["output"] for l in p["links"]]
    if len(set(outputs)) != len(outputs):
        raise lga.AdapterError("provenance.duplicate_output", "two links claim the same output")
    if provenance_hash(p["links"], p["model_version"]) != p["provenance_hash"]:
        raise lga.AdapterError("provenance.tampered", "provenance_hash does not match the links")
    return {"links": len(outputs), "outputs": outputs, "provenance_hash": p["provenance_hash"]}


@register_control("freshness_pinning")
def _control_freshness_pinning(p: Mapping[str, Any], reg: Mapping[str, Any]) -> dict[str, Any]:
    """IMPL-05-T02: the freshness gate — a record may pass only if it is internally consistent and fresh."""
    from . import contracts as _C
    _C.validate_payload("freshness_pinning", p, registry=reg)
    stale = p["observed_revision"] != p["indexed_revision"] or p["source_snapshot_hash"] != p["indexed_snapshot_hash"] or p["dirty_file_count"] > 0
    if stale != (p["freshness_status"] == "stale"):
        raise lga.AdapterError("freshness.inconsistent", "freshness_status contradicts the recorded revisions/snapshots/dirty count")
    if stale:
        raise lga.AdapterError("freshness.stale", p.get("stale_reason") or "pinned context is stale")
    return {"freshness_id": p["freshness_id"], "pinned_revision": p["indexed_revision"], "source_snapshot_hash": p["source_snapshot_hash"]}


@register_control("policy_layer")
def _control_policy_layer(p: Mapping[str, Any], reg: Mapping[str, Any]) -> dict[str, Any]:
    """IMPL-06-T02: decide one effect for one role under a validated rule set; a deny is a refusal, never a warning."""
    from . import contracts as _C
    rs = p.get("rule_set")
    if not isinstance(rs, Mapping) or "effect" not in p or "principal_role" not in p:
        raise lga.AdapterError("control.malformed", "policy_layer needs rule_set, effect, principal_role")
    _C.validate_payload("policy_layer", rs, registry=reg)
    decision = policy_decide(rs, p["effect"], p["principal_role"], p.get("context") or {})
    if decision["decision"] != "allow":
        raise lga.AdapterError("policy.denied", decision["reason"])
    return decision


@register_control("abstention")
def _control_abstention(p: Mapping[str, Any], reg: Mapping[str, Any]) -> dict[str, Any]:
    """IMPL-07-T02: an abstention record is enforceable only if its reason, sufficiency and terminal state agree."""
    from . import contracts as _C
    _C.validate_payload("abstention", p, registry=reg)
    if p["reason_code"] == "insufficient_evidence" and p["evidence_sufficiency"] != "insufficient":
        raise lga.AdapterError("abstention.inconsistent", "insufficient_evidence must carry evidence_sufficiency=insufficient")
    if p["run_state"] not in TERMINAL_STATES:
        raise lga.AdapterError("abstention.inconsistent", "abstention must land in a terminal state")
    return {"reason_code": p["reason_code"], "run_state": p["run_state"], "scope_contract_hash": p["scope_contract_hash"]}


@register_control("review_surface")
def _control_review_surface(p: Mapping[str, Any], reg: Mapping[str, Any]) -> dict[str, Any]:
    """IMPL-08-T02: a review card identity is enforceable only if display-only and free of decision-bearing fields."""
    from . import contracts as _C
    _C.validate_payload("review_surface", p, registry=reg)
    if p["authority"] != "display_only":
        raise lga.AdapterError("review.authority_violation", "review surface must be display_only")
    if p["preconditions"]["failed"] or p["preconditions"]["unresolved"]:
        raise lga.AdapterError("review.preconditions_open", "card cannot be presented for approval with failed or unresolved preconditions")
    return {"card_hash": p["card_hash"], "candidate_id": p["identity"]["candidate_id"], "satisfied": p["preconditions"]["satisfied"]}


@register_control("audit_logging")
def _control_audit_logging(p: Mapping[str, Any], reg: Mapping[str, Any]) -> dict[str, Any]:
    """IMPL-09-T02: audit entries satisfy the requirements only if every required effect is present and well-formed."""
    from . import contracts as _C
    req = p.get("requirements"); entries = p.get("entries")
    if not isinstance(req, Mapping) or not isinstance(entries, list):
        raise lga.AdapterError("control.malformed", "audit_logging needs requirements and entries")
    _C.validate_payload("audit_logging", req, registry=reg)
    result = audit_check(entries, req)
    if result["verdict"] != "PASS":
        raise lga.AdapterError("audit.incomplete", f"missing {result['missing_effects']} malformed {result['malformed_entries']}")
    return result


@register_control("offline_benchmark")
def _control_offline_benchmark(p: Mapping[str, Any], reg: Mapping[str, Any]) -> dict[str, Any]:
    """IMPL-10-T02: a gate record is enforceable only if its verdict is what the metrics and thresholds imply; INDETERMINATE never passes."""
    from . import contracts as _C
    _C.validate_payload("offline_benchmark", p, registry=reg)
    thresholds = {m: p["thresholds"].get(m, 1.0) for m in GATE_METRICS}
    values = [p["metrics"][m] for m in GATE_METRICS]
    expected = "INDETERMINATE" if any(v is None for v in values) else ("PASS" if all(p["metrics"][m] >= thresholds[m] for m in GATE_METRICS) else "FAIL")
    if p["verdict"] != expected:
        raise lga.AdapterError("benchmark.verdict_mismatch", f"recorded {p['verdict']} but metrics imply {expected}")
    if expected != "PASS":
        raise lga.AdapterError("benchmark.gate_failed", f"gate verdict {expected}")
    return {"verdict": expected, "thresholds": thresholds}
