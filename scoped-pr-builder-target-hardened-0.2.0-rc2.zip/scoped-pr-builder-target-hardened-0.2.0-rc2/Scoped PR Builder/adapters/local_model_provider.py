"""Pinned local-model boundary.

The boundary accepts only loopback model endpoints, a cryptographically pinned
model digest, and a small typed proposal schema. The injected transport remains
outside this module's authority; callers must still provide an implementation
that actually honors the endpoint contract.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
import re
from typing import Any, Callable
from urllib.parse import urlsplit

from . import local_git_adapter as lga


@dataclass(frozen=True)
class LocalModelSpec:
    provider: str
    model: str
    digest: str
    endpoint: str = "loopback"


def _validate_spec(spec: LocalModelSpec) -> None:
    if not str(spec.provider).strip() or not str(spec.model).strip():
        raise lga.AdapterError("model.spec_invalid", "local model provider and model are required")
    if not re.fullmatch(r"sha256:[0-9a-fA-F]{64}", str(spec.digest)):
        raise lga.AdapterError("model.unpinned", "model digest must be a full sha256 digest")
    endpoint = str(spec.endpoint).strip()
    if endpoint == "loopback":
        return
    try:
        parsed = urlsplit(endpoint)
    except ValueError as exc:
        raise lga.AdapterError("model.endpoint_invalid", "local model endpoint is malformed") from exc
    if parsed.scheme not in {"http", "https"} or parsed.hostname not in {"127.0.0.1", "::1", "localhost"}:
        raise lga.AdapterError("model.non_loopback", "local model endpoint must be HTTP(S) on loopback")
    if parsed.username or parsed.password:
        raise lga.AdapterError("model.endpoint_invalid", "credentials must not be embedded in the local model endpoint")


def propose_recipe(
    spec: LocalModelSpec,
    transport: Callable[[dict[str, Any]], dict[str, Any]],
    payload: dict[str, Any],
    allowed_recipes: set[str],
) -> dict[str, Any]:
    _validate_spec(spec)
    if not isinstance(payload, dict):
        raise lga.AdapterError("model.payload_invalid", "model payload must be an object")
    out = transport(payload)
    if not isinstance(out, dict):
        raise lga.AdapterError("model.schema_invalid", "model output must be an object")
    expected = {"recipe_name", "recipe_args", "evidence_refs", "rationale", "confidence"}
    if set(out) != expected:
        raise lga.AdapterError("model.schema_invalid", "model output must contain exactly the registered proposal fields")
    if not isinstance(out.get("recipe_name"), str) or out["recipe_name"] not in allowed_recipes:
        raise lga.AdapterError("model.recipe_unregistered", "model proposed an unregistered recipe")
    if not isinstance(out.get("recipe_args"), dict):
        raise lga.AdapterError("model.schema_invalid", "recipe_args must be an object")
    refs = out.get("evidence_refs")
    if not isinstance(refs, list) or any(not isinstance(x, str) or not x.strip() for x in refs) or len(refs) > 64:
        raise lga.AdapterError("model.schema_invalid", "evidence_refs must be a bounded list of non-empty strings")
    rationale = out.get("rationale")
    if not isinstance(rationale, str) or not rationale.strip() or len(rationale) > 4000:
        raise lga.AdapterError("model.schema_invalid", "rationale must be a non-empty string no longer than 4000 characters")
    confidence = out.get("confidence")
    if isinstance(confidence, bool) or not isinstance(confidence, (int, float)) or not math.isfinite(float(confidence)) or not 0 <= float(confidence) <= 1:
        raise lga.AdapterError("model.schema_invalid", "confidence must be a finite number in [0, 1]")
    if float(confidence) < 0.7:
        raise lga.AdapterError("model.abstain", "low-confidence model proposal")
    return out
