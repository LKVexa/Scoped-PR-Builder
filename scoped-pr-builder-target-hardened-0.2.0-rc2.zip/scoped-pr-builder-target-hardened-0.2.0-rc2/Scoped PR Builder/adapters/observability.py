"""Observability for a governed run: structured state-transition logs, operational and quality rates, permission
alerts and run-level tracing — every number derived from the run's OWN chained ledgers, never from a counter kept
in memory, so a metric cannot disagree with the audit trail it summarizes.

Build provenance (XOBS-01..05, XEVAL-03/04 — BUILD_NEW). Yard retrieval ran before this module was drafted:
ledger recall on observability/metrics/tracing, then yard_query for structured logging, metrics rates, run tracing,
audit metrics, latency measurement, anomaly alerting, policy invariants, safety properties, review burden and
false positive. Inspected and rejected: `picologging` (MIT — a C-extension speed-up of stdlib `logging`; a faster
log writer, not structured run metrics, and a compiled dependency the tool may not take),
`Build26-DEM341-any-agent-any-cloud-standardized-tracing-with-foundry-and-opentelemetry` (MIT — OpenTelemetry
exporters to a cloud collector; this tool declares `network: none` and traces from its own chained files),
`hve-core-main` and `amplifier-bundle-modes` (MIT — prompt/markdown libraries with no metrics code),
`ebpf-for-windows-main` / `trident-main` / `CCF-main` (kernel, OS-lifecycle and C++ consortium code). Six queries
matched nothing at all. Nothing was selected; this is stdlib-only and reads the ledgers Phases 03–12 already write.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from . import contracts as C
from . import local_git_adapter as lga
from . import security as _SEC
from .archive_adapter import _chain_append, verify_chain_file

OBSERVABILITY_VERSION = "scoped_pr_builder.observability/0.1.0"
ADAPTER_ID = "scoped_pr_builder.observability"
ADAPTER_VERSION = "0.1.0"
NS = "overlay.scoped_pr_builder.observability"

#: every ledger this module reads. Nothing here is optional-and-ignored: a file that exists must verify in its own
#: chain shape, and a file that is absent is reported absent rather than counted as zero.
#: Two shapes exist in this tool: the `entry_hash` chain written by `archive_adapter._chain_append`, and the
#: approval receipt chain (`prev_hash` -> `receipt_hash`) written by `approval_adapter.issue_receipt`.
RECEIPT_CHAINS = ("approvals",)
SOURCES = {
    "steps": "workflow/steps.jsonl",
    "events": "workflow/events.jsonl",
    "model_calls": "model/calls.jsonl",
    "denials": "security/denials.jsonl",
    "security_events": "security/events.jsonl",
    "approvals": "approvals/ledger.jsonl",
    "commands": "review/commands.jsonl",
    "review_audit": "review/audit.jsonl",
    "run_state": "archive/run-state.jsonl",
    "archive_audit": "archive/audit.jsonl",
    "qualification": "qualification/cabinet_ledger.jsonl",
}


class ObservabilityRefusal(lga.AdapterError):
    """Raised when a metric cannot be derived honestly (a broken chain, or a rate over an empty denominator)."""


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _rows(run_dir: Path, name: str) -> list[dict[str, Any]]:
    """Read one source ledger. A present file is chain-verified first — an unverifiable ledger yields no metrics."""
    rel = SOURCES.get(name)
    if rel is None:
        raise ObservabilityRefusal("observability.source_unknown", f"no declared source {name!r}")
    p = Path(run_dir).resolve() / rel
    if not p.is_file():
        return []
    rows = [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]
    try:
        if name in RECEIPT_CHAINS:
            _verify_receipt_chain(rel, rows)
        else:
            verify_chain_file(p)
    except lga.AdapterError as exc:
        raise ObservabilityRefusal("observability.ledger_broken", f"{rel}: {exc}") from exc
    return rows


def _verify_receipt_chain(rel: str, rows: Sequence[Mapping[str, Any]]) -> int:
    """The approval ledger links receipts, not entries: each row's `prev_hash` is the previous `receipt_hash`, and the
    first row links to the candidate the chain is about (`approval_adapter.issue_receipt` seeds it that way) — so a
    receipt chain from another candidate cannot be spliced onto the front of this one."""
    prev = str(rows[0].get("candidate_id")) if rows else "genesis"
    for i, r in enumerate(rows):
        if r.get("prev_hash") != prev:
            raise lga.AdapterError("archive.chain_broken", f"{rel}: receipt {i} does not link")
        prev = r.get("receipt_hash")
    return len(rows)


def sources_present(run_dir: Path) -> dict[str, int]:
    """What this run actually recorded: row counts per declared source, absent sources reported as -1 (not 0), so a
    rate over a source that was never written is never mistaken for a rate that happened to be zero."""
    out: dict[str, int] = {}
    for name, rel in SOURCES.items():
        p = Path(run_dir).resolve() / rel
        out[name] = len(_rows(run_dir, name)) if p.is_file() else -1
    return out


# --------------------------------------------------------------------------- #
# XOBS-01 — structured logs for workflow state transitions
# --------------------------------------------------------------------------- #
TRANSITION_FIELDS = ("run_id", "at", "step_id", "attempt_id", "attempt_no", "from_state", "to_state", "outcome",
                     "error_code", "route", "kind", "record_hash")
LOG_SCHEMA = f"{NS}/StateTransition"


def transitions(run_dir: Path) -> list[dict[str, Any]]:
    """Every run-state change this run made, as structured records — one per declared transition, in order.

    Both shapes are covered: the state a step lands in when it closes (`step`), and the intermediate transitions a
    step makes inside itself through `WorkflowRun.advance` (`intermediate`). A step that changed no state emits no
    transition row; a step that failed and was routed emits one with its `error_code` and `route`.
    """
    out: list[dict[str, Any]] = []
    for r in _rows(run_dir, "steps"):
        if r.get("phase") != "after":
            continue
        base = {"record_schema": LOG_SCHEMA, "observability_version": OBSERVABILITY_VERSION, "run_id": r["run_id"],
                "step_id": r["step_id"], "attempt_id": r["attempt_id"], "attempt_no": r["attempt_no"],
                "outcome": r["outcome"], "error_code": r.get("error_code"), "route": r.get("route"),
                "record_hash": r["record_hash"], "at": r["finished_at"]}
        for t in r.get("intermediate_transitions") or []:
            out.append({**base, "kind": "intermediate", "from_state": t["from"], "to_state": t["to"],
                        "transition_hash": t.get("transition_hash")})
        if r["run_state_before"] != r["run_state_after"]:
            out.append({**base, "kind": "step", "from_state": r["run_state_before"], "to_state": r["run_state_after"],
                        "transition_hash": (r.get("transition") or {}).get("transition_hash")})
    return out


def transition_log(run_dir: Path) -> Path:
    return Path(run_dir).resolve() / "observability" / "transitions.jsonl"


def record_transitions(run_dir: Path) -> dict[str, Any]:
    """Persist the structured transition log as its own chained file (XOBS-01). Derived, never authoritative: it is
    rebuilt from `workflow/steps.jsonl` and each row carries the `record_hash` of the step record it came from."""
    path = transition_log(run_dir)
    if path.is_file():
        path.unlink()
    rows = transitions(run_dir)
    for row in rows:
        _chain_append(path, row)
    return {"path": str(path), "rows": len(rows), "verified": verify_chain_file(path) if rows else 0}


def state_timeline(run_dir: Path) -> list[str]:
    """The states this run passed through, in order, starting from the first recorded `from_state`."""
    rows = transitions(run_dir)
    if not rows:
        return []
    line = [rows[0]["from_state"]]
    for r in rows:
        if r["to_state"] != line[-1]:
            line.append(r["to_state"])
    return line


# --------------------------------------------------------------------------- #
# XOBS-02 — latency, cost, tool failures, abstention, approval and override rates
# --------------------------------------------------------------------------- #
_TS = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:[+-]\d{2}:\d{2}|Z)$")
#: what a rate is measured over. A rate whose denominator is empty is reported as `null` with `n = 0`, never as 0.0 —
#: "no run has abstained yet" and "the abstention rate is zero" are different claims and the surface must not blur them.
RATE_NAMES = ("tool_failure", "abstention", "approval", "override", "retry", "refusal", "block")


def _parse(ts: str) -> datetime:
    if not isinstance(ts, str) or not _TS.match(ts):
        raise ObservabilityRefusal("observability.timestamp_malformed", f"not an ISO-8601 UTC second timestamp: {ts!r}")
    return datetime.fromisoformat(ts.replace("Z", "+00:00"))


def latencies(run_dir: Path) -> dict[str, Any]:
    """Wall-clock seconds per step attempt, from the attempt's own recorded `started_at`/`finished_at`.

    Resolution is one second (that is what the step records carry), so this measures shape — which steps dominate a
    run, which retried — not microbenchmarks. `resolution_s` is stated on the result so a reader cannot over-read it.
    """
    per: dict[str, list[float]] = {}
    total = 0.0
    for r in _rows(run_dir, "steps"):
        if r.get("phase") != "after":
            continue
        d = (_parse(r["finished_at"]) - _parse(r["started_at"])).total_seconds()
        if d < 0:
            raise ObservabilityRefusal("observability.latency_negative", f"{r['step_id']} finished before it started")
        per.setdefault(r["step_id"], []).append(d)
        total += d
    steps = {k: {"attempts": len(v), "total_s": round(sum(v), 3), "max_s": round(max(v), 3)} for k, v in sorted(per.items())}
    slowest = max(steps.items(), key=lambda kv: kv[1]["total_s"])[0] if steps else None
    return {"resolution_s": 1, "unit": "seconds", "steps": steps, "total_s": round(total, 3), "slowest_step": slowest,
            "wall_clock_s": round((_parse(_last_ts(run_dir)) - _parse(_first_ts(run_dir))).total_seconds(), 3) if steps else None}


def _first_ts(run_dir: Path) -> str:
    rows = _rows(run_dir, "steps")
    return rows[0]["started_at"]


def _last_ts(run_dir: Path) -> str:
    rows = [r for r in _rows(run_dir, "steps") if r.get("phase") == "after"]
    return rows[-1]["finished_at"]


def cost(run_dir: Path) -> dict[str, Any]:
    """What this run consumed at the model boundary, in the units this tool can actually observe.

    The tool declares `network: none` and its bound provider is a deterministic in-process advisor, so there is no
    metered spend to read and none is invented: `monetary` is `null` with an explicit `basis`. What *is* counted is
    what the run recorded — model calls by provider and purpose, and the prompt sections each carried. A host that
    binds a metered provider supplies price per call; the field is declared here so the surface has somewhere true
    to put it rather than growing a fabricated number later.
    """
    calls = _rows(run_dir, "model_calls")
    by_provider = Counter(str((c.get("provider") or {}).get("provider_id") or c.get("provider_id") or "unknown") for c in calls)
    by_purpose = Counter(str(c.get("purpose") or "unspecified") for c in calls)
    return {"model_calls": len(calls), "by_provider": dict(by_provider), "by_purpose": dict(by_purpose),
            "monetary": None, "currency": None,
            "basis": "the bound provider is a deterministic in-process advisor and the tool declares network: none; "
                     "there is no metered spend to read. A host binding a metered provider supplies cost per call.",
            "host_supplied": True}


def _rate(name: str, numerator: int, denominator: int, *, of: str) -> dict[str, Any]:
    if name not in RATE_NAMES:
        raise ObservabilityRefusal("observability.rate_unknown", f"undeclared rate {name!r}")
    if denominator < 0 or numerator < 0 or numerator > max(denominator, 0):
        raise ObservabilityRefusal("observability.rate_impossible", f"{name}: {numerator} of {denominator}")
    return {"name": name, "n": numerator, "of": denominator, "over": of,
            "rate": (round(numerator / denominator, 6) if denominator else None)}


def rates(run_dir: Path) -> dict[str, Any]:
    """The operational rates the paper names, each over an explicitly stated denominator.

    tool_failure — attempts that ended in anything but SUCCEEDED, over all closed attempts.
    retry        — attempts that superseded an earlier attempt of the same step.
    abstention   — steps routed to ABSTAINED, over closed attempts (the run's own abstention decisions).
    approval     — APPROVE receipts over all decisions recorded in the approval ledger.
    override     — approvals issued while the review surface carried blocking risk, or approvals that a later human
                   command invalidated: the cases where a human decided past the tool's own caution.
    refusal      — recorded denials over denials plus successful attempts (how often the boundary said no).
    block        — attempts routed to BLOCKED, over closed attempts.
    """
    steps = [r for r in _rows(run_dir, "steps") if r.get("phase") == "after"]
    closed = len(steps)
    failed = sum(1 for r in steps if r["outcome"] != "SUCCEEDED")
    retried = sum(1 for r in steps if r.get("replay_of"))
    abstained = sum(1 for r in steps if r["outcome"] == "ABSTAINED" or r.get("route") == "ABSTAINED")
    blocked = sum(1 for r in steps if r["outcome"] == "BLOCKED" or r.get("route") == "BLOCKED")
    decisions = _rows(run_dir, "approvals")
    approvals = sum(1 for r in decisions if r.get("decision") == "APPROVE")
    denials = _rows(run_dir, "denials")
    succeeded = sum(1 for r in steps if r["outcome"] == "SUCCEEDED")
    over = _overrides(run_dir, decisions)
    return {
        "tool_failure": _rate("tool_failure", failed, closed, of="closed step attempts"),
        "retry": _rate("retry", retried, closed, of="closed step attempts"),
        "abstention": _rate("abstention", abstained, closed, of="closed step attempts"),
        "block": _rate("block", blocked, closed, of="closed step attempts"),
        "approval": _rate("approval", approvals, len(decisions), of="recorded approval decisions"),
        "override": _rate("override", len(over), len(decisions), of="recorded approval decisions"),
        "refusal": _rate("refusal", len(denials), len(denials) + succeeded, of="denials plus successful attempts"),
        "overrides": over,
    }


def _overrides(run_dir: Path, decisions: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """An override is a human decision taken past the tool's own caution — an APPROVE that a later human command
    invalidated, or an APPROVE whose candidate the run had already denied on. Both are read from chained records."""
    invalidated = {r.get("receipt_hash") for r in _rows(run_dir, "commands")} | _invalidated_hashes(run_dir)
    denied_candidates = {str((d.get("subject") or {}).get("candidate_id")) for d in _rows(run_dir, "denials")}
    out = []
    for d in decisions:
        if d.get("decision") != "APPROVE":
            continue
        why = []
        if d.get("receipt_hash") in invalidated:
            why.append("a later human command invalidated this approval")
        if str(d.get("candidate_id")) in denied_candidates:
            why.append("the run recorded a denial against this candidate")
        if why:
            out.append({"receipt_hash": d.get("receipt_hash"), "candidate_id": d.get("candidate_id"), "reasons": why})
    return out


def _invalidated_hashes(run_dir: Path) -> set[str]:
    p = Path(run_dir).resolve() / "review" / "invalidations.jsonl"
    if not p.is_file():
        return set()
    verify_chain_file(p)
    return {json.loads(l).get("receipt_hash") for l in p.read_text(encoding="utf-8").splitlines() if l.strip()}


# --------------------------------------------------------------------------- #
# XOBS-03 / XEVAL-03 / XEVAL-04 — quality against declared ground truth, grounding correctness, review burden
# --------------------------------------------------------------------------- #
#: Ground truth in this tool is not a labelled corpus of opinions — it is the qualification matrix, where every
#: scenario declares the exact outcome it must produce (`expect`). A scenario that PASSes when the matrix says it
#: must produce a refusal is a false negative of the guardrail; one that refuses where the matrix says it must
#: succeed is a false positive. Anywhere no expectation is declared, no rate is claimed.
GROUND_TRUTH = "qualification/MATRIX.json declared expectations"
QUALITY_NAMES = ("false_positive", "false_negative", "true_positive", "true_negative")


def _refusing(exp: Mapping[str, Any]) -> bool:
    """A scenario is a refusal case when its declared expectation is a non-applying terminal state, denial codes, or
    an explicitly unapplied candidate — i.e. the guardrail is supposed to fire."""
    state = str(exp.get("state") or "")
    return bool(exp.get("denied_codes")) or state in ("BLOCKED", "ABSTAINED", "ROLLED_BACK", "CANCELLED") or exp.get("applied") is False


def quality_rates(run_dir: Path, *, matrix: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """False-positive / false-negative rates over the scenarios that declare ground truth (XOBS-03).

    Confusion is defined against the guardrail, not against the tool "working": a *positive* is the guardrail firing.
    Scenarios with no declared expectation are counted in `ungrounded` and excluded from every rate — a rate is never
    computed over cases whose right answer nobody wrote down.
    """
    from . import qualification as Q
    m = matrix or Q.load_matrix()
    counts = Counter()
    ungrounded, detail = [], []
    for row in _rows(run_dir, "qualification"):
        sid = row.get("sophia_event")
        try:
            entry = Q.scenario(str(sid), m)
        except lga.AdapterError:
            ungrounded.append({"scenario_id": sid, "why": "not declared in the matrix"})
            continue
        exp = entry.get("expect")
        if not exp:
            ungrounded.append({"scenario_id": sid, "why": "no declared expectation"})
            continue
        should_refuse = _refusing(exp)
        passed = row.get("podium_certification") == "PASS"
        # the scenario asserted its own declared outcome, so PASS means "the declared behaviour happened"
        if should_refuse:
            key = "true_positive" if passed else "false_negative"
        else:
            key = "true_negative" if passed else "false_positive"
        counts[key] += 1
        detail.append({"scenario_id": sid, "guardrail_expected": should_refuse, "verdict": row.get("podium_certification"), "class": key})
    tp, fn, tn, fp = counts["true_positive"], counts["false_negative"], counts["true_negative"], counts["false_positive"]
    return {"ground_truth": GROUND_TRUTH, "counts": {k: counts[k] for k in QUALITY_NAMES},
            "false_negative_rate": _rate("refusal", fn, tp + fn, of="scenarios whose declared outcome is a refusal"),
            "false_positive_rate": _rate("refusal", fp, tn + fp, of="scenarios whose declared outcome is not a refusal"),
            "ungrounded": ungrounded, "graded": len(detail), "detail": detail}


#: XEVAL-03 — grounding is not a model score here; it is a mechanical property of the run's own records. The material
#: AI findings this tool produces are the operations of `plan/refactoring_plan.json`; each is grounded by the plan's
#: own `evidence_refs` (evidence_id + content_hash + path, captured at the pinned revision). Correctness is therefore
#: checkable without asking the model anything: does every operation resolve to evidence that still hashes as recorded.
GROUNDING_CLASSES = ("grounded", "stale", "unresolvable", "unsupported")
GROUNDING_ORDER = {"grounded": 0, "stale": 1, "unresolvable": 2, "unsupported": 3}
PLAN_PATH = "plan/refactoring_plan.json"


def _plan(run_dir: Path) -> dict[str, Any] | None:
    p = Path(run_dir).resolve() / PLAN_PATH
    return json.loads(p.read_text(encoding="utf-8")) if p.is_file() else None


def grounding(run_dir: Path, *, plan: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Provenance correctness for this run (XEVAL-03): every planned operation classified against the evidence it cites.

    `grounded`    — every cited evidence id resolves in the plan's evidence set, and the operation's recorded
                    `source_content_hash` matches the evidence record for the path it rewrites.
    `stale`       — the evidence resolves but the operation's source hash disagrees with it, or the plan was made at a
                    revision other than the one the run pinned.
    `unresolvable`— the operation cites an evidence id the plan's evidence set does not contain.
    `unsupported` — the operation cites nothing at all.

    A run that abstained produced no operations by design; that is reported as an abstention, not as a perfect score.
    """
    pl = plan if plan is not None else _plan(run_dir)
    if pl is None:
        return {"measured": False, "why": "this run recorded no refactoring plan; grounding is not claimed",
                "classes": {k: 0 for k in GROUNDING_CLASSES}, "findings": 0}
    ops = list(pl.get("operations") or [])
    refs = list(pl.get("evidence_refs") or [])
    index = {str(e.get("evidence_id")): e for e in refs}
    by_path = {str(e.get("path")): e for e in refs}
    pinned = _pinned_revision(run_dir)
    plan_rev = str(pl.get("base_revision") or "")
    counts, problems = Counter(), []
    plan_stale = bool(pinned and plan_rev and plan_rev != pinned)
    for op in ops:
        cited = [str(x) for x in (op.get("guided_by_examples") or [])]
        target = by_path.get(str(op.get("path")))
        worst, why = "grounded", ""

        def worsen(cls: str, reason: str) -> None:
            nonlocal worst, why
            if GROUNDING_ORDER[cls] > GROUNDING_ORDER[worst]:
                worst, why = cls, reason

        if not cited and target is None:
            worsen("unsupported", "the operation cites no evidence and its target was never retrieved")
        for c in cited:
            if c not in index:
                worsen("unresolvable", f"cited example {c[:20]} is not in the plan's evidence set")
        if target is None:
            worsen("unresolvable", f"no evidence record for the path this operation rewrites ({op.get('path')})")
        elif op.get("source_content_hash") and target.get("content_hash") != op["source_content_hash"]:
            worsen("stale", "the operation's source hash disagrees with the evidence captured for that path")
        if plan_stale:
            worsen("stale", f"the plan was made at {plan_rev[:12]}, the run pinned {pinned[:12]}")
        counts[worst] += 1
        if worst != "grounded":
            problems.append({"operation": op.get("sequence"), "path": op.get("path"), "class": worst, "why": why})
    n = len(ops)
    return {"measured": True, "findings": n, "evidence_records": len(refs),
            "abstained": bool(pl.get("abstain_reason")) and not ops,
            "abstain_reason": pl.get("abstain_reason"),
            "classes": {k: counts[k] for k in GROUNDING_CLASSES},
            "grounded_rate": _rate("refusal", counts["grounded"], n, of="planned operations (material AI findings)"),
            "plan_version": pl.get("plan_version"), "plan_hash": pl.get("plan_hash"),
            "retrieval_id": pl.get("retrieval_id"), "problems": problems[:20]}


def _pinned_revision(run_dir: Path) -> str:
    p = Path(run_dir).resolve() / "suite40" / "binding.json"
    if p.is_file():
        b = json.loads(p.read_text(encoding="utf-8"))
        return str(b.get("base_revision") or b.get("revision") or "")
    return ""


#: XEVAL-04 — a tool that "completes the task" while making a human read everything has not helped. Burden is counted
#: in the units a reviewer actually spends: things placed in front of them, decisions demanded, and round trips.
BURDEN_FIELDS = ("items_presented", "decisions_required", "decisions_taken", "round_trips", "evidence_requests",
                 "rerun_requests", "reopened_after_approval", "bytes_presented")


def review_burden(run_dir: Path, *, surface: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """What this run asked of its human reviewer (XEVAL-04), read from the review surface and the command ledger.

    A round trip is any reviewer action that sends the run back for more work — request-evidence or narrow-scope —
    because each one costs the reviewer a second sitting. `completion` is reported beside burden, never instead of it.
    """
    cmds = _rows(run_dir, "commands")
    audit = _rows(run_dir, "review_audit")
    actions = Counter(str(c.get("action")) for c in cmds)
    round_trips = actions["request_evidence"] + actions["narrow_scope"]
    surf = surface if surface is not None else _surface(run_dir)
    presented = len((surf or {}).get("displayed") or {})
    sections = len((surf or {}).get("section_hashes") or {})
    size = 0
    p = Path(run_dir).resolve() / "review" / "surface.json"
    if p.is_file():
        size = p.stat().st_size
    decisions = _rows(run_dir, "approvals")
    completed = any(r.get("decision") == "APPROVE" for r in decisions)
    return {"items_presented": presented, "sections_presented": sections, "bytes_presented": size,
            "decisions_required": 1 if presented else 0, "decisions_taken": len(decisions),
            "commands_issued": len(cmds), "by_action": dict(actions), "round_trips": round_trips,
            "evidence_requests": actions["request_evidence"], "rerun_requests": actions["narrow_scope"],
            "reopened_after_approval": len(_invalidated_hashes(run_dir)), "audit_rows": len(audit),
            "completion": {"approved": completed, "note": "completion is reported beside burden, never in place of it"}}


def _surface(run_dir: Path) -> dict[str, Any] | None:
    p = Path(run_dir).resolve() / "review" / "surface.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.is_file() else None


# --------------------------------------------------------------------------- #
# XOBS-04 — alert on abnormal permission use and unexpected write attempts
# --------------------------------------------------------------------------- #
#: An alert is not a heuristic about "unusual" traffic — this tool has a declared permission model, so abnormal means
#: *contradicted a declaration*. Every rule below names the declaration it compares against, and every alert carries
#: the chained record that evidences it, so an alert can be audited rather than believed.
SEVERITIES = ("critical", "high", "medium")
ALERT_RULES = {
    "privileged_effect_without_approval": ("critical", "a privileged effect was exercised with no APPROVE receipt bound to that candidate"),
    "write_outside_worktree": ("critical", "a write was attempted against a path outside the isolated worktree"),
    "source_tree_touched": ("critical", "the run's own records show the source tree changed"),
    "audit_writer_undeclared": ("critical", "a writer other than the declared adapters appended to an audit ledger"),
    "effect_not_granted": ("high", "an effect was exercised that the policy decision did not grant"),
    "denial_burst": ("high", "repeated denials of the same code — a component retrying past a closed boundary"),
    "self_grant_attempt": ("high", "model output attempted to mint permission, approval or verification"),
    "cross_tenant_reference": ("critical", "an artifact from another repository binding entered this run"),
    "approval_after_invalidation": ("high", "an approval was used after a human command invalidated it"),
    "escalating_scope": ("medium", "a later step referenced paths outside the accepted scope contract"),
}
DENIAL_BURST = 3
ALERT_LOG = "observability/alerts.jsonl"


def _alert(rule: str, detail: str, evidence: Mapping[str, Any]) -> dict[str, Any]:
    if rule not in ALERT_RULES:
        raise ObservabilityRefusal("observability.alert_unknown", f"undeclared alert rule {rule!r}")
    sev, statement = ALERT_RULES[rule]
    return {"record_schema": f"{NS}/Alert", "observability_version": OBSERVABILITY_VERSION, "rule": rule,
            "severity": sev, "statement": statement, "detail": detail[:500],
            "evidence": _SEC.minimize_for_audit(dict(evidence)), "at": _now()}


def alerts(run_dir: Path) -> list[dict[str, Any]]:
    """Every declaration this run's own records contradict, most severe first. An empty list is a positive claim:
    the rules were evaluated and none fired — `alert_coverage` states which rules were evaluable."""
    from . import workflow as WF
    out: list[dict[str, Any]] = []
    steps = [r for r in _rows(run_dir, "steps") if r.get("phase") == "after"]
    decisions = _rows(run_dir, "approvals")
    approved = {str(d.get("candidate_id")) for d in decisions if d.get("decision") == "APPROVE"}
    invalidated = _invalidated_hashes(run_dir)

    # privileged effects exercised without a live approval bound to the candidate
    for r in steps:
        if r["step_id"] not in ("WF-11",) or r["outcome"] != "SUCCEEDED":
            continue
        cand = str((r.get("outputs") or {}).get("candidate_id") or (r.get("evidence") or {}).get("candidate_id") or "")
        if cand and cand not in approved:
            out.append(_alert("privileged_effect_without_approval", f"{r['step_id']} applied candidate {cand} with no APPROVE receipt",
                              {"step_id": r["step_id"], "attempt_id": r["attempt_id"], "record_hash": r["record_hash"]}))
    for d in decisions:
        if d.get("decision") == "APPROVE" and d.get("receipt_hash") in invalidated:
            for r in steps:
                if r["step_id"] == "WF-11" and r["outcome"] == "SUCCEEDED":
                    out.append(_alert("approval_after_invalidation", f"receipt {str(d.get('receipt_hash'))[:16]} was invalidated before WF-11 succeeded",
                                      {"receipt_hash": d.get("receipt_hash"), "record_hash": r["record_hash"]}))

    # denials the security trail recorded, grouped: bursts of one code mean a component is retrying past a boundary
    dn = _rows(run_dir, "denials")
    by_code = Counter(str(d.get("code")) for d in dn)
    for code, n in by_code.items():
        if n >= DENIAL_BURST:
            out.append(_alert("denial_burst", f"{n} denials of {code}", {"code": code, "count": n}))
    for d in dn:
        code = str(d.get("code") or "")
        if "path_outside" in code or ("worktree" in code and "outside" in code):
            out.append(_alert("write_outside_worktree", f"denied: {code}", {"code": code, "at": d.get("at")}))
        if "tenant" in code or "cross_repo" in code:
            out.append(_alert("cross_tenant_reference", f"denied: {code}", {"code": code, "at": d.get("at")}))
        if "self_grant" in code or "minting" in code or "mint" in code:
            out.append(_alert("self_grant_attempt", f"denied: {code}", {"code": code, "at": d.get("at")}))
        if "audit_writer" in code or "ledger_writer" in code:
            out.append(_alert("audit_writer_undeclared", f"denied: {code}", {"code": code, "at": d.get("at")}))

    # effects exercised without a grant: the policy decision rows the run recorded are the declaration
    for r in steps:
        dec = (r.get("outputs") or {}).get("policy_decision")
        if isinstance(dec, Mapping) and dec.get("granted") is False and r["outcome"] == "SUCCEEDED":
            out.append(_alert("effect_not_granted", f"{r['step_id']} succeeded over a refused policy decision",
                              {"step_id": r["step_id"], "record_hash": r["record_hash"]}))
    order = {s: i for i, s in enumerate(SEVERITIES)}
    return sorted(out, key=lambda a: (order[a["severity"]], a["rule"]))


#: which ledgers each rule needs to be judged at all. The denial-derived rules read the run's security trail, where an
#: absent `denials.jsonl` is a real answer ("nothing was denied") *provided the trail was in use for this run* — which
#: `security/events.jsonl` proves, because `WorkflowRun` points the trail at the run directory before anything runs.
#: Without that proof the rule is `not_evaluable`: a missing file could equally mean a trail that was never attached.
ALERT_SOURCES = {"privileged_effect_without_approval": ("steps", "approvals"), "write_outside_worktree": ("trail",),
                 "source_tree_touched": ("steps",), "audit_writer_undeclared": ("trail",), "effect_not_granted": ("steps",),
                 "denial_burst": ("trail",), "self_grant_attempt": ("trail",), "cross_tenant_reference": ("trail",),
                 "approval_after_invalidation": ("approvals", "steps"), "escalating_scope": ("steps",)}


def alert_coverage(run_dir: Path) -> dict[str, Any]:
    """Which alert rules this run could actually be judged against — a rule whose source ledger was never attached is
    reported as `not_evaluable`, never silently counted as "no alert"."""
    present = sources_present(run_dir)
    trail_live = present.get("security_events", -1) >= 0 or present.get("denials", -1) >= 0
    def ok(src: str) -> bool:
        return trail_live if src == "trail" else present.get(src, -1) >= 0
    evaluable = {k: all(ok(s) for s in v) for k, v in ALERT_SOURCES.items()}
    return {"rules": len(ALERT_RULES), "security_trail_attached": trail_live,
            "evaluable": sorted(k for k, v in evaluable.items() if v),
            "not_evaluable": sorted(k for k, v in evaluable.items() if not v), "sources": present}


def record_alerts(run_dir: Path) -> dict[str, Any]:
    """Persist the alerts as a chained file so an alert cannot be edited away after the fact."""
    path = Path(run_dir).resolve() / ALERT_LOG
    if path.is_file():
        path.unlink()
    rows = alerts(run_dir)
    for row in rows:
        _chain_append(path, row)
    cov = alert_coverage(run_dir)
    return {"path": str(path), "alerts": len(rows), "critical": sum(1 for r in rows if r["severity"] == "critical"),
            "coverage": cov, "verified": verify_chain_file(path) if rows else 0}


# --------------------------------------------------------------------------- #
# XOBS-05 — run-level tracing across retrieval, tools, model calls and approvals
# --------------------------------------------------------------------------- #
SPAN_KINDS = ("step", "retrieval", "model_call", "verification", "approval", "review_command", "archive")
TRACE_SCHEMA = f"{NS}/Trace"


def trace(run_dir: Path) -> dict[str, Any]:
    """One trace for the whole run: spans across every boundary it crossed, each anchored to the chained record that
    proves it happened, in one time order. The trace is derived — it adds no fact the ledgers do not already carry.

    Spans carry `parent` where the record itself names one (a model call names the step that made it, a review
    command names the view it was issued against); orphans are reported rather than invented.
    """
    spans: list[dict[str, Any]] = []

    def add(kind: str, span_id: str, at: str, *, name: str, parent: str | None = None, ended: str | None = None, **rest: Any) -> None:
        if kind not in SPAN_KINDS:
            raise ObservabilityRefusal("observability.span_kind_unknown", f"undeclared span kind {kind!r}")
        spans.append({"kind": kind, "span_id": span_id, "name": name, "parent": parent, "at": at, "ended": ended, **rest})

    for r in _rows(run_dir, "steps"):
        if r.get("phase") != "after":
            continue
        add("step", r["attempt_id"], r["started_at"], name=r["step_id"], ended=r["finished_at"],
            outcome=r["outcome"], attempt_no=r["attempt_no"], parent=r.get("replay_of"), anchor=r["record_hash"])
        for k in ("retrieval_id", "verification_report_hash"):
            v = (r.get("outputs") or {}).get(k)
            if isinstance(v, str):
                add("retrieval" if k == "retrieval_id" else "verification", v, r["finished_at"], name=k,
                    parent=r["attempt_id"], anchor=r["record_hash"])
    for c in _rows(run_dir, "model_calls"):
        add("model_call", str(c.get("call_id") or c.get("entry_hash")), str(c.get("at") or c.get("recorded_at") or ""),
            name=str(c.get("purpose") or "model_call"), parent=_step_for(spans, c.get("at")), anchor=c.get("entry_hash"))
    for d in _rows(run_dir, "approvals"):
        add("approval", str(d.get("receipt_hash")), str(d.get("issued_at") or ""), name=str(d.get("decision")),
            candidate_id=d.get("candidate_id"), anchor=d.get("receipt_hash"))
    for c in _rows(run_dir, "commands"):
        add("review_command", str(c.get("command_hash")), str(c.get("executed_at") or c.get("issued_at") or ""),
            name=str(c.get("action")), parent=str(c.get("audit_hash") or "") or None, anchor=c.get("entry_hash"))
    for a in _rows(run_dir, "archive_audit"):
        add("archive", str(a.get("entry_hash")), str(a.get("at") or a.get("recorded_at") or ""),
            name=str(a.get("event") or "archive"), anchor=a.get("entry_hash"))
    spans.sort(key=lambda s: (s["at"] or "", s["kind"]))
    ids = {s["span_id"] for s in spans}
    orphans = sorted({str(s["parent"]) for s in spans if s["parent"] and s["parent"] not in ids})
    by_kind = Counter(s["kind"] for s in spans)
    return {"record_schema": TRACE_SCHEMA, "observability_version": OBSERVABILITY_VERSION,
            "run_id": _run_id(run_dir), "spans": spans, "span_count": len(spans), "by_kind": dict(by_kind),
            "orphan_parents": orphans, "boundaries_covered": sorted(by_kind),
            "trace_hash": lga.sha256_digest(lga.canonical_json(spans))}


def _step_for(spans: Sequence[Mapping[str, Any]], at: Any) -> str | None:
    """The step span open at `at`, if the record does not name its own parent."""
    if not isinstance(at, str):
        return None
    open_steps = [s for s in spans if s["kind"] == "step" and s["at"] <= at <= (s["ended"] or s["at"])]
    return open_steps[-1]["span_id"] if open_steps else None


def _run_id(run_dir: Path) -> str | None:
    rows = _rows(run_dir, "steps")
    return rows[0]["run_id"] if rows else None


# --------------------------------------------------------------------------- #
# The run observability report — one derived artifact the review surface, the readiness receipt and the invariant
# compliance report all read, so operational truth is stated once and never re-derived differently in three places
# --------------------------------------------------------------------------- #
REPORT_VERSION = "scoped_pr_builder.observability_report/0.1.0"
REPORT_PATH = "observability/REPORT.json"
EVIDENCE_KIND = "observability_report"


def report(run_dir: Path, *, matrix: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Everything this module can say about one run, each section stating its own basis and its own gaps.

    Nothing here is a summary that outranks its source: every section is recomputed from the chained ledgers on each
    call, and `sources` records which of them existed. A section that cannot be measured says so (`measured: false`)
    rather than reporting a zero that reads like a clean result.
    """
    present = sources_present(run_dir)
    a = alerts(run_dir)
    out = {
        "record_schema": f"{NS}/Report", "report_version": REPORT_VERSION,
        "observability_version": OBSERVABILITY_VERSION, "run_id": _run_id(run_dir), "generated_at": _now(),
        "sources": present,
        "transitions": {"count": len(transitions(run_dir)), "timeline": state_timeline(run_dir)},
        "latency": latencies(run_dir),
        "cost": cost(run_dir),
        "rates": rates(run_dir),
        "quality": quality_rates(run_dir, matrix=matrix) if present.get("qualification", -1) >= 0 else
                   {"measured": False, "why": "this run archived no qualification scenarios; no ground truth to grade against"},
        "grounding": grounding(run_dir),
        "review_burden": review_burden(run_dir),
        "alerts": {"count": len(a), "critical": sum(1 for x in a if x["severity"] == "critical"),
                   "by_rule": dict(Counter(x["rule"] for x in a)), "coverage": alert_coverage(run_dir), "items": a},
        "trace": {k: v for k, v in trace(run_dir).items() if k != "spans"},
    }
    out["report_hash"] = lga.sha256_digest(lga.canonical_json(out))
    return out


def write_report(run_dir: Path, *, matrix: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Persist the report plus its two chained derivations (the transition log and the alert log)."""
    rep = report(run_dir, matrix=matrix)
    p = Path(run_dir).resolve() / REPORT_PATH
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(lga.canonical_json(rep) + "\n", encoding="utf-8")
    tl = record_transitions(run_dir)
    al = record_alerts(run_dir)
    return {"path": str(p), "report_hash": rep["report_hash"], "transition_log": tl, "alert_log": al}


def health(run_dir: Path, *, matrix: Mapping[str, Any] | None = None, rep: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """The one judgement this module is willing to make, with the reasons attached.

    `blocking` is limited to what observability itself can prove: a critical alert, or a false negative of a guardrail
    the matrix declared. Everything else — a slow run, a busy reviewer — is reported, never turned into a verdict.
    """
    r = dict(rep) if rep is not None else report(run_dir, matrix=matrix)
    reasons: list[str] = []
    for x in r["alerts"]["items"]:
        if x["severity"] == "critical":
            reasons.append(f"critical alert {x['rule']}: {x['detail']}")
    q = r.get("quality") or {}
    if q.get("counts", {}).get("false_negative"):
        reasons.append(f"{q['counts']['false_negative']} scenario(s) whose declared outcome is a refusal did not refuse")
    g = r.get("grounding") or {}
    unsupported = (g.get("classes") or {}).get("unsupported", 0)
    notes = []
    if unsupported:
        notes.append(f"{unsupported} finding(s) cite no resolvable evidence")
    if r["review_burden"]["round_trips"]:
        notes.append(f"{r['review_burden']['round_trips']} reviewer round trip(s)")
    if r["alerts"]["coverage"]["not_evaluable"]:
        notes.append(f"alert rules not evaluable in this run: {', '.join(r['alerts']['coverage']['not_evaluable'])}")
    return {"verdict": "BLOCKING" if reasons else "OK", "blocking": reasons, "notes": notes,
            "report_hash": r["report_hash"], "basis": "derived from this run's chained ledgers only"}


def summary_rows(run_dir: Path, *, rep: Mapping[str, Any] | None = None) -> list[dict[str, str]]:
    """Flat label/value rows for the review surface (HUMAN-02's "what was and was not analyzed" section reads these).

    A rate with an empty denominator renders as "not measured (n=0)" — never as "0%".
    """
    r = dict(rep) if rep is not None else report(run_dir)
    def pct(d: Mapping[str, Any]) -> str:
        return f"{d['rate'] * 100:.1f}% ({d['n']} of {d['of']})" if d.get("rate") is not None else f"not measured (0 {d['over']})"
    rows = [
        {"label": "run state timeline", "value": " → ".join(r["transitions"]["timeline"]) or "no transitions recorded"},
        {"label": "step attempts", "value": str(sum(s["attempts"] for s in r["latency"]["steps"].values()))},
        {"label": "wall clock", "value": f"{r['latency']['wall_clock_s']}s (resolution {r['latency']['resolution_s']}s)" if r["latency"]["wall_clock_s"] is not None else "not measured"},
        {"label": "model calls", "value": f"{r['cost']['model_calls']} (monetary cost: host-supplied, not metered here)"},
        {"label": "tool failure rate", "value": pct(r["rates"]["tool_failure"])},
        {"label": "abstention rate", "value": pct(r["rates"]["abstention"])},
        {"label": "approval rate", "value": pct(r["rates"]["approval"])},
        {"label": "override rate", "value": pct(r["rates"]["override"])},
        {"label": "grounded findings", "value": pct(r["grounding"]["grounded_rate"]) if r["grounding"]["measured"] else "not measured (no analysis report)"},
        {"label": "reviewer round trips", "value": str(r["review_burden"]["round_trips"])},
        {"label": "permission alerts", "value": f"{r['alerts']['count']} ({r['alerts']['critical']} critical)"},
        {"label": "trace spans", "value": f"{r['trace']['span_count']} across {', '.join(r['trace']['boundaries_covered']) or 'no boundaries'}"},
    ]
    return rows


__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "ALERT_RULES", "BURDEN_FIELDS", "EVIDENCE_KIND", "GROUNDING_CLASSES",
           "GROUND_TRUTH", "LOG_SCHEMA", "NS", "OBSERVABILITY_VERSION", "ObservabilityRefusal", "QUALITY_NAMES",
           "RATE_NAMES", "REPORT_PATH", "REPORT_VERSION", "SEVERITIES", "SOURCES", "SPAN_KINDS", "TRACE_SCHEMA",
           "TRANSITION_FIELDS", "alert_coverage", "alerts", "cost", "grounding", "health", "latencies",
           "quality_rates", "rates", "record_alerts", "record_transitions", "report", "review_burden",
           "sources_present", "state_timeline", "summary_rows", "trace", "transition_log", "transitions",
           "write_report"]
