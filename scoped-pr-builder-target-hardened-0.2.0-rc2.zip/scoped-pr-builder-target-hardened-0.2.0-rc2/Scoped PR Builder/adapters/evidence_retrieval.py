"""Scoped PR Builder — Suite 51 / Funnel evidence retrieval and refactoring plan (SLICE-04).

Retrieves *analogous local examples* for a scope contract from the pinned revision only,
funnels them into a deduplicated working set, and derives a deterministic refactoring
plan. Everything here is lexical and rule-based: no model is consulted, and the plan is
explicitly ``advisory_only`` — it cannot mint permissions, approvals, or evidence.

Records mirror the authoritative suites:
  51.1 ExactLocalEvidenceRecord  -> ``evidence`` (target_source + analogous_example)
  51.4 EvidenceAuthorityRecord   -> ``authority`` (repository evidence is authoritative)
  09   Funnel                    -> dedup keys / recall metrics on each evidence record

Donor provenance: the BM25 ranking core (``BM25.fit`` / ``BM25.score`` and the idf
formula) is ADAPTED from AzureSearch-MRC ``MRC/bm25.py`` (MIT, Microsoft, HEAD
25886cf2241a73e23d5d68ab66ddc6dfff09b222). Adaptation: code-aware tokenizer instead of
whitespace+stopwords, scores computed per document id, deterministic tie-breaking by
path, no logging/main. See ``../THIRD-PARTY-NOTICES.md`` and ``../PROVENANCE.jsonl``.
"""
from __future__ import annotations

import math
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Sequence

from . import local_git_adapter as lga
from . import security as _SEC

ADAPTER_ID = "scoped_pr_builder.evidence_retrieval"
ADAPTER_VERSION = "0.1.0"
PLAN_VERSION = "scoped_pr_builder.refactoring_plan/0.1.0"
DEFAULT_TOP_K = 8
DEFAULT_MAX_BYTES = 256 * 1024
MIN_EXAMPLES_FOR_SUFFICIENCY = 1
GUARDED = (PurePosixPath("Scoped PR Builder/PROVENANCE.jsonl"), PurePosixPath("Scoped PR Builder/THIRD-PARTY-NOTICES.md"))

_TOKEN_RE = re.compile(r"[A-Za-z][a-z]+|[A-Z]+(?![a-z])|[0-9]+|[a-z]+")


def tokenize(text: str) -> list[str]:
    """Deterministic code-aware tokenizer: splits paths, snake_case and camelCase; lowercases."""
    out = []
    for raw in re.split(r"[^A-Za-z0-9]+", text):
        if not raw:
            continue
        for part in _TOKEN_RE.findall(raw):
            if len(part) >= 2:
                out.append(part.lower())
    return out


class BM25:
    """Best Match 25 (adapted from AzureSearch-MRC MRC/bm25.py, MIT)."""

    def __init__(self, k1: float = 1.5, b: float = 0.75) -> None:
        self.k1 = k1
        self.b = b
        self.tf_: list[dict[str, int]] = []
        self.idf_: dict[str, float] = {}
        self.doc_len_: list[int] = []
        self.avg_doc_len_ = 0.0

    def fit(self, corpus: Sequence[Sequence[str]]) -> "BM25":
        tf: list[dict[str, int]] = []
        df: dict[str, int] = {}
        doc_len: list[int] = []
        for document in corpus:
            doc_len.append(len(document))
            frequencies: dict[str, int] = {}
            for term in document:
                frequencies[term] = frequencies.get(term, 0) + 1
            tf.append(frequencies)
            for term in frequencies:
                df[term] = df.get(term, 0) + 1
        n = len(corpus)
        self.idf_ = {term: math.log(1 + (n - freq + 0.5) / (freq + 0.5)) for term, freq in df.items()}
        self.tf_ = tf
        self.doc_len_ = doc_len
        self.avg_doc_len_ = (sum(doc_len) / n) if n else 0.0
        return self

    def score(self, query: Sequence[str], index: int) -> float:
        frequencies = self.tf_[index]
        doc_len = self.doc_len_[index]
        total = 0.0
        for term in query:
            freq = frequencies.get(term)
            if not freq:
                continue
            numerator = self.idf_[term] * freq * (self.k1 + 1)
            denominator = freq + self.k1 * (1 - self.b + self.b * doc_len / self.avg_doc_len_)
            total += numerator / denominator
        return total


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _receipt(payload: Mapping[str, Any]) -> str:
    return lga.sha256_digest(lga.canonical_json(dict(payload)))


@dataclass(frozen=True)
class EvidenceBundle:
    adapter_id: str
    adapter_version: str
    retrieval_id: str
    repository_id: str
    worktree_id: str
    base_revision: str
    source_snapshot_hash: str
    scope_contract_hash: str
    query_tokens_digest: str
    corpus_size: int
    evidence: list[dict[str, Any]] = field(default_factory=list)
    authority: dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> str:
        return lga.canonical_json(asdict(self))


def _is_binary(blob: bytes) -> bool:
    return b"\x00" in blob[:8192]


def retrieve_examples(
    binding: lga.RepositoryBinding,
    contract: Mapping[str, Any],
    *,
    top_k: int = DEFAULT_TOP_K,
    max_bytes: int = DEFAULT_MAX_BYTES,
    intake: Mapping[str, Mapping[str, Any]] | None = None,
) -> EvidenceBundle:
    """Retrieve target sources and analogous examples for ``contract`` from the pinned tree."""
    root = Path(binding.root_path)
    if contract.get("base_revision") != binding.base_revision or contract.get("repository_id") != binding.repository_id:
        _SEC.record_denial("SEC-04", "security.sec04.foreign_repository" if contract.get("repository_id") != binding.repository_id else "security.sec04.foreign_revision", "scope contract is bound to another repository/revision", subject={"scope_contract_hash": contract.get("scope_contract_hash")})  # SEC-04-T02
        raise lga.AdapterError("retrieval.binding_mismatch", "scope contract is not bound to this repository/revision")
    if intake is not None:
        # DATA-*-T04: retrieval over the source tree proceeds only from an ADMITTED intake record; STALE/DENIED/missing
        # records refuse (abstain), review states are surfaced on the card — a non-admitted source is never inferred over.
        from . import intake as _I
        _I.require_admitted(intake, ["DATA-01"])
    allowed = tuple(PurePosixPath(p) for p in contract["allowed_paths"])
    forbidden = tuple(PurePosixPath(p) for p in contract.get("forbidden_paths", ()))
    listed = lga.git_bytes(root, "ls-tree", "-r", "--name-only", "-z", binding.base_revision).decode("utf-8").split("\0")
    files = sorted(PurePosixPath(p) for p in listed if p)

    targets: list[PurePosixPath] = [p for p in files if lga.within(p, allowed) and not lga.within(p, forbidden)]
    if not targets:
        raise lga.AdapterError("retrieval.no_targets", "no files in the pinned tree fall inside allowed_paths minus forbidden_paths")

    docs: list[tuple[PurePosixPath, bytes]] = []
    skipped = 0
    for p in files:
        if lga.within(p, allowed) or lga.within(p, forbidden) or any(g == p for g in GUARDED):
            continue
        blob = lga.read_blob(root, binding.base_revision, p)
        if len(blob) > max_bytes or _is_binary(blob):
            skipped += 1
            continue
        docs.append((p, blob))

    # Query: intent text + target paths + target contents (targets are what we seek analogues of).
    query_tokens: list[str] = tokenize(contract["title"]) + tokenize(contract["description"])
    target_records = []
    for t in targets:
        blob = lga.read_blob(root, binding.base_revision, t)
        query_tokens += tokenize(t.as_posix()) + tokenize(blob.decode("utf-8", errors="replace"))
        target_records.append((t, blob))
    query_digest = lga.sha256_digest(lga.canonical_json(sorted(set(query_tokens))))

    corpus_tokens = [tokenize(p.as_posix()) + tokenize(b.decode("utf-8", errors="replace")) for p, b in docs]
    ranked: list[tuple[float, PurePosixPath, bytes]] = []
    if docs:
        model = BM25().fit(corpus_tokens)
        for i, (p, b) in enumerate(docs):
            s = model.score(query_tokens, i)
            if s > 0.0:
                ranked.append((s, p, b))
    ranked.sort(key=lambda t: (-round(t[0], 9), t[1].as_posix()))

    # Funnel: deduplicate by exact content hash, then by near-duplicate token-set key.
    seen_content: set[str] = set()
    seen_dedup: set[str] = set()
    retrieval_id = lga.sha256_digest(lga.canonical_json({"scope": contract["scope_contract_hash"], "rev": binding.base_revision, "q": query_digest}))
    retrieved_at = _now()
    evidence: list[dict[str, Any]] = []

    def _record(p: PurePosixPath, blob: bytes, kind: str, funnel: dict[str, Any]) -> dict[str, Any]:
        text = blob.decode("utf-8", errors="replace")
        lines = text.count("\n") + (0 if text.endswith("\n") or not text else 1)
        rec = {
            "record_schema": "suite51.repository_retrieval_memory.exact_local_evidence/ExactLocalEvidenceRecord",
            "retrieval_id": retrieval_id,
            "repository_id": binding.repository_id,
            "worktree_id": binding.worktree_id,
            "canonical_path": p.as_posix(),
            "evidence_kind": kind,
            "exact_locator": f"{p.as_posix()}@{binding.base_revision}#L1-L{max(lines, 1)}",
            "byte_range": f"0-{len(blob)}",
            "source_snapshot_hash": binding.source_snapshot_hash,
            "content_hash": lga.sha256_digest(blob),
            "match_status": "exact_pinned",
            "funnel": funnel,
        }
        rec["evidence_id"] = lga.sha256_digest(lga.canonical_json({"r": retrieval_id, "p": rec["canonical_path"], "h": rec["content_hash"], "k": kind}))
        rec.update({"sophia_judgment": "relevant_to_declared_intent" if kind == "analogous_example" else "declared_target_source",
                    "charlotte_validation": "validated:pinned_revision_exact_bytes",
                    "landon_status": "retrieved",
                    "professor_explanation": None})
        rec["podium_receipt"] = _receipt(rec)
        rec["retrieved_at"] = retrieved_at
        _SEC.mark_untrusted(rec, text, "repository_content")  # SEC-01-T02: repository content is data — marked and scanned, never instruction
        rec["secret_spans"] = _SEC.scan_secrets(text)  # SEC-03-T02: counted, never copied
        return rec

    for t, blob in target_records:
        evidence.append(_record(t, blob, "target_source", {"rank": 0, "score": None, "dedup_key": lga.sha256_digest(lga.canonical_json(sorted(set(tokenize(blob.decode('utf-8', errors='replace'))))))}))

    rank = 0
    for score, p, blob in ranked:
        if _SEC.scan_secrets(blob.decode("utf-8", errors="replace")):
            continue  # SEC-03-T02: secret-bearing files are never admitted as analogous evidence
        chash = lga.sha256_digest(blob)
        dkey = lga.sha256_digest(lga.canonical_json(sorted(set(tokenize(blob.decode("utf-8", errors="replace"))))))
        if chash in seen_content or dkey in seen_dedup:
            continue
        seen_content.add(chash)
        seen_dedup.add(dkey)
        rank += 1
        evidence.append(_record(p, blob, "analogous_example", {"rank": rank, "score": round(score, 6), "dedup_key": dkey}))
        if rank >= top_k:
            break

    authority = {
        "record_schema": "suite51.repository_retrieval_memory.evidence_authority/EvidenceAuthorityRecord",
        "repository_id": binding.repository_id,
        "worktree_id": binding.worktree_id,
        "claim_scope": contract["scope_contract_hash"],
        "repository_evidence_id": retrieval_id,
        "repository_snapshot_hash": binding.source_snapshot_hash,
        "repository_evidence_hash": lga.sha256_digest(lga.canonical_json([e["content_hash"] for e in evidence])),
        "memory_evidence_id": None,
        "memory_evidence_hash": None,
        "relation_status": "repository_only",
        "authority_order": "repository_evidence_over_memory_over_model",
        "resolution_status": "resolved",
        "contradiction_note": None,
    }
    authority["authority_decision_id"] = lga.sha256_digest(lga.canonical_json({"r": retrieval_id, "claim": authority["claim_scope"]}))
    authority.update({"sophia_judgment": "repository_evidence_is_authoritative", "charlotte_validation": "validated:no_memory_or_model_claims_admitted",
                      "landon_status": "resolved", "professor_explanation": None})
    authority["podium_receipt"] = _receipt(authority)
    authority["resolved_at"] = retrieved_at

    return EvidenceBundle(
        adapter_id=ADAPTER_ID, adapter_version=ADAPTER_VERSION, retrieval_id=retrieval_id,
        repository_id=binding.repository_id, worktree_id=binding.worktree_id, base_revision=binding.base_revision,
        source_snapshot_hash=binding.source_snapshot_hash, scope_contract_hash=contract["scope_contract_hash"],
        query_tokens_digest=query_digest, corpus_size=len(docs), evidence=evidence, authority=authority,
    )


def build_plan(contract: Mapping[str, Any], bundle: EvidenceBundle) -> dict[str, Any]:
    """Derive a deterministic, advisory-only refactoring plan from the contract and evidence."""
    if bundle.scope_contract_hash != contract["scope_contract_hash"]:
        raise lga.AdapterError("plan.evidence_mismatch", "evidence bundle was retrieved for a different scope contract")
    targets = [e for e in bundle.evidence if e["evidence_kind"] == "target_source"]
    examples = [e for e in bundle.evidence if e["evidence_kind"] == "analogous_example"]
    if len(targets) > contract["max_changed_files"]:
        status, reason = "ABSTAIN", f"{len(targets)} target files exceed max_changed_files={contract['max_changed_files']}"
    elif len(examples) < MIN_EXAMPLES_FOR_SUFFICIENCY:
        status, reason = "ABSTAIN", "insufficient analogous evidence in the pinned repository"
    else:
        status, reason = "PLANNED", None
    operations = [
        {
            "sequence": i + 1,
            "operation": "bounded_rewrite_within_scope",
            "path": t["canonical_path"],
            "source_content_hash": t["content_hash"],
            "rationale": contract["title"],
            "guided_by_examples": [e["evidence_id"] for e in examples[:3]],
            "limits": {"max_changed_files": contract["max_changed_files"], "max_diff_lines": contract["max_diff_lines"]},
        }
        for i, t in enumerate(targets)
    ]
    body = {
        "plan_version": PLAN_VERSION,
        "authority": "advisory_only",
        "status": status,
        "abstain_reason": reason,
        "intent_id": contract["intent_id"],
        "scope_contract_hash": contract["scope_contract_hash"],
        "repository_id": bundle.repository_id,
        "worktree_id": bundle.worktree_id,
        "base_revision": bundle.base_revision,
        "source_snapshot_hash": bundle.source_snapshot_hash,
        "retrieval_id": bundle.retrieval_id,
        "evidence_refs": [{"evidence_id": e["evidence_id"], "path": e["canonical_path"], "content_hash": e["content_hash"], "kind": e["evidence_kind"]} for e in bundle.evidence],
        "operations": operations,
        "expected_size_band_ceiling": contract["size_band_ceiling"],
        "verification_required": ["patch_applicability", "build", "tests", "lint_static", "scope_diff", "size_limits", "cross_reference_integrity"],
        "rollback": {"checkpoint_revision": bundle.base_revision, "method": "discard_isolated_worktree_and_restore_checkpoint"},
        "uncertainty": {
            "evidence_sufficiency": "sufficient" if status == "PLANNED" else "insufficient",
            "target_count": len(targets),
            "example_count": len(examples),
            "top_example_score": examples[0]["funnel"]["score"] if examples else None,
        },
        "cannot": ["mint_permissions", "mint_approvals", "assert_verification", "expand_scope"],
    }
    body["plan_id"] = lga.sha256_digest(lga.canonical_json({"scope": body["scope_contract_hash"], "retrieval": body["retrieval_id"], "ops": body["operations"]}))
    body["plan_hash"] = lga.sha256_digest(lga.canonical_json(body))
    body["created_at"] = _now()
    # PAPER-CAP-02-T03: effect boundary — a plan may be proposed only over exact analogous evidence it actually cites.
    from . import guardrails as GR
    # PAPER-CAP-05-T03: every planned claim cites evidence; gaps are surfaced (abstention), never invented.
    GR.enforce("plan.propose", {"CAP-02": GR.facts_analogous_evidence(bundle, body), "CAP-05": GR.facts_knowledge_gaps(body)}, rule_ids=["CAP-02", "CAP-05"])
    return body


__all__ = ["ADAPTER_ID", "ADAPTER_VERSION", "PLAN_VERSION", "BM25", "EvidenceBundle", "build_plan", "retrieve_examples", "tokenize"]
