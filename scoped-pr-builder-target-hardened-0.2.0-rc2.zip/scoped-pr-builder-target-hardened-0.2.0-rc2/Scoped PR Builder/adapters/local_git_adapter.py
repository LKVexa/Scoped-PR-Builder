"""Scoped PR Builder — reference local-Git adapter (overlay composition, unnumbered).

This module is the *executable* counterpart of ``scoped_pr_builder_adapters.jasp``
(service ``ScopedPrBuilderLocalGitAdapter``). It is deliberately small, standard-library
only, and read-mostly: it binds a repository/worktree/revision, computes a
content-addressed snapshot identity, manages *isolated* detached worktrees, lists
changed paths, and enforces repository-relative path confinement. It never applies
patches, never commits, and never touches the network.

Authority model (mirrors the overlay policy ``scoped_pr_builder_policy.jasec``):
  * repository context / freshness / worktrees remain authoritative in Suite 40;
  * confinement rules remain authoritative in Suite 50.6;
  * this adapter only *executes* those rules locally and fails closed on any
    missing, malformed, out-of-root, or unresolvable input (``AdapterError``).

Donor provenance (see ``../THIRD-PARTY-NOTICES.md`` and ``../PROVENANCE.jsonl``):
  The git/worktree/path-confinement primitives (``git``, ``git_bytes``,
  ``relative_path``, ``within``, ``validated_roots``, ``tree_identity``,
  ``worktree_add``, ``worktree_remove``, ``changed_paths``, ``require_within_scope``,
  ``atomic_write_bytes``, ``path_exists_at``) and the ``canonical_json`` /
  ``sha256_digest`` helpers were ADAPTED from the MIT-licensed
  AutoSaddler repository (src/autosaddler/v2/harness/git.py and
  src/autosaddler/v2/core/domain.py). Adaptation: dropped the AutoSaddler
  candidate/mutation model and provider-asset filtering; renamed to target
  conventions; added fail-closed ``AdapterError`` semantics, canonical-root
  verification, and the Suite-40-shaped ``RepositoryBinding`` record.
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import tempfile
from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

ADAPTER_ID = "scoped_pr_builder.local_git_adapter"
ADAPTER_VERSION = "0.1.0"
SCHEMA_VERSION = "scoped_pr_builder.contract/0.1.0"


class AdapterError(RuntimeError):
    """Fail-closed adapter failure. ``code`` is a stable, machine-readable reason."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code


# --------------------------------------------------------------------------- #
# Canonical serialization and digests (adapted from AutoSaddler domain.py)     #
# --------------------------------------------------------------------------- #
def canonical_json(value: Any) -> str:
    """Deterministic JSON: sorted keys, compact separators, ASCII only."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def sha256_digest(value: bytes | str) -> str:
    payload = value.encode("utf-8") if isinstance(value, str) else value
    return f"sha256:{hashlib.sha256(payload).hexdigest()}"


# --------------------------------------------------------------------------- #
# Path confinement (adapted from AutoSaddler git.py)                           #
# --------------------------------------------------------------------------- #
def relative_path(value: str) -> PurePosixPath:
    """Return a repository-relative POSIX path or raise ``AdapterError``.

    Rejects empty values, absolute paths, ``..`` segments, backslashes, NUL bytes,
    and Windows drive prefixes so that no caller can escape the confined root.
    """
    if not isinstance(value, str) or not value:
        raise AdapterError("path.empty", "repository-relative path required")
    if "\x00" in value or "\\" in value:
        raise AdapterError("path.malformed", f"illegal characters in path: {value!r}")
    if len(value) >= 2 and value[1] == ":":
        raise AdapterError("path.absolute", f"drive-prefixed path rejected: {value!r}")
    if value.startswith("/"):
        raise AdapterError("path.absolute", f"absolute path rejected: {value!r}")
    segments = value.split("/")
    if any(seg in ("", ".", "..") for seg in segments):
        raise AdapterError("path.escape", f"path must be canonical and repository-relative without traversal: {value!r}")
    return PurePosixPath(value)


def within(path: PurePosixPath, roots: Sequence[PurePosixPath]) -> bool:
    return any(path == root or root in path.parents for root in roots)


def path_within(path: Path, root: Path, *, allow_equal: bool = True) -> bool:
    """Return whether ``path`` is contained by ``root`` using native path semantics.

    Both paths are resolved before comparison.  Unlike string-prefix checks this works
    with Windows separators/case rules and does not mistake sibling prefixes (for
    example ``repo-old`` for ``repo``).
    """
    child = Path(path).resolve()
    parent = Path(root).resolve()
    if child == parent:
        return allow_equal
    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False


def validated_roots(paths: Sequence[str | PurePosixPath], label: str, *, allow_empty: bool = False) -> tuple[PurePosixPath, ...]:
    roots = tuple(relative_path(str(p)) for p in paths)
    if not roots and not allow_empty:
        raise AdapterError("scope.empty", f"{label} paths cannot be empty")
    return roots


def require_within_scope(
    paths: Sequence[PurePosixPath],
    allowed: Sequence[PurePosixPath],
    forbidden: Sequence[PurePosixPath] = (),
) -> None:
    """Fail closed if any path is outside ``allowed`` or inside ``forbidden``."""
    protected = sorted(str(p) for p in paths if not within(p, allowed) or within(p, forbidden))
    if protected:
        raise AdapterError("scope.violation", f"paths outside the approved scope: {', '.join(protected)}")


# --------------------------------------------------------------------------- #
# Git primitives (adapted from AutoSaddler git.py)                             #
# --------------------------------------------------------------------------- #
def git(path: Path, *arguments: str) -> str:
    return git_bytes(path, *arguments).decode("utf-8", errors="replace").strip()


def git_bytes(path: Path, *arguments: str) -> bytes:
    try:
        completed = subprocess.run(
            ["git", *arguments],
            cwd=path,
            capture_output=True,
            check=True,
            env={**os.environ, "GIT_TERMINAL_PROMPT": "0", "LC_ALL": "C"},
        )
    except FileNotFoundError as exc:  # git binary absent
        raise AdapterError("git.unavailable", "git executable not found") from exc
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.decode("utf-8", errors="replace").strip() if exc.stderr else ""
        raise AdapterError("git.failed", f"git {' '.join(arguments)} failed: {stderr}") from exc
    return completed.stdout


def tree_identity(repo: Path, revision: str) -> str:
    """Content-addressed identity of the full tree at ``revision`` (sha256 of ls-tree -r -z)."""
    return sha256_digest(git_bytes(repo, "ls-tree", "-r", "--full-tree", "-z", revision))


def path_exists_at(repo: Path, revision: str, path: PurePosixPath) -> bool:
    listed = git_bytes(repo, "ls-tree", "-z", "--name-only", revision, "--", path.as_posix())
    return listed == path.as_posix().encode("utf-8") + b"\0"


def read_blob(repo: Path, revision: str, path: PurePosixPath) -> bytes:
    """Read a file's bytes at a pinned revision without touching the working tree."""
    if not path_exists_at(repo, revision, path):
        raise AdapterError("blob.missing", f"{path} does not exist at {revision}")
    return git_bytes(repo, "show", f"{revision}:{path.as_posix()}")


def worktree_add(repo: Path, destination: Path, revision: str) -> Path:
    """Create an *isolated*, detached worktree at ``destination`` pinned to ``revision``."""
    destination = destination.resolve()
    root = canonical_root(repo)
    if destination == root or root in destination.parents:
        raise AdapterError("worktree.nested", "isolated worktree may not live inside the source repository")
    if destination.exists():
        raise AdapterError("worktree.exists", f"destination already exists: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    git(repo, "worktree", "add", "--detach", str(destination), revision)
    return destination


def worktree_remove(repo: Path, path: Path) -> None:
    """Remove one *registered* linked worktree and refuse every other path.

    A rollback record is data, not authority to delete a directory.  The target must
    be outside the source repository and must appear in ``git worktree list`` for
    that repository.  If Git cannot remove it, fail closed rather than falling back
    to an unscoped recursive delete.
    """
    root = canonical_root(repo)
    target = Path(path).resolve()
    if path_within(target, root):
        raise AdapterError("worktree.remove_unsafe", "refusing to remove the source repository or a path inside it")

    linked: list[Path] = []
    for line in git(root, "worktree", "list", "--porcelain").splitlines():
        if line.startswith("worktree "):
            linked.append(Path(line[len("worktree "):]).resolve())
    if target not in linked or target == root:
        raise AdapterError("worktree.unregistered", f"refusing to remove a path that is not a registered linked worktree: {target}")

    completed = subprocess.run(
        ["git", "worktree", "remove", "--force", str(target)],
        cwd=root,
        text=True,
        capture_output=True,
        check=False,
        env={**os.environ, "GIT_TERMINAL_PROMPT": "0", "LC_ALL": "C"},
    )
    if completed.returncode != 0:
        raise AdapterError("worktree.remove_failed", completed.stderr.strip() or f"git worktree remove failed for {target}")
    subprocess.run(["git", "worktree", "prune"], cwd=root, capture_output=True, check=False, env={**os.environ, "GIT_TERMINAL_PROMPT": "0", "LC_ALL": "C"})
    if target.exists():
        raise AdapterError("worktree.remove_incomplete", f"git reported success but the linked worktree still exists: {target}")


def changed_paths(workspace: Path, parent_revision: str) -> tuple[PurePosixPath, ...]:
    """Tracked changes vs ``parent_revision`` plus untracked (non-ignored) files, sorted."""
    tracked = git(workspace, "diff", "--name-only", parent_revision, "--").splitlines()
    untracked = git(workspace, "ls-files", "--others", "--exclude-standard").splitlines()
    return tuple(sorted({relative_path(item) for item in (*tracked, *untracked) if item}, key=str))


def atomic_write_bytes(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as destination:
            destination.write(content)
            destination.flush()
            os.fsync(destination.fileno())
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


# --------------------------------------------------------------------------- #
# Repository binding (target-native; shaped after Suite 40.5 worktree record)  #
# --------------------------------------------------------------------------- #
def canonical_root(repo: Path) -> Path:
    """Resolve and verify that ``repo`` is exactly a git top-level directory."""
    repo = Path(repo).resolve()
    if not repo.is_dir():
        raise AdapterError("repository.missing", f"not a directory: {repo}")
    toplevel = Path(git(repo, "rev-parse", "--show-toplevel")).resolve()
    if toplevel != repo:
        raise AdapterError("repository.not_root", f"{repo} is not the repository root ({toplevel})")
    return toplevel


@dataclass(frozen=True)
class RepositoryBinding:
    """Pinned repository/worktree/revision identity (Suite 40.5-shaped)."""

    schema_version: str
    adapter_id: str
    adapter_version: str
    repository_id: str
    worktree_id: str
    root_path: str
    branch_or_snapshot: str
    base_revision: str
    current_revision: str
    source_snapshot_hash: str
    dirty_file_count: int
    isolation_status: str
    worktree_hash: str
    bound_at: str

    def to_json(self) -> str:
        return canonical_json(asdict(self))


def bind_repository(repo: Path, revision: str = "HEAD", *, require_clean: bool = False) -> RepositoryBinding:
    """Bind a local repository at an exact revision and return an immutable identity record.

    Fails closed when the path is not a repository root, the revision does not resolve
    to a commit, or (``require_clean``) the working tree carries uncommitted changes.
    """
    root = canonical_root(repo)
    try:
        full = git(root, "rev-parse", "--verify", "--quiet", f"{revision}^{{commit}}")
    except AdapterError as exc:
        raise AdapterError("revision.unresolved", f"revision {revision!r} does not resolve to a commit") from exc
    if not full or len(full) < 40:
        raise AdapterError("revision.unresolved", f"revision {revision!r} did not yield a commit id")
    head = git(root, "rev-parse", "HEAD")
    status = git(root, "status", "--porcelain", "--untracked-files=all")
    dirty = len([line for line in status.splitlines() if line.strip()])
    if require_clean and dirty:
        raise AdapterError("worktree.dirty", f"{dirty} uncommitted change(s) present; clean tree required")
    branch = git(root, "rev-parse", "--abbrev-ref", "HEAD")
    snapshot = tree_identity(root, full)
    common_dir = Path(git(root, "rev-parse", "--git-common-dir"))
    if not common_dir.is_absolute():
        common_dir = (root / common_dir).resolve()
    repository_id = sha256_digest(str(common_dir))
    worktree_id = sha256_digest(str(root))
    worktree_hash = sha256_digest(canonical_json({"root": str(root), "revision": full, "dirty": dirty, "snapshot": snapshot}))
    return RepositoryBinding(
        schema_version=SCHEMA_VERSION,
        adapter_id=ADAPTER_ID,
        adapter_version=ADAPTER_VERSION,
        repository_id=repository_id,
        worktree_id=worktree_id,
        root_path=str(root),
        branch_or_snapshot=branch if branch != "HEAD" else f"detached@{full}",
        base_revision=full,
        current_revision=head,
        source_snapshot_hash=snapshot,
        dirty_file_count=dirty,
        isolation_status="source_worktree" if common_dir == (root / ".git").resolve() else "linked_worktree",
        worktree_hash=worktree_hash,
        bound_at=datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
    )


def revalidate_binding(binding: RepositoryBinding) -> None:
    """Fail closed if the repository no longer matches the pinned binding (freshness gate)."""
    root = canonical_root(Path(binding.root_path))
    current = git(root, "rev-parse", "HEAD")
    if current != binding.current_revision:
        raise AdapterError("freshness.stale", f"HEAD moved from {binding.current_revision} to {current}")
    if tree_identity(root, binding.base_revision) != binding.source_snapshot_hash:
        raise AdapterError("freshness.snapshot_mismatch", "pinned tree identity no longer matches")


__all__ = [
    "ADAPTER_ID",
    "ADAPTER_VERSION",
    "SCHEMA_VERSION",
    "AdapterError",
    "RepositoryBinding",
    "atomic_write_bytes",
    "bind_repository",
    "canonical_json",
    "canonical_root",
    "changed_paths",
    "git",
    "git_bytes",
    "path_exists_at",
    "path_within",
    "read_blob",
    "relative_path",
    "require_within_scope",
    "revalidate_binding",
    "sha256_digest",
    "tree_identity",
    "validated_roots",
    "within",
    "worktree_add",
    "worktree_remove",
]
